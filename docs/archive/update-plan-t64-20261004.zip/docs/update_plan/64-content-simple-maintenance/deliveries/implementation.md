# T64 实施记录

2026-10-03，工作区D:/CODE/weixin/wxprogrom7.15。用户授权教师个人内容取消状态与审核/发布/归档流程，改直接维护、删除；已有大量工作区修改保留，不提交/推送。

状态：S0–S4已收尾，微信真实交互与最终视觉待验[MA-T64-001](../../../manual-acceptance.md#ma-t64-001)。以下区分实现、逻辑检查、编译与工具证据；未对真实数据库迁移、清理或补种。

## 实施结果

| 节点          | 结果                                                                                                                                                                                                                                          |
| ------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| S0 计划门禁   | 计划先于运行代码；格式、本地链接/空白、项目技能检查及self-test、diff检查exit 0                                                                                                                                                                |
| S1 后端与合同 | 本人病例直接保存/编辑/删除，完整保存后可教学选用，不再要求医学审核或发布。系统病例只读，他人写入拒绝；旧审核/发布/克隆写入409退役。新增病例与题库DELETE接口，合同经脚本生成                                                                   |
| S2 API/Demo   | public统一读写，bootstrap唯一装配。Demo同步权限、保存即用、删除与快照；个人题库副本/回执/所有权持久化，刷新不丢，幂等导入不恢复被删来源                                                                                                       |
| S3 页面与导航 | 内容两标签、搜索、病例创建与题库入口；列表/详情可查看、本人编辑/删除。删除一次确认，取消不写、失败保留、成功移除。去掉所有资源生命周期状态栏/徽标和审核/发布/归档/恢复入口。旧status地址/偏好忽略，返回保留关键词，旧审核页经角色保护回病例库 |
| S4 集成与文档 | 静态、边界、合同、定向与编译检查通过，唯一全量旧断言修复并定向通过；微信两次工具阻塞登记台账。产品/UI/安全/架构/数据库及计划索引已同步；T62逐文件校验归档，完整计划只保留T63/T64                                                              |

病例编辑沿用五步生成/编辑器，直接保存原记录，不为编辑自动克隆。新增知识目录选择，必须明确绑定1–3个知识点；加载失败或未选不保存，旧多绑定明确提示重新选择，不静默截断。API旧PUT省略绑定保留原值，显式列表更新，显式空列表兼容旧客户端；新UI必须有绑定。保存仍验证完整definition/rubric与目标适配，没有通过取消状态来放松内容校验。

题库保留从课堂最终测试审阅页保存授权单选题、查看和编辑个人副本；无新增手动创建或组卷。副本编辑/删除不改变原冻结测试，题库版本与client_request_id继续用于冲突检测、幂等及身份保护。

## 数据与运行边界

- 病例内部`published`仅表示可选用，`medical_review_status=not_required`，不伪造专家签署。历史审核记录保留；知识目录来源/专家审核、课堂最终测试教师审阅及学生AI学习路线不变。
- 删除为内部逻辑标记：病例`deleted`，题库沿用`archived`存储；活动列表、详情和新课堂选用不暴露删除记录。界面无已归档分类和恢复流程，不物理级联删除教学历史。
- 新增迁移`20261003_0037_case_attempt_snapshot.py`：独立训练新增nullable JSON快照，新attempt冻结最小病例/判分内容，旧attempt在病例首次编辑/删除前冻结。历史训练继续按原definition/rubric评分，既有课堂读自身opening快照，学生响应不暴露隐藏判分内容。迁移有非空快照时拒绝downgrade并保留数据/列/版本；SQL NULL及JSON null可安全视为空。
- API环境使用此代码前需在其受控流程执行0037迁移。本轮只在隔离fixture验证，不修改当前真实库、Demo业务存储或真实种子；没有提交/推送。

## 检查记录

2026-10-03；前端/脚本目录为仓库根，后端为`backend`。日志仅保存必要摘要，不含完整学生作答或隐藏病例。

| 命令/范围                                                                              | 退出码及结果                                                             | 证据                                                                                                                                                                                               |
| -------------------------------------------------------------------------------------- | ------------------------------------------------------------------------ | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `python scripts/check-project-skills.py`及`--self-test`，S0计划Prettier/链接/空白/diff | 0                                                                        | 门禁完成后才实施                                                                                                                                                                                   |
| `npm run contract:generate`                                                            | 0；OpenAPI与生成TypeScript同步，不手改合同                               | [生成日志](../../../../output/t64/contracts-generate.log)                                                                                                                                          |
| `npm run type-check`、`node scripts/frontend-boundaries.mjs`、`npm run contract:check` | 最终均0；边界216项                                                       | [类型](../../../../output/t64/acceptance-final-type-check.log)、[边界](../../../../output/t64/acceptance-final-boundaries.log)、[合同](../../../../output/t64/acceptance-final-contract-check.log) |
| `npx eslint`（41个T64前端文件，`--max-warnings=0`）、`npx prettier --check`同范围      | 均0；新增QA修复文件另行检查0                                             | [Lint](../../../../output/t64/acceptance-final-eslint.log)、[格式](../../../../output/t64/acceptance-final-prettier.log)                                                                           |
| `npx vitest run`（内容资源、导航/偏好、审核退役、课堂选用等8个文件）                   | 0，67项通过                                                              | [集成定向](../../../../output/t64/acceptance-retry-vitest.log)                                                                                                                                     |
| API/Demo/训练等11个文件；病例/题库页面3个文件                                          | 分别0，35项和36项通过；绑定兼容补测3文件13项，编辑器绑定上限补测16项通过 | 子节点定向结果；不相加宣称独立总数                                                                                                                                                                 |
| `npm run test -- --maxWorkers=4`                                                       | 1；113文件中112通过、1失败，620项中619通过、1失败                        | [一次全量](../../../../output/t64/acceptance-full-vitest.log)                                                                                                                                      |
| `npx vitest run src/features/qa/core-behavior.spec.ts`                                 | 0，8项通过；该文件Lint/格式均0                                           | [失败项修复复验](../../../../output/t64/acceptance-qa-core-behavior-vitest.log)                                                                                                                    |
| 后端10文件集中`python -m pytest -q --tb=short`（下方命令）                             | 0，37项通过；早期失败及修复保留于日志                                    | [后端记录](../../../../output/t64/backend-verification.log)                                                                                                                                        |
| `python -m pytest -q --tb=short tests/test_t64_snapshot_migration.py`                  | 最后0，2项通过；覆盖有快照拒绝降级且数据/结构/版本不变                   | 同上                                                                                                                                                                                               |
| `python -m ruff check .`、`python scripts/check_boundaries.py`                         | 均0，9模块；迁移保护补改的两文件Ruff另行0                                | 同上                                                                                                                                                                                               |
| 显式Demo watcher、`npm run build:mp-weixin`                                            | 开发编译完成，生产exit 0                                                 | [生产构建](../../../../output/t64/build-demo.log)                                                                                                                                                  |
| 原生WXSS开发/生产、内容组件原生WXML、doctor                                            | WXSS各69文件exit 0；WXML工具ok=true；doctor exit 0                       | [微信摘要](../../../../output/t64/wechat-validation.md)                                                                                                                                            |

后端集中回归命令：

```powershell
python -m pytest -q --tb=short tests/test_t05_content_application.py tests/test_t43_question_bank.py tests/test_t44_question_bank_sources.py tests/test_case_hardening.py tests/test_second_phase.py tests/test_t53_content_action_summary.py tests/test_t64_simple_content.py tests/test_t64_snapshot_migration.py tests/test_pbl_api.py tests/test_t63_content_learning_pruning.py
```

全量唯一失败是Demo退役发布操作对缺失资源也拒绝409，而旧测试仍预期null。修复测试以验证当前退役合同，API模拟404到null的兼容映射保留；没有为测试恢复已退役功能。只复验失败文件，未重复全量，不宣称第二次全量绿色。初次类型hook参数、Demo装配循环和旧课堂审批断言也已修复，最终检查通过；后端早期重复知识关联、JSON null兼容与合成fixture权限问题已修正，没有修改真实种子。

## 微信与归档

显式Demo watcher保持运行，开发目录固定`dist/dev/mp-weixin`；普通刷新与doctor通过，SDK3.17.2、URL安全校验开启。正式打开登录页后的教师按钮真实tap先返回rawPath错误，仅重开同项目窗口后第二次tap超时；按两次上限停止，不清存储、不绕过角色、不模拟业务操作。最终T64画面及资源真实操作未取得，原生编译不能替代SDK渲染；补验统一由MA-T64-001维护，T63教师旧状态补验已被替代，学生底部视觉仍留原编号。

T62归档包保留2份原文及MANIFEST，CRC、字节数与SHA-256核对通过；旧引用改到索引锚点，原MA-T60-001不变。[归档审计](../../../../output/t64/archive-t62.json)。历史T44–T61包不变，没有追认为验收通过。

回退须按本轮增量处理并保护工作区既有修改；不能只回前端而保留保存即用的新接口。存在快照时迁移自身拒绝降级，不能删除快照绕过保护。工程已收尾，人工待验MA-T64-001；未执行API真实库迁移、真实AI、生产和真机验收，不以Demo证明这些范围。
