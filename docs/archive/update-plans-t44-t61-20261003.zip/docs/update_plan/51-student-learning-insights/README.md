# T51 学生学情与当前学习流程同步

2026-09-30。先完成本计划门禁，再实施。保护已有工作，不提交或推送。

代码与逻辑验收已收尾，见[交付记录](deliveries/completion.md)。最终微信画面人工待验 MA-T51-001，计划收尾不代替该项验收。

## 现状与目标

当前流程是研讨、单目标学习路线、阅读、AI 病例、最终测试和结果页共享导学。学情首页仅加载研讨列表，dashboard 一直为空；旧 reports 接口已退役。新路线已持久化步骤、阅读心跳、完成诊断和最终成绩，混合试卷含逐题得分与简答模型判分。

本次为学生建立本人范围的实时学情只读投影，API 与 Demo 使用当前流程数据。保留首页所有区块、DOM 布局、CSS、图标与视觉风格；仅修改数据绑定、必要口径文案和记录跳转。旧报告详情不恢复，教师学情、底部独立病例学习、评分规则、试卷与结果页面不变。

## 数据口径

- 本周圆环与近四周趋势：北京时间自然周，以已完成最终结果的平均测试得分展示；真实零分与无样本 null 区分。待评分、失败或未提交不进入成绩。比较仅在本周和上周均有样本时给出分数差。兼容历史单选与新混合试卷，不把自主测试称作教师认证。
- 现有“知识掌握度”改为“测试得分”；没有掌握阈值，不新增合格判定。“掌握知识点”改为“已测知识点”，统计有完成结果的目标去重数量。其余位置、样式不变。
- 时间为全部本人路线阅读 heartbeat 的累计秒数，展示累计阅读时长；没有逐日账本，不宣称本周或全流程活跃时长。计划完成率为全部已生成路线中已有最终结果的占比，未生成成功的路线仍属未完成。
- AI 诊断次数：通过完成快照校验的研讨参与记录数，每次研讨只计一次；排除邀请、未完成诊断及私人续问。
- 薄弱点：有效完成诊断中的知识缺口与推理问题；同目标有后续已完成测试时，以最新测试证据更新知识缺口，满分移除该知识缺口，非满分保留为需要巩固并展示测试得分，不擅自判定不及格。即使此前未识别缺口，最新非满分结果也可形成知识巩固点。不同诊断的重复目标合并计数，无诊断但有测试证据的目标计一次。推理问题没有量化得分，保持 null。
- 总结引用最近已完成研讨的结构化诊断，辅以实际路线进度和测试结果；不新增模型调用，不捏造 AI 结论。建议行动指向真实未完成路线，其次最近结果或研讨。
- 最近对话记录保持原有横向卡片，每个参与研讨与其路线合并为一条，以当前学习阶段更新状态、时间和入口；邀请不显示。路线完成进入结果解析/导学，其他路线进入计划，尚无路线进入原研讨。

实机兼容补充：已有 Demo 存储的研讨标识与后续预置路线标识可能不一致，不重置旧数据。未能关联到可见研讨的本人路线单独作为学习记录展示，使用安全路线标题并直达计划/结果；已关联路线不重复。API 同样支持本人历史路线的独立投影，不能因缺少研讨卡片而丢弃路线行动入口，也不能由路线推造有效诊断次数。

## 模块与合同

新增学习模块学生只读接口 `GET /learning/student-insights?limit=20&offset=0`，身份只能来自 `require_student`。不接受外部 student_id，不读取其他学生记录，不返回学生答案、消息正文、隐藏病例、模型元数据或未发布答案。

PBL 自有仓储通过 public port 提供本人参与与校验后的完成诊断安全字段；Learning 自有仓储读取本人路线、步骤、阅读与完成结果。装配在 wiring/composition，不跨模块直接访问 ORM。不新增数据库表或迁移。

前端增加 Learning 所属 insights port/API adapter/Demo adapter，经 bootstrap 统一装配、public 入口供页面读取；API 失败绝不回退 Demo。每次 onShow 重新读取，身份变化/旧请求返回不覆盖新数据。分页与汇总独立，后续页不重新覆盖首页汇总。

合同字段采用现有首页所需形状，服务端 snake_case、前端 camelCase：page 含 summary.dashboard、可选 summary.nextAction、items、total、limit、offset。dashboard 含 dataBasis（learning_route_results/synthetic_demo）、periodStart/periodEnd、masteryScore/masteryDelta/masterySampleCount、studyMinutes、studyDurationBasis（recorded_reading）、planCompletionRate、testedKnowledgeCount、aiDiagnosticCount、statusLabel、trend（periodStart/periodEnd/score/sampleCount）、weaknesses（targetType/targetCode/label/occurrences/masteryPercentage）、aiSummary。记录含 id、session（id/topicLabel/caseTitle）、summaryText、updatedAt、action。action 含 kind（discussion/route/result）、sessionId、可选 routeId、label。契约生成脚本更新 OpenAPI，不手改生成物。

Demo 从现有持久化研讨与路线实时投影，不引入固定 dashboard、假增长百分比，不重置已经同步为五题的 Demo 数据。

## 实施顺序

1. 本文格式、链接、whitespace、项目技能检查通过后开始运行代码改动。
2. 实施 PBL public 安全读取、Learning 聚合与学生 API/响应 schema，补本人范围、自然周、零分/待评分、薄弱点后续证据、历史格式测试。
3. 实施前端 port/API/Demo 和最小首页绑定；保留 CSS 与页面结构，补实时变化、分页、过期响应和跳转检查。
4. 生成并检查合同。Luna 执行主代理指定的测试、类型、边界检查，主代理处理失败。检查与本次数据聚合风险匹配。
5. 按[微信验收](../../wechat.md)使用当前 Demo 流程查看学情非空指标、趋势、薄弱点、卡片跳转及返回刷新；截图与用户现有页面对照。共享工具和 watcher 串行操作。工具阻塞按[人工台账](../../manual-acceptance.md)登记，实际代码缺陷必须修复。
6. 更新必要权威数据说明、交付记录与[计划索引](../README.md)。记录命令、退出码及未验范围，不重复已完成阶段验收。

## 风险与回滚

累计阅读与自然周测试的时间范围不同，文案明确区分；旧目标仍可多目标，按实际结果和逐题归属投影，不能默认所有历史试卷都是五题。没有完成结果时显示无样本，不展示假掌握率。总结和薄弱点只能表达已有证据，不能当作新的模型诊断。

只读投影无需迁移；回滚仅撤销本次新增接口/装配/绑定并恢复本次改过的口径文案，不删除路线、答卷或用户已有工作。
