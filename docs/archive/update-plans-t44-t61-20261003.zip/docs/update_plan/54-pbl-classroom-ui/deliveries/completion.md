# T54 交付记录

2026-10-02。已收尾，人工待验 [MA-T54-001](../../../manual-acceptance.md#ma-t54-001)。未提交、推送或正式发布。

## 结果

- PBL 根页移除测试待处理分栏，仅保留课堂列表、创建和阶段看板。旧 diagnostics 链接进入独立测试待办列表，旧已保存队列筛选不再让主导航恢复队列。
- 首页测试待办通过二级列表进入同一最终测试；保存、反馈退改、重试生成和开放继续在最终测试详情，合法班级/课堂/类别及无栈返回保留。
- 固定诊断承载只读研讨分析，证据摘要、薄弱点、推理问题与历史反馈保留，不再显示退役审批待处理身份。测试详情仍保留核对试题所需的固定分析摘要；完整分析在固定诊断读取，成绩与作答解析在学情。
- 课堂标题、三项真实计数、四阶段轨迹和两项详情入口重排，延续蓝白/蓝青医学风格。返回课堂重新读取看板，显示最新事实。未知计数保留 —，不补造测试状态。
- API/Demo共用页面，无后端、数据库或生成契约变更。

## 门禁与验证

实施前计划格式、两处现有相对链接人工核对及 git diff --check 通过；python scripts/check-project-skills.py 和 --self-test 均退出码 0。保护已有暂存、未暂存及未跟踪工作，不整理其他阶段。

| 检查                                                       | 结果与证据                                                                                                                                                                                                                                |
| ---------------------------------------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| 定向 Vitest：导航、PBL范围/阶段、待办/队列、诊断及最终测试 | 初次12文件93项，90通过/3旧断言失败，exit 1；改为新身份与按钮定位后受影响2文件17项全部通过，exit 0。[初次](../../../../output/t54/vitest.log)、[复验](../../../../output/t54/vitest-retry.log)。额外旧根页直链迁移测试见最终范围复验日志。 |
| npm run type-check                                         | exit 0，[日志](../../../../output/t54/type-check.log)                                                                                                                                                                                     |
| 受影响 ESLint --max-warnings=0                             | exit 0，[日志](../../../../output/t54/eslint.log)；最终测试新增断言另复验                                                                                                                                                                 |
| node scripts/frontend-boundaries.mjs                       | exit 0，202实现文件，[日志](../../../../output/t54/frontend-boundaries.log)                                                                                                                                                               |
| npm run build:mp-weixin                                    | exit 0，exec session 14540，Build complete；第三方Zod注释告警无构建失败                                                                                                                                                                   |
| VITE_APP_MODE=demo npm run dev:mp-weixin                   | watcher session 85170，Build complete. Watching for changes；dist/dev/mp-weixin 已确认新页面、轨迹及只读标签，不改生成目录                                                                                                                |
| 原生 wcsc.exe -lc 四个受影响 WXSS                          | exit 0，[日志](../../../../output/t54/native-wxss.log)；仅证明语法，不证明SDK渲染                                                                                                                                                         |
| git diff --check 受影响文件                                | exit 0                                                                                                                                                                                                                                    |

定向范围：teacher.spec.ts、teacher-root-scope.spec.ts、teacher-pbl-alignment.behavior.spec.ts、teacher-pbl-diagnostic-detail.behavior.spec.ts、TeacherFinalTestReviewQueue.spec.ts、教师待办/独立队列/诊断详情/最终测试/课堂进度行为、page-navigation.spec.ts、navigation.spec.ts。命令全文及退出码在相应日志；本轮没有后端改动，不重跑数据库/AI/生产验收。

## 微信工具证据与限制

最终新增旧根页直链迁移断言通过，root范围6项退出码0：[最终范围复验](../../../../output/t54/vitest-root-final.log)。三份最后改动测试的 ESLint 退出码0：[最终Lint](../../../../output/t54/eslint-final.log)。合并复用未受改动影响的通过证据，本轮定向94项全部通过；未重复全量测试。

simulator_refresh exit 0、ok=true；doctor 首次exit 1，刷新后exit 0，SDK 3.17.2、URL校验开启。currentPage 与 .role-button.teacher 文本读取两次均 CLI exit 0 但业务 ok=false（rawPath 无法解构）。截图成功但画面为全局WXSS编译错误，不能用作PBL渲染通过证据。[工具记录](../../../../output/t54/wechat-runtime.json)、[阻塞截图](../../../../output/t54/wechat-blocked.jpg)。课堂组件及未修改登录页 compile_wxss 都业务 code=10041，console 未定位源码；停止重试。按项目规则登记人工待验后收尾。

回退只撤本轮文件差异和新增 test-queue 页面/路由，不重置工作树或数据。不改共享 TeacherPageFrame 的其他工作区样式，不改变测试题数、审核权限或评分。

用户追问后进一步核对进入方法：显式 open_project_window 返回 reuse/s0，simulator_open_page 登录页触发成功，但 pageStack=[]；路径、登录和版本均正常，全部71个生成WXSS的独立原生编译退出码0。内部编译失败根因尚未定位，不能把工具初始化不足直接当根因。见[进入方法核对](../../../../output/t54/entry-diagnosis.md)。

## 用户要求复查后的结果

本次先重跑定向12文件94项，全部通过，exit 0：[复查](../../../../output/t54/verification-20261002.log)。复查发现独立队列切换教师身份后仍保留原课堂与类别，已清除旧筛选并由身份代次重建组件；补充身份切换断言。受影响3文件12项全部通过，exit 0：[身份修复复验](../../../../output/t54/verification-identity-tests.log)。复用其余未受影响结果，当前定向覆盖95项；没有宣称重新全跑95项。类型检查、修复文件Lint及生产构建均exit 0，构建session 67047。

同版本内部wcc-electron桥独立编译71个样式也通过，随后仅关闭并重新打开指定项目窗口，保留本地数据。新会话成功进入登录页，真实点击教师按钮进入待办。通过simulator_open_page进入PBL（不计作主导航点击通过），运行时确认pages/teacher/pbl/index；[课堂看板](../../../../output/t54/pbl-list-reopened.jpg)显示当前保存课堂，三项计数1/0/0、学生处于形成综合、之前三节点完成，无测试待处理分栏，内容与底栏无遮挡。当前学生尚未生成诊断/测试，不应补造入口。

独立测试队列[代表图](../../../../output/t54/test-queue-reopened.jpg)显示待审1、退改0、生成失败0，布局可读。真实点击.queue-back返回教师待办成功；真实点击首页.todo-row进入独立队列（待审类别）成功。组件内主导航两次定位失败，审阅最终测试按钮定位失败，均业务ok=false/no such element；停止定位重试。固定诊断、最终测试详情与课堂详情点击/返回仍在MA-T54-001待验。此前WXSS错误随本次重开消失，恢复动作已验证，但内部根因未定位；不再记录为持续编译阻塞。
