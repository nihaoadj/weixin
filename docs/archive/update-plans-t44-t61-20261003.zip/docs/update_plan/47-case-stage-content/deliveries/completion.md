# T47 收尾记录

2026-09-28 10:07（Asia/Shanghai）。已完成计划内 AI 病例学习阶段开场与回看更新，未修改学习页底部的独立病例训练，未提交或推送。

## 结果

- `CaseRead.stages` 从冻结病例定义投影前三阶段公开 `goal_id/objective` 与首条引导提示，第四阶段使用服务端固定反思内容；现有当前阶段 `goals/next_prompt` 保留。内部 `completion_requirements` 不出现在学生响应中。无数据库迁移或病例重新生成。
- 页面沿用编号分点布局，按各阶段响应内容渲染目标与提问；切换、完成回看、草稿、发送及失败重试保持原有行为。API、Zod、生成类型和 Demo 同步；Demo 既有存储的缺失阶段字段由读取时补齐，保留对话。

## 检查与证据

| 检查                                                                                         | 结果                                                                            |
| -------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------- |
| 计划门禁：Prettier、`git diff --check`、项目技能自检、链接路径                               | 退出 0                                                                          |
| `npm run contract:generate`、`npm run contract:check`                                        | 退出 0；OpenAPI/TS生成物已同步                                                  |
| `python -m pytest tests/test_t44_learning_routes.py tests/test_t44_provider_contracts.py -q` | 退出 0，28 passed；后续响应类型调整的四阶段用例定向复测退出 0                   |
| 三个前端定向 Vitest 文件、`npm run type-check`、受影响文件 ESLint、`npm run build:mp-weixin` | 退出 0，44 passed；首次前端检查的两处旧夹具和 Demo 标签类型失败已修复后复测通过 |
| `python -m ruff check` 受影响文件、前后端边界脚本、`git diff --check`                        | 退出 0                                                                          |
| Demo watcher、微信工具 `open_project_window`、`simulator_refresh`、`npm run test:mp:doctor`  | 编译完成，命令退出 0；SDK 3.16.3、URL安全校验开启                               |

微信 Demo 用学生身份从预置计划 `...0004` 点击“继续病例学习”。在第二阶段读取到“解释小血管扩张如何产生局部红、热”等两条病例目标及对应提问；点回第一阶段读到两条不同目标，输入框只读。普通刷新后重新登录并从计划入口进入同一病例，第二阶段内容仍恢复。已审阅实际渲染图：[第二阶段](../../../../output/wechat/t47-current.jpg)、[第一阶段回看](../../../../output/wechat/t47-review.jpg)。截图中的对话为 Demo 合成数据，不含真实学生回答。

一次直接向 Windows CLI 传带 `&` 的双参数页面 URL 返回 1，随后使用正常计划入口完成相同重进验证；未改页面数据或清理存储。首次查找“开始病例学习”按钮时页面仍在已开始的聊天状态，定位超时；截图与当前阶段文字确认页面正常渲染，刷新后新页面的开始按钮可点击。

未执行真实 Coze 输出质量、医学专家审阅、真机、API生产环境和 PostgreSQL 验证；它们不能由本次 Demo 结果推定。回退只需撤销本次响应、页面和 Demo 增量，冻结病例及对话数据不需清理。
