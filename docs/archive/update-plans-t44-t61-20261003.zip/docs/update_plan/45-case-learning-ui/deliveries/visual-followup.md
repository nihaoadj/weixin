# T45 UI续验

日期：2026-09-27，Asia/Shanghai。继续原任务，保留首次检查和失败记录；未提交或推送，也未修改其他产品页面。

## 最终确认

2026-09-27 22:39，用户在本对话明确确认T45手动验收通过。此前剩余的左右滑动切换阶段、手机键盘打开时输入栏和安全区验收已由该反馈补齐；MA-T45-001已关闭，T45已完成。以下工具未证明项及阻塞记录保留为历史，不作为当前未完成项，也不改写为自动化通过。

## 最新实现

仅病例页自定义导航，按真实状态栏和微信胶囊边界计算标题区域。新增透明病例插画和介绍页底部浅蓝曲线；阶段连线移到按钮外，解决原生按钮裁剪。用户补充要求优先：阶段目标、AI回复、处理中/完成提示均无气泡容器，只有学生消息保留浅青圆角气泡；编号标记仍保留。AI标识改为纯青色三条交叉细线构成的六射线星号，无额外竖线或渐变。

插画保存于 `src/static/case-learning-clipboard.png`，使用内置 imagegen 提取参考图的透明3D病例插画；原始生成文件保留于 `C:/Users/adj/.codex/generated_images/01a0e30b-7dab-7a02-ab5c-c2e3f524ba67/exec-291153df-09cb-4c23-a44a-82505e3aea43.png`。已删除本次先前制作且不再使用的clipboard SVG。

## 实际微信证据

复用原Demo watcher及现有开发者工具，源码编译至 `dist/dev/mp-weixin`，通过受支持wechatide CLI普通刷新。iPhone 12/13 (Pro)，SDK 3.16.3，390px宽；自定义导航读取状态栏47px、导航44px。以下CLI命令退出码均为0，同时检查响应ok和实际状态；CLI退出0本身不代表业务通过。

- `automation_navigate --action navigateTo`进入预置计划003（单参数routeId），真实点击 `.action .primary`，先正常完成该测试计划资料步骤，再点击病例入口。未调用业务方法、setData或清理存储。
- `automation_element_action --action text`核对介绍标题“局部红肿”，点击 `button.start-button`进入第一阶段。实际介绍截图 `output/wechat/t45-intro-final.jpg`，实际开场截图 `output/wechat/t45-chat-plain-goals.jpg`，均已逐张审阅。
- 点击 `button.case-summary`展开事实，读取 `scroll-view.expanded-facts`获得三条公开事实，再点击收起。
- 点击 `button.stage-tab.locked`获得完成当前阶段后才能解锁提示；阶段仍为病理识别。
- 通过textarea输入合成测试回答并点击send，第一阶段完成后仍显示第一阶段反馈，第二阶段可查看。`scrollTo --x 0 --y 999`滚到底，截图 `output/wechat/t45-stage1-reply.jpg`已审阅：只有学生消息带气泡，AI回复及目标/完成提示连续排版，底栏可见。后续在第二阶段发送合成机制回答，同一病例会话保留两个阶段消息，第三阶段解锁。
- `view.goals-list`的background-color实际为transparent，学生消息为 `rgb(232, 247, 249)`。AI图标实际为新星号。初版截图 `t45-intro-first.jpg`、`t45-chat-first.jpg`及修改中间图 `t45-chat-final.jpg`只作为过程证据，最终以plain-goals和stage1-reply为准。

## 自动化未证明项目（历史）

触摸操作使用真实 `touchstart/touchmove/touchend`，向左一组后查询为第二阶段；后续向右一组仍读回current=1，不能宣称双向手势验收通过。带`:nth-child(3)`的选择器读回第一阶段，点击success也未改变swiper current，停止用该选择器推进。曾出现page node not found/no such element以及截图与当前节点状态失步；未把这些返回视为源码缺陷，也未反复截图试探缓存。

剩余双向手势、第三/四阶段真实路径、长历史回看、键盘/安全区见 [MA-T45-001](../../../manual-acceptance.md#ma-t45-001-病例学习参考图与阶段聊天)。当前页面成功渲染已消除首次“无任何成功UI截图”的证据缺口；真实AI、真机、医学审阅和实际开发库0035迁移仍未执行。原四阶段行为/合同/共享记忆检查复用；本次展示检查见[检查记录](checks.md)。

## 唯一标识续验与完成审计

2026-09-27 22:24。上一轮属于进展：修改权威源码、完成展示检查并取得新渲染/交互证据。本轮增加阶段按钮 `case-stage-N` 和聊天区域 `case-stage-chat-N` 的唯一标识及ARIA关联，不改变外观。普通刷新后通过真实计划入口进入，ID选择器读回目标阶段且实际改变swiper current，解决原序号选择器定位错误；单页ESLint、Prettier、小程序构建再次退出0，见checks.md。

- 点击 `#case-stage-3` 后，swiper current=2、标签为“证据判断，当前查看”；输入合成证据回答后第四阶段由锁定变为可查看。
- 点击 `#case-stage-4` 后读取开场为“我们现在进入第 4 个阶段：总结反思。”。不足回答仅收到继续引导，阶段保持反思；实际截图 `output/wechat/t45-reflection-stay.jpg`已审阅。
- 补充包含事实/机制/判断、推理不足和改进方法的长回答后完成病例。输入前textarea实测93px高、composer104.33px高，保持有界；滚到反思聊天底部后完成提示与返回按钮可见。实际截图 `output/wechat/t45-reflection-completed.jpg`已审阅。模拟器tap textarea未呈现手机键盘，不以此证明键盘遮挡通过。
- 完成后点击 `#case-stage-1`，swiper current=0，读回原第一阶段学生消息；完成阶段均可只读回看。各聊天区域的学生/AI消息对数分别为1/1、1/1、1/1、2/2，每阶段均有固定开场。
- 点击finish-button正常返回计划，当前行动为“学习路线已完成”。随后通过受支持 `automation_wx_api call navigateTo`及临时JSON参数重新进入同一caseId（不调用业务方法），介绍按钮变为“回顾病例学习”；真实点击后四阶段消息计数与退出前完全一致，无textarea且仍有完成状态。临时导航参数已删除，存储未清理。

| 用户要求                                                      | 当前证据                                                                                                                                                   | 审计结果                  |
| ------------------------------------------------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------- | ------------------------- |
| 先分析方案再实施，仅病例学习范围                              | T45方案门禁、源文件及范围记录；产品页面仅route-case和其导航配置                                                                                            | 已实施                    |
| 计划进入介绍、开始后聊天                                      | 正常计划入口、intro-final/chat-plain-goals实际图及真实start点击                                                                                            | 已验证                    |
| 第四阶段总结反思，达成后才推进                                | 固定阶段配置、Demo四阶段实际路径、反思stay/complete、后端四阶段测试                                                                                        | 已验证所测Demo与合同      |
| 每阶段固定目标开场、单阶段聊天、纵向回看                      | 四个实际区域固定开场/消息归属、scrollTo到底与实际长回复图                                                                                                  | 已验证                    |
| 顶部病例事实展开/收起                                         | case-summary真实点击、expanded-facts三条事实与收起                                                                                                         | 已验证                    |
| 整体一套记忆，只切换阶段消息                                  | 同一caseId退出/进入完整恢复、阶段消息计数、后端`test_four_stage_chat_preserves_history_and_returns_original_message_phases`逐阶段校验共享history与证据边界 | 已验证所测Demo与API合同   |
| 严格参考色彩、字阶、间距、组件、布局，按新图取消AI气泡/改星号 | 源码局部token/字号/留白/圆角，实际intro、plain-goals、reflection-stay、completed图逐张审阅；用户新图优先于旧目标卡片                                       | 已验证所测390px模拟器状态 |
| 左右滑动阶段                                                  | swiper源码与change行为测试；工具双向手势证据不完整；2026-09-27 22:39用户明确确认手动验收通过                                                               | 已验证（用户手动确认）    |
| 计划中的键盘/安全区验收                                       | 有界输入和底栏实际图；模拟器未显示手机键盘；2026-09-27 22:39用户明确确认手动验收通过                                                                       | 已验证（用户手动确认）    |

用户反馈前尚不能声明整个目标完成：首次全页WXML/运行时定位阻塞、随后触摸/选择器失步、剩余原生手势/键盘缺少可用操作证据；当时独立源码、检查及可执行UI流程已完成，并按微信验收的同类最多两次尝试规则停止重试。现已由用户手动确认补齐上述两项，目标要求均有对应代码、检查、实际渲染/交互或用户验收证据，无剩余任务范围内工作。

## 插画生成原始提示

输入为用户的 `C:/Users/adj/Desktop/病例学习.png`，transparent_background=true。

> Use case: background-extraction. Edit target: the supplied UI reference. Extract ONLY the blue-and-white 3D medical clipboard with magnifying glass, pale translucent cyan bubble cluster and two little white plus signs from the right side of the upper hero section. Preserve the reference object's exact composition, tilt, proportions, soft blue shadows, glossy light-blue glass, vibrant blue clip and handle, fine pale-blue document lines, white medical cross. Make this a clean isolated reusable app illustration on real transparent background, tightly framed with a small margin, approximately square portrait aspect ratio. Keep the soft blue bubble cluster behind the clipboard as part of the illustration. Do not include ANY UI text, phone frame, title, badge, card, navigation bar, background rectangle, new object or watermark. This is an asset extraction to match this exact reference, not a redesign. Preserve the original smooth 3D rendered material style; do not replace with flat vector art.
