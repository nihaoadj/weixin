# T57 固定区域与左右手势交付

2026-10-03，已收尾，人工待验：[MA-T57-001](../../../manual-acceptance.md#ma-t57-001)。工作区为`D:/CODE/weixin/wxprogrom7.15`，保留既有暂存/未暂存/未跟踪工作，无提交或推送；模式为Demo，无后台、合同、数据或seed更新。

用户要求71.4%不碰圆环边缘、PBL固定区域滚动、完成学生标题加青色竖标、手机左右切页；实施中追加默认八卡完整展示。完成率数字改26rpx、百分号20rpx，保留0/null/100%语义。PBL hero、筛选、统计、标题和底栏固定，只有学生卡及查看更多处于原生scroll-view，切范围重建滚动区；新建表单也保留独立滚动。默认8条不变，仍是两列四行；hero收紧到最小210rpx，行gap12rpx、进度上下margin6/8rpx，统计与模块间距相应压缩，姓名26rpx、进度22rpx和48rpx按钮保留。默认八卡按照实测学生区域高度均分四行，卡片内边距恢复16rpx、内部三行均匀分配空间；无法测量时沿用padding12rpx的紧凑可滚布局。目标是第四行按钮完整位于底栏上方、空间分布自然，最终渲染尚待补验。

共用页框监听原生touch事件，PBL/学情/内容按导航顺序切换；学情先切总览/知识与推理/学生，再从端点进入相邻主页面。仍使用既有根页导航和各页独立筛选偏好。单指位移至少60px、横向超过纵向1.5倍、800ms内才切换；纵向先移动后锁定滚动，多指/取消/长按不导航，左侧20px保留原生返回；统计日期/选班弹层和新建表单拦截手势。未增加动画或更改详情页。

实施前计划完成格式/链接/技能门禁；追加八卡要求先修订计划，再收紧布局。主代理实现与串行构建/微信检查，Luna只修改相关测试并执行选定检查。检查暴露Vue TouchList与数组类型不兼容，已将手势输入改ArrayLike，兼容小程序数组；模板属性顺序也已修正。

## 自动验证

所有日志位于[本轮检查目录](../../../../output/t57/checks)。下表记录首轮固定区域/手势检查，后续空间分布只复验新改动影响的课堂组件；除特别注明外退出码均为0。

| 检查              | 命令/结果                                                                                                                                        | 证据                                                                                                              |
| ----------------- | ------------------------------------------------------------------------------------------------------------------------------------------------ | ----------------------------------------------------------------------------------------------------------------- |
| 计划/技能门禁     | `npx prettier --write docs/update_plan/57-teacher-fixed-regions-gestures/README.md`、`python scripts/check-project-skills.py`，本地链接/空白检查 | 计划与技能自检通过                                                                                                |
| UI/导航/根页定向  | `npm exec -- vitest run --reporter=dot`，9个受影响spec，81项通过，完整文件参数在日志首行                                                         | [定向日志](../../../../output/t57/checks/targeted-ui-navigation.log)                                              |
| 全量前端          | `npm run test -- --reporter=dot --maxWorkers=4`，98个文件、529项通过，34.64s                                                                     | [全量日志](../../../../output/t57/checks/full-vitest-workers4.log)                                                |
| 类型              | `npm run type-check`                                                                                                                             | [类型日志](../../../../output/t57/checks/type-check.log)                                                          |
| Lint/格式         | `npm exec -- eslint --max-warnings=0`、`npm exec -- prettier --check`，6个运行文件及5个相关spec，完整参数在日志首行                              | [Lint](../../../../output/t57/checks/eslint-scoped.log)、[格式](../../../../output/t57/checks/prettier-check.log) |
| 前端边界          | `node scripts/frontend-boundaries.mjs`                                                                                                           | [边界日志](../../../../output/t57/checks/frontend-boundaries.log)                                                 |
| Demo生产构建      | 设置`VITE_APP_MODE=demo`后`npm run build:mp-weixin`                                                                                              | [最终构建](../../../../output/t57/checks/build-final.log)                                                         |
| 开发/生产原生WXSS | 设置实际`WECHATIDE_CLI_PATH`后`node scripts/wechat/check-wxss.mjs`，以及`--project dist/build/mp-weixin`，两份产物各72文件通过                   | [开发](../../../../output/t57/checks/wxss-eight.log)、[生产](../../../../output/t57/checks/wxss-build-final.log)  |
| WXML工具编译      | `wechatide -c Codex compile_wxml --project dist/dev/mp-weixin --file-path <path>`，PBL根页、课堂组件、页框及学情根页四份均ok=true/exit0          | [模板日志](../../../../output/t57/checks/wxml-final.log)                                                          |
| 微信环境          | 显式Demo watcher session22386输出Build complete，开发目录普通刷新；`npm run test:mp:doctor`通过，SDK3.17.2、urlCheck=true                        | [doctor](../../../../output/t57/checks/doctor.log)                                                                |

定向覆盖横向正反向/端点、纵向锁定、多指、短位移、长按、取消、左侧边缘，页签切换保留筛选和弹层拦截；默认8卡，10名样本点击更多展开到10卡，统计/标题在滚动区外；完成率71.4%、null及100%文本。DOM断言不证明原生滚动效果、字号空间或无遮挡。

## 空间分布跟进

用户随后提供实际PBL画面，八名及全部按钮已完整显示，但第四行到底栏留有大块空白。依该反馈修订计划后，用当前锁定的uni-app运行时检查了`$nextTick`等待setData的实现及`createSelectorQuery().in(component)`适配；仅课堂组件接入原生区域高度测量。默认8条时网格minHeight取区域实测高度减2px，存在查看更多时另留44px，四行1fr均分，卡片三行用space-between并恢复16rpx内边距。使用minHeight，不限制长姓名的内容高度；更多展开后撤掉minHeight，恢复自然滚动。课堂/创建状态/视口变化重测，测量序号拒绝迟到结果，卸载时移除resize回调；未测到有效高度沿用紧凑布局，不新增固定空白或裁切。

空间跟进已完成Demo[构建](../../../../output/t57/checks/build-balanced.log)、开发/生产各72文件原生WXSS编译（[开发](../../../../output/t57/checks/wxss-balanced.log)、[生产](../../../../output/t57/checks/wxss-build-balanced.log)），及课堂组件[WXML编译](../../../../output/t57/checks/wxml-balanced.log)，均exit0。定向课堂参考13项与既有课堂对齐/根页17项通过，共30项；[参考测试](../../../../output/t57/checks/balanced-pbl-reference.log)验证实测高度应用、更多按钮预留、展开恢复自然网格、无效高度、过期resize测量丢弃及卸载解绑，[原行为](../../../../output/t57/checks/balanced-pbl-behavior.log)未回归。手势/其他根页未再改，复用首轮检查；新测量行为补定向测试与类型/Lint/格式。用户截图证明紧凑八卡可见，不证明新均分布局已在微信渲染验收。

空间跟进的`npm run type-check`、受影响Vue/spec的`npm exec -- prettier --check`及`npm exec -- eslint --max-warnings=0`最终均exit0，见[类型](../../../../output/t57/checks/balanced-type-check.log)、[格式](../../../../output/t57/checks/balanced-prettier-check.log)、[Lint](../../../../output/t57/checks/balanced-eslint.log)。本地文档链接/尾随空白与`git diff --check`通过，未扩大测试范围或改全量超时。

首次全量默认并发98文件中仅Demo seed用例超时5000ms，记录[失败日志](../../../../output/t57/checks/full-vitest.log)。未改断言、超时或跳过用例；该用例[单独复跑](../../../../output/t57/checks/isolated-demo-seed.log)3.09s通过，降低worker并发后529项全量通过，支持资源压力解释。构建有既有zod纯注释提示，不影响退出码；测试仍有scroll-view/picker未注册的Vue提示，原生验收另行记录。

## 微信证据与未验

正常开发项目第一次currentPage查询失败：`getPageMetaByWebviewId(...)`为null，无法解构rawPath；关闭再打开同一开发项目并doctor后，第二次同类失败，业务返回ok=false，未单独保存进程退出码。已依[微信阻塞规则](../../../wechat.md#阻塞与人工交接)停止相同环境上的交互/截图重试。只读console仅命中inspectee的MPPage.getCurrent错误。WXSS及WXML检查通过；这不证明页面完成渲染。

最终八卡无遮挡、圆环小数实际空间、固定列表滚动与手机左右手势未取得当前可审阅证据，集中登记MA-T57-001并继续收尾。旧T55/T56截图只作历史，不作为当前视觉通过证据，不宣称达到量化90%相似度。正式发布前补齐台账中的当前视觉及手机交互；用户无需当场配合。

权威[UI文档](../../../ui.md)与[计划索引](../../README.md)同步。回退仅撤本次专用布局和手势接入，不撤此前学情参考UI、八人Demo或已保存的课堂/路线。无本轮待删除的无用途临时文件，检查日志保留作证据。
