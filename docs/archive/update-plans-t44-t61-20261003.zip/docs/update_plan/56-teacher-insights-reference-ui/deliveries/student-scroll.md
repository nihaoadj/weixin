# T56 学生记录固定区域滚动交付

2026-10-02。[跟进计划](student-scroll-plan.md)已先通过格式、本地链接、空白与项目技能自检，再修改运行源码。用户要求学生学习记录固定在一个区域，只在区域内滚动，并继续以[学生参考图](../../../../ui参考图/学情/02-学情-最终参考-03-学生.png)为准。

## 实现与影响

学情学生页启用页框的固定内容选项，顶部 hero、班级/课堂、三页签及底栏保持固定。学生卡片填充剩余视口空间，卡片标题位于列表原生 scroll-view 外；卡片下保留64rpx冰蓝留白。滚动区使用 enhanced 并隐藏滚动条。范围变化以筛选键重建列表滚动容器；加载更多、失败重试、空状态与原学生详情入口沿用现有实现。

学生行仅在该列表启用专用样式：80rpx头像、122rpx最小行高、内边距、28rpx分数徽标、两条等宽统计标签及箭头；长内容仍可在字段内换行。总览低分预览不使用这些新行样式；页框选项默认关闭，总览、知识与推理和其他页面继续使用既有外层滚动。未修改API/公开合同、后台、Demo数据、参考图或其他页面样式，未提交/推送。

## 自动检查

按AGENTS复用Luna xhigh子代理，主代理只负责源码修复与微信串行操作。

| 检查                               | 结果                          | 证据                                                                                                                         |
| ---------------------------------- | ----------------------------- | ---------------------------------------------------------------------------------------------------------------------------- |
| 7文件 Prettier、ESLint             | 各exit0                       | [格式](../../../../output/t56-scroll/final-checks/01.log)、[Lint](../../../../output/t56-scroll/final-checks/02.log)         |
| `npm run type-check`               | exit0                         | [类型](../../../../output/t56-scroll/final-checks/03.log)                                                                    |
| 学情展示、根页和页框三文件定向测试 | exit0，20项                   | [测试](../../../../output/t56-scroll/final-checks/04.log)                                                                    |
| 最终 enhanced 属性后格式/Lint      | 各exit0                       | [格式](../../../../output/t56-scroll/scrollbar-checks/01.log)、[Lint](../../../../output/t56-scroll/scrollbar-checks/02.log) |
| 最终 Demo 微信构建                 | exit0                         | [构建](../../../../output/t56-scroll/scrollbar-checks/03.log)                                                                |
| 最终构建目录原生 WXSS              | exit0，72文件                 | [样式](../../../../output/t56-scroll/scrollbar-checks/04.log)                                                                |
| 开发目录原生 WXSS                  | exit0，72文件                 | [样式](../../../../output/t56-scroll/native-dev-final.log)                                                                   |
| `test:mp:doctor`                   | exit0，SDK3.17.2、URL校验开启 | [运行时](../../../../output/t56-scroll/doctor-final.log)                                                                     |

首轮20项中1项失败，暴露学生分支漏接原`select-panel`事件；补回原事件绑定后20项全通过，保留[初次失败记录](../../../../output/t56-scroll/checks/04.log)。没有修改断言以回避失败。最终只增加原生 enhanced 属性，复用此前类型/20项通过证据；不重跑未受影响的全量测试。

## 微信真实操作与渲染

Demo watcher session22312，开发目录 `D:/CODE/weixin/wxprogrom7.15/dist/dev/mp-weixin`。源码稳定后核对WXML的`enhanced`/隐藏滚动条属性，再原生编译生成样式。微信普通编译和热更新曾将页面切回总览/登录，未把该状态中的“no such element”视为代码渲染通过；从实际登录页点击教师，工具redirectTo进入学情学生页。没有清理存储、改dist或用setData/业务方法代替操作。

常规手机视口430px，内部截图548×1184，最终拍摄约23:32–23:33。列表尺寸404×470.54 CSS像素，内容高度694 CSS像素；原生`automation_element_action --action scrollTo --selector .student-records-scroll --x 0 --y 5000`成功。滚动后吴同学等后续记录与最后一行完整可见，真实0/1、0%与暂无结果正常。

滚动前后hero位置均为(0,0)，卡片标题均为(12,187.3333)，证明移动发生在列表区域。两张最终截图逐张审阅：hero、筛选、页签、卡片标题和底部导航保持位置，白色圆角卡片及下方冰蓝留白保持完整，滚动条已隐藏，底部最后一条学生记录可阅读。工具的scrollTop property读取为空，不将其当作滚动数值证据；以实际滚动操作、元素位置和前后画面证明。

- [学生列表首屏](../../../../output/t56-scroll/students-first.jpg)
- [学生列表滚动到底](../../../../output/t56-scroll/students-bottom.jpg)
- [真实滚动](../../../../output/t56-scroll/scroll-action.log)、[区域尺寸](../../../../output/t56-scroll/scroll-size.log)、[内容高度](../../../../output/t56-scroll/scroll-height.log)
- [标题位置：之前](../../../../output/t56-scroll/heading-before.log)、[之后](../../../../output/t56-scroll/heading-after.log)

最终实际打开日期弹层并读取`2026-09-03 至 2026-10-02 · 北京时间`后关闭；实际点击知识与推理/总览/学生，读取三种正确hero标题。知识页学生滚动区查询为空；默认外层滚动恢复由页框/根页行为测试覆盖，未将组件内外层scroll-view实际拖动记为本轮通过。工具最终留在学生首屏。

本次要求的学生区域内滚动已自动验收通过，不再属于[MA-T56-001](../../../manual-acceptance.md#ma-t56-001)待验项目。原组件内查看全部、诊断展开、学生详情/结果返回、主导航、原生筛选提交及超过20条时实际追加交互仍按原台账维护；当前Demo记录不足20条，分页逻辑由定向测试覆盖。真机/API生产未执行。当前代码增量基线保留在 `output/t56-scroll/baseline/`，回退只撤销本次固定布局/专用行样式，不回退原学情优化或用户已有工作。
