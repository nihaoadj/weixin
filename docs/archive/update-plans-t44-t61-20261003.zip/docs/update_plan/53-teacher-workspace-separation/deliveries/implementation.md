# T53 实施记录

最终状态（2026-10-01）：S0–S6 已收尾，人工待验 MA-T53-001。下文接续记录中的中间态及失败保留，最终出口以[出口审计](exit-audit.md)和末尾最终复验为准。

2026-09-30 用户授权按更新文档逐步完整实施。S0 规划门禁证据见[规划交付](planning.md)，本记录不改写此前仅交付规划的事实。

## 起始范围与工作树

分支 `dev`，起始再次检查 `git status --short`，工作区含大量既有暂存/未暂存/新增/删除工作及 T52/T53 文档和证据。本次只修改 T53 所需范围，不重置、暂存、提交或推送。

## 当前节点

S1 已通过：准确测试状态与跨班待审摘要、授权单选来源解析、完成时间与混合题型学情投影、历史 AI 补卡只读边界。S2 独立根页与导航已接入，筛选与返回继续收尾；S3 资源分类和独立来源页开始接续；S4–S6 未开始。

节点完成后记录实际文件范围、命令/目录/时间/退出码、证据、未验项与出口，不预填通过结果。共享数据库、生成产物、watcher 和微信操作串行执行。

## S1 检查进展

- 2026-09-30 18:58:10–18:58:36（Asia/Shanghai），`backend`：`python -m pytest tests/test_t53_retired_cards.py tests/test_t53_teacher_queries.py tests/test_t53_teacher_insights.py tests/test_t44_question_bank_sources.py tests/test_t44_analytics.py -q`，退出码 0，22 passed。受管 SQLite fixture；21 条警告来自既有外键循环清理。证据：[测试日志](../../../../output/t53/S1-backend-tests-2.log)。覆盖真实 SQL 队列、来源授权、有效冻结修订、自主隐私、混合统计、不同时间窗口及退役写入。
- 同日 18:58:45–18:58:46，`backend`：上述五个测试及两个新 Analytics 文件、PBL public/repository 的 Ruff 检查退出码 0，证据：[检查日志](../../../../output/t53/S1-backend-lint-2.log)。之后扩大到本轮后端改动范围发现三个 import 排序问题，已修复；综合范围复验待完成。
- 同日 19:01:34，项目根目录：`npx vitest run src/features/content/infrastructure/t53-question-bank-source.spec.ts src/features/content/infrastructure/demoQuestionBank.spec.ts src/features/content/public.spec.ts`，退出码 0，3 文件、8 测试通过。首轮发现新增测试 HTTP mock 缺 session 导出，修复为 partial mock 后通过。覆盖来源最小映射、首次原样导入、冲突/幂等、副本隔离、历史 AI 卡只读和正式内容流程。
- `npm run contract:generate` 已执行，退出码 0；生成新增接口与稳定错误合同，不手改生成物。契约一致性检查仍待 S1 综合出口。

同日 S1 后续检查：

- 19:06:44，根目录，`npx vitest run src/features/pbl/infrastructure/demoPblRepository.spec.ts`，退出码 0，8 passed；包含有效课堂冻结诊断、修订不匹配、自主/私人内容排除与教师 scope。
- 19:09:55，根目录，`npx vitest run src/features/learning/infrastructure/t53-teacher-review-queue.spec.ts src/features/analytics/infrastructure/demoTeacherInsights.spec.ts src/features/analytics/infrastructure/apiTeacherInsights.spec.ts`，退出码 0，14 passed。`npm run type-check` 随后退出码 0；此前新增测试 duplicate spread 与 grading fixture 错误已修复。
- 19:14:43，再次定向复验 `t53-teacher-review-queue.spec.ts`，退出码 0，7 passed；此次仅因新增 Demo 来源课堂 ID 持久字段及投影而重验。新增 optional 字段保留旧存储，不使用中文显示标题或更新时间推断来源/发布时间。
- 根目录，S1 受影响前端文件（bootstrap、Analytics domain/public/adapter/schema/spec、Content 来源与退役改动、Learning 队列与投影、PBL Demo 投影、错误合同）执行 `npx eslint <上述范围> --max-warnings=0`，退出码 0；scoped Prettier 已整理。
- 契约与边界均退出码 0：[契约](../../../../output/t53/S1-contract-check.log)、[前端边界](../../../../output/t53/S1-frontend-boundaries.log)、[后端边界](../../../../output/t53/S1-backend-boundaries.log)。后端扩大范围 import 排序修复后，[S1 完整影响范围 Ruff](../../../../output/t53/S1-backend-scope-lint.log) 退出码 0。新前端投影接入后再次执行 `node scripts/frontend-boundaries.mjs`，退出码 0。

S1 出口：新查询、来源副本、混合统计与各窗口、授权/隐私和 API/Demo 合同已有定向证据；后续页面直接消费 public 查询，无需拉取完整详情拼列表。整轮未完成；S2–S6 页面、综合检查和微信交互/渲染仍未验收。

## S2 当前实现与过渡

已注册 PBL、学情、内容三个根页，新增共享 `TeacherPageFrame`、每页独立 scope 实例与按账号/工作区隔离的班级偏好。首页替换为摘要聚合页，不再挂载三个业务工作区；旧 tab/section 经 platform 导航解析到责任根页。主导航 reLaunch，详情保留原生返回与限定根页 fallback。

当前保留旧 PBL/学情/内容子组件以接续已有功能；S3–S5 将完成内部资源分型、课堂队列与新学情投影。PBL 暂时仍保留旧只读结果入口，首页资源摘要目前仅覆盖医学审核者；这是阶段过渡，S6 前必须收敛，不构成最终职责分离。

19:26:09，根目录 `npx vitest run src/platform/navigation/teacher.spec.ts`：退出码 0，7 passed。新增根页后 `npm run type-check` 退出码 0；`node scripts/frontend-boundaries.mjs` 退出码 0（211 implementation files）。曾发现组件直接使用 storage 违反既有边界，现改由 navigation preference port 处理，复验通过。

S2 尚未完成：首页和 scope 竞态/身份行为测试正在接续，详情旧地址与页面上下文仍需核对，小程序构建和微信导航/渲染未执行；不得据导航单元测试宣称实际工具验收通过。

S2 后续：35 项导航/首页/scope 测试首轮 34 通过，发现 reviewer 错误时缺少未知计数展示及测试 onLoad mock 类型过窄；已修复，未失败的四个文件保留通过证据，首页六项再次退出码 0，类型复验退出码 0。首页错误时计数显示 `—`，成功区块仍可操作。新页面生产构建退出码 0；开发 watcher 明确 Demo 编译成功。真实登录进入待办并审阅代表截图，组件主导航两次定位失败，已登记 [MA-T53-001](../../../manual-acceptance.md#ma-t53-001)。[工具记录](../../../../output/t53/S2-wechat-runtime.json) 分开记录工具信息、登录、导航阻塞与画面审阅，不宣称三个根页均有真实交互证据。

S3 可独立接续的资源分类和来源预览开始实施。共享导航已建立，但资源/课堂/学情具体筛选与返回需随各自新页面一起完成验证；S2 最终出口仍待这些上下文接续，S3 未通过前不登记资源迁移完成。未改变整轮范围或免除任何最终要求。

## S4 当前增量：课堂入口与真实测试队列

PBL 根页已退出 `TeacherPblWorkspace`/旧 Home 挂载，接续完整课堂列表、创建和关闭组件，以及新 `TeacherFinalTestReviewQueue`。待处理队列直接消费 Learning public 最小状态投影，分别展示待审、退改、生成失败及服务端动作权限；仅导航至既有最终测试详情，不新增审批写入。课堂选择仅接受医学审核通过且已发布的病例；课堂看板不再用旧 work-item 状态表达研讨进展，切换班级会使旧看板请求失效，创建/关闭防止重复点击。

2026-09-30（Asia/Shanghai），根目录：Luna 执行定向队列和 root scope 共 6 项测试，退出码 0；前端边界退出码 0，214 个实现文件。证据：[队列测试](../../../../output/t53/S4-queue-tests.log)、[边界](../../../../output/t53/S4-queue-boundaries.log)。首轮 Lint 发现根页遗留未使用 `loading`，已移除；根页、课堂组件及课堂行为测试定向 Lint 复验退出码 0。20:03:26，`npx vitest run src/components/teacher/teacher-pbl-alignment.behavior.spec.ts` 退出码 0，6 passed，覆盖单一知识目标、资源选择边界、课堂动作与范围切换迟到响应。

S4 尚未通过：同一测试退改和详情上下文、独立筛选持久化及完整阶段验收仍待接续。旧成绩入口暂时作为只读过渡，待 S5 新结果页接续后删除；不据本次队列检查宣称 PBL 已完成全部职责收敛。

后续增量：主导航增加受限 `reviewKind` 参数，待办三类测试分别导向对应队列；PBL 面板、课堂与队列类型偏好按账号保存，和独立班级偏好分开。20:08:00，导航、scope 和队列共 14 项测试退出码 0；此前首页 6 项测试退出码 0。类型与影响范围 Lint 复验退出码 0。

## S3 当前增量：独立导入接续

独立来源复制页已注册，最终测试页只保留已保存单选题的跳转入口，移除 Content 导入写入及内嵌编辑器。病例、讨论问题和题库列表的无栈返回已接到内容根页对应资源。20:09:39，病例编辑、问题编辑、题库三个行为测试文件退出码 0，19 passed。

Luna 定向导入/测试详情首轮 17 项中 14 项通过；类型和 Lint 退出码 0，证据：[首轮测试](../../../../output/t53/S3-import-tests.log)、[类型](../../../../output/t53/S3-import-types.log)、[Lint](../../../../output/t53/S3-import-lint.log)。修复确认动作测试缺少界面刷新等待后，发现取消再进入时请求 ID 未保持的实际缺陷；请求 ID 缓存从页面实例移至模块作用域，键按账号、来源 ID、摘要隔离，不存题目内容。20:12:17 再次导入页 6 项测试退出码 0；未失败的最终测试详情 11 项保留首轮通过证据。

S3 尚未通过：资源四类列表和医学审核返回上下文仍在接续，需综合复核、构建与对应微信最小流程；本次导入通过不替代全阶段验收。

S3 后续：病例/问题详情与编辑页面消费受限 `resource/keyword/status` 返回参数，资源所有者由页面固定，不接受任意返回地址。医学审核列表及详情保持审核权限，内容筛选贯穿列表/详情/返回，旧待办来源仍可回待办。Luna 执行资源列表与知识卡两个行为文件，9 passed，Lint 退出码 0：[资源测试](../../../../output/t53/S3-resources-tests.log)、[资源 Lint](../../../../output/t53/S3-resources-lint.log)。20:32:57，医学审核导航五项测试退出码 0。阶段综合出口仍未登记。

S4 后续：唯一最终测试页增加审阅反馈及同一测试退改动作，未保存题目需先保存，未确认退改用同一请求重试；开放/保存与未决退改互斥。API 保存退改反馈，Demo 同步保持题目与草稿摘要不变；不重建测试。测试详情返回 PBL 根页的合法来源范围，实际测试班级优先于外部链接班级。离页或身份变化失效旧请求，未决请求保留重试语义。受管后端 `test_t53_teacher_queries.py` 和 `test_t44_learning_routes.py` 共 19 passed；Demo routes 和最终测试行为共 28 passed；类型退出码 0。证据：[后端](../../../../output/t53/S4-review-backend.log)、[前端](../../../../output/t53/S4-review-frontend.log)、[类型](../../../../output/t53/S4-review-types.log)。随后详情返回补充测试，20:27:37 导航与最终测试共 22 passed；定向 Lint/Ruff 退出码 0。

## S5 接续准备与当前过渡

学情根页已退出旧 `TeacherInsightsWorkspace`，新只读工作区直接消费 overview/students/knowledge/diagnostics 四类最小投影。进度、完成成绩与冻结诊断分开说明时间口径；0 分与无样本分开，百分比按服务端 0–100 显示；知识与诊断部分失败互不抹去成功事实。班级、日期和面板独立保存，切换主导航不强行覆盖已保存面板。根页仍需课堂选择入口、筛选竞态行为与综合类型/构建核对。

完整混合结果和学生详情正在接续既有注册路径。当前学生详情入口仍处于迁移过渡；S5 出口前需实际替换并验证，随后才能删除 PBL 成绩入口。S2/S3/S4 的最终上下文和流程出口也仍待综合核对，整轮目标保持未完成。

S5 后续增量：增加只读课堂目录分页选择，保留显式深链接课堂过滤；目录失败不阻断统计查询。新只读工作区定向 4 passed，覆盖服务端百分比、不混淆 null/0、局部失败、迟到范围响应及仅摘要导航：[测试证据](../../../../output/t53/S5-read-workspace-tests.log)。混合结果 API mapper 不再将缺失简答得分或满分补为 0；20:41:43，`apiLearningRoutes.spec.ts` 共 16 passed，含缺值与真实 0，以及新队列缓存失效。影响范围 Lint 退出码 0；前端边界退出码 0，215 个实现文件。综合类型检查发现正在接续的学生详情错误导入，已交对应子任务修复；不将该次检查登记为通过。

固定诊断页已统一为测试审阅依据，读取与返回保留合法 PBL 来源范围，并保护切教师/失去角色后的迟到响应。首轮行为测试发现 stub 未呈现 description 和 queued mock 未重置，修复测试隔离后，20:37:18 七项行为测试退出码 0；影响范围 Lint 退出码 0。未据这些定向检查宣称 S4/S5 全流程完成。

## S6 接续：旧壳与旧进度入口

2026-10-01（Asia/Shanghai），已在生产引用复核后删除 14 个旧工作区组件/helper/contracts/routing 与 6 个专用测试；保留课堂组件、分页和仍被生产使用的展示 helper。混合覆盖的 `content-navigation.behavior.spec.ts` 保留真实问题详情的加载、失败重试及返回检查，移除已删除问题列表的旧视觉/交叉职责断言，并补固定内容所有者和合法筛选上下文。旧 `pbl-progress` 注册地址保留为类型化学情 progress 重定向，不再读取旧逐学生成绩；专用行为测试改为范围传递、非法参数清除和角色校验，导航边界同步维护。

根目录，20:35:36，`npm test -- src/pages/teacher/pbl-progress/pbl-progress.behavior.spec.ts src/platform/navigation/page-navigation.spec.ts src/components/teacher/content-navigation.behavior.spec.ts src/pages/teacher/insights/index.behavior.spec.ts`：退出码 0，18 passed。包含独立筛选、深链接、无效日期、切班清课堂、目录乱序与身份切换保护。此前导航源码检查发现知识卡已使用受限 `backFromTeacherDetail`，断言允许该共享 helper，不要求恢复旧工作台返回。此项不证明全部新页面的真实微信交互或渲染。

S4/S6 发现历史详情仍显示审阅动作的问题，已在 `03-api-data.md` 补充服务端 `current_scope_active` 投影合同。页面先接只读状态与隐藏审阅/重试动作，缺失权限字段不默认为可写；后台/domain/API/Demo 与生成契约仍在接续，因此整轮类型/集成检查尚不能登记通过。20:37:56，根目录 `npm test -- src/pages/teacher/learning/final-test.behavior.spec.ts`：退出码 0，16 passed，含历史范围失效的可读/禁写入口。首轮新增用例误从 textarea 的 textContent 检查值，修正为实际 value 后通过。当前仅是页面定向证据，仍需服务端与 Demo 范围事实验证。

S6 尚未通过：旧统计适配清理、普通教师资源可行动摘要、权限投影完整接续、全量测试/契约/边界/构建及最终文档和人工验收记录待完成。没有提交、推送或发布。

S6 后续：Luna 删除六个旧 Analytics 读方法及专用 domain/mapper/runtime DTO/Demo 适配与测试；public、ports、API/Demo repository、conformance 和 bootstrap 移除对应旧段，保留新 Insights 及 PBL 共用路线读取 helper。新 Insights API/Demo 定向 7 passed，影响范围 ESLint、`git diff --check` 退出码 0；类型检查仅报告尚在接续的 `currentScopeActive` 缺失，不登记为通过。后端历史接口、生成契约和历史数据均未据引用清理删除。

课堂创建快照保存原班级与目标，迟到返回不清空新班草稿、不打开旧课堂；关闭请求切班后不重新加载旧看板，组件卸载失效列表/看板请求。20:41:47，根目录 `npm test -- src/components/teacher/teacher-pbl-alignment.behavior.spec.ts` 退出码 0，9 passed，增加不在首个列表页的课堂深链接、关闭迟到和创建迟到三个场景。页面/导航接续影响范围 ESLint 退出码 0；仍需完整合同接续后综合验收。

## S6 后续：权限投影与本人资源摘要

本波子任务结束后，按用户 2026-10-01 的指令，运行代码及文档由主代理直接更新，后续子代理仅执行指定测试。历史测试的 `current_scope_active` 已接入服务端 TeacherTest 详情、列表、保存及退改响应，前端 required domain/runtime 校验、API mapper、Demo 每次读取重算；写接口继续独立验证活动班级和成员。课堂关闭不被当成范围失效。Luna 首轮后端用例发现新增测试把原队列用例尾部断言截入了新用例；主代理移回，并在新用例保持 inactive queue 为零。受管重试 20 passed、Ruff 退出码 0，首轮错误未改写：[pytest](../../../../output/t53/S6-scope-backend-tests.retry.log)、[Ruff](../../../../output/t53/S6-scope-backend-lint.retry.log)。API/Demo 定向 33 passed。

盘点确认现有资源列表带正文且不能直接当作本人待办。主代理先修订 `03-api-data.md`，新增 `/problems/teacher-action-summary`：仅本人病例草稿/退回/有效批准待发布、本人讨论问题草稿/退回、本人独立卡草稿/退回计数；审核者另看非本人待审病例和独立卡，普通教师对应值为 null。已批准病例校验当前审核摘要，匿名作者历史问题、已发布项、审核中的本人资源、退役卡与没有对应动作的题库状态不造待办。首页不再调用完整医学审核列表，仅消费摘要并导航，局部错误保留其他成功区块。

Demo 病例复用作者记录；通用问题补持久化作者映射，新创建卡绑定作者，读取/写入与审核排除本人规则对齐 API，历史卡原学生可见范围保留。普通教师摘要与医学审核摘要分开。Luna 验证前端 3 文件 12 passed、类型退出码 0：[测试](../../../../output/t53/S6-content-summary-frontend-tests.log)、[类型](../../../../output/t53/S6-content-summary-frontend-types.log)。新服务端测试首轮用了不存在的 ORM `User.openid`，主代理改为既有 `external_id` 后受管重试 1 passed：[后端测试](../../../../output/t53/S6-content-summary-backend-tests.retry.log)；影响范围 Ruff、ESLint 退出码 0。测试覆盖跨教师隔离、角色、摘要无正文、本人审核排除、退役卡及陈旧批准摘要。

`npm run contract:generate`、`npm run contract:check` 均退出码 0，生成物含 TeacherTest 权限字段与 Content 摘要，不手改生成文件；生成脚本使用隔离临时资源。新摘要增加 OpenAPI/runtime compile-time conformance。前后端边界退出码 0，前端 199 个实现文件；生成后主代理 `npm run type-check` 退出码 0。

题库列表和详情的合法关键词/生命周期范围随导航保留，无栈返回内容根页的个人题库；身份变化不携带上一用户筛选。21:01:20，根目录题库行为 10 passed。PBL 根页保留班级状态，归档班级可观察历史课堂但禁创建/关闭；创建班级标签与当前实际选择一致。21:06:28，根目录课堂行为 10 passed，root scope 4 项此前通过，定向 ESLint 退出码 0。已按源码同步 product、architecture、ui 和计划索引，未将整轮未完成验收写成通过。

整轮仍待：教师端组合检查、剩余无消费适配复核、全量前后端集成/静态检查、最终构建、交付要求证据映射及人工验收记录收尾。MA-T53-001 的微信工具定位阻塞继续保留，不重复无效点击；既有逻辑通过不替代新布局的真实交互与渲染。未提交、推送或发布。

教师区域组合验收：`npx vitest run src/components/teacher src/pages/teacher src/platform/navigation` 首轮 169 项中 167 passed，发现无消费者的旧 student-detail 路由别名导致重复注册断言，以及旧 Analytics 重定向测试仍期待混合工作台；类型检查发现班级状态 string 需要明确收敛为活动/归档。主代理删除旧别名、修正真实目标断言并显式验证状态联合后，Luna 原范围重试 27 文件、169 passed，类型退出码 0：[行为重试](../../../../output/t53/S6-teacher-integration-tests.retry.log)、[类型重试](../../../../output/t53/S6-teacher-integration-types.retry.log)。测试存在原生 picker stub 警告，无失败。此项为教师区域组合检查，未代替最终全量前后端验收或构建。主题/计划 scoped Prettier、`git diff --check` 均退出码 0，MA-T53-001 增补真实新增范围并标明旧待办截图不证明新资源区块。

## S6 接续：无消费者列表清理与学情导航

主代理复核生产引用后删除 Learning 的旧 `getTeacherFinalTests` / `getTeacherRouteResults` public、port、API/Demo adapter、列表 DTO 和 runtime schema；保留授权单份详情、PBL 课堂投影、新待处理队列及后端历史读取接口。测试初始化改用 test-only helper 组合保留的课堂投影与授权详情，不增加生产接口。首轮 4 文件 41 项中 40 passed、类型退出码 0；D02 新建课堂来源实际为 `demo-pbl-1`，旧初始化按数字 `1` 筛选导致未找到测试，已修正查询标识并等待原范围加学生详情重试。首轮证据见 `output/t53/S6-learning-cleanup-tests.log` 与 `S6-learning-cleanup-types.log`，失败不登记通过。

按 S5 要求补齐学生学情详情到 PBL 的导航：仅未开放且已生成的待审/退改测试，或未开放的生成异常显示入口；携带事实所属班级、课堂与队列类型，不在学情执行保存、开放或重试。身份变化后旧入口拒绝导航。学生知识区标题改为“知识表现摘要”，不宣称掌握程度。本次受影响 ESLint 退出码 0，行为与类型重试尚待结果。

完成审计仍发现两项需要继续核对/补齐：进度根面板目前只展示发布路线完成率与判分数量，学生详情具有路线步骤、阅读与测试状态，但未证明未完成研讨状态覆盖；内容病例/讨论问题列表动作尚未消费服务端逐资源权限，不能仅凭后端写入拒绝声称权限展示已完成。后端全量 pytest 正在原受管进程执行；未据局部通过宣称整轮完成。

接续复验：第一轮重试 D02 已通过，范围测试初始化另有同名调用误用新建课堂标识；主代理收敛为按班级读取既有预设活动/失效测试后，Luna 于 21:24:15 运行相同 5 文件检查，48/48 passed，`npm run type-check` 退出码 0：[行为第二次重试](../../../../output/t53/S6-learning-cleanup-tests.retry2.log)、[类型第二次重试](../../../../output/t53/S6-learning-cleanup-types.retry2.log)。包含未开放测试导航、生成异常、已开放/生成中无入口及身份切换禁旧导航。`git diff --check` 本次范围退出码 0。S6 审计发现的资源权限展示及未完成研讨投影补齐已在 `03-api-data.md` 明确目标与约束，尚未实施，不作为通过证据。后端全量测试原进程仍在运行。

## S6 接续：逐资源动作展示（前端与 Demo）

主代理新增 Problem 读取的 `allowedActions` / runtime `allowed_actions`（缺省为空，禁止由作者 ID 猜测权限），内容资源列表按投影显示编辑、提交医学审核、发布或退回。病例待审/已批准不显示非法编辑；其他作者/无权限投影保留只读详情。Demo 通用问题按内部 owner 映射，病例按作者、当前状态及批准摘要一致性计算，读取时实时投影；写入后问题响应重新授权读取，不以持久化动作作为权限事实。页面筛选或身份改变、卸载后，旧读取/确认框/写入结果与 finally 不覆盖新范围。

Luna 定向 4 文件 20/20 passed、格式化后资源组件重试 7/7 passed、类型退出码 0：[前端行为](../../../../output/t53/S6-content-permissions-frontend-tests.log)、[类型](../../../../output/t53/S6-content-permissions-frontend-types.log)。后加真实 Demo 本人/他人资源动作断言 2/2 passed：[Demo 权限投影](../../../../output/t53/S6-content-permissions-demo-tests.log)。影响范围 ESLint 首轮仅资源按钮属性顺序 warning，主代理修正后组件 ESLint 退出码 0；其余文件首轮无错误/警告。

API 的动作投影与生成契约尚未补齐，因此当前 API 模式缺少投影的资源操作暂不展示；这属于实施中间态，不能视为 S3/S6 出口。后端全量 pytest PID 9724 经两次只读快照确认存在，但 21:24:12 后日志长时间停在 62%，CPU 几乎不增长；正在用原 session 诊断中断获取等待栈，尚无通过/失败结果，不重复启动同一全量检查。后续需补服务端动作投影、未完成研讨进度与最终集成检查。

资源动作后端已接续：Content 应用按 Actor/owner 和状态计算允许动作，批准病例发布还验证已批准摘要一致性；Problem 列表、详情与通用写入响应携带枚举动作，学生返回空数组。`test_t53_content_action_summary.py` 补本人/他人、学生、审核中、有效/陈旧批准投影断言，21:38:09 受管定向测试 1 passed（3.77s）、退出码 0：[后端权限](../../../../output/t53/S6-content-permissions-backend-tests.log)。影响范围 Ruff 退出码 0。`npm run contract:generate` 与 `npm run contract:check` 退出码 0，生成物含 `allowed_actions`，未手改。API mapper 缺省无动作、未知动作拒绝与 Demo 权限 3/3 passed，生成后类型退出码 0：[API/Demo](../../../../output/t53/S6-content-permissions-api-tests.log)、[生成后类型](../../../../output/t53/S6-content-permissions-generated-types.log)。此前 API 中间态已接续，不再作为未实施项。

资源详情也改为按允许动作显示编辑；实际病例进入病例编辑器并归属内容 cases，问题归属 questions，身份变化及卸载后不接收旧请求或编辑导航。详情专项检查正在执行。原全量 pytest 诊断 Ctrl+C 后 session exit 1、原 Python PID 不存在，但没有输出等待栈，不能判定全量通过；保留原日志与中断诊断，后续集成检查须重新获得完整证据。整轮仍有未完成研讨进度投影、最终全量/边界/构建与交付出口，目标保持未完成。

资源详情专项验收 5/5 passed、类型退出码 0：[详情行为](../../../../output/t53/S6-content-permissions-detail-tests.log)、[详情类型](../../../../output/t53/S6-content-permissions-detail-types.log)。详情/导航测试及新增 mapper 测试 ESLint 退出码 0。本次仅补资源权限和详情归属，不将定向检查代替全量与微信真实布局取证。

## S6 接续：未完成研讨的只读进度

PBL public 增加 `PblTeacherDiscussionRecord` 与 `teacher_discussions` 读取，SQL 仅原教师、授权原班级、课堂来源、参与创建时间窗口，返回参与/课堂/学生标识、阶段、状态和开始/完成时间，不读取消息或私人续问。Analytics 既有学生查询增加 `discussion_progress`，详情增加 `discussions`；没有已发布路线的参与者以及已离班但原课堂有参与事实的学生也可按原范围只读查看，研讨批次不进入路线完成率分母。已有完整诊断继续单独依冻结修订匹配读取。

Luna 受管定向 `test_t53_teacher_insights.py` 与 `test_t53_teacher_queries.py` 共 8 passed、退出码 0，含进行中无路线、创建窗口与完成窗口区分、原课堂历史读取、另一教师拒绝、自主来源排除及响应字段白名单：[后端研讨进度](../../../../output/t53/S6-discussion-progress-backend-tests.log)。有 7 条既有 SQLite fixture teardown cyclic-FK 排序 warning，无失败或保留资源。Ruff 退出码 0。

API mapper/runtime 和学情进度、学生详情已接新字段，进度说明参与创建批次与路线发布批次分别统计；没有参与事实显示本区间无参与记录，缺少可显示投影时显示未提供，不补造零。详情使用中文阶段标签且只读。前端首轮 15 项中 14 passed，发现 active 显示条件误改，以及 FindingGroup 错加研讨字段导致类型失败；主代理定点修复后，相同三文件 15/15 passed、类型退出码 0：[行为重试](../../../../output/t53/S6-discussion-progress-frontend-tests.retry.log)、[类型重试](../../../../output/t53/S6-discussion-progress-frontend-types.retry.log)。定向 ESLint 退出码 0。`npm run contract:generate` 与 `npm run contract:check` 退出码 0，生成物同步，无手改。

Demo 尚未接同等研讨进度读取及可靠参与开始时间；现有 Demo 持久化参与记录没有独立创建时间，不能用私人续问更新时间冒充开始时间或静默清空历史。此项仍需接续并验证，当前未证明 API/Demo 完整一致。最终全量前后端、边界、生产构建、微信台账和逐项交付出口仍未完成。未提交、推送或发布。

## S6 接续：Demo 研讨事实与完整集成检查

2026-10-01，主代理接续 Demo 研讨读取：新参与首次创建即持久化开始时间，恢复时不修改；预设新数据具有明确合成时间，旧持久化记录缺失时间不重置或补造。仅原教师课堂的最小阶段事实进入学情，未完成且没有路线的学生可只读查看；历史缺失开始时间显示未提供，并保持参与计数未知。Demo 自主研讨及私人消息不进入该投影。四文件 26/26 passed、类型退出码 0，证据 `output/t53/S6-discussion-progress-demo-tests.log`、`S6-discussion-progress-demo-types.log`；影响范围 ESLint 退出码 0。

最终前后端边界检查退出码 0：`S6-final-frontend-boundaries.log`（199 实现文件）、`S6-final-backend-boundaries.log`（9 模块）。小程序生产构建退出码 0：`S6-final-build.log`，仅既有 Zod Rollup 注解提示。

全量前端首轮有两项失败（超时及其后身份状态污染），单个两次冷启动的队列测试采用已有 Demo 测试同等级 15 秒预算后，无限并发重试仍出现多文件冷导入超时，未把失败登记为通过。限定两个 worker 后完整执行原 92 文件、481 项，全部通过、退出码 0，时间 22:06:52–22:08:30 +08:00，证据 `S6-frontend-full-tests.retry2.log`；不修改断言或全局超时。

后端全量首轮中断退出码 1，保留原日志；重跑使用 `python -m pytest -vv -o faulthandler_timeout=60`，migration 一次等待栈后该测试通过并继续执行，尚需以终态记录整体结果。

生产引用复核又确认旧诊断/工作项列表 public 无消费者，主代理删除 `getTeacherPblDiagnostics`、`getTeacherPblWorkItems`、对应 repository port 和 API collection adapter。固定诊断详情保留，Demo 课堂看板与详情仍使用的内部计算保留；不删除后端历史接口或迁移。此项发生在上述全量前端通过之后，已交测试代理重新执行全量、类型、Lint、边界和构建；尚待结果。产品/架构及 MA-T53-001 同步研讨时间口径、历史未知时间及逐资源动作补验。整轮出口审计仍未完成，未提交、推送或发布。

后端全量重试于 22:14:25 +08:00 完成：345/345 passed、344 条 warning、退出码 0，耗时 816.39 秒，证据 `output/t53/S6-backend-full-tests.retry.log`。warning 包含既有 SQLite cyclic-FK teardown；此前 faulthandler 等待栈对应的 migration 用例随后通过，无失败，不将等待栈误记为终态失败。前端旧列表清理后的重新集成及逐项出口审计仍待完成。

旧 PBL 列表清理后的完整复验已通过：92 文件/481 项、类型、指定 ESLint、前端边界（199 文件）和小程序生产构建全部退出码 0，日志 `output/t53/S6-final-pbl-cleanup-{tests,types,lint,boundaries,build}.log`。随后主代理发现 Demo 总览人数仍把缺少开始时间的历史讨论计作区间样本，已改为只由明确开始时间的窗口内讨论贡献人数；历史详情和未知参与计数保持原语义。补充混合事实断言，本次修正正在定向/全量复验中，前述通过证据不覆盖随后修改。

## S6 出口审计接续：学情详情归属与知识卡竞态

缺日期 Demo 区间人数修正已复验：定向 5/5、全量 92 文件/481 项、类型、指定 ESLint、小程序生产构建全部退出码 0，证据 `output/t53/S6-final-undated-sample-{demo-tests,tests,types,lint,build}.log`。

主代理按 S5 第 5 项核对后发现学生/结果详情虽已只读归属学情，完整实现仍留在旧地址。现已将页面及对应行为测试移到 `pages/teacher/insights/student-detail` 和 `pages/teacher/insights/result`；正式导航使用新路径，旧地址仅教师角色门禁与标识/最小上下文校验后 goReplace，不再读取业务。导航层丢弃任意返回 URL，非法标识回学情根页；注册保留旧路径，显式 legacy 路由常量只作兼容，不恢复第二套详情。原有详情行为断言整体保留，新增旧链接替换及无业务读取核对。原生标题同步为固定诊断/课堂学情。迁移首轮 57 项中 56 passed，唯一失败为 ROUTES 与 pages.json 兼容路径不一致，已补两条显式旧路由常量；失败日志保留 `S6-final-insights-relocation-navigation-insights-tests.log`。

同轮核对发现知识卡页缺少账号变化与迟到响应保护。主代理补身份/生命周期 context，切换账号或角色后清空旧卡、审核队列与编辑草稿，刷新审核权限；迟到读取、写入、确认回调和 finally 不覆盖新账号，卸载使请求失效。独立卡创建、编辑、送审、审核和停用合同保持，历史 pbl_ai 仍只读。新增跨账号迟到读取、旧停用确认/卸载与角色失效三项行为测试。本轮修改已交测试代理运行定向及完整检查，尚待终态；文档同步新正式路径，MA-T53-001 补旧链接兼容验收。最终逐项出口审计尚未通过，未提交、推送或发布。

## 最终复验与阶段出口

学情迁移及知识卡身份保护的定向 64/64、全量 92 文件/487 项通过；指定范围 ESLint 退出码 0，前端边界 201 实现文件通过，构建退出码 0。类型检查首轮唯一 unknown 标识参数错误由主代理收敛为 string/number；随后导航 30 项、type-check、单文件 ESLint 和最终小程序生产构建全部退出码 0，证据 `output/t53/S6-final-relocation-guards-*` 及 `S6-final-relocation-guards-retry-*`。未用构建通过替代类型通过。

后端保持最后全量 345/345 passed；最后 `npm run contract:check`、`python backend/scripts/check_boundaries.py`（9 模块）、受影响五模块与 T53 tests Ruff 全部退出码 0，证据 `S6-final-contract-boundary-check.log`、`S6-final-backend-boundaries-confirm.log`、`S6-final-backend-ruff.log`。schema 生成物与服务端一致，未手改。

S2–S6 按源码/逻辑/合同/构建出口收尾，逐要求与场景核对见[出口审计](exit-audit.md)。新增页面真实微信导航、编辑、返回、布局与键盘检查仍因已登记组件定位阻塞保留 MA-T53-001，不宣称全量实机或真实 AI 验收通过。依微信规范登记后允许计划收尾；正式发布需补齐台账。未提交、推送或发布，既有工作树和历史数据保留；本次证据日志用于交付保留，无新增无用途临时脚本。

最终文档验收：scoped Prettier、`git diff --check`、T53 八份 Markdown 的 105 个相对链接及两个正式/两个兼容详情的注册与文件核对全部退出码 0，无缺失目标，证据 `output/t53/S6-final-document-checks.log`。仅有 Git CRLF 提示。该检查后仅补充本段验收事实及出口审计日志链接，未修改运行代码。
