# T53 出口审计

审计日期：2026-10-01（Asia/Shanghai）。工作树分支 `dev`、HEAD `5c961ea`，含 1427 条既有及本轮变更；不以 HEAD 代替工作树实现。代码由主代理完成，接续子代理仅执行测试。本表将逻辑、构建和微信实际交互分开；S0–S6 已收尾，人工待验 MA-T53-001。最后导航标识类型修正已复验，最终契约检查通过。

## 要求核对

| 计划要求                                     | 当前实现及源码核对                                                                                                                                        | 验证与结论                                                                                                                                    |
| -------------------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------- |
| README 1、S2：三个独立根页，无三业务同时挂载 | `pages.json` 注册 PBL/insights/content 根页；待办只读取 Learning 队列和 Content 摘要。`TeacherPageFrame` 主导航经 platform reLaunch，根页独立拥有请求状态 | root-scope、教师首页、insights/index、导航行为通过；真实切换待 MA-T53-001                                                                     |
| README 2、S3–S6：写入唯一归属                | PBL 创建/关闭及最终测试写入；Content 资源/审核/题库写入；Insights 只筛选与按需读取，未开放测试入口只导航 PBL                                              | 核对 Insights 所有按钮/public 调用无业务写入；final-test、import-question、question-bank、content-navigation 行为通过                         |
| README 3、S3/S4/S5：按各自任务组织           | PBL 课堂及测试队列，内容四资源及各自状态，学情四面板/学生/完整结果；PBL 无成绩列表，测试页无题库编辑器                                                    | 教师工作区与旧生产引用核对，资源/课堂/结果行为通过                                                                                            |
| README 4、S1/S4：状态与动作准确              | 队列只取当前活动范围的 ready/pending_review、needs_changes、未开放可重试异常；历史只读排除；详情服务端 current_scope_active                               | `test_t53_teacher_queries.py`、队列 API/Demo、final-test 行为通过；课堂关闭不等于归档或离班                                                   |
| README 5、S5：混合/旧格式、时间与隐私        | 结果展示单选、多选集合、简答正文/参考/评分；平均分按完成时间、路线进度按发布批次、诊断按匹配完成快照、参与按开始时间                                      | `test_t53_teacher_insights.py`、SQL 范围用例、API/Demo Insights、结果 13 项行为通过；无样本 null、真实 0 保留；历史 Demo 日期未知不算窗口样本 |
| README 6：不改变冻结/历史/医学授权/API 模式  | 来源复制独立修订，首次内容原样；Content 逐资源允许动作仅供展示，写入重复授权；历史 pbl_ai 写入拒绝、原学生范围保留                                        | 后端全量含 T43/T44/T48/T53 授权、冻结、幂等、修订及历史读取通过；bootstrap 模式装配、前后端边界通过；无新增迁移或清库                         |
| S2/S5/S6：旧地址薄适配，无断链               | 旧首页 key、analytics/index、list、pbl-progress 转责任根页；学生/结果正式页迁入 insights，旧详情 role guard + 验证最小标识后 goReplace                    | 导航注册、原生返回/无栈回所属根页、非法标识、旧详情无业务读取检查通过；最后类型收敛复验 30 项与类型检查均通过                                 |
| S6：清理、文档及验收交付                     | 删除无消费旧壳、Analytics 六列表、Learning 两列表及 PBL 两列表前端 surface；保留生产内部辅助、授权详情、后端历史接口/迁移。产品/架构/UI/计划/人工台账同步 | 生产引用搜索无被删入口消费者，边界检查 201 实现文件；静态/契约/构建通过；阶段逻辑出口已满足，微信按台账补验                                   |

## 场景核对

所有以下逻辑用例在全量前端或后端集合内；逻辑通过不代表真实微信点击与渲染通过。

| 04 场景                      | 已核对的证据及结果                                                                                         |
| ---------------------------- | ---------------------------------------------------------------------------------------------------------- |
| 同教师两个班级               | root-scope / insights/index 分离班级偏好，队列跨班范围、显式 session 深链接行为；身份按用户 key 隔离       |
| 生成中/失败/待审/退改/已开放 | T53 query 队列分类、Demo review queue、final-test retry/request-changes/release；已开放不进入待审          |
| 学习未完成、测试已开放       | T44 classroom release 与 Demo mainline；服务端学习完成和测试开放双门禁                                     |
| 未交/判分中/失败/0 分        | T48 mixed final test、Demo learning route、T53 Insights 与结果详情；无最终结果不造分，0 保留               |
| 新五题混合与旧三题           | T48、Teacher final-test 混合固定类型、结果混合/legacy 行为；冻结后只读                                     |
| 跨发布和完成区间             | T53 Insights 分离发布队列与成绩日期、合法 null 分母；Demo 同场景                                           |
| 无效快照修订/私人续问        | T53 SQL snapshot revision、冻结诊断 read port 范围；教师投影无消息或私人正文                               |
| 自主路线/另一教师班级        | T53 SQL/API scope、bank source autonomous rejection、Demo facts；列表/聚合/详情排除                        |
| 归档/关闭/离班               | T53 current_scope_active 与 T44 locator historical read；只读历史与当前禁写分离，完成路线可接续            |
| 副本取消/重复/源变化         | import-question 只读预览/取消/同 payload 重试/新摘要重新确认；T44 bank source 与题库 API/Demo 副本版本隔离 |
| 普通教师/医学审核者          | Content summary、allowed_actions、知识卡队列/送审/审核；本人不能审核自己，陈旧批准不能发布                 |
| 历史 pbl_ai                  | T53 retired-card 写入拒绝无 mutation/commit、队列排除、原可见范围保留；知识卡历史无按钮                    |
| 筛选/身份/请求乱序           | 根页、资源、课堂、队列、测试、Insights 和结果行为；知识卡新增旧响应/旧确认/卸载/角色失效覆盖               |
| 局部错误/空/长文/键盘        | 前端局部错误与重试、未知计数、草稿保留和缺字段用例通过；新布局长文/键盘/安全区实际渲染待 MA-T53-001        |

## 检查证据

- 后端 `python -m pytest -vv -o faulthandler_timeout=60`：345 passed，exit 0，816.39 秒；[完整日志](../../../../output/t53/S6-backend-full-tests.retry.log)。SQLite teardown 344 warnings；一次慢 migration faulthandler 栈后该用例通过，非失败资源。首轮停顿中断日志保留，不算通过。
- 最后新增页面迁移/知识卡保护后全量 `npm run test -- --maxWorkers=2`：92 文件、487 passed，exit 0；[完整日志](../../../../output/t53/S6-final-relocation-guards-full-tests.log)。使用两个 worker 控制冷导入并发，未删断言或扩大全局 timeout。
- 同轮定向 64 passed、ESLint 0、前端边界 201 文件/0、小程序生产构建 0；[定向](../../../../output/t53/S6-final-relocation-guards-targeted.log)、[Lint](../../../../output/t53/S6-final-relocation-guards-lint.log)、[边界](../../../../output/t53/S6-final-relocation-guards-boundaries.log)、[构建](../../../../output/t53/S6-final-relocation-guards-build.log)。类型检查首轮发现 unknown 标识参数，主代理增加 string/number 收敛后导航 30 项、类型、Lint、生产构建全部退出码 0：[导航复验](../../../../output/t53/S6-final-relocation-guards-retry-targeted.log)、[类型](../../../../output/t53/S6-final-relocation-guards-retry-types.log)、[Lint](../../../../output/t53/S6-final-relocation-guards-retry-lint.log)、[最终构建](../../../../output/t53/S6-final-relocation-guards-retry-build.log)。未因类型错误重复未受影响的 487 项全量。
- 所有 schema 经 contract:generate 生成，未手改。最终 `npm run contract:check`、后端边界（9 模块）与受影响 analytics/content/learning/pbl/classroom 及 T53 tests 的 Ruff 全部退出码 0：[契约](../../../../output/t53/S6-final-contract-boundary-check.log)、[后端边界](../../../../output/t53/S6-final-backend-boundaries-confirm.log)、[Ruff](../../../../output/t53/S6-final-backend-ruff.log)。此前定向与生成检查见[实施记录](implementation.md)。
- 文档 scoped Prettier、`git diff --check`、T53 八个 Markdown 文件的 105 个相对链接及四个正式/兼容 detail 路由核对全部退出码 0，无缺失目标；[文档检查](../../../../output/t53/S6-final-document-checks.log)。Git 的 CRLF 提示不属于尾随空白错误。

## 微信证据与发布边界

[MA-T53-001](../../../manual-acceptance.md#ma-t53-001) 已登记真实组件导航定位阻塞，两次失败后停止重试。S2 待办截图只证明当时页面，不证明新根页、资源权限、研讨阶段或新详情渲染。补验已列出主导航/筛选/角色、课堂测试审阅、原样复制和副本编辑、混合结果、旧链接迁移及长文/键盘安全区；不使用 setData 或业务调用替代点击。

按照[微信验收完成口径](../../../wechat.md#完成口径)，工具阻塞登记后允许计划收尾，但必须明确人工待验，不能写全部验收通过；正式发布仍需补齐台账。未提交、推送或正式发布。
