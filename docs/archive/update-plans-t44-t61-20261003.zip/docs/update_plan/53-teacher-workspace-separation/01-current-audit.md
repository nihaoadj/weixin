# T53 现状审计与页面取舍

核对日期：2026-09-30；分支 `dev`，HEAD `5c961ea`。工作区含大量既有暂存、未暂存和新增文件，因此 HEAD 不是完整实现基线；下列判断以当前工作树源码为准。T52 清理已经完成，不重新恢复其删除页面或旧写入。

本文是实施前的源码快照；其中旧组件路径在 S6 已删除或替换，不能作为当前入口。当前源码与检查结果见[实施记录](deliveries/implementation.md)。

## 已确认的职责交叉

| 当前事实与依据                                                                                                                                                                                                                         | 影响                                                             | 本轮处理                                                            |
| -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ---------------------------------------------------------------- | ------------------------------------------------------------------- |
| [教师首页](../../../src/pages/teacher/index/index.vue)持有多个工作区及共享 `selectedClassId`；导航合同（基线 `../../../src/components/teacher/teacherWorkspaceContracts.ts`，现已删除）以 `overview/reports/problems/pbl` 标识同页区域 | 切换学情与 PBL 会共享班级上下文，首页负责跨模块加载与导航        | 首页只保留待办；三个主条目各建独立根页和筛选状态；旧 key 仅兼容解析 |
| PBL 首页（基线 `../../../src/components/teacher/TeacherPblHome.vue`，现已删除）同时展示诊断与结果；计数（基线 `../../../src/components/teacher/pblHomePresentation.ts`，现已删除）以 `finalTestId && !resultId` 计算待处理             | 已开放未作答、判分中等也可能进入待审；PBL 承担成绩分析入口与列表 | 待审取实际状态；结果列表迁入学情，PBL 仅保留状态摘要和跳转          |
| [PBL 工作项](../../../backend/app/modules/pbl/application/use_cases.py)将已开放映射为 `task_published`，其他测试状态映射为 `pending`                                                                                                   | 退役任务语义掩盖生成与审核差异                                   | 新页面用独立状态事实；保留旧合同期间不让它驱动动作                  |
| [测试审阅页](../../../src/pages/teacher/learning/final-test.vue)内嵌题库副本编辑器并调用 content 导入                                                                                                                                  | PBL 详情同时承担教学审批和可复用资源维护                         | 保留复制入口，编辑/保存迁到内容下独立导入页                         |
| [教师结果页](../../../src/pages/teacher/learning/result.vue)主要按单选字段渲染；[结果 DTO](../../../src/features/learning/domain/finalTests.ts)已有多选、简答、评分要点字段                                                            | 混合测试不能完整查看，迁移页面本身不能解决问题                   | 由学情拥有结果详情；补齐按题型展示及旧格式兼容                      |
| [教师结果页](../../../src/pages/teacher/learning/result.vue)默认返回 PBL；[旧学生详情](../../../src/pages/teacher/analytics/student-detail.vue)仍在使用                                                                                | 从学情进入结果也可能返回错误工作区，旧命名不能证明无用           | 建立来源上下文；核对旧学生详情职责后迁移，不直接删除                |
| 内容列表（基线 `../../../src/components/TeacherProblemList.vue`，现已删除）混合病例、问题与知识卡，用统一状态页签；历史 `pbl_ai` 来源影响卡片归类                                                                                      | 来源被误当作待审核状态，各资源生命周期混在一起                   | 按类型导航，展示真实发布与医学审核双轴；历史 AI 来源保留为来源说明  |
| 教师学情（基线 `../../../src/components/teacher/TeacherClassroomReportAnalytics.vue`，现已删除）已用路线投影，但[知识点统计](../../../backend/app/modules/analytics/application/classroom_reports.py)只读取单选答案                    | 混合卷知识点统计缺项；知识薄弱点与推理问题尚未整合到教师学情     | 补 objective/short-answer 独立统计及有效完成诊断只读投影            |
| [教师统计服务](../../../backend/app/modules/analytics/application/classroom_reports.py)按所选时间内发布路线组成批次，再读取这些路线截至当前的完成结果                                                                                  | 不能将其解释为“所选时间内交卷成绩”                               | 保留并标明发布批次进度；新增完成时间成绩视图时单独定义筛选与分母    |

## 已存在的合同与缺口

- [题库导入仓储](../../../backend/app/modules/content/infrastructure/teacher_question_bank.py)要求首次导入内容、目标与维度保持来源原样；当前测试页的副本编辑形态容易违反此合同。新内容入口先只读预览并原样入库，再通过独立题库详情编辑，不改变首次导入规则。
- [learning 公开接口](../../../src/features/learning/public.ts)已有教师测试列表、结果列表、保存、要求修改、重试与开放能力。测试/结果列表要求班级，当前不提供跨班精准待审队列。
- [后端测试与结果查询](../../../backend/app/modules/learning/api/routes.py)校验教师与班级范围；[仓储](../../../backend/app/modules/learning/infrastructure/route_repository.py)按教师、课堂来源和班级筛选。列表不宜直接作为待办摘要，结果完整快照也不宜用于成绩汇总列表。
- [测试模型](../../../backend/app/modules/learning/infrastructure/route_models.py)区分生成、审核和 attempt 状态；已开放题目冻结。[应用层](../../../backend/app/modules/learning/application/learning_routes.py)校验可编辑版本与当前课堂范围。
- [有效完成证据查询](../../../backend/app/modules/pbl/infrastructure/repositories.py)已有完成快照与修订一致性判定；教师学情需要独立授权投影，不能复用学生本人接口或读取私人续问。
- [病例 DTO](../../../backend/app/modules/content/api/schemas.py)分别提供发布状态与医学审核状态；[医学审核 API](../../../backend/app/modules/content/api/medical_review.py)区分提交者与具有审核权限的审查者。
- [个人题库 API](../../../backend/app/modules/content/api/question_bank.py)已有导入、详情、编辑、归档；只接受去标识化 `route_test_question` 来源及摘要校验。目前来源读取只允许单选；题库是个人所有且有资源状态与修订审核状态。迁移编辑入口不能绕过现有审核或扩展为共享题库。

## 页面与组件取舍

本表是实施决定；本轮文档阶段不删除运行文件。具体删改列表在 S6 根据实际引用复核。

| 当前页面/组件                                                                | 决定                     | 接续与条件                                                                         |
| ---------------------------------------------------------------------------- | ------------------------ | ---------------------------------------------------------------------------------- |
| `pages/teacher/index/index.vue`                                              | 重构保留                 | 待办根页；删除内嵌三工作区、共享筛选和业务编辑                                     |
| `TeacherWorkspaceNav`                                                        | 保留重构                 | 统一主导航，切换独立根路由，使用新语义 key                                         |
| `TeacherPblWorkspace`、`TeacherInsightsWorkspace`、`TeacherContentWorkspace` | 按需拆分或删除壳层       | 单一职责组件可以复用；仅透传旧工作区状态的壳层不再保留                             |
| `TeacherPblHome`                                                             | 重构                     | 课堂操作与真实待审状态；删除结果列表及混合 `mode`                                  |
| `TeacherPblClassrooms`                                                       | 收敛复用                 | 课堂创建/关闭只由 PBL 挂载，避免并存隐藏列表与第二套关闭按钮                       |
| `pbl-diagnostic-detail`、`TeacherPblWorkItemDetail`                          | 保留收敛                 | 固定诊断只读，支持当前测试审阅；不恢复建议题处置                                   |
| `learning/final-test`                                                        | 保留业务，调整归属与内容 | PBL 下唯一测试审阅；去除题库内嵌编辑；保留混合与历史格式                           |
| `pbl-progress`                                                               | 迁移职责                 | 学情课堂进度详情；旧地址只做参数适配和重定向                                       |
| `learning/result`                                                            | 迁移并补齐               | 学情结果详情；旧地址重定向，旧行为测试随职责改写                                   |
| `analytics/student-detail`                                                   | 迁移复用                 | 学情学生详情；合并重复详情后才删除旧实现                                           |
| `TeacherClassroomReportAnalytics`                                            | 拆分复用                 | 学情各面板与独立读模型，消除 `mastery` 掌握度误称                                  |
| `TeacherProblemList`                                                         | 重构或拆分               | 内容类型入口与独立列表，去掉混合 pending 分类                                      |
| 病例/问题编辑、知识卡、医学审核页面                                          | 保留并统一内容归属       | 维持现有权限、审核与发布服务端约束                                                 |
| 个人题库列表/详情                                                            | 保留                     | 加独立来源导入页，不新增组卷、共享或全班发布                                       |
| `classes/classes.vue`                                                        | 保留支撑页               | 管教师班级，不作为第四个教学业务工作区；主入口在 PBL，学情可读取班级目录           |
| `list/list.vue`、`analytics/index.vue`                                       | 继续薄重定向             | 将旧入口定向到新学情页；不承载列表或聚合业务                                       |
| T52 已删除的三个页面、五个未挂载组件和旧适配                                 | 保持退役                 | 见[T52 交付](../52-teacher-retired-cleanup/deliveries/completion.md)，不在本轮重建 |

## 明确去除的功能形态

去除同页工作区共用筛选、PBL 的成绩分析列表、测试页的题库编辑、内容页以历史 AI 来源推断待审、基于旧任务状态决定新测试动作、重复课堂列表与编辑入口。旧地址需要兼容时只保留无业务状态的适配页。

历史结果、冻结诊断、已保存题库副本和正式内容数据保留。退役后端接口仅在确认无消费者、公开合同与兼容策略后处置；不顺带删除迁移、历史 schema 或回填脚本。
