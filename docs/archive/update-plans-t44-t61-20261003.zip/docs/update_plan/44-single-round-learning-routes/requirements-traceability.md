# T44 需求与实施追踪

状态：主要功能及仓库测试已完成，微信自主/课堂主线和教师投影已验证；空状态转[MA-T44-001](../../manual-acceptance.md#ma-t44-001-空学习计划入口)。工具/环境阻塞登记后允许计划收尾；全局前端覆盖率仅作质量报告，实际缺陷和必要测试失败仍须处理。证据见[实施记录](deliveries/implementation-progress.md)。学情同步留到下一任务，本次仅恢复原版页面并显示本人研讨记录。

| ID  | 用户需求/必要工程结果                          | 设计依据                                                             | 实施步骤       | 验收证据                   |
| --- | ---------------------------------------------- | -------------------------------------------------------------------- | -------------- | -------------------------- |
| R01 | 课堂及自主只进行一轮研讨后学习                 | [流程](02-product-workflows.md)                                      | P2/P3/P6       | B01/B11+退役审计           |
| R02 | 研讨完成AI自动生成并发布路线                   | [生成事务](04-domain-state-machines.md)                              | P2.3–P2.5      | B01–B04                    |
| R03 | 资料/病例依据真实弱点，未审核直接学习          | [AI来源](06-ai-sources-review.md)                                    | P2.2/P2.4      | B02/B04                    |
| R04 | 现有权威来源+AI导读，不伪造来源或审核          | [AI来源](06-ai-sources-review.md)                                    | P2.2           | B04+UI资料                 |
| R05 | 阅读前台计时、手动确认、不设最低时长           | [状态机](04-domain-state-machines.md)                                | P3.1           | B05                        |
| R06 | AI病例三阶段多轮合格后放行，不打分             | [病例流程](02-product-workflows.md)及[合同](06-ai-sources-review.md) | P3.2           | B06/B07+UI01/UI02          |
| R07 | 路线完成才能测试                               | [解锁](04-domain-state-machines.md)                                  | P3.3           | B08+UI03                   |
| R08 | 课堂最终测试教师审阅后开放；只审一份分析和题目 | [API](05-api-data-contracts.md)                                      | P4.1/P4.2/P5.6 | B09+UI02                   |
| R09 | 自主测试直接开放，全部私有不送教师             | [流程](02-product-workflows.md)                                      | P2.4/P3.5/P4.4 | B02/B12/B13                |
| R10 | 单选题，一次提交，正确率计分，无达标线         | [测试规则](02-product-workflows.md)                                  | P3.3–P3.5      | B10/B11                    |
| R11 | 只有最终测试计分，无补考或二轮任务             | [统计](04-domain-state-machines.md)                                  | P3.5/P4.4/P6   | B11/B13+退役审计           |
| R12 | 待完成任务显示真实计划并进入新页面             | [页面](03-pages-navigation.md)                                       | P5.1/P5.2/P5.5 | UI01/UI02+首页spec         |
| R13 | 清除旧研讨、二轮和关联结果/证据                | [清理](07-migration-cleanup.md)                                      | P1/P6          | DB03/DB05/DB08/DB09        |
| R14 | 保留账号/班级/知识库/独立病例/题库             | [保留证明](07-migration-cleanup.md)                                  | P1.2–P1.7      | DB04/DB06/DB07             |
| R15 | Demo可直接展示并完整体验新流程                 | [Demo](08-demo-scenarios.md)                                         | P5.7           | B16+UI01–UI06              |
| R16 | 步骤明确，只在少数重要节点标准验收             | [实施](09-implementation-steps.md)及[退出](10-verification-exit.md)  | P0–P7/G0–G3    | 节点记录、无改动不重复全量 |
| R17 | public边界、API/Demo隔离、生成物同步           | [接口](05-api-data-contracts.md)                                     | P4.5/P4.6/P6.5 | G2/G3边界/契约             |
| R18 | 幂等/并发/失败恢复/答案不泄漏/结果唯一         | [事务](04-domain-state-machines.md)                                  | P2/P3/P4       | B01/B07/B09/B10/B12        |
| R19 | 实际工具渲染与外部边界分别报告，不无限测试     | [验收](10-verification-exit.md)及[风险](11-risks-rollback.md)        | P7             | UI证据/失败项/停止记录     |

文档交付审计须确认R01–R19均有对应章节、实施步骤和验收项，不能只列需求标题。实施完成时将每项实际证据链接追加，不提前修改“待实施”状态。

## 当前仓库内实际证据

以下为已执行的定向范围；完整命令、失败修复和退出码见[实施记录](deliveries/implementation-progress.md)。当前收尾按第10章规则判定；下文历史缺口不自动形成重复验收任务。

| 需求        | 实际实现/验证位置                                                                                                                                                        | 当前边界                                    |
| ----------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------ | ------------------------------------------- |
| R01/R02/R18 | `backend/tests/test_t44_learning_routes.py`、`test_t44_concurrent_submit.py`、`test_t43_live_dialogue.py`：两入口完成冻结/唯一shell、回滚、claim恢复、迟到拒绝、唯一提交 | 后端完整复验通过；真实Coze未验              |
| R03/R04     | `backend/tests/test_t44_provider_contracts.py`及provider兼容检查：目标/来源、严格三任务合同、无fallback                                                                  | 合成transport已验证；真实Coze与医学质量未验 |
| R05/R06/R07 | `test_t44_learning_routes.py`与`src/pages/student/learning/routes.behavior.spec.ts`：阅读lease、零秒手动完成、三阶段、安全阻塞、病例原请求恢复、双条件                   | 后端/DOM通过；Demo阅读病例实操通过          |
| R08/R09     | `test_t44_learning_routes.py`：课堂原教师范围、失效课堂mutation拒绝、保存原响应、开放冻结、自主完全私有                                                                  | 教师保存/等待/开放及两条主线实操通过        |
| R10/R11     | `test_t44_concurrent_submit.py`、路线结果/事务用例：唯一结果与计分事件、66.7、零分、完整答案与固定解析                                                                   | 并发HTTP与事务定向通过；教师统计DOM已切v3   |
| R12         | 六学生页面及`routes.behavior.spec.ts`：计划入口/空列表/完成tab、等待教师、结果零分、身份切换                                                                             | 12项行为通过；学习卡及完成tab实操通过       |
| R13/R14     | `backend/tests/test_t44_data_migrations.py`、`test_t44_question_bank_sources.py`、`test_t43_question_bank.py`、历史迁移22项                                              | G1受管测试通过；实际开发库apply未执行       |
| R15         | `demoLearningRoutes.ts`及bootstrap装配、新页面                                                                                                                           | 两条主线及教师投影通过；空状态MA-T44-001    |
| R16/R19     | [实施记录](deliveries/implementation-progress.md)及G0交付：分节点有限检查；G3独立项登记                                                                                  | 后端门禁通过，前端/工具缺口单列             |
| R17         | 生成契约脚本、13个conformance编译合同；`apiLearningRoutes.spec.ts`8项真实schema解析/命令映射                                                                             | contract、类型、前后端边界检查通过          |
| R18         | 路线/提交/病例真实API负向与回滚，DOM迟到确认框跨身份提交修复                                                                                                             | 定向通过，不以mock代替服务端证明            |

G3秘密扫描退出1：3个既有历史指纹，本次工作区未检出新增；该门禁未通过。原计划阈值与发布门槛保持不变。

2026-09-27 最新证据：R05/R06/R07在Demo工具中实际走通阅读确认、病例三阶段与测试解锁，同一路线进度由`0/2`修为`1/2`再到`2/2`；R10的草稿退出恢复实际显示`1/3`，三题保存显示`3/3`，原生确认框后的提交/结果仍待验。R12学情原版视觉恢复并显示本人研讨记录，不把未同步的掌握度/趋势/薄弱点算作T44评价结果。前端G3首轮426项通过但覆盖率77.21%/62.72%/77.98%未达门槛，后端首轮14失败已分别定向修复；UI01–UI06未全部闭合。详细命令、截图与失败分类见[实施记录](deliveries/implementation-progress.md)。

R08在预置课堂D05上已实际证明完成路线`2/2`仍待教师开放；教师用可见入口登录后对同一测试修改解析、保存并退出恢复。原生确认框后的开放及学生返回仍待真实工具验收，不能用保存行为代替开放证明。

G3后端完整复验`npm run backend:check`退出0、309 passed、覆盖率88%。R10/R11预置D08课堂结果在教师和学生页面均显示66.7分、答对2/3题；实际新提交仍因原生确认框的工具交互限制待验，唯一计分与统计范围以后端B11/B13用例证明。

R11/B13补充`src/features/analytics/infrastructure/demoClassroomReports.spec.ts`4项公开Demo仓储合同检查：已提交结果与未完成路线分离、零分计完成、知识聚合/上海日期/分页、教师班级范围拒绝，定向测试与类型/格式/Lint通过。G3前端首轮覆盖率门槛仍未达到，补测不冒充新的全量结论。

## 可执行性复核的补充映射

| 原需求  | 本次补齐的实施约束                                                        | 定向证据    |
| ------- | ------------------------------------------------------------------------- | ----------- |
| R02/R18 | 同事务route/test shell，响应后生成调度、独立Session、claim与崩溃恢复      | B01/B03     |
| R06/R18 | 发布时预建case，消息revision/claim与同ID重放、安全修正                    | B06/B07     |
| R11/R17 | 现有账本source type/规则注册，结果与事件同事务，冻结目标                  | B13         |
| R12/R17 | 去study_paths后知识点入口仍能创建研讨；生成等待有限读取                   | B15/B16     |
| R13/R14 | FK闭包反向引用、独立plan/evaluation保留、cutoff防再次删除、启动不越过清理 | DB03–DB08   |
| R08/R18 | 草稿新增题ID和跨test校验，历史读取与release授权分层                       | B09/B12     |
| R19     | 仓库/Demo完成与真实Coze/API启用分别判定                                   | G3/外部记录 |

复核结论：核心业务和实施顺序已经明确，可作为一次完整更新的实施基线；是否运行完成仍以实际P/G交付为准。真实数据库目标和新Coze固定合同是执行阶段需核实的环境条件，不以本次文档检查代替。
