# 06 AI 合同、来源、审核与隐私

状态：T44 计划目标。schema v8 和以下 version=1 结构化任务尚未实现；本地 mock 不是真实 Coze 或医学质量证据。

## 1. 提供方与生成任务

沿用现有后端专用 provider/gateway 与显式 Coze Bot/Workflow。生产只允许 Coze；openai_compatible 仅开发/测试。不增加客户端模型 SDK，不外发身份/班级名单，不把旧通用聊天 adapter 当作生产 Coze 完成证据。

本期增加三种受管任务：`learning_route_generation`、`final_test_generation`、`route_case_turn`。通过明确 request schema/task kind 复用现有 transport，不擅自创建或修改远程 bot/workflow。真实环境需要支持任务路由与新固定合同；缺少时显式阻塞，不 fallback 到另一个提供方。

每个外部任务遵循已配置超时，一次尝试失败保存 error code；重试由原操作 identity/claim 保护。禁止自动无限重试。

## 2. PBL schema v8

保留：schema_version=8、interaction_style、learning_response、diagnostic_status、diagnosis_outcome、knowledge_gaps、reasoning_issues、phase_assessment、安全状态/提示。

移除新运行链的 recommended_questions、双轮 candidate_tasks 与自动 recommended_knowledge_cards。最终题目和路线改由独立生成任务创建，避免路线失败使原研讨无法完成。

完成规则继续要求 synthesis+complete、ready、合法学生证据与 educational 安全。identified_gaps 必须有真实关联证据；no_clear_gaps 不得带伪弱点；probing/insufficient_evidence/unavailable 不得附已确认任务。

新建 classroom 与 student_initiated 均使用 v8；旧研讨按清理方案删除，不保留 v6/v7 在线执行 fallback。历史 schema 定义只在必要迁移/历史事实中保留，不作为运行选择。

## 3. 路线生成输入

仅发送：固定完成分析的去标识化薄弱点/推理问题、主要目标、允许知识点集合、版本化公开学习材料、允许来源摘要及来源 ID。不得发姓名、openid、学号、班级名单、完整原对话、私人续问、隐藏病例事实或医学审核内部字段。

课堂 goals 取原课堂集合；自主取绑定目标或最多三个有证据目标。目标描述和 source lookup 由持久化 active catalog 读取，目录缺失/多个 active 继续显式失败，不能恢复静态节点或硬编码材料。

provider 输入包含 source kind 只用于教学语言；是否需要教师审阅最终题目仍由服务端决定。

## 4. 路线生成输出与校验

严格 version=1 JSON：title、goal_point_codes、learning_rationale、reading_steps、synthetic_case、安全状态。阅读 1–3 项，病例恰好 1 项。

reading_step：stable_key、目标点、linked_findings（目标巩固可空）、source_ids、ai_guide、分段解释、learning_points。至少一条有效来源，各主要目标有学习覆盖；正文不冒充原文。不接受模型 URL，来源 title/机构/版本/URL 从 allowed source ID 映射。

synthetic_case：stable_key、合成病例标题与公开情境、目标点、case facts、三个阶段目标、仅服务端保存的阶段完成要求和引导提示。阶段必须按 pathology_recognition/mechanism_explanation/evidence_judgment 排列，每阶段 1–3 个可解释学习要求，不含数字评分或剂量/处方指令。

校验范围：extra=forbid、长度/项数、稳定键唯一、目标/来源必须在允许集合、覆盖完整、引用发现有效、病理内容安全、三个阶段完整。无效输出整份路线不发布；不能只接受其中一段并显示路线已生成。

资料默认按目标固定顺序，AI 根据弱点选择每段讲解和资料，病例排在资料之后；不以客户端关键词规则代替 AI 学习路线。版本/digest 由服务端 canonical JSON 生成。

## 5. 最终测试生成

输入来自同一完成快照与已冻结路线目标/公开材料，不读取病例后续回答来临时追加题目。输出 version=1、questions、安全状态，每主要目标 3 题、最多 9 题。

每题包含 stable_key、primary_point_code、prompt、4 个不同选项、correct_option、explanation、linked_findings/source_ids；题干及解析分别限定 2000 字符，单选项 500 字符。索引严格 0–3，唯一参考答案由结构化字段表达；不接受多选、推理打分、病例评分题或双轮变式。

服务端检查题目非空/不重复、目标全覆盖、来源和发现关联有效，答案不在学生未提交 DTO 出现。模型负责提出题目/参考答案，正式计算正确数由服务端确定性执行；AI 不能直接提交 final_score。

课堂先保留 pending_review 草稿；自主由服务器直接 released 并明确未审核属性。教师可编辑题目，但发布后的版本锁定；教师审核不是医学专家签署。

## 6. 病例多轮合同

请求 version=1：当前 phase、phase_started_revision、current_revision、公开病例情境、本阶段目标、当前学生消息、有限同病例历史。历史最多 20 条，当前阶段合法证据标识单独列出。模型会话与原 PBL provider conversation 隔离。

响应 version=1：learning_response、phase_assessment `{phase,decision,goal_checks,evidence_message_ids,missing_elements}`、safety_status/notice。每个 goal_check 关联当前阶段目标 ID，值仅 satisfied/needs_more_evidence；不返回 score、grade 或 pass threshold。

检查全部 current-phase goal 已满足、至少一条 current-phase student evidence、证据引用真实且与当次 revision 一致，才允许相邻转换。前两阶段 decision=advance，最后阶段 complete；错误阶段、assistant evidence、旧回答、虚构目标和无证据判定均拒绝。

stay 返回具体缺失要点与下一问；模型正常提供解释不会自动完成阶段。安全分流阻止推进并提示教学支持。不根据轮数设通过标准，也不因为模型失败生成固定“合格”回应。

完成要求是教学过程资格，不是正式成绩。页面、证据账本、analytics 均不得把 goal_checks 映射成百分比或能力分。

## 7. 自动发布例外的边界

用户明确允许个人路线资料和病例未经教师审核直接学习，因此不走 content 医学审核/公共发布链。该例外仅覆盖 route 私有内容及自主最终测试，不能用于绕过公共病例、知识卡或其他正式资源原审核。

route 内容标“AI 生成的个性化学习内容，未经教师审核”；资料的公开来源支持状态照实呈现。课堂最终测试 release 后标“教师已审阅”，不得显示“专家医学审核通过”。没有专家签署的源目录保留 pending_expert_review 标签。

T40 新研讨不再生成独立补充卡草稿，避免学习路线之外新增第二套教师审核。教师手工维护独立内容与原医学审核仍保留。

## 8. 内容与隐私安全

- 全部 API 以服务端 actor、源 participation 和 owned class 判断；自主猜测 ID、列表、详情、进度、统计均不可见。
- 学生 test 提交前不返回答案/解析；病例不返回私有完成要求、原课堂 hidden facts、参考推理或 provider DTO。
- 教师只审固定分析和测试，路线病例完整交互只对本人可见；完成后的私人续问正文、数量、时间和结果不加入教师端。
- 日志只记录 task kind、内部资源摘要、schema、耗时、安全/失败码；不输出 token、prompt、完整回答、病例隐藏字段或 raw console/data。
- 对无效目标/来源与医学安全分流做负向测试；不能把“来源可追溯”当作“医学正确已确认”。

## 9. 合同实施与外部联调

先实现 strict schema、request builder、CheckedGateway 及 mock 正/负样例；同步 Bot/Workflow/parser/开发 adapter 和 fixtures。G2 验证元数据最小化、来源/证据校验、无 fallback 和失败恢复。

G3 只证明仓库合同和 Demo 状态。真实 Coze 固定版本协议、bot/workflow 配置及教学专家质量审查作为外部项记录，不为了本轮文档或 Demo 请求真实凭据、不自动修改外部平台。新流程允许未审核内容学习不等于生产医学质量已验证。

## 10. 统一任务信封与 API 模式交付边界

三种新任务的本地 gateway 统一输入 `{task_kind,schema_version:1,request_id,input}`，输出 `{task_kind,schema_version:1,request_id,result}`。PBL 对话自身 schema_version=8 单独保留，不与这三个 version=1 混用。adapter 将信封显式映射到现有 Bot/Workflow 受管 transport；parser 首先验证 task_kind/request_id/version，再按本章对应结果 schema 校验，不能把 route/test JSON 当作 PBL diagnostic 解析。

任务路由、响应样例和超时配置必须列为实施交付项；本地 mock 正/负样例分别覆盖三种任务。实际 Coze 没有新合同支持时，API 模式返回受控 provider-contract failure 并保留 shell/已发布组件，不表示新流程 API 已联调完成。代码与 Demo 可以完成仓库内更新；启用真实 API 新流程前，必须获得支持该信封/等价已验证映射的固定 Coze 配置和每种任务一次成功/失败的脱敏证据。该项不由历史 PBL Bot、Demo 或本文档替代，也不新增无限本地复测。
