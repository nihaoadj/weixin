# 09 分步骤、分节点实施

状态：P0–P6实现及必要检查已有证据，P7已执行仓库检查和微信两条主线。覆盖率与既有失败如实保留，工具阻塞登记[人工台账](../../manual-acceptance.md)后不阻断收尾。实际结果见[实施记录](deliveries/implementation-progress.md)，不重复未受改动影响的通过项。

## 1. 四个检查节点

| 节点        | 时点                      | 范围                                                            | 不执行                                   |
| ----------- | ------------------------- | --------------------------------------------------------------- | ---------------------------------------- |
| G0 文档门禁 | P0 完成                   | 文档格式/相对链接/空白、项目技能结构检查、需求追踪              | 全量测试、构建、Demo                     |
| G1 数据安全 | P1 模型/迁移/清理方案完成 | 临时库安全、0033/0034/清理保留项/拒绝与恢复                     | 前端全量、全站工具验收、真实库默认 apply |
| G2 业务合同 | P2–P4 主业务合并完成      | 新业务定向用例、权限/并发/provider/评分/API-Demo 合同、模块边界 | 全局覆盖率、完整跨角色工具回归           |
| G3 最终集成 | P5/P6 页面与退役完成      | 一次标准完整门禁、一次受影响 Demo 交互/渲染、交付               | 旧 T43 全量验收队列、真机、生产          |

P1 可先在隔离迁移环境验证完整 schema，运行模块在 P2–P6 对齐；若 0034 因旧 consumers 尚未退役只能先验证 0033/清理，则 G1 如实标“部分”，P6 仅补 0034 差异用例后关闭，不重复全部 G1。未关闭 G1 不进入最终交付。

## 2. P0 文档、事实和执行基线

| 步骤 | 操作                                               | 产物/完成条件                               |
| ---- | -------------------------------------------------- | ------------------------------------------- |
| P0.1 | 读取根规则、适用权威文档、git status，保护已改文件 | 当前审计和既有改动范围清楚                  |
| P0.2 | 写本计划各章、用户决定、需求追踪和清理边界         | 不留课堂/自主、成绩、审核、历史处理决策缺口 |
| P0.3 | 明确 schema/head、old/new 接口和代码改动位置       | 执行者无需另查流程归属才能开始              |
| P0.4 | 同步主题入口、计划索引与概述，完成 T43 归档        | 当前仅 T44；T43 完成归档且不再验收          |
| P0.5 | 执行 G0，写文档 delivery                           | G0 通过；代码仍未实施                       |

## 3. P1 数据、迁移与清理

| 步骤 | 具体修改                                                                                       | 产物/完成条件                                        |
| ---- | ---------------------------------------------------------------------------------------------- | ---------------------------------------------------- |
| P1.1 | learning 新 route_models.py 与 domain 状态规则，注册 metadata；所有新 source/scope/unique 约束 | 一来源一计划、一测试一次提交被数据库保护             |
| P1.2 | content 题库通用来源字段、mapper/import receipt，旧 FK 可脱钩                                  | 内容/版本保留，旧来源不可回查学生                    |
| P1.3 | 0033、新 schema/default、source 映射、cutover manifest、旧 ID 单调保护                         | 0032→0033 与空库均验证；不删除业务数据               |
| P1.4 | cleanup_t44_learning.py，默认 dry-run、备份、digest、关联 closure、停写和事务校验              | 目标/保留清单可审阅；歧义或备份失败拒绝              |
| P1.5 | 0034 的旧结构预检与退役；保留独立 training/shared learning                                     | 有旧记录拒绝、清理后允许；downgrade 不假恢复         |
| P1.6 | fixture/测试种子适配新 head，旧 schema 迁移 fixture 独立保存                                   | 不对真实 dev.db 执行测试，不 create_all 冒充历史升级 |
| P1.7 | G1，记录每个检查结果                                                                           | 清理和保留项在受管临时库证明；实际目标 apply 另记    |

P1 不自动执行受管开发库 apply。实际资源具备后按第07章一次切换，不用反复全量测试代替资源核实。

## 4. P2 AI 与完成后自动生成

| 步骤 | 具体修改                                                                          | 产物/完成条件                                                          |
| ---- | --------------------------------------------------------------------------------- | ---------------------------------------------------------------------- |
| P2.1 | PBL schema v8、request builder、checked gateway、Bot/Workflow/parser/开发 adapter | 保留四阶段/回应方式，删除双轮候选和自动补充卡                          |
| P2.2 | 新 route/test/case strict inference schema 与最小输入 mapper                      | 来源/目标/证据 allowlist，无学生身份或私密外发                         |
| P2.3 | pbl completion 用例注入 learning completion port，创建 route/test shell locator   | completion 与 route/test shell 同事务；port仅flush；外部失败不回滚完成 |
| P2.4 | 响应后 BackgroundTasks/注入Session factory、claim、route发布、再test生成          | 成功路线不被 test 失败阻塞；自主直接/课堂待审                          |
| P2.5 | 分组件 retry 与过期 claim，重复完成回调不再生成                                   | 同来源只有一份对象，GET 无副作用，无 fallback                          |
| P2.6 | 对应 provider/幂等/失败恢复定向检查                                               | 此阶段不跑全量 backend/frontend                                        |

## 5. P3 路线学习、病例、测试与结果

| 步骤 | 具体修改                                                                                  | 产物/完成条件                            |
| ---- | ----------------------------------------------------------------------------------------- | ---------------------------------------- |
| P3.1 | route list/detail 和 reading step 用例/API、前台 heartbeat/complete                       | 顺序和本人校验，时长只记进度，失败不解锁 |
| P3.2 | 发布时预建 case session、read/message repository、strict phase checks、claim/revision CAS | 三阶段逐个学习，无数字评分、无聊天泄漏   |
| P3.3 | test 双条件 read/start、唯一 attempt、draft 版本保存与题目ID归属                          | 两个条件任一缺失都不读题/不作答          |
| P3.4 | 最终 submit、确定性正确率、result freeze、receipt/证据                                    | 一次整份提交；未交无分数，零分 completed |
| P3.5 | 新证据 source 与正式/私人范围、结果读取                                                   | 路线无分，课堂 formal、自主 student_only |
| P3.6 | 状态/并发/事务/权限/答案负向定向检查                                                      | 修失败项，不在小修改后跑全局覆盖率       |

## 6. P4 教师审阅、题库、学情与公开合同

| 步骤 | 具体修改                                                                | 产物/完成条件                                |
| ---- | ----------------------------------------------------------------------- | -------------------------------------------- |
| P4.1 | teacher test list/detail/save/request-changes/retry/release 用例及 port | 同一分析和测试，无逐题医学审核；owned class  |
| P4.2 | 问题覆盖、version/digest、开放原子回执、反馈和通知                      | released 不可改，不重复开放/工作项           |
| P4.3 | content 题库新来源桥接、导入/编辑/归档                                  | 无学生材料，副本不改变已开放题               |
| P4.4 | classroom dashboard/progress 与 analytics result read port              | 只计完成课堂结果，过程/自主不计正式成绩      |
| P4.5 | frontend domain/ports/public、API/Demo adapters、Zod/mapper/wiring      | 页面无需绕过 public；API 显式错误无 fallback |
| P4.6 | contract:generate，同步所有生成产物及相关 fixtures                      | 不手改 OpenAPI/types；catalog 仍来自数据库   |
| P4.7 | G2：定向业务包+contract check+前后端 boundaries                         | 关闭关键状态/权限/计分/来源；不全量验收      |

## 7. P5 页面、任务入口与 Demo

| 步骤 | 具体修改                                                  | 产物/完成条件                           |
| ---- | --------------------------------------------------------- | --------------------------------------- |
| P5.1 | 注册六个新 student learning 页面和导航常量                | 参数/身份保护、原生返回和来源上下文     |
| P5.2 | learning 首页与 PblTaskList 真实 route card、全部任务列表 | 知识点不伪任务，卡片进入 plan-detail    |
| P5.3 | reading/case 交互、timer、键盘、安全区、错误/恢复         | 可顺序真实学习，过程不出现分数          |
| P5.4 | final-test/result，draft/submit feedback 和解析           | 提交前无答案，提交后只读，无再测        |
| P5.5 | knowledge-node、PBL completion、student insights 深链     | 移除旧练习，指向同 route/result         |
| P5.6 | teacher diagnostic/progress/follow-up/analytics 页面替换  | 单份审阅/单份结果，无旧轮次/阈值        |
| P5.7 | Demo 业务版本、D01–D10，真实可走课堂/自主                 | 清理旧集合但保留资源；刷新不 reset 进度 |
| P5.8 | 页面行为、adapter、类型、改动文件 Lint/格式定向检查       | 本阶段不重复全部页面截图或全局测试      |

必须在 G3 前完成 Demo，不接受“API 已改，Demo 待以后同步”的交付。

## 8. P6 旧逻辑彻底退役

| 步骤 | 具体修改                                                                                 | 产物/完成条件                                                                    |
| ---- | ---------------------------------------------------------------------------------------- | -------------------------------------------------------------------------------- |
| P6.1 | 删除旧 study practice、PBL mastery/intervention、classroom package 执行与公开能力        | 无第二轮生成/激活/提交路径；独立病例能力保留                                     |
| P6.2 | 退役 suggestion adopt、包 publish/medical-review、旧 plan submit/report repair API与脚本 | 旧 mutation 明确 RETIRED_FLOW，旧 read 无串新数据                                |
| P6.3 | 去旧模型 registry/re-export/schema/default/seed，完成0034                                | 新 head、空库/旧库升级/保留证明一致                                              |
| P6.4 | 清除 UI cycle/达标/改善/耗尽、通知深链、过期测试断言                                     | 不靠只删文字掩盖仍运行的双轮逻辑                                                 |
| P6.5 | 更新相关架构/数据/接口/数据库/安全/开发/设计文档                                         | 根据实际完成证据改当前规则；历史迁移不改写                                       |
| P6.6 | rg 残留审计和最小退役断言；有0034差异补 G1 对应项                                        | 剩余 cycle 只允许原PBL多轮对话、独立兼容/历史共享字段与迁移记录，均非新PBL执行链 |

实施审计发现0001直接使用当前Base.metadata，会把后续新表提前创建。为保证0032真实旧schema与0033唯一创建新表，允许在0001固定历史pilot表集合这一技术修复；保留revision及既有目标库行为，不改写历史业务事实。0033的新表DDL冻结，运行时registry剔除退役表；须经空库、真实0032fixture与normal create_all不复活检查。

退役检索至少含：`can_retest/canRetest`、`max_cycles/maxCycles`、`current_cycle/currentCycle`、`automation_exhausted/automationExhausted`、`next_cycle_activated`、双变式生成、PBL mastery 阈值、旧报告 repair。逐个分类，不能要求历史文档和迁移中所有“第二轮”字样消失。

## 9. P7 最终交付节点

1. 核对需求追踪每项有实际实现证据、G0/G1/G2 无未处理关键失败。
2. 执行 G3 一轮标准完整检查，分项记录结果，避免 wrapper 失败后其他项未执行却标绿。
3. 显式 Demo watcher、dev 项目普通编译、doctor，真实走自主和课堂主线；截图最少充分并逐张审阅。
4. 修本次出现的问题，只重跑受影响失败项；如果代码变化实质影响集成结论才补一次完整复验。
5. 停止验收，记录完成范围、失败项、外部项及回退。工具/环境阻塞登记人工台账后允许计划收尾；实际缺陷和必要测试失败仍须处理，不无限追加测试。
6. 只有用户明确授权才提交/推送；本次文档或实施授权不自动授权提交、部署、生产清理或外部平台变更。

## 10. 节点分工与阶段记录

G0–G3 到达检查节点时，主代理确定具体命令、受影响范围和出口条件，再启动 `gpt-6-luna`、`reasoning_effort='xhigh'`、`fork_turns='none'`（或少量必要上下文）执行既定检查。传入必要文件与矩阵 ID，返回命令、目录、时间、退出码、失败摘要及证据路径；不自行扩测、降低门槛或修改同一产物。主代理负责修复、架构/业务判断与节点出口。

共享数据库、watcher、微信工具和同一产物操作串行；不同隔离资源的只读检查可并行。子代理不可用时明确记录原因，由主代理完成同样范围。局部修复合并后集中复验受影响项，不因每次修改新增验收节点。

记录统一使用[工程交付模板](../delivery-template.md)，T44 只补阶段/矩阵与资源信息；纯文档同步只记必要节点结果，避免重复过程日志。

每个 P/G 更新 [实施记录](deliveries/implementation-progress.md)：修改范围、命令/UTC或上海时间、退出码、结果、未执行与原因、实际资源、下一步。没有命令/交互证据的状态不能写通过。纯局部样式/文案修复只记录受影响检查，不建立新的全量节点。

## 11. 本次可执行性复核补齐的工作项

以下是原 P 步骤的必要细化，合并进对应阶段执行，不新增独立阶段或全量节点。

| 阶段      | 必须同步的文件/能力                                                                                               | 完成条件                                                                                                          |
| --------- | ----------------------------------------------------------------------------------------------------------------- | ----------------------------------------------------------------------------------------------------------------- |
| P2.3/P2.4 | pbl use_cases/两个消息 API、bootstrap/composition、learning wiring、请求UoW和生成dispatch adapter                 | 同 Session 创建两个 shell；响应后任务新开同目标Session；两个入口均自动生成；重放不重复调度；断电后可显式恢复      |
| P3.2      | route_models/case用例/API/provider、前端routeCases及病例页                                                        | route发布预建唯一case session；GET不写；pending message可读；同ID失败/过期恢复；安全修正重新判定，不能越级        |
| P3.4/P3.5 | learning/public.py、application/evidence.py、evidence port/repository、新result用例                               | 两种source type获正式注册；整体result一次、knowledge metrics每点一次；同事务回滚/重放；目录变动不阻断冻结目标提交 |
| P4.1/P4.2 | 教师题目保存/release schema与UI、question source port                                                             | 新题由服务端分配ID，跨test ID拒绝；已发布不可编辑；历史read与active成员release分开授权                            |
| P5/P6     | learning/application/study.py、study_ports、api/study.py、pbl public读/创建port、src/types/study.ts与知识点调用链 | 去掉study_paths后资料读取和发起新研讨仍可用；新客户端不传new_round/path_id/cycle；不能引用已删表                  |
| P5        | learning领域next_action/mapper/API-Demo、详情与病例页面                                                           | 等待状态有限读取，停止条件明确；超时先读取同消息/同对象，不自动重写                                               |
| P1/P6     | 一次性清理脚本、0033/0034、启动迁移/seed入口                                                                      | cutoff和已完成标记阻止再次清理新研讨；0034不跨过有数据清理；真实目标按显式revision顺序停写切换                    |

对应定向证据复用现有 B01/B03/B07/B09/B13/B15/B16 和 DB03/DB08；只增加必要边界断言，不再另建测试队列。
