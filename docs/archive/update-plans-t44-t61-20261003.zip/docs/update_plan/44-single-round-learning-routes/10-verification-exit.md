# 10 有限验证、标准节点与退出条件

状态：仓库检查和微信两条主线已有证据；空状态登记为[MA-T44-001](../../manual-acceptance.md#ma-t44-001-空学习计划入口)，不阻断计划收尾。实际结果见[实施记录](deliveries/implementation-progress.md)。只做必要验证，不以重复测试或截图作为完成标准。

## 1. 执行节奏

只设 G0 文档、G1 数据安全、G2 业务合同、G3 最终集成四个节点。**全量测试、全局覆盖率和标准小程序交付验收集中在 G3。** P2–P6 小修改使用最小受影响检查，通过后进入下一步。

不默认执行 npm run check:all：它链式失败会阻止后续检查，且容易重复多个阶段已做的事项。G3 将标准命令分别执行并记录，不能重复跑 backend:test 和 backend:check 以获得同一全量结论。

测试文件下文凡标“待新增”均是计划目标，不代表当前存在或已经通过；实施时登记实际文件和用例数。

## 2. G0 文档门禁

范围仅本计划、索引、摘要及本次涉及的主题文档；根 AGENTS.md 不增加阶段状态：

```text
npx prettier --check docs/update_plan/44-single-round-learning-routes docs/update_plan/README.md docs/update_plan/summary.md docs/README.md docs/development.md
python scripts/check-project-skills.py
git diff --check -- docs/update_plan docs/README.md docs/development.md
```

另用临时只读脚本检查新文档相对链接、尾随空白、文件目录、需求追踪和各阶段/节点引用；新未跟踪文件不能只靠 git diff --check。该脚本不写源文件，不访问网络。

技能自检使用新的 `scripts/check-project-skills.py`；仅技能自身变化时额外运行 `--self-test`。原工程标准技能已退役，不恢复旧路径。G0 到节点后由 Luna xhigh 执行主代理选定检查并返回证据，主代理判定出口；其他节点按第09章同样分工。

G0 通过只说明文档结构和需求完整，不说明运行流程、迁移、AI、UI 或安全已验收。

## 3. G1 数据与清理安全

现有安全入口：`npm run backend:test:safety`、`npm run backend:test:migrations`。实际新增定向检查位于`backend/tests/test_t44_data_migrations.py`、`backend/tests/test_t44_question_bank_sources.py`，结合历史迁移和题库保留用例在launcher-owned临时SQLite中验证；命令、退出码与结果见实施记录：

| ID   | 必须证明                                                           |
| ---- | ------------------------------------------------------------------ |
| DB01 | 空库到 head 与真实0032 fixture→0033→清理→0034都成功，head唯一      |
| DB02 | 非本人/未知/生产/shared资源、链接边界、错误marker、缺备份拒绝      |
| DB03 | 默认dry-run不写数据库、不生成AI、不seed；manifest改变拒绝apply     |
| DB04 | 题库内容/版本保留、旧FK解除、独立病例/资源/班级/知识目录不减少     |
| DB05 | 清理旧研讨、私人续问、两个轮次、报告、证据及通知复习关联，无悬空FK |
| DB06 | 同整数ID不同source_type不误删；保留对象进入closure时拒绝           |
| DB07 | 中途注入错误全部rollback；备份可读并在独立临时位置完成恢复演练     |
| DB08 | 0034旧数据残留拒绝；新数据存在降级拒绝；不通过删新数据制造可回退   |
| DB09 | session等旧数字ID高水位保留，新对象UUID不与旧链接串号              |
| DB10 | 本次证据清理例外不开放普通DELETE，不改变append-only运行写约束      |

安全/迁移检查发生新修改才定向复跑相关项。真实受管开发库 apply/恢复另列证据；不存在明确目标时标外部待执行，不能让测试fixture清理冒充开发库清理。

## 4. G2 业务合同验收矩阵

| ID  | 场景/预期                                                         | 建议定向测试组，待新增            |
| --- | ----------------------------------------------------------------- | --------------------------------- |
| B01 | completion重复/并发仅一route，snapshot/revision冻结               | t44_completion/routes             |
| B02 | 路线直接发布，课堂test待审、自主直接开放                          | t44_generation/review             |
| B03 | route失败不回滚研讨；test失败不挡已发布route                      | t44_generation                    |
| B04 | 无效目标/来源/schema/unsafe不能发布，无provider fallback          | t44_provider_contracts            |
| B05 | reading顺序、手动完成、heartbeat去重/后台不累计，无最低时长       | t44_reading                       |
| B06 | 病例三阶段、至少当前学生证据、无越级/旧assistant证据，无分数      | t44_case_learning                 |
| B07 | case消息重试不重复，迟到response不覆盖，安全阻塞不放行            | t44_case_learning                 |
| B08 | route/test任一未满足拒读题/开始/保存/提交，直连API不能绕过        | t44_final_tests                   |
| B09 | 教师owned class、失效成员、version/digest、开放冻结               | t44_teacher_review                |
| B10 | 唯一attempt、draft恢复、答案全集、并发重复submit仅一result        | t44_final_tests                   |
| B11 | 2/3=66.7、0分completed、未交NULL；无达标线/二轮/补考              | t44_result_rules                  |
| B12 | 未交不泄答案，完成解析本人可见，自主任何教师query均不可见         | t44_permissions                   |
| B13 | 仅最终test scored evidence，analytics只计完成课堂result，无六维分 | t44_analytics                     |
| B14 | 题库明确入库、独立编辑/归档，不改变已开放test                     | t44_bank_sources                  |
| B15 | 源时区/日期首尾、稳定分页、身份切换/晚响应、cache失效             | t44_reads/adapters                |
| B16 | API/Demo同合同与上述状态差异，同一request重放一致                 | frontend route/test/case adapters |

后端定向用例通过根 `npm run backend:test -- tests/<实际文件> -q` 或 backend 工作目录 `python -m pytest tests/<实际文件> -q` 执行，仍由当前安全fixture接管数据库；不用未知engine。

前端 `npm run test -- <实际受影响spec路径>`；schema/mapper稳定后运行 `npm run contract:check`、`node scripts/frontend-boundaries.mjs`、`python backend/scripts/check_boundaries.py`。若bootstrap/public types变化，运行 `npm run type-check`，不默认全局coverage。

G2过关需矩阵关键项有真实证据，不能只mock用例方法调用来证明授权/事务，也不能仅用组件DOM测试证明微信实际渲染。

B03额外覆盖两处进程中断：shell提交后尚未领取生成claim、route发布后test尚未开始。两者都能恢复同一pending对象，不能永久卡住或重复创建；有效claim未过期时仍拒绝抢占。

## 5. P5/P6 局部检查规则

纯文案/样式：改动文件Prettier、Lint；可见变化按需在当前Demo编译检查对应页面，不全站回归。交互变化：受影响页面behavior spec和adapter定向用例；数据/schema变化：对应用例/mapper/contract。迁移/测试资源/bootstrap变动：对应安全/迁移；权限变化：负向范围用例。

已通过状态未受影响不重复截图。小修引入新的共享导航/身份影响或已有证据外溢时扩大到相关流程，仍不自动重跑每个历史阶段。

## 6. G3 标准完整命令

功能和退役全部完成后，依据[开发规范的检查选择](../../development.md#按改动选择验证)、[当前命令定义](../../development.md#常用命令)和 `package.json` 建立当次 G3 清单，分别登记命令、时间、退出码和失败类别；不在计划另维护完整命令目录。

T44 的 G3 范围包括格式/Lint/类型、前端全量覆盖率、后端静态及全量覆盖率、生成契约校验、前后端模块边界、秘密扫描、小程序构建及下节最小工具流程。`npm run backend:check` 当前包含 Ruff 与 pytest 覆盖率全量，并非仅静态检查；同一轮不得再运行 `backend:test` 获取同一全量结论。若脚本定义变化，先核对实际展开项再执行。

backend安全/迁移已在G1证明，G3 backend完整suite仍包含对应用例，不另外再运行一次相同完整backend:test。若fixture/migration在G1后有新改动，先补定向安全检查。

无依赖或构建依赖变更，本轮不为纯业务重复audit:all/prod/backend:audit；若实施新增/更新依赖则先更新计划并纳入审计。禁止用增加allowlist规避问题。

2026-09-27按用户最新决定，全局前端覆盖率在T44中作为质量报告，不再单独阻断本次交付。`vitest.config.ts`保留statements/lines/functions/branches统一80%的仓库检查配置及原覆盖范围，`npm run test:coverage`、`npm run check`因此仍可能退出非零；必须如实记录测试失败与覆盖率不足分别造成的结果，不将非零命令改写为通过。此前85%/85%/80%及80%检查结果保留为历史证据。后端85%门槛保持不变；本次决定不改变仓库通用发布检查或其他阶段规则。

T44前端交付要求：实际执行的测试无失败；B01–B16关键合同、权限及失败边界有有效断言；格式/Lint/类型、契约、模块边界及构建按范围通过。UI01–UI06只做必要验证，工具或环境阻塞登记[人工台账](../../manual-acceptance.md)后允许收尾，不等待人工补验。关键行为缺测试、必要测试失败或运行缺陷仍阻断交付。不得为全局百分比追加无关测试或缩小coverage范围。学情指标同步排除本次范围，仅验证原版展示与本人研讨记录。

secret3项指纹仍按本次新增与既有历史记录分类，T43历史指纹不重新转为该阶段补验任务；秘密扫描与其他既有失败单列，不因覆盖率规则调整自动豁免。

## 7. 微信开发者工具最小完整验收

环境、CLI、watcher、开发目录、普通编译、doctor 与真实交互/截图方法统一按[微信验收](../../wechat.md#开发环境)执行，不在计划复制工具命令。工具共享资源串行，由主代理准备就绪环境，Luna 仅执行分配流程和检查；Demo 与 API 的证明范围分别记录。

| UI ID | 操作及证明                                                                   |
| ----- | ---------------------------------------------------------------------------- |
| UI01  | 自主完成研讨→任务卡真实进入新计划→资料确认→病例三个阶段→最终测试→结果        |
| UI02  | 课堂完成研讨后路线立即可学；教师同一分析编辑/保存/开放；学生双条件满足后测试 |
| UI03  | 路线已完但教师未审，真实等待状态；开放后返回保留进度                         |
| UI04  | 测试草稿退出恢复、一次提交后无重考；课堂结果在教师进度/巩固只计一份          |
| UI05  | 一个代表生成/回复失败状态及可见恢复；空任务/完成记录有正确入口               |
| UI06  | 常规手机默认视口检查长资料/对话/解析、输入与固定栏，实际scroll/返回          |

场景映射统一见[Demo 场景](08-demo-scenarios.md#2-主流程合成数据)：UI01→D01，UI02→D02，UI03→D05/D06，UI04→D07/D08/D09，UI05→D10及空任务/完成列表预置状态，UI06在上述主线页面抽查。D03/D04提供可继续操作的展示状态，不额外要求走完整链或重复截图。

2026-09-27按用户最新决定，本次不执行320逻辑宽及其他窄屏专项验收，UI06使用当前428逻辑宽的常规手机模拟视口检查受影响输入、长内容、滚动/返回及固定栏。该证据只证明所测视口，不宣称全部主流机型或真机兼容；不做全站多宽度矩阵。非整数分/零分可由真实新Demo状态或逻辑证据覆盖；不为每个seed强制拍图。

先用watcher/产物/WXML/元素属性/真实断言确认状态，只在必须证明可见结果时截图。每页面每状态默认一张当次代表性图；损坏/关键区域缺失/真实新状态才补拍并记原因。正常返回不要求重复截图。截图须逐张审阅，敏感答案/隐藏病例不纳入证据输出。

构建、逻辑、握手、交互、渲染分别报告。工具/环境阻塞按[微信验收](../../wechat.md#阻塞与人工交接)停止尝试并登记人工台账，不阻断推进或收尾，不用源码/DOM/旧截图补成通过。本次不执行真机。

## 8. 停止规则

1. G3首先完整执行一轮各标准项，不因一个失败跳过其他独立项的记录。
2. 失败先定位本次范围或既有基线；修复后只复跑失败/受影响检查。
3. 仅实质代码/schema变更使原集成结论失效时，补一次完整复验；无改动不重复全量。
4. 全局前端覆盖率不足仅登记质量缺口。工具/环境阻塞登记人工台账后继续推进并允许收尾；外部项单列，不标通过。实际缺陷和必要测试失败仍须处理，不新增无限回归队列。
5. 修纯文案、等待用户状态或观察同状态不触发新的全量/近似截图。达到当前验收目的立即停止。

## 9. 交付判定

计划完成：需求实现、必要仓库检查及缺陷处理完成；微信受影响流程已验证或因工具/环境阻塞登记人工台账。允许标记“已收尾，人工待验：MA-xxx”，用户后续补验不重开整个计划。覆盖率质量缺口及既有失败随报告保留，不能宣称通用`check`或全部验收通过。

未完成：仍有实现缺口、必要测试失败或已知功能缺陷。实际开发库清理、真实Coze、专家医学质量、PostgreSQL/生产与真机分别列外部状态及发布条件；微信工具阻塞不单独构成计划未完成。

文档完成：仅G0和文档需求追踪通过，P1–P7保持待执行。仅文档阶段适用该结论，不执行运行门禁；后续实施按对应阶段证据更新状态。

## 10. 可执行性复核新增的定向断言

这些断言合并进既有矩阵用例，不增加测试节点或新的完整门禁。

- B01/B03：两个PBL消息入口都在同事务创建route/test shell；注入shell失败整笔回滚；提交成功后响应无需等待生成；后台不复用已关闭请求Session，重复调度/重试同claim不重复provider调用。
- B07：route发布已存在唯一case session，纯GET零写入；病例pending/claim过期可恢复同ID，旧expected_revision重放不误拒绝，迟到回应不越级；unsafe不成为证据，新修正回答只有合法判定才恢复。
- B09/B12：教师新题ID由服务端分配、跨test引用拒绝；离班/归档前后区分历史读取与草稿/release权限。
- B13：通过真实现有EvidenceApplication写两种新来源，不只mock append；result/metric/dedupe一次，证据异常全事务回滚，目录后续失活不改变已冻结答卷计算。
- B15/B16：知识点读材料/发起自主研讨不查已退役study_paths；等待轮询到期/onHide终止，无自动写重试，后台完成后刷新能读取原对象。
- DB03/DB08：完成cutover后不能重新apply清理新研讨；有旧数据直接upgrade head拒绝；既有0032固定schema与空库升级两种路径分别证明。

API真实外部交付出口：三种Coze任务固定合同/映射配置和最小脱敏调用证据齐全，才声明真实API新流程已联调；缺少时如实标“仓库与Demo所测范围完成，API外部联调待执行”，不扩成本地无限回归。
