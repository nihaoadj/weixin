# T44 实施进度

状态：**已收尾，人工待验MA-T44-001。** 主要实现、仓库测试、微信两条主线及教师投影已有证据，结论见[收尾交付](completion.md)。全局覆盖率仅作质量报告，历史失败保留；微信证据见[微信记录](parallel-wechat-acceptance.md)，待验流程见[人工台账](../../../manual-acceptance.md)。历史未完成结论保留为当时状态，不自动恢复验收。

## 阶段与节点

| 阶段/节点        | 当前状态                           | 依据/下一动作                                                              |
| ---------------- | ---------------------------------- | -------------------------------------------------------------------------- |
| P0 文档          | 编写完成，G0结果以文档交付为准     | [全套计划](../README.md)及需求追踪                                         |
| G0 文档门禁      | 通过，仅文档范围，不代表运行验收   | 新规范同步后：20份文档/103本地链接/空白/需求追踪/技能结构，见documentation |
| P1 / G1 数据安全 | 仓库内数据安全检查通过             | 安全13项、历史迁移22项、数据/题库15项；实际开发库待执行                    |
| P2 AI自动生成    | 仓库实现与合同验证完成             | schema v8与三任务合同、两个入口后台调度；真实Coze单列外部未验              |
| P3 学习与计分    | 完成                               | 步骤、三阶段、双条件、唯一结果；并发/事务回滚/迟到恢复已有证据             |
| P4 / G2 业务合同 | 后端/前端合同及Demo主线已有证据    | 真实Coze单列外部待验，不用Demo代替                                         |
| P5 页面与Demo    | 两条主线及教师投影已验证           | 学情仅恢复展示；空状态转MA-T44-001，不阻断收尾                             |
| P6 旧逻辑退役    | 旧双轮模块/port/SQL/入口退役已实施 | 旧接口空/404/RETIRED_FLOW已验证                                            |
| P7 / G3 最终集成 | 按现行出口收尾                     | 覆盖率为质量报告；历史失败及外部未验保留；MA-T44-001交人工台账             |

## 当前实际边界

0033/0034、清理脚本、后端退役、新页面与Demo适配已落地；G1受管测试通过，契约由脚本更新。微信工具阻塞项见人工台账，不阻断收尾；必要测试失败和实际缺陷仍须处理。实际开发库清理、真实Coze、PostgreSQL/生产及真机仍未执行，不能据此声明外部环境已验。

不把T43历史334 passed、Demo截图或题库人工操作转写为T44验收通过。T43按用户明确决定完成归档并免除剩余验收，后续不再验收T43。旧队列不进入T44。

后续每阶段按[模板](template.md)追加日期、命令/退出码、矩阵ID、证据、失败/外部项和回退，达到节点条件后停止，不无限扩大测试。

## 2026-09-27 实施启动与定向结果

运行代码已增量加入12张路线业务表及0033/0034迁移草稿、受管清理脚本草稿、schema v8与三类任务信封、路线应用编排/SQL存储/学生教师API。两个研讨消息入口保存完成快照及路线/测试shell后使用独立Session后台生成；最终计分接入现有证据账本。前端领域、API合同与Demo adapter草稿已创建，页面与旧入口尚待完成。

主代理执行（受管pytest临时SQLite，非开发库）：

| 命令（backend目录）                                                                                                                                                                                                                                                                                                                    | 退出码 | 结果与范围                                                                                               |
| -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ------ | -------------------------------------------------------------------------------------------------------- |
| `python -m pytest tests/test_t44_provider_contracts.py -q`                                                                                                                                                                                                                                                                             | 0      | 10 passed；schema v8、三种任务严格合同/来源与证据校验、受管transport与无fallback                         |
| `python -m pytest tests/test_t44_learning_routes.py -x -q --tb=short`                                                                                                                                                                                                                                                                  | 0      | 4 passed；自主唯一成绩/66.7与答案隐私、课堂开放冻结、生成失败恢复、阅读lease与幂等；不代表G2矩阵全部通过 |
| `python -m ruff check app/modules/learning/application/learning_routes.py app/modules/learning/application/route_ports.py app/modules/learning/domain/learning_routes.py app/modules/learning/infrastructure/route_repository.py app/modules/learning/api/routes.py app/modules/learning/api/route_schemas.py --output-format concise` | 0      | 当时六个新增文件静态通过；其后阅读sections映射与日志需定向复验                                           |

首测修复测试title列误置及SQLAlchemy CAS内存同步的时区比较错误后，四项业务测试通过。现有fixture产生共享旧模型外键循环drop警告，尚未完成P6退役，不据此标记迁移安全通过。

随后新增资料GET合同检查与知识点入口退役检查，同命令退出0、5 passed（9.37s）：实际删除受管测试库的study_paths/两个practice表后，资料读取/新研讨创建仍可用；旧practice mutation返回409、reason=RETIRED_FLOW。前后端边界检查分别通过（`python backend/scripts/check_boundaries.py`、`node scripts/frontend-boundaries.mjs`），后端首次发现wiring循环后已将AI装配移入bootstrap/composition修复；未增加边界allowlist。AI装配改动后同一5项业务集复验退出0、5 passed（8.88s）。

三个Luna子代理因平台用量限制终止，主代理已接管其实际文件；子代理未给完整可审阅命令结果的工作不记通过。迁移/清理仍待G1安全与保留证明，前端六页、教师入口、旧链退役、契约生成、G2/G3和微信流程待实施。未运行真实数据库apply、Coze、生产或真机；未提交/推送。

## 可执行性复核状态

2026-09-26 再次按源码复核并补齐后台生成事务、病例创建/恢复、现有证据接入、去study_paths后的入口、FK及独立评价保留、manifest与版本匹配备份。步骤和原验收矩阵同步；本次G0文档检查通过（16份、69个相对链接），证据见documentation第7节。P1–P7及运行检查仍未执行，真实目标与Coze合同在执行时核实；不恢复T43验收。

## 2026-09-27 边界补齐与代理验收

三个Luna xhigh子代理已恢复，分别继续迁移/题库、provider/教师统计、前端六页/Demo。新验收代理因4/4槽位无法创建，既有Luna执行指定节点检查，不再递归委派。

Provider代理在backend执行 `python -m pytest tests/test_t44_provider_contracts.py tests/test_t43_provider_schema.py tests/test_pbl_providers.py -q`，退出0、40 passed（43.60s，UTC 16:16:30–16:17:15）。线上入口严格v8；v6/v7仅用于历史结构读取，正常消息不再持久化旧候选题。此旧命名文件只验证本次provider兼容边界，不恢复T43验收队列。

主代理新加病例恢复与非法答卷检查后，7项集退出1、6 passed、1 failed（12.51s）。发现重试原病例消息重复进入history、被严格输入合同拒绝，已排除当前消息并限制当前证据数量。定向 `python -m pytest tests/test_t44_learning_routes.py::test_case_failed_turn_recovers_same_message_and_unsafe_does_not_advance -q --tb=short` 退出0、1 passed（4.06s），包括unsafe不推进及修正回答合法恢复。

继续新增生成claim过期/迟到回应和证据异常整笔回滚，9项集尚待验证；首次执行因代理重写analytics模块期间文件短暂缺失而9 setup errors（2.78s），不记业务失败修复或通过，待模块落盘后复验。Teacher结果读取新增 typed DTO、上海日期边界转UTC，题库route_test_question来源读取已接入，content导入消费者由数据代理同步。

前后端边界再检退出0：9后端模块、217前端实现文件。未新增allowlist。教师旧任务包/旧学习port不再装配到正常PBL，旧报告应用读返回空/404；知识点discussion state不再读退役建议表。路线摘要加入失效课堂scope提示，已发路线及已开放测试保留本人读取；失效范围禁止新开放和生成重试。

9项路线业务集在analytics模块落盘后复验退出0、9 passed（13.45s），含生成claim过期/迟到响应不能替换内容、证据异常结果和答卷整笔回滚、同请求合法恢复。尚不代表G2全部覆盖。

## 2026-09-27 G2定向节点证据

Luna xhigh验收代理 `/root/g2_verification` 在backend执行主代理指定的 `python -m pytest tests/test_t44_learning_routes.py tests/test_t44_provider_contracts.py tests/test_t44_analytics.py -q --tb=short`：UTC 16:36:14–16:36:56，退出0、26 passed。随后六个路线实现文件及route测试文件Ruff检查退出0。测试覆盖11项路线、12项provider及3项analytics；存在25条fixture旧共享独立病例/学习表的SQLite循环drop警告，未将其当作生产兼容证据。

本次路线集新增完整草稿恢复、保存receipt固定响应、旧tab lease失效、幂等三类通知UUID与提交事务联动。通知内部保留旧整数entity_id，并用nullable entity_public_id投影新路线UUID；对外 entity_id 为 int|string。RouteCommandReceipt用nullable response_snapshot保存reading/draft可重放响应。教师保存改为就地更新保留题目UUID，位置先移到临时区再重排，避免identity-map覆盖警告。后台CAS/唯一约束冲突统一409，阅读心跳token+last_seen CAS及原子累加。新路线响应日期统一UTC；上海日期窗口转UTC查询。

`npm run contract:generate` 退出0，OpenAPI、生成类型及公共病理目录/测试fixture通过脚本更新；其内部受管空库完整upgrade至0034成功，不是实际开发库apply。生成后接口未改变字段，仅进一步统一日期输出。Provider三文件包在私有阶段completion_requirements补齐后退出0、41 passed（UTC16:29:49–16:30:34）；该字段仅外发本阶段冻结规则，不出现在学生病例DTO。

G2仍待题库新来源实际导入/编辑隔离、前端API-Demo适配与身份/生命周期证据；G1历史迁移初始metadata和runtime旧表注册问题正在修正。尚未进入G3，不将定向测试标为完整验收。

## 2026-09-27 P6退役与依赖收口

正常运行已删除旧双轮学习/课堂包执行、掌握度与报告修复模块；QuestionPublicationPort仅保留已审核病例上下文，不再生成旧PBL补充卡或提供两轮资源。旧transition_pbl_t14、backfill_pbl_evaluations、rebuild_t43_reports与transition_t43_packages命令直接返回RETIRED_FLOW，不打开数据库。独立Report班级归属回填保留，改用独立SQLite验证备份，不依赖退役脚本。

Luna xhigh在backend执行 `python -m pytest tests/test_t14_automatic_mastery.py tests/test_t20_study_paths.py tests/test_t29_report_backfill.py tests/test_t15_learning_report.py tests/test_t43_report_rebuild.py tests/test_t43_package_draft.py -q --tb=short`，UTC16:55:14–16:55:37，退出0、11 passed；保留当前phase gateway、资料目录完整性、独立Report归属及自主隐私覆盖，旧入口证明空列表/404/RETIRED_FLOW。10条SQLite共享独立模型teardown排序警告仍记录。随后collect-only预检退出1，306项被收集、3处纯旧任务包依赖错误；已移除这些退役模块专用测试与旧report dashboard测试，未恢复旧模块。新增CLI参数化覆盖transition_t43_packages，尚待定向结果。

迁移历史依赖另有必要修正：0001固定原pilot表清单，0004独立MetaData补齐users/problems引用stub；不改变历史业务revision和字段，仅解除对当前runtime metadata的依赖。0032真实固定schema及空库路径由G1提供证据，不能以计划或运行metadata冒充。

## 2026-09-27 完成事务与AI合同复验

主代理在backend执行provider三个文件、T44 analytics及退役CLI定向包，退出0、46 passed（39.04s）。本次仅因provider格式/旧public退役及新增CLI参数化复验受影响集合，不代表G3。新增 `test_completion_shell_failure_rolls_back_frozen_analysis_and_recovers` 两入口参数化用例，注入shell flush后异常，断言完成快照、完成边界、路线及完成账本均未提交；已提交消息key通过既有60秒PBL恢复机制结算后可重新完成，同一路线唯一。backend定向该用例退出0、2 passed（4.94s），覆盖B01失败事务；一条独立共享模型drop排序警告。

教师save receipt现在保存原响应，即使后来已开放，原请求仍返回原保存版本/状态，不以当前可变状态替代；正常权限先校验。实际API测试拒绝跨测试question UUID与去空白重复选项，版本/digest保持不变，开放后原save重放响应一致；定向退出0、1 passed（4.29s）。旧PBLmutation body改为可选通用object，缺body不再先被旧DTO422截断；退役T15/package定向退出0、3 passed（5.14s）。后端collect-only由Luna退出0、302项，无导入错误；这是收集证据，未执行全量。

B07补齐病例claim过期与迟到响应的实际证据：同消息ID、原expected_revision在旧claim到期后恢复，阶段只推进一次；旧claim晚到被VERSION_CONFLICT拒绝，消息及decision各一份，最终phase/revision不被替换。首次失败为用例信封缺request_id（KeyError，非业务缺陷），补齐后backend定向退出0、1 passed（3.77s）。

P6继续删除PBL repository/port中的旧建议题、提交教师、反馈、旧报告查询实际SQL实现。路线14项回归退出1、13 passed、1 failed（19.07s）：知识点资料入口仍依赖report_participations，属于本次删除遗漏。已替换成最小student_dialogues_for_point读取本人研讨ID/阶段/路线定位，完全不读旧报告、任务包或完整消息；对应退役表删除后的真实入口定向退出0、1 passed（4.76s）。其他13项业务当次通过；完整后端G3尚未执行。

实际并发最终提交：`python -m pytest tests/test_t44_concurrent_submit.py -q --tb=short` 在受管SQLite同时发起两次HTTP提交，退出0、1 passed（5.64s）；合法响应/冲突后原请求恢复指向相同结果，唯一RouteLearningResult与private_final_test账本事件。先前两次用例失败为用例读取非合同字段draft_version及错误source名称，均仅修测试到权威合同，运行逻辑未改。

Luna后端退役收口完成三个文件：test_pbl_api退出0、4 passed；T11 integration退出0、11 passed；T21 feedback退出0、3 passed。保留schema8阶段、教师归属、冻结/私人续问和独立目录/转化检查，旧候选发布/反馈只验证RETIRED_FLOW及无部分写入。collect-only随后退出0、307 tests collected，diff check退出0，尚未运行完整coverage。

同一实际并发用例补充B13冻结目录断言：在学习完成/测试开放后把live catalog归档，最终提交和knowledge账本仍按已冻结目标成功，唯一结果/计分事件不变；定向退出0、1 passed（3.75s）。未降低目录在新生成/普通资料查询时的active要求。

B09权限收口发现学生retry只对课堂test组件校验范围，route组件可绕过失效课堂。已统一两类生成mutation均校验active class+current membership；已发路线/已开放测试本人继续规则不变。归档未开放后route/test两种retry直连API均409、CLASSROOM_SCOPE_INACTIVE；受影响教师locator/历史读取定向退出0、1 passed（3.98s）。Demo同态由前端同步。

前端P6/v3检查收口：删除两份纯旧package/report spec；conformance取消退役生成DTO依赖，新增13个route/test/result/retry/release编译合同校验。API统计适配定向5 passed，教师analytics workspace/学生结果分页/教师overview三个行为文件25 passed（退出0），保留空/零分、分页、失败恢复、迟到与身份更换检查，不恢复达标/六维/人工支持队列。上述五个保留检查文件ESLint退出0、Prettier已写。全局type-check退出1，剩余前端运行整合及旧题库/progress spec问题，conformance自身未报错；不能记类型门禁通过。

## 2026-09-27 G1出口与学生交互补齐

Luna xhigh完成受管数据/题库组：`python -m pytest tests/test_t44_data_migrations.py tests/test_t44_question_bank_sources.py tests/test_t43_question_bank.py -q`退出0、15 passed（60.48s）；历史迁移按准确revision逐项固定后`python -m pytest tests/test_migrations.py -q`退出0、22 passed（128.03s）。先前安全组13项通过，owned/授权44文件Ruff与format check退出0。清理异常只返回通用integrity constraint failure/database operation failure，不暴露SQLite原文，不以测试特例分支实现。实际开发库apply仍属外部待执行。

主代理新增`src/pages/student/learning/routes.behavior.spec.ts`，最终定向退出0、10 passed，ESLint退出0：资料后台停止heartbeat、零秒人工完成同ID重试、身份切换迟到回复、病例持久化原ID/内容/revision恢复、只轮询不重发、hide停止轮询、草稿退出保存、整卷一次提交原ID恢复、零分完成及跨路线结果拒绝。确认弹窗迟到回调用例先真实复现跨身份提交，前端修复固定identity/context/test/attempt版本和答案快照后通过；未以测试绕过。上述DOM证据不代替微信真实交互。

后端已进入G3唯一标准全量静态/覆盖率轮次，运行`npm run backend:check`，结果待登记。前端仍在退役/类型整合；局部边界检查发现教师final-test直引domain type，已安排改经public；backend-boundaries当次PASS。唯一Demo watcher曾完成编译，随后删除旧page注册仍触发ENOENT，待最终编译后再刷新工具，不把中间构建记为最终UI证据。

学生行为进一步覆盖计划空状态/已完成tab及路线完成后等待教师，最终该文件12 passed、退出0。新增`apiLearningRoutes.spec.ts`实际解析Zod响应、验证未提交题目泄漏答案/非法选项拒绝、原revision/digest/请求ID映射、零分固定结果、病例恢复、heartbeat和API错误传播，8 passed、退出0；ESLint通过。此处mock HTTP传输但使用真实schema，不作为服务端权限/事务证据。

清理余项：Luna首轮失败测试残留`C:\Users\adj\AppData\Local\Temp\medical-qa-pytest-oob4a7kb`仅pytest所有权marker与合成数据库；精确路径和内容已核验，代理的PowerShell删除曾被执行策略拒绝；主代理随后调用项目原有`app.testing_resources.cleanup_managed_database`，验证精确临时目录、marker/token、kind及仅有marker/合成数据库后成功清除（退出0）。未绕过所有权校验。

G3秘密扫描：2026-09-27 09:10（Asia/Shanghai）执行`npm run security:secrets`退出1，3项均scope=history，位置仍为旧miniprogram/pages/student/chat/chat.js:137、chat.ts:141/147，指纹d778f15337798100、8a3ca2c594c75a93、f6d7abe6cb857ce9。本次工作区未检出新增秘密；全历史扫描门禁仍失败，不增加allowlist、不重写历史或把T43已免验事项恢复验收。历史秘密处理由仓库责任方另行闭环。

G3生成契约：`npm run contract:check`退出0（2026-09-27 09:12 Asia/Shanghai）；脚本使用独立受管临时数据库升级head0034，重新导出OpenAPI、生成TS、公共目录及fixture后比较一致。不是实际开发库清理或真实provider证据。

## 2026-09-27 G3后端全量与定向修复

Luna xhigh执行唯一标准`npm run backend:check`，Ruff通过，pytest退出1：294 passed、14 failed、307 warnings（504.27s），TOTAL 87.76%，现有85%门槛达到。证据[g3-backend-check.log](g3-backend-check.log)保留命令、Ruff、覆盖率和14项失败清单；已省略原始traceback，避免日志包含完整学生输入及测试token。

主代理处理其中7项：统计旧schema2/weak_points断言迁到当前v3；历史0030 fixture只移除实际存在的T43未来表/列；独立exit-quiz的遗留practice_unlocked读取真实触发KeyError，改按本人已完成研讨路线或已有独立review历史判断，不恢复study表；独立complete_plan范围校验统一一次查询，保留冲突恢复。`python -m pytest tests/test_second_phase.py tests/test_t05_learning_application.py tests/test_t08_knowledge_review.py tests/test_t43_migration.py -q --tb=short`退出0、27 passed（36.38s），受影响文件Ruff检查通过。其余7项旧研讨/followup测试预期由Luna定向修复；不再重复全量。独立SQLite环外键drop warnings仍记录。

前端旧学习spec由Luna收口到仍受支持的独立病例医学审核及manual review：teacher-adapters/demoLearningRepository.caseReview两文件2 tests passed、ESLint与diff check退出0；不恢复旧计划/profile/课堂包。主代理API mapper显式any全部改为实际Zod schema推导的类型，API定向8项与ESLint通过。

后端余下7失败已由Luna修复：t17真实RouteGateway唯一路线/旧报告为空，t20旧submission GET404/POST409且诊断/私有归属不变，t31线上schema8fixture，t32冻结/独立证据/卡片及私人续问幂等保留且不查已退役表。指定4文件Ruff与pytest退出0、20 passed（23.64s）。G3证据日志保留失败名称和coverage，不保留可能包含完整学生回答的原始traceback；14个首轮失败均已有对应定向修复证据，不重复全量。

G3边界在本次真实API修复后检查：`python backend/scripts/check_boundaries.py`退出0，9 modules；`node scripts/frontend-boundaries.mjs`退出0，202 implementation files。前端`npm run type-check`随后退出0（由前端代理执行）。微信唯一Demo watcher最新增量Build complete后已打开指定开发目录并普通refresh；doctor首测尚无runtime退出1，再待真实login page可读后定向重试退出0，SDK3.16.3、URL校验true。当前模拟器428逻辑宽，不能冒充320窄屏或主线交互已验。

G3前端标准首轮初查：`npm run format:check`退出1，共39项格式差异（完整清单[g3-format.log](g3-format.log)）；大多为本次T44源码，按所有权做定向Prettier后复核。唯一`docs/archive/t43-completed-20260926/ARCHIVE-COMPLETION.json`为此前未跟踪归档、非本次范围，保持原样，不能为T44全局门禁静默改历史。`npm run lint`退出1：3个unused import/变量、route-reading.vue 2条属性顺序warning，详见[g3-lint.log](g3-lint.log)，前端代理定向修复后复核。`npm run type-check`在前端页面最新改动前曾退出0，本次并行改动出现teacher final-test.vue的switch事件签名错误，已交前端代理修复后重跑。

Demo研讨主仓储新增T44专用`pbl:t44-demo`严格版本化存储；默认D01自主/D02课堂停在synthesis，前三阶段各3条合成学生消息及导师反馈；正常完成改schema8、直接触发单一路线/测试，去候选题和旧二轮种子。恢复对已完成/私人续问原请求重放、当前本人范围和teacher归属校验。新仓储定向7 passed、ESLint通过。已发现Demo路线完成回调仍把PBL vascular目标写成静态acute并把课堂session映射44，已交前端修冻结目标与原课堂号；该缺陷未闭合前不标D01/D02通过。

微信工具窗口在持续增量编译时尝试登录发生automator timeout，截图仅显示“编译...”白屏，已删除该临时截图，未计UI证据。唯一watcher进程句柄随后报告Unknown process id，确认已停止；待源码稳定后重新启动一个watcher，再按普通refresh/doctor/真实点击验收，不能把中间Build complete或doctor独自算UI通过。

B03两个进程中断边界补齐：新增`test_pending_shell_and_published_route_resume_after_dispatch_interruptions`，实际把completion后dispatch抑制模拟shell提交但尚未claim，通过原route重试恢复发布与test ready；第二条手动只发布route不领取test claim，再从学生API恢复同一test。断言两个session各一route/test，无重复对象。首测直接读取长寿命SQLAlchemy identity map误见`pending`，测试加`db.expire_all()`重新读库后该项退出0、1 passed（3.61s）；未改运行逻辑。失败资源由项目所有权helper验证marker及精确Temp子目录后清理，退出0。

## 2026-09-27 13:50 学情原版恢复与微信实测

用户明确要求学情完整同步移到下次任务。本次将`src/pages/student/insights/index.vue`恢复为改动前T43原版模板与CSS，仅将旧报告空列表改接本人已参与的研讨列表，保留原版最近对话卡片；旧详情页也恢复为改动前版本，卡片点击对应研讨页。用此前coverage产物中的改动前源码逐行比对：CSS完全一致，模板仅“加载更多”条件由旧报告总数改为真实分页标志。`src/pages/student/insights/index.behavior.spec.ts`3项通过；微信Demo同一学生实际可见4条研讨记录并能打开指定`dialogueId`。两张当次截图：[原版顶部](ui-student-insights-original.png)、[原版记录](ui-student-insights-records.png)。本次不生成学情掌握度、趋势、薄弱点与分数；当前原版指标仍为未评价占位，完整学情同步留到下一任务。

其后补查身份失效边界：旧学生记录立即清除并显示原版错误状态，迟到响应不再写回；`index.behavior.spec.ts`增为4项，定向退出0。页面视觉模板和CSS仍保持上述比对结果。

G3前端标准首轮：84个文件426项测试通过；statements/lines 77.21%、functions 62.72%、branches 77.98%，未达现有85%/85%/80%门槛。Lint、类型、前端边界、Demo构建退出0；全局格式退出1，仅先前未跟踪的归档JSON格式差异，本次T44文件定向Prettier通过。后端标准首轮294通过14失败，14项分别定向修复通过，87.76%达到门槛；按停止规则不重复无差异全量。`npm run contract:check`退出0；秘密扫描退出1，3项均为已记录历史指纹，无本次新增。以上均不能写作G3全绿。

微信Demo的唯一watcher句柄消失且项目窗口关闭后，确认句柄不存在，再启动一个新watcher（`VITE_APP_MODE=demo; npm run dev:mp-weixin`，Build complete）并重开项目窗口。阅读页当次可见截图[资料学习](ui-reading-default.png)覆盖此前无效白屏图；真实点击“完成资料学习”返回计划并解锁病例。实际操作发现完成步骤仍显示`0/2`，修正Demo adapter进度更新及旧持久化状态的只读投影，定向4项测试通过，刷新后同一路线显示`1/2`。随后真实输入病例三个阶段，界面依次显示“机制解释”“证据判断”“完成”，返回计划显示`2/2`并可进入最终测试。首题选择后自动保存，退出再进入仍显示`已保存 1/3 道`；补足后显示`3/3`。测试原生提交确认框已出现，但当前CLI无法以可验证真实点击触发原生弹窗按钮，故提交/结果不记UI通过；保留草稿，不以setData/callMethod/mock代替。新增题目稳定DOM id只服务可访问定位，不影响视觉。

本次最新定向复核：`npx vitest run src/pages/student/learning/routes.behavior.spec.ts src/features/learning/infrastructure/demoLearningRoutes.spec.ts src/pages/student/insights/index.behavior.spec.ts`退出0、19 passed；`npm run type-check`退出0；前端边界退出0（203 files）；受影响文件ESLint和Prettier通过（最终测试页属性顺序warning已修）。微信实测仅证明当前Demo、当前SDK及默认428逻辑宽；UI01研讨输入、完整自主提交/结果、UI02课堂教师全链、UI03/UI04课堂统计和UI06的320逻辑宽仍待验。学情完整指标同步按用户指令排除本次范围。实际开发库apply/清理、真实Coze、PostgreSQL/生产和真机另列外部未验项。

## 2026-09-27 13:55 课堂等待状态补验

在同一微信Demo学生身份打开预置D05路线（`10000000-0000-4000-8000-000000000005`），真实页面显示路线`2/2`、最终测试“待审阅”和禁用的“等待教师开放”，未提前展示测试题；截图[课堂等待](ui-classroom-waiting.png)已审阅。随后通过可见登录入口切换Demo教师身份，打开同一测试`f0000000-0000-4000-8000-000000000005`，页面实际状态为“待教师审阅”。尚未完成教师编辑/开放及学生返回复验，不将UI02/UI03整体记通过。标准后端全量首轮的14项定向修复后已启动一次完整复验，结果待独立验收输出；此时不提前声明G3后端通过。

教师测试审阅页随后用真实输入修改D05第一题解析，点击“保存测试草稿”后按钮显示“草稿已保存”；退出再进入同一测试，控件值仍为更新后的解析。此操作仅证明教师编辑/保存/恢复，开放仍受原生确认框的工具交互限制。页面为题目及保存/开放按钮增加稳定DOM id，未改变可见样式；`npx vitest run src/pages/teacher/learning/final-test.behavior.spec.ts`退出0、8 passed，相关ESLint与Prettier退出0。

G3后端完整复验由Luna xhigh独立执行`npm run backend:check`，退出0；309 passed、0 failed、308 warnings，总覆盖率88%（12,767 statements / 1,491 missed），运行约596秒。此前首轮14失败已由对应定向修复闭环，本次完整复验证明后端标准门禁通过；未输出或保存可能包含学生完整回答的原始测试日志。

微信Demo教师打开预置课堂D08只读结果`e0000000-0000-4000-8000-000000000008`，界面显示班级1/课堂1/学生1、66.7分与答对2/3题；切换学生身份后打开同一路线结果，显示相同分数及“教师审阅后开放”。此项仅证明同一预置结果的师生可见表现，不代替新提交后的唯一计分/统计证明；后者以后端B11/B13为准。结果页包含题目与选择，本次不保存该页截图，避免证据输出学生作答。

学生学习计划列表通过真实点击“已完成”tab后，预置课堂结果卡显示`已完成 2/2 个学习步骤`及“查看学习结果”入口；只证明完成列表入口，不冒充空任务状态已验。

学情身份失效保护及页面稳定DOM定位改动后，`npm run type-check`退出0，`node scripts/frontend-boundaries.mjs`退出0（203 files），T44文档与受影响页Prettier及`git diff --check`退出0；`VITE_APP_MODE=demo; npm run build:mp-weixin`退出0，构建可生成小程序产物。未因这些局部改动重复前端全量coverage或合同生成检查。

前端G3覆盖率缺口独立只读审计：既有T43基线为lines/statements71.44%、functions60.71%、branches76.51%；T44首轮提高至77.21%、62.72%、77.98%，没有总体退化，但当前新增/改动源码仍包含大部分未命中点。当前`coverage/lcov.info`共27,940可执行行/21,574命中、1,489函数/934命中、4,883分支/3,808命中；同分母达到现有门槛至少还差2,175行、332函数、99分支命中。LCOV不含statement绝对点数。39个未跟踪源码即使全覆盖，按当前分母lines/functions也最多约81.41%/69.58%；不能通过少量新文件测试宣称达到门槛，亦不降低阈值或排除合理源码。

按T44的B13语义补充`src/features/analytics/infrastructure/demoClassroomReports.spec.ts`4项：完成/未完成路线统计分离、知识只按已提交结果聚合、上海日期首尾、学生和结果分页、零分完成、会话进度、非法日期及角色/班级拒绝。调用Demo analytics repository公开接口而非镜像函数；定向Vitest、ESLint、Prettier、类型均退出0。未重跑全量coverage，G3前端仍按首轮失败记录，不把预计提升当作已达标。

## 2026-09-27 P7 本轮出口核对

用户完成新自主研讨及最终提交后提供截图，指出结果页“返回学习计划”先退到测试页，第二次才到计划。已修复提交成功使用`goReplace`替换测试页，结果页按钮使用`goReplace`明确定位同一route详情，不再盲退上一层。学生行为/平台导航两文件27项通过，受影响ESLint/Prettier和`npm run type-check`退出0；微信代理在同一已有结果上做一次返回复验，不重新作答/提交。用户要求后续人工验收一次给完整流程、检查点及停止条件，已写AGENTS。

导航补丁后微信实测通过：当前自主route `f70ef23e-20f6-413b-9990-8cdfa801e4d0`从已完成详情真实查看结果，再仅点击一次结果页返回按钮，currentPage直接为同route的plan-detail；未经过final-test，仍显示2/2、已完成、已提交。UI01按用户人工研讨/确认与工具阅读、病例、结果回看组合证据闭合，范围见[微信并行记录](parallel-wechat-acceptance.md)。新课堂研讨到自动生成链及空任务状态等剩余矩阵项仍按实际证据核对，不因自主主线通过宣布T44全部完成。

用户最新明确取消本次320逻辑宽/窄屏专项验收，只要求常规手机正常。UI06范围已改为当前428逻辑宽模拟视口的输入、长内容、滚动/返回及固定栏检查；旧记录中的320未验保留为当时状态，不再构成本次出口缺口。未宣称未测主流机型或真机兼容。用户已在新建自主研讨中发送首问，后续由微信代理继续核对实际新会话和主线，不以已完成私人续问替代。

并行补验取得可持久证据：前端不带coverage全量84文件、437项全部通过，退出0，见[脱敏汇总](frontend-test-results.json)；用户协助真实点击D05教师确认开放和学生确认提交，工具核对已开放/冻结、进度2/2保留及唯一结果`27c58a88-ce35-4b2a-8a97-3cf7fbe418fb`。返回计划只有结果入口且ALREADY_SUBMITTED，无重考。完整操作见[微信并行记录](parallel-wechat-acceptance.md)。发现两处实际显示缺陷并修复：已提交路线摘要误写等待路线完成，改优先显示已提交；教师Demo进度按数组后写覆盖同学生路线，改按最近活动时间选择，并在提交更新路线时间。学生行为13项、analytics5项和Demo路线10项定向通过，受影响Lint/格式/类型通过；最新两处微信渲染复验由同一代理继续，UI01新研讨与320宽尚待人工协助。未把前述旧失败倒写为通过。

用户在80%调整及并行补测之后再次明确调整T44验收：全局前端覆盖率仅作质量报告，不单独阻断本次交付；关键业务/权限/失败边界测试与微信真实流程仍必须通过。退出规则和需求追踪同步，仓库80%配置、coverage范围、后端85%与通用check脚本不变。最新并行报告见[前端补测](parallel-frontend-coverage.md)：适配器定向23项通过，完整coverage命令退出1，statements/lines77.15%、functions64.77%、branches77.83%。这一历史非零结果保留，不因验收规则调整倒写为通过；无需为全局数值继续追加无关测试。微信完整主线与其余必要检查尚未全部闭合，目标不标完成。

用户随后明确将前端覆盖率门禁调整为80%。已将`vitest.config.ts`的statements/lines/functions从85改为80，branches保留80，后端85和coverage源码范围不变；T44退出规则同步。此前覆盖率百分比与失败结果作为当时门槛下的历史证据保留，不能倒写。并行覆盖率验收代理后续按新门槛执行一次集中全量，结果待返回；旧函数覆盖率62.72%仍不足80%，本次配置修改不等于门禁已通过。

提交与开放均使用微信原生`uni.showModal`确认；再次核对微信CLI只提供小程序元素操作，当前无法定位原生弹窗按钮。真实工具流程已证明资料确认、病例三阶段、测试草稿恢复、教师审阅草稿保存、课堂等待及预置结果读取，但UI01–UI04完整主线和UI06窄屏实测仍未通过。保留原有确认交互及其身份、版本、答案快照保护，不为绕过工具限制改动业务页面；不把组件模拟确认或后端提交用例记作微信点击证据。

按[退出规则](../10-verification-exit.md#8-停止规则)停止无差异的重复全量验收。G3后端完整复验通过；前端标准全量测试426项通过，但覆盖率statements/lines77.21%、functions62.72%、branches77.98%低于85%/85%/80%；全局格式受范围外既有归档JSON影响退出1；秘密扫描仅有3个历史指纹仍退出1。合同、Lint、类型、前后端边界和Demo构建通过。本次结论为“主要功能已实施/验收未完成”，不标全绿；解除条件是补足与现有门槛相符的前端覆盖、仓库责任方处理历史指纹/归档格式，以及可真实操作原生确认与320逻辑宽的工具环境。真实开发库、真实Coze、PostgreSQL/生产、真机依计划单列外部未验项。用户明确将学情指标同步留给下一任务，本次仅保留原版样式并显示本人研讨记录。未提交、推送或部署。

继续对照后端教师mutation合同发现Demo同态缺口：失效课堂在后端拒绝保存、请求修改、重试生成及开放，Demo此前只拦截学生重试；Demo保存还会接受重复选项和其他测试的题目ID。已在`demoLearningRoutes.ts`教师mutation入口统一要求active课堂，并对题目身份、题干/选项重复与长度、答案整数、生成状态执行同合同校验。`npx vitest run src/features/learning/infrastructure/demoLearningRoutes.spec.ts`退出0、6 passed；新用例证明失效课堂历史仍可读、四种mutation均拒绝且状态不变，非法编辑无部分写入，合法保存/开放可重放且学生随后能开始测试。`npm run type-check`、受影响文件ESLint/Prettier及`git diff --check`均退出0；`VITE_APP_MODE=demo; npm run build:mp-weixin`退出0。该定向证据不改写此前G3前端全量覆盖率失败结论；微信原生确认框和学情指标同步边界保持不变。

继续做T44 Demo/API只读合同核对后，补齐五处真实差异：病例完成后拒绝新消息但保留原消息幂等重放，重放回应/决策配当前阶段和revision；阅读新start轮换lease，超过30秒的旧间隔不计时；route未published不得单独重试test；已开始作答的路线摘要显示`testing`。测试独立生成失败时，路线完成后仍显示`waiting_test_generation`且禁止开始作答；test重试成功后刷新为`ready_for_test`。另修已提交测试的旧start收据不能重开作答页，而同一submit请求仍回放唯一结果。新增合同用例后`npx vitest run src/features/learning/infrastructure/demoLearningRoutes.spec.ts`退出0、10 passed；学生/教师最终测试行为两文件退出0、20 passed。首次扩充D10断言发现test重试后摘要未刷新，补`refreshTest`后同一10项集通过。最后一次摘要修复后`npm run type-check`、受影响文件ESLint/Prettier、`git diff --check`及Demo小程序构建均退出0。局部合同修复不改变学情原版样式；前端全量coverage、微信原生确认及窄屏仍按前述未通过记录。
