# T44 前端覆盖率并行补测

本次仅补前端 API adapter spec，没有修改运行源码、coverage 配置或覆盖率范围。补测聚焦学生研讨完成后的冻结路线/测试交接，私有续问不得更换完成快照；学生阅读材料与进度租约恢复；教师题目队列、带版本保存与退回；失败生成重试的请求身份；学生重新打开已完成路线后的结果回读。

| 检查                                                                                                                                                  | 结果                                                         |
| ----------------------------------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------ |
| `npm run test -- src/features/pbl/infrastructure/apiPblRepository.spec.ts src/features/learning/infrastructure/apiLearningRoutes.spec.ts`             | 退出 0，2 files / 23 tests passed                            |
| `npx eslint src/features/pbl/infrastructure/apiPblRepository.spec.ts src/features/learning/infrastructure/apiLearningRoutes.spec.ts --max-warnings=0` | 退出 0                                                       |
| `npx prettier --check src/features/pbl/infrastructure/apiPblRepository.spec.ts src/features/learning/infrastructure/apiLearningRoutes.spec.ts`        | 退出 0                                                       |
| `npm run type-check`                                                                                                                                  | 退出 0                                                       |
| `npm run test:coverage`                                                                                                                               | 退出 1，Vitest 全局门槛失败；当次明细见 `coverage/lcov.info` |

统一 80% 门槛下，当次 statements/lines 为 **77.15%**（21,688/28,111），functions 为 **64.77%**（960/1,482），branches 为 **77.83%**（3,909/5,022）。按当前分母达到门槛至少还差 801 行、226 函数、109 分支命中。相对此前记录的 77.21% / 62.72% / 77.98%，函数覆盖提升 2.05 个百分点，行与分支分别变化 -0.06 与 -0.15 个百分点；这次统计的文件/分支分母已变化，不能把整体变化归因到本次两份 spec。

全量输出还出现 `TeacherClassroomReportAnalytics.behavior.spec.ts` 未注册 Vue `picker` 组件的非阻断 warning。所补业务边界未发现运行实现缺陷；当次全量门槛未通过，依退出规则停止继续扩充无关测试。

为补足第一次 coverage 执行未保留的测试计数，随后以相同工作区源码执行不带 coverage 的全量 Vitest：`npm run test -- --reporter=default --reporter=json --outputFile=<temporary raw file>` 退出 0，84 个测试文件 passed、437 项 tests passed，失败和 pending 均为 0。由此确认先前 `npm run test:coverage` 的退出 1 来自全局 coverage 门槛。脱敏结果保存在 `frontend-test-results.json`，仅含汇总计数、文件名、文件状态及文件级计数，不含测试标题、失败消息或栈。

按用户最新决定，全局 coverage 不足只列入 T44 质量报告，不作为交付阻断；通用仓库命令仍会因现有 coverage 门槛返回非零。
