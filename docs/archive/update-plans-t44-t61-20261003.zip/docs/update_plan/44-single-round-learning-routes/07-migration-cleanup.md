# 07 迁移、旧研讨清理与保留数据

状态：T44 计划目标。**本章不是已执行清理记录。** 当前未指定实际受管开发数据库；文档交付不对任何数据库 apply。用户已明确授权清理旧研讨与闭环，执行者无需反复询问产品范围，但必须核实实际资源、备份和完整关联。

## 1. 切换原则

T44实施前的基线为`20260924_0032`，当前源码唯一head为`20260926_0034`；`20260926_0033`建立新对象/脱钩能力，清理工具执行后再由`20260926_0034`退役旧结构。空库及受管历史fixture的升级已有测试证据，不能据此推断任何真实开发数据库已迁移或已清理；实际目标仍按本章顺序切换。

原业务停止写入、完成备份、登记切换清单后，清理**切换前全部旧 classroom/student_initiated PBL session 及其派生闭环**，不留下可继续执行的旧两轮。清理期间不生成新研讨，Demo/开发 seed 在清理和 head 升级完成后写入。

生产/shared/未知数据库不自动升级或清理；本期执行工具只接受已核实受管非生产 SQLite。PostgreSQL 不宣称可直接使用该清理工具。

## 2. 清理清单

| 类别             | 明确删除范围                                                                                                                               |
| ---------------- | ------------------------------------------------------------------------------------------------------------------------------------------ |
| 原研讨           | 旧 pbl_sessions、pbl_participations、pbl_messages、pbl_private_follow_up_results、pbl_diagnostic_snapshots                                 |
| 原建议/审核/反馈 | pbl_question_suggestions、pbl_submissions、pbl_teacher_feedbacks、classroom_question_reviews                                               |
| 自主学习旧对象   | study_paths、study_practice_groups、study_practice_attempts，包括两轮与未完成组                                                            |
| 正式旧对象       | source_type=pbl_suggestion/classroom_package 的 learning_plans、关联 learning_tasks/attempts/evaluations                                   |
| T43 旧对象       | classroom_task_packages、classroom_package_items、classroom_final_reports、t43_legacy_plan_mappings、对应 teaching_command_receipts        |
| 任务派生病例     | learning_task_id 属于已清理任务的 case_attempts、其 messages/stage_submissions/assessments/ai_call_logs；按关联 closure 清理其派生学习对象 |
| PBL 自动卡       | source_snapshot_id 属于旧快照的 AI knowledge_card_contributions、原学生/目标及专用审核/复习关联；手工/目录卡不删除                         |
| 证据             | 源指向上述研讨、练习、任务、评价、任务派生 assessment 或结果的 event+metric                                                                |
| 通知/复习        | 明确 entity/source 指向清理集合的通知、review items、关联 review state/attempt；不按知识点整组删除                                         |
| 旧审计辅助       | 只属于旧调用的最小 audit/ref 数据及转换回执；不删无关安全记录                                                                              |

旧 pbl suggestion 已复制成独立教学 `Problem` 时保留公开内容，将 ProblemOrigin 脱钩为 legacy_detached，不能保留可回查学生研讨的旧 source ID。未复制的 suggestion 本身删除。

旧 closure 中出现单独 source_assessment learning plan 时，依据其 assessment 是否属于任务派生病例判断；只有源 assessment 属于旧任务 closure 才删除。不能把所有 case_assessment 计划视为 PBL 任务清空。

## 3. 保留清单与证明

| 保留对象                                                      | 清理前后证明                                                        |
| ------------------------------------------------------------- | ------------------------------------------------------------------- |
| users、classes、class_members                                 | ID 集合及必要非敏感结构摘要一致                                     |
| active catalog、模块/知识点/边、sources/materials             | 版本、节点/边/来源数量、canonical digest 一致                       |
| 独立 Problem/病例/人工知识卡                                  | 内容 digest、status/version、owner 关联一致；仅指定旧来源字段可脱钩 |
| 独立 case_attempt/assessment/messages及其plan/task/evaluation | 与旧task closure无关联的ID、内容与评价摘要一致；不全局删共享字段/表 |
| 教师题库 item/revision/archive 状态                           | 题干/选项/答案/解析/版本/owner digest 一致；来源字段按脱钩方案变化  |
| 无关 ordinary QA、历史问答报告                                | ID/摘要一致，不纳入 PBL 清理                                        |
| 无关 evidence/notification/review                             | 非目标 ID 集合不减少；不能清空整个表                                |

清理报告只输出类别计数、完整性结果和受管资源标识摘要；备份文件和 manifest 按受管敏感资源处理，不写学生内容到 delivery。

## 4. 0033：建立新结构与可脱钩来源

1. 按[领域模型](04-domain-state-machines.md)建 route/step/case/test/attempt/result/receipt 表、唯一索引和 scope check。
2. 给题库 revision/import receipt 增加通用 source_kind/source_public_id/source_digest；原 source_package_item_id 改 nullable，并准备移除强制依赖。
3. 为每个旧 package item 建临时一致来源映射，同来源的题库版本共享一个新的匿名 UUID；source_kind=legacy_detached，digest 和副本内容保留。新的 UUID 不可解析回旧学生或旧任务。
4. 导入回执保留 request identity 与 bank item 关系，但切断旧 package FK；旧来源再导入固定拒绝，不用历史回执重建任务。
5. 建 `t44_cutover_manifests`，记录切换 token、目标资源摘要、原 head、计划删除计数、保留摘要和 ID 高水位；不存原文或密钥。
6. 旧 PBL 数字 locator 不能重用。SQLite 的 session/participation/snapshot 主键采用单调 AUTOINCREMENT，迁移及清理保留旧 max ID 高水位；新表公开 UUID 不受清空旧整数影响。
7. 新 schema version=8 的枚举/默认与 source scope 准备就绪，但在切换完成前不启动新业务 seed。

0033 默认只改 schema 和必要来源映射，不删除研讨、任务或证据。初始迁移使用当前 metadata 的历史行为要在临时库验证：空库路径与真实 0032 旧结构路径都必须覆盖，不能只用新 ORM create_all 冒充历史升级。

## 5. 一次性清理工具合同

待新增 `backend/scripts/cleanup_t44_learning.py`，不是现有可执行命令。参数明确为：

| 参数                         | 规则                                                                                         |
| ---------------------------- | -------------------------------------------------------------------------------------------- |
| `--database`                 | 必填绝对 SQLite 文件路径，验证规范路径/链接边界与受管资源身份                                |
| `--dry-run`                  | 默认，仅读；输出类别、保留检查、阻塞项，无 AI/seed/网络                                      |
| `--manifest`                 | 必填；dry-run为新文件输出路径，apply为同一冻结manifest输入；含目标ID/摘要和切换token，无原文 |
| `--apply`                    | 写入模式，不能与 dry-run 同时使用                                                            |
| `--confirm-development`      | apply 必须提供，同时拒绝生产/共享/未知资源                                                   |
| `--backup`                   | apply必填新绝对路径，备份0033状态；一致性备份并在受管副本验证可恢复                          |
| `--baseline-backup`          | dry-run必填升级0033前原head的完整备份路径；登记至manifest，apply核实它仍可读且摘要一致       |
| `--expected-manifest-digest` | apply 必填，实际集合或保留摘要变化时拒绝，要求重新 dry-run                                   |

受管测试 fixture 可使用 launcher-owned marker/token；受管开发资源沿用既有 ownership 校验方式，不创造“路径叫 dev.db 就安全”的判断。数据库目标未核实只停 apply，仍可完成文档和临时库逻辑验证。

执行示例只使用占位的受管目标，不能把仓库默认 dev.db 写成允许自动清理的实际地址：

```text
python backend/scripts/cleanup_t44_learning.py --database <受管绝对路径> --dry-run --manifest <新manifest路径> --baseline-backup <升级0033前的完整备份>
python backend/scripts/cleanup_t44_learning.py --database <同一受管路径> --apply --manifest <同一manifest路径> --confirm-development --backup <0033状态新备份路径> --expected-manifest-digest <刚核实摘要>
```

工具先扫描数据库 FK 和明确 polymorphic source 映射。发现未知关联、同 ID 跨 source type 歧义、保留项被纳入 closure、备份失败或 manifest 陈旧时拒绝 apply，不能猜测后继续。

## 6. apply 的严格顺序

1. 确认停写、0033 已应用、备份完整、manifest 一致，记录切换 token。
2. 题库和独立教学副本先脱钩，比较内容/版本摘要；任一不一致立即回滚。
3. 删除精准关联的证据 metrics→events、通知、复习引用与派生审计。
4. 先处理 closure 内 learning_plans.source_assessment_id、learning_tasks.source_attempt_id 等指向待删病例的反向引用：待删行的 nullable 指针先置 NULL，或按拓扑先删该依赖；任何保留对象仍引用待删集合则拒绝 apply，不能自动置空保留侧字段。解除集合内部引用后，再删除派生病例子记录、assessment/attempt及仅由其产生的派生计划。
5. 删除旧 feedback/medical review/转换映射/报告/回执等依赖对象。
6. 删除自主 attempts→groups→paths；旧 task attempts/evaluations/tasks/plans；包 item/package 的循环引用先解除，再删主体。
7. 删除 PBL 自动卡及其专用依赖；保留人工/目录卡。
8. 将旧 participation completion_snapshot_id 清空以解除循环 FK；删除 private results、submissions、suggestions、messages、snapshots、participations、sessions，按实际 FK 拓扑确定子到父顺序。
9. 核对清理集合为零、保留摘要匹配、FK integrity、旧 ID 高水位未倒退；全部成立才提交事务及 cutover 完成标记。

顺序以上述依赖为原则，不能关闭 FK、清空全库或删除保留对象来绕过 RESTRICT。失败 rollback 保留原 schema/data 和错误类别；部分删除成功不能视为清理完成。

统一 evidence 的删除是本次特定切换例外，日常写入仍 append-only，无公开 DELETE 接口。删除 dedupe_key 仅限目标 closure，不按前缀大范围误删其他事件。

## 7. 0034：移除旧结构

先检查 cutover marker、旧关联 count=0、保留项一致。空临时库没有旧数据时允许建立等价空切换标记后继续，不需要真实开发库清理。

删除旧专用 study practice/path、classroom package/item/report、question review、T43 mapping，以及 PBL suggestion/submission/旧反馈专用结构；新的测试反馈走 route_test_review_events。

保留 PBL sessions/participations/messages/snapshots/private_follow_up 结构用于新的研讨，去掉 snapshot 的双轮 candidate fields 和旧在线 schema 路由。learning_plans/tasks 继续服务独立病例，不在0034全局删它们的共享字段或 learning_plan_evaluations 表。current_cycle/max_cycles/automation_exhausted、variant/cycle及evaluation仅保留独立能力/既有历史兼容用途；删除的是PBL双轮用例、判定器、公开输入与调度分支，新route/test/result不读写这些字段。清理只删除目标plan关联的evaluations，非目标独立plan/task/evaluation必须保留。

移除题库旧 package FK/字段、旧 metadata 注册、兼容 re-export、旧脚本运行入口和 seed。旧迁移文件保留，不改写历史链。可读旧报告路径不以新对象替代同 ID。

0034 有旧数据、来源未脱钩或新结果需要回退时明确拒绝 downgrade。测试需验证 upgrade/reject/空库及高水位行为，不得为了降级成功删新业务数据。

## 8. 业务切换与恢复

受管目标完成 0033→dry-run→备份→apply→0034 后，启动新 runtime、刷新 API contract、运行新 seed（仅 Demo/明确开发 seed），清理客户端旧业务集合版本并保留身份/无关内容。

新数据出现后的回退优先前向修复；必须恢复旧系统时停写、保存新数据快照、恢复切换前完整备份并匹配旧代码。不能声称 schema downgrade 能恢复已删除研讨或合并新旧成绩。

实际开发/共享/生产资源清理在 delivery 单独记录。G1 临时库验证不代表这些资源已清理，不因缺少实际资源而反复跑全量验收。

## 9. 防止再次清理新研讨与启动跨过切换

dry-run只写指定manifest文件，不写数据库标记；apply读取同一文件并核对传入digest与资源/head，成功事务才写数据库cutover完成标记。manifest必须冻结切换前session/participation/snapshot的目标ID集合及高水位，closure从该集合扩展；不能每次 apply 都重新选择数据库里的全部 PBL。0033 时新 route/test 表必须为空，停写后采集一次 cutoff。发现已有新 route、切换已完成 marker 或目标资源/head不符时拒绝新的 apply；同 token 已成功执行的重放只读返回原切换摘要，绝不再扫描删除新会话。

运行新程序之前不得直接执行自动 `upgrade head` 越过清理。当前 `backend:dev`、`backend:migrate`、seed等入口会升级head，0034必须以旧数据/切换标记预检阻止这类误启动；禁止把失败变成自动清理。真实受管目标先停写并固定0033 revision，执行dry-run→备份→apply，再显式升0034，最后启动匹配新schema的应用。采用SQLite一致性备份，恢复演练串行且只针对受管副本。

空库可从历史链升到新head，必须单独覆盖；0032有数据 fixture 升0033并清理后升0034也必须单独覆盖。动态读取当前metadata的早期迁移不能用于伪造0032旧库；fixture来源应是独立固定旧DDL/旧schema快照，校验当前ORM未提前改变该基线。

## 10. 共享结构与 FK 闭包的保留出口

源码依据：learning/infrastructure/models.py 的 LearningPlan.source_assessment_id 和 LearningTask.source_attempt_id 是无 ON DELETE 的可空外键，不能先删病例父对象再猜测依赖可删；LearningPlanEvaluation 不是只靠表名就能证明PBL专用。0033/cleanup只对冻结typed closure操作，0034只退役确定专用的表。

manifest 增加所有“保留对象→目标对象”边的阻塞摘要和共享表非目标行摘要。apply先验证阻塞边为零，所有指针调整只属于待删除行，最终 FK integrity 成立。共享评价/计划/任务字段保留不等于保留PBL双轮运行：旧PBL写接口已退役，PBL mastery/intervention不再装配，新路线状态与计分完全走新表。不能为了rg字样归零破坏独立内容。

DB04/DB06补一个独立case→assessment→plan/task/evaluation完整保留fixture；DB05补一个目标task→派生case→assessment→派生plan的循环引用fixture；分别证明保留摘要不变和正确拓扑清理。对保留行跨入目标集合的非预期引用必须拒绝并说明阻塞类型，不自行扩大删除范围。

## 11. 两份备份与回退的匹配版本

实际受管目标停写后，**升级0033前先完成原head完整备份B0**，记录原schema/head、代码版本、资源所有权、校验摘要及可恢复性。B0作为baseline-backup进入manifest，用于恢复原0032系统；不能把已改题库来源结构的0033备份当作原版本备份。

清理apply的 --backup 另建立0033状态备份B1，用于恢复清理前的0033维护状态。apply同时核实manifest中的B0仍可用和B1已完成；B0/B1都不覆盖已有文件。先在受管副本验证恢复，不能把备份覆盖当前工作库。实际回退原系统使用B0加匹配旧代码；B1只能搭配0033维护环境，不能直接启动旧0032应用。未指定真实目标时只实现与验证这套协议，不执行真实备份/迁移。
