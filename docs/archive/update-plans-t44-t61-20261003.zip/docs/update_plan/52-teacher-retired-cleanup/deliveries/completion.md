# T52 收尾交付

2026-09-30。已收尾，人工待验：[MA-T52-001](../../../manual-acceptance.md#ma-t52-001)。未提交、未推送，所有改动在既有暂存源码上增量完成，未重置已有工作。

## 交付范围

- 删除教师无入口的问题统计、普通问答报告批阅、独立病例学情三个页面，同步移除 pages.json 注册、ROUTES 与已失效测试。
- 删除未挂载的 TeacherAnalyticsOverview、TeacherDefinitionList 和旧 WorkItems → WorkItemList → FilterPanel 组件链；保留当前 TeacherPblHome、课堂创建及有效页面。
- 固定诊断详情移除建议题发布展示、反馈编辑、目标学生/全班选择、终态关闭/发布操作、旧版诊断与历史任务指引及相关状态、事件、样式。保留证据、知识缺口、推理问题、历史反馈和关联测试审阅入口。
- PBL public/port/API/Demo 同步删除旧反馈写入、建议题编辑/采用、旧跟进、旧教师轮次结果与汇总。保留有效诊断读取、历史反馈读取、当前看板/课堂操作、学生历史报告读取和兼容拒绝行为。
- analytics public/port/API/Demo 删除四个旧 getAnalytics* 方法与旧映射/Demo 数据；当前 getClassroom* 统计保持有效。
- 学情标签改为“知识点作答”，旧任务包说明改为学习路线，首页描述改为实际学习进度与测试结果；移除无生产调用的旧轮次展示映射。

保留两个旧地址重定向、后端退役响应、生成契约和数据库历史；未恢复关闭课堂入口，未扩大至学生历史流程或数据库清理。

## 门禁与逻辑证据

计划先于运行代码，格式、相对链接、空白及项目技能检查通过。主代理选择检查，Luna xhigh 执行定向/最终验收；主代理核对增量差异、无残留引用、当前 API/Demo 与开发产物。

| 命令                                                                                                                                   | 退出码 | 结果与证据                                                                   |
| -------------------------------------------------------------------------------------------------------------------------------------- | ------ | ---------------------------------------------------------------------------- |
| `python scripts/check-project-skills.py`、`--self-test`                                                                                | 0      | 技能结构与负例自检通过                                                       |
| `npx vitest run src/components/teacher src/pages/teacher src/platform/navigation`                                                      | 0      | 25 文件、161 项；[日志](../../../../output/t52/vitest.log)                   |
| `npx vitest run src/features/pbl/infrastructure/apiPblRepository.spec.ts src/features/pbl/infrastructure/demoPblRepository.spec.ts`    | 0      | API/Demo 2 文件、15 项，删除读写适配后复核通过                               |
| `npm run test -- src/features/analytics`                                                                                               | 0      | 当前统计 API/Demo 2 文件、10 项                                              |
| `node scripts/frontend-boundaries.mjs`                                                                                                 | 0      | 200 个实现文件；[日志](../../../../output/t52/frontend-boundaries.log)       |
| `npx eslint src/components/teacher src/pages/teacher src/platform/navigation src/features/analytics src/features/pbl --max-warnings=0` | 0      | [最终日志](../../../../output/t52/final-eslint.log)                          |
| `npm run type-check`                                                                                                                   | 0      | [日志](../../../../output/t52/final-type-check.log)                          |
| `npm run test`                                                                                                                         | 0      | 全量 87 文件、451 项通过；[日志](../../../../output/t52/final-test.log)      |
| `npm run build:mp-weixin`                                                                                                              | 0      | 小程序生产构建完成；[日志](../../../../output/t52/final-build-mp-weixin.log) |
| `git diff --check`                                                                                                                     | 0      | [日志](../../../../output/t52/final-diff-check.log)                          |

首次定向测试 exit 1：一项断言仍引用旧“学生提交”轨迹，修正为当前研讨完成轨迹后 161 项通过。首次 ESLint exit 1：删除旧组件测试后 `vi` 导入闲置，移除后最终 exit 0；[首次失败日志](../../../../output/t52/eslint.log)保留。测试有 uni-app 原生标签在 DOM 环境未解析警告；构建有依赖注释标记提示，未造成失败。

## 微信工具与未验范围

复用当前 Demo watcher PID 20728；开发 app.json 不再注册三个退役页面，生成诊断 WXML 无旧操作/提示并包含固定诊断新轨迹。开发产物核对只证明代码已生成，不替代渲染。

支持的 CLI 普通刷新、真实点击教师登录、工作台文字读取成功。`npm run test:mp:doctor` exit 0，URL 校验开启，SDK 3.17.2，视口 428×835。组件导航定位两次失败后停止；[工具记录](../../../../output/t52/wechat-runtime.json)。未取得诊断详情、测试审阅入口与返回的最终交互/截图证据，按 MA-T52-001 交接，正式发布前补验。未运行后端测试、契约生成或数据库命令，因为本轮不改这些合同；API 生产及真机未经本轮验证。

## 回退

按本次工作区增量恢复所删页面/组件、导航和适配方法；不使用仓库级 reset/checkout，不覆盖原有暂存与历史记录。三份本轮编辑辅助脚本已删除，验收日志作为有效证据保留。
