# T63 实施与验收记录

## 基线与授权

2026-10-03，工作区 D:/CODE/weixin/wxprogrom7.15。用户要求先计划、再实现功能修剪。已读取git status并确认大量已有改动；仅增量编辑本次范围，不提交/推送，不删除现有数据。

## S0

计划文件已建立并通过门禁，检查前运行代码尚未修改。

- `npx prettier --write/check docs/update_plan/63-content-learning-pruning/*.md docs/update_plan/63-content-learning-pruning/deliveries/*.md`：exit 0。
- 本地链接目标与尾随空白检查：exit 0。
- `python scripts/check-project-skills.py`：exit 0。
- `python scripts/check-project-skills.py --self-test`：exit 0。
- `git diff --check -- docs/update_plan/63-content-learning-pruning`：exit 0。

## S1 教师内容入口

已完成。TeacherContentResources / TeacherContentScreen只保留病例库与个人题库，移除讨论题、补充卡、历史管理及重复最近发布区。资源类型与偏好按身份保留合法筛选；旧资源参数统一回病例库并清理旧关键词/状态。病例审核入口只在病例类型按审核角色显示；个人题库仍可从最终测试保存单选题，独立筛选、编辑及归档。

旧教师 problem-edit / knowledge-cards 为角色保护跳转壳；历史非病例详情不能恢复编辑。教师导航、内容、医学审核返回和偏好定向检查：首轮45 passed / 1 failed，旧医学审核返回断言修正后5个受影响文件36项通过，exit 0。保留流程另由S4的59项回归覆盖。

## S2 API 与 Demo

已完成。Content活动问题仅投影 guided_case，非病例详情404、写入409 `RETIRED_FLOW`；教师补充卡及审核队列为空、写入409。QA旧学生问题列表为空、详情/线程404、旧作答写入409，普通会话继续保留。Learning旧独立小测、回忆、复习捕获/移除写入409，旧队列/dashboard稳定为空；knowledge-map保留。权限先校验，历史模型、记录和证据未删除，未新增迁移。

Demo三个仓储同步以上边界，未清除存储或回退当前路线；正规病例保存/审核发布与个人题库不变。定向13个文件50项通过，exit 0；11文件ESLint及格式exit 0。旧generic问题写入关闭，正规病例继续使用专用saveGuidedCase入口。

后端定向 `python -m pytest` 65项通过，exit 0；首轮旧成功合同及测试构造不完整已修正，再验证通过。`python -m ruff check .`、`python scripts/check_boundaries.py`均exit 0，9模块。

定向准确命令（cwd=backend）：`python -m pytest tests/test_api.py tests/test_data_layer.py tests/test_case_hardening.py tests/test_second_phase.py tests/test_t08_knowledge_review.py tests/test_t53_retired_cards.py tests/test_t53_content_action_summary.py tests/test_t63_content_learning_pruning.py tests/test_t05_content_application.py -q`。

后端全量 `python -m pytest -q` 一次：347 passed / 1 failed，exit 1，634.61s。唯一失败test_database_safety的E2E合同仍要求活动列表返回7条（包含1条旧讨论题），改为活动6个病例且只读SQL核对数据库仍7行，不修改launcher、seed或数据库配置。首轮复验新增SQL连接未显式关闭导致Windows临时库清理失败，改用contextlib.closing后，`python -m pytest tests/test_database_safety.py::test_e2e_launcher_seeds_api_data_and_matches_cors_origin -q --tb=short`：1 passed，10.31s，exit 0。Ruff和后端边界再次exit 0。未重跑全量，其他347项通过证据复用。见[后端脱敏记录](../../../../output/t63/backend-full.log)。

## S3 学生入口

已完成。学习首页自主学习只保留病例学习/知识点学习，移除教师练习入口；病例列表去除旧开放讨论。knowledge-loop按合法知识点跳知识节点，无参数/无效参数回学习首页；旧question-detail回病例列表。兼容壳不读取卡片或发起复习，身份变化拒绝迟到导航。7个文件59项定向检查、受影响Lint/格式exit 0。

## S4 集成与微信

Luna xhigh执行所选验收并返回精简日志。`npm run type-check`、前端边界216文件、`npm run contract:check`、38文件ESLint、39文件Prettier均exit 0。契约无变化，无需生成或手改。病例编辑/最终测试/题库/知识节点/路线5文件59项保留回归exit 0。

`npm run test -- --maxWorkers=4`：111文件中110通过，589项中587通过/2失败，exit 1。唯一失败page-navigation.spec仍把3个已退役地址视为二级详情页；定向确认后调整为角色保护及共享导航跳转合同，新增1项。修复后该文件7项通过，ESLint/格式exit 0；未重复全量，其他110文件的通过证据复用。详见[集成日志](../../../../output/t63/acceptance-final-test.log)、[修复复验](../../../../output/t63/acceptance-final-navigation-repair.log)。

显式 `VITE_APP_MODE=demo npm run build:mp-weixin` exit 0；只有依赖zod的Rollup注释处理提示。复用现有Demo watcher（PID6960）及开发目录，不启动/终止用户watcher，不改dist。开发原生WXSS73文件、生产71文件均exit 0。工具普通刷新ok=true；doctor最终exit 0，SDK3.17.2、URL校验开启。

微信CLI使用 `D:/codeapp/微信web开发者工具/wechatide.cmd -c Codex`，项目为 `D:/CODE/weixin/wxprogrom7.15/dist/dev/mp-weixin`。真实教师登录点击、学生登录点击均ok=true。正式页面导航到内容病例/题库并截图；直接导航只证明页面可打开，不算标签点击通过。学生学习首页真实点击 `.practice-card--knowledge` 后运行时为knowledge-node / pathology.cell-injury.adaptation，未进入独立小测。548×1182截图已逐张审阅：

- [病例库](../../../../output/t63/teacher-cases-final.jpg)：两类资源、病例创建与底栏可读；当前保存数据为空，只验证空态。
- [个人题库](../../../../output/t63/teacher-bank-final.jpg)：在用/归档、搜索及入库来源说明可读，无旧卡片入口；当前为0道空态。
- [学习首页](../../../../output/t63/student-learning-final.jpg)：原AI计划、最终测试入口与底栏保留；未取得页面底部卡片的可见截图。
- [知识节点](../../../../output/t63/student-knowledge-final.jpg)：学习目标、准备资料、知识关联及开始研讨保留，固定行动区无遮挡。

教师资源组件内真实定位两次no such element，停止继续试探。学生根view的scrollTo返回ok但画面未移动，不将其认定为滚到底；知识点学习按钮真实tap及导航已通过。旧错误地址曾产生WXML not found，系验收路径误写，更正为注册页面后正常；错误图与重复未移动图不作为通过证据并清理。微信摘要见[记录](../../../../output/t63/wechat-validation.md)。

剩余人工交互/底部画面按[MA-T63-001](../../../manual-acceptance.md#ma-t63-001)登记；不要求立即配合。未运行API生产、真实AI全链及真机；复用当前路线/最终测试行为检查，不伪称全链实际操作通过。不提交/推送，不清库。

文档范围Prettier、本地链接/尾随空白和相关增量`git diff --check`均exit 0；临时修剪脚本、错误路径截图、重复未滚动截图已删除，最终代表证据保留。

收尾：S0–S4完成，人工待验MA-T63-001，未提交/推送。三份失败pytest受管资源已通过所有权helper清理；首轮新增只读连接产生的E2E临时残留 `C:/Users/adj/AppData/Local/Temp/medical-qa-e2e-4_ejhnk3/app.sqlite3` 的精确非递归删除被自动审批拒绝，理由仅为 `blocked by policy`，未改用其他方式绕过。该临时文件仍保留，不影响最终测试结果或产品运行。
