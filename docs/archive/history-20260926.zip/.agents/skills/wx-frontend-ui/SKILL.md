---
name: wx-frontend-ui
description: Design, implement or audit WeChat Mini Program pages and components in this Vue/uni-app repository.
---

# WX Frontend UI

Design for pathology PBL teaching: clear evidence, truthful states and an obvious next action. Use the existing Vue 3/TypeScript/uni-app stack and sound shared tokens; scope corrections to affected consumers.

## Choose the needed guidance

- Layout, hierarchy, controls or accessibility: read the relevant [quality-bar](references/quality-bar.md) and [frontend design](../../../docs/frontend/design.md) sections. Apply page → module → record → field grouping; distinct modules need surfaces, homogeneous records need spacing/dividers, and each page has at most one strongest focus.
- New pages or substantial redesigns: use [design workflow](references/design-workflow.md). A compact direction can live in the response. A narrow style/copy fix needs only the affected state and rules.
- A specific design/UX question needing local retrieval: [knowledge](references/knowledge.md). Routine fixes require no search. [Sources](references/sources.md) records pinned origins and licenses.
- Business reads/writes or navigation: use [frontend public interfaces](../../../docs/frontend/public-interfaces.md) and [current product contract](../../../docs/product/features.md). Historical navigation labels do not override verified routes.
- Implementation and rendered evidence: [verification](references/verification.md). Pure skill/document maintenance does not require application builds.

Preserve long-text, loading, empty, error and disabled states that the affected flow can reach. Keep labels consistent with outcomes, entered text recoverable, and fixed controls clear of content and safe areas. Check inherited selectors before reusing shared styles.

For audit-only requests, report evidence-backed findings with locations and impact; make edits only when requested. Distinguish defects from preferences and unverified runtime behavior.

Complete implementation through the affected Demo flow and inspected Developer Tools rendering, fixing observed failures within scope. Build/DOM results do not prove Mini Program rendering; record missing evidence. Follow [AGENTS.md](../../../AGENTS.md) for update routing.
