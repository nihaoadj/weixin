---
name: wx-engineering-standards
description: Route code or engineering-rule changes in this repository to the applicable contracts and checks.
---

# WX Engineering Standards

Use [AGENTS.md](../../../AGENTS.md) for the project entry point. Check the worktree before editing; preserve unrelated work. User instructions and existing authorization govern the task; this skill adds no approval step.

Select only the relevant route:

- Functional changes: [engineering workflow](../../../docs/operations/engineering-workflow.md) defines UpdatePlan, verification and delivery. Ordinary maintenance needs no new plan or delivery directory.
- Business behavior: [current product contract](../../../docs/product/features.md). For implementation status or resumed work, check [plan and evidence index](../../../docs/update_plan/README.md); distinguish 当前事实 from 计划目标.
- Frontend data/contracts: [data layer](../../../docs/data-layer.md) and [public interfaces](../../../docs/frontend/public-interfaces.md); structural checks use `node scripts/frontend-boundaries.mjs`.
- Backend modules: [module map](../../../docs/backend/module-map.md) and [architecture](../../../docs/architecture.md); apply R05 public-contract/port boundaries, check with `python backend/scripts/check_boundaries.py`.
- Database or AI/identity/sensitive data: read the applicable [database](../../../docs/backend/database.md) or [security](../../../docs/governance/security.md) section before changing that boundary.
- Demo-visible changes: [WeChat validation](../../../docs/operations/wechat-validation.md), independently of whether an UpdatePlan is needed. UI work uses [wx-frontend-ui](../wx-frontend-ui/SKILL.md).

For substantial delivery records, use [the template](references/delivery-template.md) as applicable. Keep build, logic, interaction, rendering and external evidence distinct.

When maintaining project skills, run `python .agents/skills/wx-engineering-standards/scripts/self_check.py --self-test` and `python .agents/skills/wx-engineering-standards/scripts/self_check.py`. These validate structure and routing, not runtime behavior or external acceptance.
