# 病理学 PBL 教学助手

唯一产品端为微信小程序。前端使用 uni-app、Vue 3、TypeScript、Vite；后端使用 FastAPI、SQLAlchemy、Alembic，开发与受管测试使用 SQLite。PostgreSQL 尚未完成验证。

## 开发要求

- 编辑前查看 `git status`，保护已有暂存、未暂存和未跟踪工作；只修改本次范围，不恢复他人删除的文件。提交、推送须用户明确授权。
- 页面通过 `src/features/*/public.ts` 使用业务能力，`src/bootstrap/wiring.ts` 是唯一 API/Demo 装配点。后端跨模块协作通过 `public.py` 或明确 port；API 失败必须显式报错，不自动回退 Demo。
- 授权和数据范围由服务端校验；客户端、日志和取证不得泄露服务端秘密、完整学生回答或病例隐藏字段。生成契约通过脚本更新，不手改生成物。
- 改变业务流程、数据、公开合同、权限或运行边界时，先按[工程工作流](docs/operations/engineering-workflow.md)建立或更新 UpdatePlan 并通过计划门禁。纯文档、规则及不改变行为的局部展示维护可直接实施。
- Demo 可体验的运行变更必须同步 Demo，并按[微信验收规范](docs/operations/wechat-validation.md)验证受影响的最小流程：显式 Demo watcher、`dist/dev/mp-weixin`、工具普通编译、真实交互和必要的当次内部截图审阅。
- 验证与改动相称；全量集中在集成或发布检查点，达到目标后停止。记录命令、退出码和未验收项，不把构建、Demo 或历史结果当作真实服务、渲染或生产证据。

## 子代理分工

- 范围明确、可独立交付的简单任务（如文件检索、文档检查、既定测试执行）默认交给 `gpt-6-luna` 子代理，设置 `reasoning_effort='xhigh'`。只传必要文件、输入、输出和完成条件，使用 `fork_turns='none'` 或少量相关轮次，避免复制整段历史。
- 到达计划验收节点时，主代理先确定本节点的检查范围，再自动启动 Luna xhigh 子代理执行测试，返回命令、退出码、失败摘要及证据路径；不自行扩大测试范围或降低门槛。主代理处理修复、核实结果并判断是否达到出口。
- 共享数据库、Demo watcher、微信工具和同一测试产物的操作保持串行；复杂业务或架构决策由主代理负责。子代理不可用时明确说明并由主代理继续完成。

## 按任务查阅

只读本次任务需要的章节，不要求每次编辑读完整文档集。

| 任务                                     | 权威入口                                                                                                                                                              |
| ---------------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| 功能、角色、阶段、评分、隐私与内容审核   | [当前产品合同](docs/product/features.md)；涉及实施状态或接续工作时核对[计划与交付索引](docs/update_plan/README.md)                                                    |
| 模块边界与跨模块依赖                     | [架构](docs/architecture.md)、[前端公开接口](docs/frontend/public-interfaces.md)、[后端模块图](docs/backend/module-map.md)                                            |
| API/Demo、数据读写、会话、缓存、生成契约 | [数据层](docs/data-layer.md)                                                                                                                                          |
| 数据库、迁移、清理与恢复                 | [数据库](docs/backend/database.md)及[工程工作流的数据库规则](docs/operations/engineering-workflow.md#数据库与生成物)                                                  |
| 授权、AI、凭据与敏感数据                 | [安全边界](docs/governance/security.md)                                                                                                                               |
| 页面、组件与视觉修改                     | [前端设计](docs/frontend/design.md)、`wx-frontend-ui` 技能；运行验收用[微信验收规范](docs/operations/wechat-validation.md)                                            |
| 命令、测试或发布                         | [开发命令](docs/operations/development.md)、[工程验证路由](docs/operations/engineering-workflow.md#按改动选择验证)；发布时读[部署要求](docs/operations/deployment.md) |

## 指令维护

个人偏好维护在全局 `AGENTS.md`；本文件只保留项目简述、开发要求和查阅入口。产品合同写入产品文档，阶段状态与证据写入计划索引及交付记录，专项操作写入对应文档或技能引用。计划不证明实现，已收尾阶段不自动恢复验收；修改功能时核对实际源码与适用合同。

项目技能按具体任务选用：`wx-engineering-standards` 路由工程变更，`wx-frontend-ui` 处理 UI，`code-review-and-quality` 审阅指定代码差异，`screenshot` 仅处理用户要求的桌面截图。不要把历史成果、旧规则快照或同一段要求重新堆回入口。
