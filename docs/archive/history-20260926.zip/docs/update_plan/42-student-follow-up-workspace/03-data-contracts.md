# 03 数据与组件合同

## 页面组合合同

详情页维持两个相互独立的读取状态：

```text
route.planId
  → getTeacherPblFollowUp(planId)
  → authorized plan
       ├─ 立即渲染本课概况/判定/任务/评价
       └─ getAnalyticsStudent(plan.student_id, plan.source_context.class_id, dateFrom, dateTo)
            → 渲染整体学习情况
```

- 路由 `classId` 只用于返回上下文；数据查询的 studentId/classId 必须来自已授权 PBL plan。
- `dateFrom/dateTo` 为详情加载时计算的最近 30 个自然日（含当日），两个值随本次页面实例保持稳定。
- PBL 请求失败时不发起 analytics 请求。
- analytics 请求失败时不得清空或遮挡 PBL 详情；允许单独重试。
- 请求令牌分别保护 PBL 主请求和学情请求，避免快速重入让旧响应覆盖新状态。

## 组件输入

`TeacherPblFollowUpDetail` 新增 `learning?: AnalyticsStudent`、`learningLoading: boolean` 与 `learningError: string`，并新增 `retryLearning` 事件。组件仍接收 PBL `detail/loading/error` 与 `retry`，不自行请求、不读取路由、不访问 storage，也不接收或触发任何反馈写操作。

## 确定性展示映射

### 学生身份

- `learning.student.nickname.trim()` 非空时作为姓名。
- analytics 未返回或失败时显示 `学生编号 ${plan.student_id}`。
- 班级、课堂与专题始终来自 plan，不用 analytics 覆盖课堂上下文。

### 本课任务概况

- `completedTasks = tasks.filter(status === 'completed').length`。
- `totalTasks = tasks.length`。
- 当前轮次使用 `current_cycle/max_cycles`。
- 课堂结果复用既有 verification/decision 展示映射。
- “研讨已完成”来源于正式 plan 已由完成诊断创建这一业务前置条件，不从客户端聊天推断阶段细节。

### 整体学习指标

- 正式活动：assigned 非空时显示 `completed ?? 0 / assigned`；assigned 为空而 completed/started 有值时显示“已记录 N 项”；均为空显示“暂无正式记录”。
- 完成率、均分、改善均保留后端 `null` 语义，不以 0 代替。
- 改善 > 0 显示 `+N`，=0 显示 `0`，<0 显示负数。
- 维度只显示 `sampleCount > 0` 或至少一个分数字段非空的记录；值优先 `currentScore`，其次 `averageScore`。
- 病例按 `lastAssessedAt` 降序，空时间稳定排后，最多显示 3 条；排序基于副本，不修改 props。
- 不用 timeline、learningPlan 或 practiceMastery 与 PBL 正式任务混写；这些旧合同继续保留兼容，但本次不制造重复模块。

## API / Demo

- API 仍调用 `/analytics/students/{student_id}` 与现有 PBL follow-up endpoint；无 schema 变化。
- Demo `getAnalyticsStudent` 返回与学生 ID 对应的合成姓名和非空正式统计，用于验证整体学习模块；数值必须保持内部一致。
- Demo 文案继续说明是合成教学记录，不得作为真实 AI、授权或生产证据。
- API 模式任何失败都显式呈现，不切换 Demo。

## 权限与数据最小化

- analytics 与 PBL 两个 adapter 均经 bootstrap 装配和各自 public API；页面不直接请求。
- classId 使用 plan 内服务端授权上下文，防止路由篡改造成跨班读取。
- 页面只展示聚合指标、公开任务题面和当前学生结果，不展示原始答案、隐藏证据、其他学生或教师内部字段。
- 不恢复 `sendTeacherPblFollowUpFeedback` 导出，不新增编辑器或 action。

## 无合同变化结论

本次不修改后端、OpenAPI、生成类型、PBL/analytics port 或 `src/bootstrap/wiring.ts`。如实现中发现现有字段不足，必须先修订本计划，不能在 UI 中推断新业务事实。
