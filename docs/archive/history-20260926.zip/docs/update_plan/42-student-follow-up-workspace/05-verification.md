# 05 验证与验收

## 文档门禁

```powershell
npx prettier --check "docs/update_plan/42-student-follow-up-workspace/**/*.md"
python .agents/skills/wx-engineering-standards/scripts/self_check.py --self-test
python .agents/skills/wx-engineering-standards/scripts/self_check.py
git diff --check -- docs/update_plan/42-student-follow-up-workspace
```

## 前端检查

```powershell
npx prettier --check src/components/teacher/TeacherPblFollowUpDetail.vue src/pages/teacher/pbl-follow-up-detail/pbl-follow-up-detail.vue src/features/analytics/infrastructure/demoAnalyticsRepository.ts
npx vitest run src/components/teacher/teacher-pbl-follow-up-detail.behavior.spec.ts src/components/teacher/teacher-pbl-alignment.behavior.spec.ts src/features/learning/infrastructure/teacher-adapters.spec.ts src/platform/navigation/page-navigation.spec.ts
npm run lint
npm run type-check
node scripts/frontend-boundaries.mjs
npm run build:mp-weixin
```

不修改后端/API/schema/迁移时，不运行合同生成、数据库迁移或后端全量测试。若范围改变，先修订计划。

## 逻辑验收矩阵

| ID  | 输入或操作                | 必须断言                                                        |
| --- | ------------------------- | --------------------------------------------------------------- |
| V01 | PBL plan 首次加载         | 查询 studentId/classId 来自 plan，随后异步呈现整体学情          |
| V02 | 学情非空                  | 显示姓名、近 30 天指标、有效维度和最多 3 条近期病例             |
| V03 | assigned/分数/改善为 null | 显示真实空值文案，不显示 0 分或 0%                              |
| V04 | 本课有 4 项任务、3 项完成 | 本次课堂概况显示 3/4、真实轮次与系统结果                        |
| V05 | analytics 加载中          | 只在整体学习模块显示加载，PBL 模块不消失                        |
| V06 | analytics 失败            | 保留本课/任务/判定，并出现模块级重试                            |
| V07 | analytics 重试成功        | 清除模块错误并显示学习数据，不清空 PBL 主详情                   |
| V08 | PBL 失败                  | 整页错误，不发起学情请求，可重试或返回列表                      |
| V09 | 需支持计划                | 显示失败目标和两轮评价，无 textarea、反馈按钮或历史反馈         |
| V10 | 长姓名/长题干/长判定      | 可换行、无横向溢出、状态标签不遮挡                              |
| V11 | 旧学生档案深链            | 仍转向同班 PBL 巩固跟进，不恢复旧档案                           |
| V12 | 源码审计                  | 仅经 analytics/PBL public API 读取，无直接 request/storage/写入 |

## 微信开发者工具验收

```powershell
$env:VITE_APP_MODE='demo'
npm run dev:mp-weixin
```

等待 `Build complete. Watching for changes...`，开发者工具只加载 `D:\CODE\weixin\wxprogrom7.15\dist\dev\mp-weixin`，执行普通刷新。最小流程：

1. Demo 教师进入 `PBL > 巩固跟进`，确认学生列表与原职责不变。
2. 进入“演示学生·周宁”的详情，确认首屏身份、本次课堂概况、整体学习情况可见。
3. 审阅字段层级、蓝白配色、圆角/边框、模块留白和状态色；确认无卡片堆叠。
4. 向下滚动，确认任务、补强目标和评价完整，底部安全区无遮挡。
5. 确认没有反馈输入、发送按钮或人工评分动作。
6. 返回原班级巩固跟进；若自定义组件限制真实点击，使用支持的导航仅作为补充证据并明确未验证项。

最少保留两张本次截图：详情首屏（整体 + 本课）和详情下半页（任务 + 判定历史）。上一版截图不能证明本次修改。

## 视觉验收矩阵

| 检查       | 通过标准                                                   |
| ---------- | ---------------------------------------------------------- |
| 层级与焦点 | 学生身份清楚；本课概况为唯一最强焦点；整体与本课不混淆     |
| 字体与节奏 | 标题/正文/元数据层级明确，模块间距大于记录间距，长中文可读 |
| 构图与密度 | 窄屏无横向溢出；同类记录用分隔线；异质模块有独立 surface   |
| 状态与控件 | 状态不只靠颜色；局部错误有 44px 重试；无不应出现的写操作   |
| 小程序运行 | 实际文字、滚动、安全区和返回经开发者工具观察，不以构建代替 |

## 结论边界

- 分别报告格式、测试、Lint、类型、边界、构建、Demo watcher、工具刷新、真实交互和截图审阅。
- 真机、真实登录、远程 API/Coze、生产数据库和医学专家审核不在本次范围。
