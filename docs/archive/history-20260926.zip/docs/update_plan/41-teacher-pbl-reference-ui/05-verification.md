# 05 验证与验收

运行位置：项目根目录。下列为待执行清单，不因文档列出命令就算通过。新增 spec 在对应实施阶段创建后才能运行。

## 1. 文档门禁

```powershell
npx prettier --check "docs/update_plan/41-teacher-pbl-reference-ui/**/*.md"
python .agents/skills/wx-engineering-standards/scripts/self_check.py --self-test
python .agents/skills/wx-engineering-standards/scripts/self_check.py
git diff --check -- docs/update_plan/41-teacher-pbl-reference-ui
```

该目录当前未跟踪，`git diff --check` 不足以覆盖它；另外逐个读取 Markdown，检查尾随空格和本地相对链接实际存在。远程链接不执行不必要网络访问；代码块内的计划文件名不视为已创建链接。

## 2. 静态、逻辑与构建检查

```powershell
npx vitest run src/components/teacher/pblHomePresentation.spec.ts src/components/teacher/TeacherPblHome.behavior.spec.ts src/components/teacher/teacher-pbl-alignment.behavior.spec.ts src/components/teacher/teacher-workspace-alignment.behavior.spec.ts src/features/pbl/infrastructure/demoPblRepository.spec.ts
npm run lint
npm run type-check
node scripts/frontend-boundaries.mjs
npm test
npm run build:mp-weixin
```

共享导航条件样式接入后执行全量前端测试以检查外溢；如原有失败存在，记录测试名、现象和本次是否影响，不删除或跳过。生产构建只证明产物可生成，不证明开发者工具目录已更新。

未修改后端/API/schema 时不运行数据库迁移、后端全套测试或契约生成。若范围改变，先补 03，再执行对应 `contract:generate/check`、受管权限/契约测试；不得运行未知数据库的 `backend:migrate`。

## 3. 逻辑验收用例

| ID  | 准备和操作                           | 必须断言                                                    | 证据层        |
| --- | ------------------------------------ | ----------------------------------------------------------- | ------------- |
| V01 | 输入讨论中/完成/待判定/需支持学生    | 三计数按定义且不互相替代                                    | 纯函数        |
| V02 | 同学生多个计划                       | 优先级确定，目标 plan ID 稳定                               | 纯函数        |
| V03 | 有快照、无快照、有计划、无计划       | 动作类型与 ID 正确，无详情无箭头                            | 函数+组件     |
| V04 | 已知、缺失、非法、相同时间；切换排序 | 升降序正确，未知末尾，同值稳定                              | 纯函数        |
| V05 | 其他班级/课堂/快照工作项             | 不合并、不泄露其他记录                                      | 函数+组件     |
| V06 | Demo 教师看某课堂                    | 只有该课堂参与/任务学生，姓名非 openid                      | adapter       |
| V07 | Demo 字符串课堂 ID 及数值计划关联    | 对应记录可进真实既有详情，不靠页面猜 ID                     | adapter       |
| V08 | Demo 空课堂、自主记录、重复刷新      | 空态真实，私人记录不出现，无重复种子                        | adapter       |
| V09 | 挂载首页并加载数据                   | 区域顺序、真实标题/姓名/计数正确                            | 组件          |
| V10 | 班级/课堂切换、A 慢 B 快             | A 迟到成功/失败/finally 不覆盖 B                            | 组件          |
| V11 | 多页与中途错误、重复页               | 获取完整集合或明确报错，无死循环                            | 组件          |
| V12 | 创建/返回/失败                       | 表单实际打开、输入保留、新课堂被选择                        | 组件          |
| V13 | 诊断/跟进分段                        | 同页切换真实列表；不发出旧 section 跳转                     | 组件          |
| V14 | 旧 query、待办入口、详情进入/返回    | 只落到新版首页对应模式；班级/课堂上下文不丢失；旧队列不挂载 | 导航+组件     |
| V15 | 四个一级 active 分别渲染             | 只有 PBL 新变体，其余外观条件不变                           | 导航+样式审计 |

## 4. 开发者工具准备

先检查当前是否已有 live watcher；有则轮询原 handle，不因观察超时重复启动。没有时：

```powershell
$env:VITE_APP_MODE='demo'
npm run dev:mp-weixin
```

等到 `Build complete. Watching for changes...`，保持进程运行。开发目录唯一为 `D:\CODE\weixin\wxprogrom7.15\dist\dev\mp-weixin`。

另一个受控终端：

```powershell
$env:WECHATIDE_CLI_PATH='D:\codeapp\微信web开发者工具\wechatide.cmd'
$env:WECHATIDE_CLIENT='Codex'
& $env:WECHATIDE_CLI_PATH -c Codex open_project_window --project 'D:\CODE\weixin\wxprogrom7.15\dist\dev\mp-weixin' --window-mode liteMode
& $env:WECHATIDE_CLI_PATH -c Codex simulator_refresh --project 'D:\CODE\weixin\wxprogrom7.15\dist\dev\mp-weixin'
npm run test:mp:doctor
```

doctor 必须实际取得 SDKVersion，URL 安全检查保持开启。旧 `test:mp:*` 多数脚本已在 package.json 指向禁用入口，不作为可用验收脚本。只用支持的 `automation_element_action` 和 `simulator_screenshot`；禁止旧 WS、setData、页面业务方法和系统鼠标截图。

## 5. 真实交互与视觉验收

| ID  | 实际操作                                   | 观察点                                                                                    | 最小取证                                           |
| --- | ------------------------------------------ | ----------------------------------------------------------------------------------------- | -------------------------------------------------- |
| W01 | Demo 教师进入 PBL 默认页                   | 原生 PBL、横幅、三工具、摘要、学生卡、底栏；无重复旧模块                                  | 默认页最终截图 1 张                                |
| W02 | 打开班级/专题 picker、选择、切分段、切排序 | picker 不插入正文选项行；分段在同一页面更新列表；原生标题仍为 PBL；无旧三分区或页尾旧入口 | 动作与元素断言；诊断/跟进各保留一张必要状态截图    |
| W03 | 点击有诊断记录，原生返回                   | 正确快照，返回原课堂与筛选；不打开别人记录                                                | 页面路径/可见标识断言                              |
| W04 | 点击正式跟进，原生返回                     | 正确计划、系统判定只读，回原上下文                                                        | 页面路径/动作断言                                  |
| W05 | 创建入口、填字段、验证禁用/提交、返回      | 创建约束、防重复、成功定位；不操作真实后端                                                | 表单代表状态 1 张及结果断言                        |
| W06 | 长标题、列表滚到底、展开长选项             | 文字不撞状态/箭头，末条可达，底栏无遮挡                                                   | 与 W01 不同滚动状态 1 张                           |
| W07 | 可达的空/错误/重试状态                     | 空与失败分开，重试恢复，不用改 data 制造                                                  | 真实可达时取证；不可达明确记录缺口                 |
| W08 | 切其他一级页再回 PBL                       | 其他页面布局/选中态未变，PBL 状态恢复                                                     | 元素与必要视觉抽查；共享导航按项目规则检查核心路径 |

初始目标视口为工具默认手机宽度，再选择工具支持的窄屏检查。无法设置宽度或操作原生控件时，先查受支持工具能力；不能声称多宽度通过。真机按用户要求本次不执行。

五项视觉判定分别记录：颜色（含普通字对比）、字体层级、间距留白、圆角/边框/阴影/底栏、整体布局。每项写“通过/失败/未验证 + 证据路径 + 观察理由”。不能只写“已还原”。

## 6. 截图与最终审计

- 路径建议 `output/wechat/t41-pbl-home-final.png`、`t41-pbl-create.png`、`t41-pbl-bottom.png`；这些是预定路径，不代表文件已存在。
- 每张来自当前代码的内部截图必须实际打开审阅；不能以文件大小、截图存在或旧截图代替。
- 同状态不重复截取；仅在代码/交互造成新可见状态、原截图损坏或关键区域缺失时补拍，并记原因。
- 交付时检查源文件、命令输出、真实点击、截图四类证据是否一致。必需项缺证据则目标未完成；真机/生产等明确排除项单独列限制。
