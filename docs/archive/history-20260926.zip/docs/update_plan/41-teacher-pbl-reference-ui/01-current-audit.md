# 01 当前实现审计

目的：在修改前区分已存在能力、实施草稿和缺口。日期：2026-09-21。

## 1. 输入与范围

- 业务对象：教师一级 PBL 工作区，不是“内容”页。
- UI 基准：本任务附件 `C:\Users\adj\.codex\attachments\a3ea508f-f575-433c-bb0c-14bd16434d03\image-1.png`。后续提供的文件树截图只规定文档组织方式，不替代 PBL 视觉参考图。
- 项目路径：`D:\CODE\weixin\wxprogrom7.15`；当前分支 `dev`。
- 仓库已有大量暂存、未暂存和未跟踪修改。不能以 HEAD 直接覆盖本次目标文件。

## 2. 当前调用链和缺口

| 位置                                                   | 已核实事实                                                                 | 本次需要做的事                                  |
| ------------------------------------------------------ | -------------------------------------------------------------------------- | ----------------------------------------------- |
| `src/pages/teacher/index/index.vue`                    | 工作区壳层、班级数据、一级导航、详情跳转；当前仍按 PBL section 改原生标题  | PBL 工作区始终显示“PBL”，其他标题不动           |
| `src/components/teacher/TeacherPblWorkspace.vue`       | 已把默认课堂接到新首页，但显式 diagnostics/follow-ups 仍渲染旧导航和旧队列 | 改为始终只渲染新首页；旧 section 仅映射首页分段 |
| `TeacherPblClassrooms.vue`                             | 创建表单、课堂分页、关闭课堂、阶段看板及详情动作                           | 复用管理能力，补显式创建入口，避免复制创建逻辑  |
| `TeacherWorkspaceNav.vue`                              | 四项共享导航，青绿选中态                                                   | 只在 PBL 激活时启用蓝色/浅蓝选中变体            |
| `src/features/pbl/public.ts`                           | 课堂列表、看板、工作项、跟进公开函数可用                                   | 优先复用，不增加页面直连请求                    |
| `src/features/pbl/infrastructure/demoPblRepository.ts` | 已有课堂/诊断/正式计划种子；看板按 owners 枚举，姓名使用内部 key           | 收敛到当前课堂参与者，合成姓名与队列/跟进一致   |
| `src/components/teacher/TeacherPblHome.vue`            | 已接入横幅、工具、摘要、双模式和记录，但仍保留旧页尾入口                   | 移除旧入口，补初始模式/模式恢复合同             |
| `src/components/teacher/pblHomePresentation.ts`        | 已有诊断/跟进映射、排序与定向测试                                          | 保持真实映射，不为旧队列增加旁路                |

表中省略目录的 Vue 文件均在 `src/components/teacher/`。上述记录是文件检查结果，不是测试通过结论。

## 3. 当前草稿不能直接交付的原因

1. 新主页已接入，但“全部诊断/全部跟进”仍会打开图一旧页面，与用户要求矛盾。
2. 首页底部仍保留“课堂管理/全部诊断/全部跟进/Demo”旧入口，破坏图三结构。
3. PBL 原生标题会随旧 section 变成“诊断审阅/巩固跟进”，而不是始终保持 `PBL`。
4. 旧 query 和待办入口需要保留兼容，但只能设置首页分段，不能恢复旧列表。
5. 班级选择、课堂请求、进入创建的先后顺序仍须保持测试覆盖；加载期间点击创建不能被静默丢失。
6. 当前时间只能由工作项获得，不能称为所有训练活动的完整更新时间；继续按第 03 册限定来源。

## 4. 改动范围白名单

- 可修改：上述 PBL 首页/容器/管理组件、PBL 激活条件下的导航样式、PBL 默认标题、PBL 纯展示函数和相关测试、Demo PBL 仓储、T41 文档及必要的前端设计说明。
- 可新增：两张 PBL 本地 SVG、PBL 首页行为测试和展示函数测试。
- 默认不修改：其他主页面、详情页视觉、AI provider、医学审核、知识卡权限、数据库、生成合同、全局 token、构建依赖。
- 如果发现必须改公开合同：停止该子步骤，先在第 03 册写出逐字段变化与测试，再通过补充计划门禁；“允许改后端”不等于可以省略设计与验证。

## 5. 执行前只读复核

在项目根目录执行并把结果摘要写入 delivery，不输出学生内容或身份凭据：

```powershell
git branch --show-current
git status --short
git diff --stat
git diff --cached --stat
Get-FileHash src/components/teacher/TeacherPblWorkspace.vue
Get-FileHash src/components/teacher/TeacherPblClassrooms.vue
Get-FileHash src/features/pbl/infrastructure/demoPblRepository.ts
```

出口：文件归属、草稿状态、实际接口和待改范围已记录；出现与本审计不一致的新修改时，先阅读新差异并更新审计，不覆盖它。
