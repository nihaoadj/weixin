# 更新计划

T01–T42 已按滚动规则收缩为一份 [阶段概述](summary.md)。概述保留各阶段核心成果、仍生效规则、后续取代关系和未验证边界；当前源码、迁移和权威运行文档仍是事实来源。

当前只把最近两次更新计划作为验收依据：

- [T44 单轮学习路线、AI 病例学习与最终测试](44-single-round-learning-routes/README.md)：用户已确认方案，当前仅交付完整更新文档，运行实施尚未开始。课堂与自主研讨均自动发布路线，仅最终单选测试计分；课堂题目教师审阅后开放，自主全部私有。具体改动与 P0–P7 步骤见[实施章节](44-single-round-learning-routes/09-implementation-steps.md)，G0–G3 检查及仅 G3 全量的规则见[验收出口](44-single-round-learning-routes/10-verification-exit.md)。文档证据见[本轮交付](44-single-round-learning-routes/deliveries/documentation.md)。
- [T43 课堂任务包、统一学习报告与教师题库](43-classroom-task-package-reports/README.md)：主要功能已实施，但本轮于 2026-09-26 按用户要求收尾，完整验收未完成，不恢复旧测试队列。后续未执行项见[收尾交接](43-classroom-task-package-reports/11-remaining-work-handoff.md)，逐次证据见[实施进度](43-classroom-task-package-reports/deliveries/implementation-progress.md)。最近完整后端记录为334 passed、88.01%；前端全局覆盖率与最终完整门禁、安全历史指纹及外部验收未关闭。T44 将替代其双轮运行规则，尚未实施。

T42 及更早阶段已收缩入 [阶段概述](summary.md)。T37–T42 原目录属于既有未跟踪工作，暂予保留，避免本次更新删除此前未提交文件；它们不作为额外当前计划或新验收依据。T43历史证据不证明T44，T44文档也不证明运行实现；当前代码事实与各阶段实际交付必须分别核实。

## 滚动维护规则

- 本目录只完整保留最近两次计划及其 `deliveries/`；更早计划在创建新计划前压缩进 [阶段概述](summary.md)。
- 压缩必须保留当前仍生效的产品/工程规则、被后续计划覆盖的关系、迁移节点、验证结论和明确未验证项，不能只保留“已完成”标签。
- 功能变更的先计划后实施、计划门禁和交付要求见[工程工作流](../operations/engineering-workflow.md#更新分流)；纯文档或不改变运行边界的维护无需建立新计划。
- 未经用户明确授权，不提交、推送、部署或对未知数据库执行迁移、回填。
