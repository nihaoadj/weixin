# 验证与验收

## 数据库与迁移

- `npm run backend:test:safety`
- `npm run backend:test:migrations`
- 0027→0028 保留既有业务数据并新增完整 v4 图谱。
- 空库→head 与 0027→head 的目录指纹相同。
- 约束拒绝重复编码、自环、重复边、非法枚举和悬空来源。
- 同一版本重复 code 拒绝，不同版本复用稳定 code 允许；仓储只返回 active 版本的数据。
- active 目录增加一个来源和材料完整的节点后，仓储动态返回新节点；5 模块/30 节点只约束 v4 基线，不限制未来目录版本。空目录仍显式失败。
- downgrade 只移除 T38 表，不修改既有证据、PBL、题目或用户记录；再次 upgrade 恢复同一基线指纹。

## 医学图谱完整性

- 恰有 5 个模块、30 个稳定点、30 份学习材料、34 条持久化边、14 个公开来源。
- 每条边两端存在、无自环、无重复、全图无环。
- 每条边至少一个来源、非空 rationale/limitation、合法 relation kind、confidence 和审核状态。
- 所有被引用来源有非空 key/标题/发布者、HTTPS URL 和合法 ISO 访问日期；破坏来源元数据后所有目录读取显式失败。
- 运行时边集合与 `docs/knowledge-base/dependency-audit-v4.md` exact-match。
- “充血与淤血 → 水肿”逐边限制必须明确只讨论静脉淤血增加静水压，不把主动性充血归为同一机制；数据库、Demo 和文档说明一致。
- 明确断言已删除的错误边不存在：坏死→凋亡、可逆损伤→缺氧、可逆损伤→氧化应激、急性→慢性、
  细胞适应→组织再生、充血/缺氧→休克。

## 后端与合同

- 相关 content、learning、QA、PBL、analytics 测试通过。
- `rg` 证明运行时代码不再导入 `POINTS`、`tree_view`、`POINT_DATA` 来读取节点/材料，或在源码定义前置字典。
- active catalog 缺失/冲突时显式失败，不使用静态 fallback。
- `LocalMockGateway` 缺少目标知识点时不生成固定编码的 `knowledge_gaps`；有目标时只回传请求中已经目录校验的编码。
- 教师展示 mapper 不按静态 knowledge point code 补标题；Demo 动态任务从生成目录快照取知识点标题，未知编码使用中性文案。
- `npm run contract:generate` 后审阅 OpenAPI 与生成类型，再运行 `npm run contract:check`。
- API/Demo 返回相同 v4 节点、依赖和来源状态。

## 前端

- 相关格式、Lint、类型检查和 Vitest 通过。
- 图谱单元测试逐条核对所有边的起点、终点、类型和跨模块属性。
- 聚焦树对每个模块列出所有入向和出向跨模块依赖并保持“前置 → 后学”方向；全树不裁边、不改方向、不制造兄弟串联。
- 20%–100% 缩放、拖动边界、全树适配、节点点击和长页面滚动无回归。
- 节点详情能看到依据和“专家复核待完成”，不使用“已审核/绝对可信”的误导文案。

## 微信开发者工具

- PowerShell 显式设置 `$env:VITE_APP_MODE='demo'` 后运行 `npm run dev:mp-weixin`。
- watcher 输出 `Build complete. Watching for changes...`。
- 工具只加载 `D:\CODE\weixin\wxprogrom7.15\dist\dev\mp-weixin` 并执行普通编译。
- 从学生学习主页进入知识点树，实测模块切换、单树外部依赖、全树、缩放、拖动、复位和节点详情。
- 保存当次内部截图；不以 H5、data 检查或历史截图代替。

## 外部待验收

- 病理学课程负责人/执业专家逐边签署。
- PostgreSQL 迁移、生产回填和备份恢复。
- 微信真机、真实登录、真实 API 数据和真实教学使用。
