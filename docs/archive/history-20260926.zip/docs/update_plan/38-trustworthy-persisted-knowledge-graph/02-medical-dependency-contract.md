# 医学依赖合同与拟定图谱

## 箭头合同

图上 `A → B` 只表示“学习 B 前建议掌握 A”。医学语义由边的 `relation_kind` 决定：

| 类型                   | 含义                              | 禁止误读                     |
| ---------------------- | --------------------------------- | ---------------------------- |
| `response_continuum`   | 同一应激/损伤反应谱中的条件性衔接 | 不代表必然进展               |
| `mechanistic_basis`    | A 提供理解 B 的关键机制           | 不代表 A 是 B 的唯一病因     |
| `structural_component` | A 是识别或解释 B 的组成部分       | 不代表 A 单独足以诊断 B      |
| `specialized_pattern`  | B 是 A 所属范畴的特殊模式         | 不代表所有 A 都会形成 B      |
| `repair_phase_basis`   | A 是理解修复阶段 B 的前置         | 不代表所有损伤均按同一时间线 |
| `assessment_framework` | A 提供分析 B 的框架               | 不表示病理因果               |
| `common_source`        | A 是 B 的常见来源                 | 不表示 B 只有该来源          |
| `occlusive_mechanism`  | A 可通过血管闭塞参与 B            | 不表示所有 B 均由 A 引起     |
| `outcome_definition`   | A 是理解 B 结局/定义的基础        | 不表示箭头方向等同发生顺序   |
| `classification_basis` | A 是分类或鉴别 B 的基础           | 不表示 A 单独完成分类        |
| `grading_basis`        | A 支持组织学分级                  | 不与临床分期混同             |
| `staging_basis`        | A 支持肿瘤范围/播散分期           | 不与组织学分级混同           |

## v4 依赖矩阵

以下 33 个展示行对应 34 条持久化边（第 33 行拆成两条）；未列出的关系不进入运行时图谱。

| #   | 来源 → 目标                                   | 类型                 | 机制与限制                                                          | 证据     |
| --- | --------------------------------------------- | -------------------- | ------------------------------------------------------------------- | -------- |
| 1   | 细胞适应 → 可逆性损伤                         | response_continuum   | 适应能力被超过后可出现损伤；不是必然进展                            | S01      |
| 2   | 缺氧性损伤 → 可逆性损伤                       | mechanistic_basis    | 短暂/较轻缺氧可致 ATP 下降和可逆性改变                              | S01、S02 |
| 3   | 氧化应激损伤 → 可逆性损伤                     | mechanistic_basis    | ROS 是细胞损伤机制，结局取决于强度和持续时间                        | S01      |
| 4   | 可逆性损伤 → 坏死                             | response_continuum   | 持续或严重损伤越过不可逆点后可发生坏死                              | S01、S02 |
| 5   | 炎症介质 → 炎症血管反应                       | mechanistic_basis    | 介质调控血管扩张和通透性变化                                        | S03      |
| 6   | 炎症介质 → 白细胞募集                         | mechanistic_basis    | 趋化因子、细胞因子和内皮激活参与募集                                | S03、S04 |
| 7   | 炎症血管反应 → 白细胞募集                     | mechanistic_basis    | 内皮黏附与跨内皮迁移是募集基础                                      | S04      |
| 8   | 炎症血管反应 → 急性炎症形态                   | structural_component | 血管改变构成急性炎症形态基础之一                                    | S03      |
| 9   | 白细胞募集 → 急性炎症形态                     | structural_component | 中性粒细胞等浸润构成急性炎症形态基础                                | S03      |
| 10  | 炎症介质 → 慢性炎症                           | mechanistic_basis    | 持续细胞因子信号维持慢性反应                                        | S04      |
| 11  | 白细胞募集 → 慢性炎症                         | structural_component | 巨噬细胞、淋巴细胞和浆细胞浸润是核心形态                            | S04      |
| 12  | 慢性炎症 → 肉芽肿性炎症                       | specialized_pattern  | 肉芽肿是持续刺激下的特殊慢性炎症模式                                | S04、S05 |
| 13  | 坏死 → 急性炎症形态                           | mechanistic_basis    | 坏死/组织损伤信号可诱导急性炎症                                     | S03      |
| 14  | 急性炎症形态 → 肉芽组织                       | repair_phase_basis   | 修复中炎症期为后续增殖及肉芽组织形成提供环境                        | S06      |
| 15  | 肉芽组织 → 细胞外基质重塑                     | structural_component | 肉芽组织含成纤维细胞和临时 ECM，随后发生重塑                        | S06、S07 |
| 16  | 组织再生 → 创伤愈合                           | structural_component | 再上皮化/实质细胞增殖是愈合组成                                     | S06      |
| 17  | 肉芽组织 → 创伤愈合                           | structural_component | 肉芽组织是增殖期关键结构                                            | S06、S07 |
| 18  | 细胞外基质重塑 → 创伤愈合                     | structural_component | ECM 合成、降解和重组决定瘢痕成熟                                    | S06、S07 |
| 19  | 慢性炎症 → 纤维化                             | mechanistic_basis    | 持续炎症与修复信号可促进 ECM 沉积                                   | S04、S07 |
| 20  | 细胞外基质重塑 → 纤维化                       | mechanistic_basis    | 合成/降解失衡可造成过度基质沉积                                     | S06、S07 |
| 21  | 创伤愈合 → 影响修复的因素                     | assessment_framework | 先理解正常愈合，才能分析氧合、感染、营养等影响                      | S06      |
| 22  | 充血与淤血 → 水肿                             | mechanistic_basis    | 仅静脉淤血经静脉压/毛细血管静水压升高促进液体滤出；主动性充血不等同 | S08      |
| 23  | 炎症血管反应 → 水肿                           | mechanistic_basis    | 炎症性通透性增高是水肿机制之一                                      | S03、S08 |
| 24  | 血栓形成 → 栓塞                               | common_source        | 血栓可脱落形成血栓栓子；并非所有栓子均为血栓                        | S09      |
| 25  | 血栓形成 → 梗死                               | occlusive_mechanism  | 原位血栓闭塞可致组织缺血和梗死                                      | S09、S14 |
| 26  | 栓塞 → 梗死                                   | occlusive_mechanism  | 栓塞性血管闭塞可致梗死                                              | S09、S14 |
| 27  | 坏死 → 梗死                                   | outcome_definition   | 梗死是缺血所致的组织坏死，脑等器官形态可不同                        | S09、S14 |
| 28  | 肿瘤发生机制 → 肿瘤异型性                     | mechanistic_basis    | 驱动改变可形成异常增殖表型；异型性并非所有肿瘤的同等表现            | S10      |
| 29  | 肿瘤异型性 → 良恶性肿瘤区别                   | classification_basis | 异型性支持形态评估，但不能单独决定良恶性                            | S10、S11 |
| 30  | 良恶性肿瘤区别 → 浸润与转移                   | classification_basis | 浸润/转移是恶性行为核心特征                                         | S10      |
| 31  | 肿瘤异型性 → 肿瘤分级与分期                   | grading_basis        | 组织学分级关注分化和异常程度                                        | S11      |
| 32  | 浸润与转移 → 肿瘤分级与分期                   | staging_basis        | 分期关注原发范围及区域/远处播散                                     | S12      |
| 33  | 良恶性肿瘤区别、浸润与转移 → 肿瘤对机体的影响 | classification_basis | 局部侵袭、转移和其他肿瘤行为共同决定影响；转移不是必要条件          | S10      |

第 33 行在数据库中拆成两条边，分别保存独立说明。因此实际持久化边数为 **34**；表格以一个共同目标合并展示以便阅读。

## 来源登记

| ID  | 来源                                                                                                                     | 用途                                           |
| --- | ------------------------------------------------------------------------------------------------------------------------ | ---------------------------------------------- |
| S01 | [Mechanisms and Morphology of Cellular Injury, Adaptation, and Death](https://pmc.ncbi.nlm.nih.gov/articles/PMC7171462/) | 适应、可逆/不可逆损伤、缺氧、氧化应激          |
| S02 | [Histology, Cell Death](https://www.ncbi.nlm.nih.gov/books/NBK526045/)                                                   | 可逆损伤、坏死、缺氧与细胞死亡                 |
| S03 | [Acute Inflammatory Response](https://www.ncbi.nlm.nih.gov/books/NBK556083/)                                             | 介质、血管反应、白细胞和坏死诱导炎症           |
| S04 | [Chronic Inflammation](https://www.ncbi.nlm.nih.gov/books/NBK493173/)                                                    | 慢性炎症细胞、介质、纤维化和肉芽肿             |
| S05 | [Mechanisms of granulomatous inflammation](https://pubmed.ncbi.nlm.nih.gov/2488875/)                                     | 肉芽肿形成机制与条件                           |
| S06 | [Physiology, Wound Healing](https://www.ncbi.nlm.nih.gov/books/NBK535406/)                                               | 炎症、增殖、肉芽组织、再生和重塑               |
| S07 | [Principles of Wound Healing](https://www.ncbi.nlm.nih.gov/books/NBK534261/)                                             | 成纤维细胞、ECM、肉芽组织和瘢痕                |
| S08 | [Physiology, Edema](https://www.ncbi.nlm.nih.gov/books/NBK537065/)                                                       | 静水压、通透性和淋巴回流等水肿机制             |
| S09 | [Virchow Triad](https://www.ncbi.nlm.nih.gov/books/NBK539697/)                                                           | 血栓、血栓栓塞、缺血与梗死                     |
| S10 | [What Is Cancer?](https://www.cancer.gov/about-cancer/understanding/what-is-cancer)                                      | 肿瘤发生、良恶性行为、浸润、转移和机体影响     |
| S11 | [Tumor Grade](https://www.cancer.gov/about-cancer/diagnosis-staging/diagnosis/tumor-grade)                               | 组织学分级与细胞异常程度                       |
| S12 | [Cancer Staging](https://www.cancer.gov/about-cancer/diagnosis-staging/staging)                                          | 肿瘤范围与播散分期                             |
| S13 | [Shock](https://www.merckmanuals.com/professional/critical-care-medicine/shock-and-fluid-resuscitation/shock)            | 证明休克是低灌注→缺氧/细胞损伤，支持删除反向边 |
| S14 | [Infarction MeSH Descriptor](https://meshb.nlm.nih.gov/record/ui?ui=D007238)                                             | NLM 对梗死、坏死、局部缺血及血栓/栓塞的定义    |

实施中补充：原 S02 说明一般坏死机制，但未直接定义梗死；美国国家医学图书馆 MeSH 的 S14 直接定义梗死及血栓/栓塞的常见关系，因此上表第 25–27 行改为逐边关联 S14。MeSH 定义不等于本项目医学专家签署。

## 可信度与审核状态

- `confidence=high`：来源直接支持边的核心机制且限定条件可明确表达。
- `confidence=moderate`：关系适合作为学习前置，但存在组织、病因或表型差异，必须显示限制说明。
- 所有 v4 边初始 `evidence_status=source_supported`。
- 所有 v4 边初始 `medical_review_status=pending_expert_review`，`reviewer_id/reviewed_at` 为空。
- 未满足以上字段、来源失效或出现环的边不能进入 active catalog。
