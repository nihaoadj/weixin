# 数据库、接口与兼容设计

## 数据库模型

### `knowledge_catalogs`

- `id`、`version`（唯一）、`label`、`status`、`reference_note`、`created_at`
- T38 仅允许一个 `status=active` 的目录，由仓储完整性检查保证。

### `knowledge_modules`

- `id`、`catalog_id`、`code`、`label`、`description`、`position`
- 唯一约束 `(catalog_id, code)` 与 `(catalog_id, position)`。

### `knowledge_points`

- `id`、`catalog_id`、`module_id`、`code`（跨版本稳定，但只在所属目录版本内唯一）、`title`、`objective`、`description`
- `case_slug`、`position`、`evidence_status`、`medical_review_status`、`reviewer_id`、`reviewed_at`
- 唯一约束 `(catalog_id, code)` 与 `(module_id, position)`；审核人可空 FK 指向 `users.id`。旧目录归档后，新目录可以复用相同稳定编码并保留旧版本数据；按 code 查找必须同时约束 active catalog。

### `knowledge_dependencies`

- `id`、`catalog_id`、`prerequisite_point_id`、`dependent_point_id`
- `relation_kind`、`rationale`、`limitation`、`confidence`
- `evidence_status`、`medical_review_status`、`reviewer_id`、`reviewed_at`、`position`
- 唯一约束 `(catalog_id, prerequisite_point_id, dependent_point_id)`，检查起点不等于终点。
- 模块内外使用同一张表；“跨模块”由两个端点所属模块派生，不另存可能漂移的布尔值。

### `knowledge_study_materials`

- `id`、`catalog_id`、`point_id`、`version`、`scenario`、`background`、`example`、`remediation`、
  `reference_note`、`evidence_status`、`medical_review_status`。
- 每个 active knowledge point 恰有一份 active material；JSON 字段只保存结构化教学段落，不保存答案、学生内容或隐藏病例事实。
- 节点详情和学习路径从该表读取，不能再通过 `POINT_DATA` 拼出标题、说明或学习材料。

### `knowledge_sources` 与关联表

- 来源表保存稳定 `source_key`、标题、发布者、URL、来源类型、访问日期。
- `knowledge_point_sources` 和 `knowledge_dependency_sources` 使用联合唯一约束，说明该来源支撑的范围。
- URL 只指向公开权威资料，不保存受版权保护的长篇原文。

## 迁移与基线数据

- 新迁移：`20260916_0028_persisted_knowledge_graph.py`，父版本 `20260914_0027`。
- 迁移以显式、可审阅的 v4 基线插入 1 个目录、5 个模块、30 个点、30 份学习材料、34 条边、14 个公开来源和来源关联。
- 新库因 0001 会按当前 metadata 建表，0028 必须能识别空表并只插入一次；旧库由 0028 建表后插入同一数据。
- migration 完成后计算确定性指纹；测试固定模块、点、边、关系元数据和来源端点，而不只检查数量。
- T38 不自动迁移开发、共享或生产库；只在受管测试临时库验证。

## 运行时端口

在 content public/application 边界新增 `KnowledgeCatalogPort`；实际公开方法：

- `catalog_version()`、`module_labels()`
- `tree_view()` / `point_view(code)`：逐节点返回结构化依赖和来源
- `contains_points(codes)`
- `card_for_code(code)` / `cards_for_points(codes)` 继续通过内容仓储读取已入库的系统卡片，禁止从知识点常量生成。
- `study_material_view(point_code)` 从 `knowledge_study_materials` 读取；不存在时显式返回资源不存在，不静态生成。

`SqlAlchemyKnowledgeCatalogRepository` 是唯一生产适配器。各业务应用通过 wiring 注入端口，不允许 domain/application
导入 SQLAlchemy，也不允许使用无 Session 的全局查询或静态 fallback。

仓储完整性检查不得把本版的 5 模块/30 节点数量写成运行时恒定条件：active 目录至少有一个模块和一个节点，所有节点都属于本目录模块、都有来源与一份同目录学习材料，所有依赖端点、来源、机制说明和有向无环关系均有效。5/30/34/14 只由 v4 迁移与基线测试固定；未来受审阅目录增加节点时，不应因旧版数量常量而被拒绝。

`source_supported` 还要求被引用来源具备非空 source key、标题与发布者，URL 使用公开 `https://` 地址，`accessed_on` 是合法 ISO 日期；不能仅凭关联表存在就把空来源当成证据。模块、节点和材料的关键教学文本也必须非空。任一读取发现无效元数据时显式 503，不能返回部分图谱或降级为静态说明。

## API 合同

`GET /knowledge/tree` 和 `GET /knowledge/points/{code}` 保留原字段，并新增：

```text
catalog:
  version, evidence_status, medical_review_status
point:
  evidence_status, medical_review_status, source_keys
dependencies[]:
  prerequisite_code, dependent_code, relation_kind,
  rationale, limitation, confidence,
  evidence_status, medical_review_status, source_keys
```

- `prerequisite_codes` 由 `dependencies` 投影，用于旧客户端兼容。
- 移除无证据的循环 `related_codes` 生成；兼容字段只由同一组持久化依赖中的 outgoing 边投影，不额外创建关联关系。前端知识树和节点详情直接消费结构化 `dependencies`，不以兼容字段构造拓扑。
- API 数据库缺少 active catalog、出现重复 active catalog、悬空引用或环时显式返回服务不可用，不回退到旧常量。

## 跨模块影响与兼容

- 30 个点编码不变，因此既有学习证据、PBL 诊断、题目绑定和学习路径仍可解析。
- 目录版本从 v3 升到 v4；新响应、任务和生成物使用 v4，历史记录保留其原版本，不原地改写。
- PBL 可用 topic 和 point 校验改为仓储查询；provider allowed-points 由当前 Session 的 active catalog 构建。
- QA、learning evidence、analytics、content authoring 和 study path 均改为注入端口。
- 旧 `POINT_DATA` 若仍保留，只能承载与知识目录无关的开发病例/练习蓝图；任何运行时节点、模块、说明、
  学习材料或依赖读取均不得导入它。系统练习卡继续真实存放在既有 `knowledge_card_contributions` 表。
- 若某历史编码在 active catalog 不存在，读取历史仍显示编码并标记“历史目录项不可用”；新写入拒绝未知编码。

## Demo 合同

- Demo 不连接后端数据库，但其快照必须由迁移到 head 的受管临时数据库导出，不能再导入源码 `tree_view()`。
- 导出脚本的 `--check` 会建立受管临时库、运行迁移、读取 active catalog 并与提交的 JSON 比较。
- Demo 和 API 共享同一前端 schema，包含逐边证据元数据；Demo 不宣称已执行真实生产迁移。

## 数据与权限

- 学生和普通教师只有读取 active catalog 权限。
- T38 不新增写接口；目录发布通过受审阅迁移进行。
- reviewer 字段为未来医学审核流程预留，T38 基线为空，防止伪造审核身份。
- 不保存患者数据、学生回答、提示词或凭据；来源表仅保存公开书目信息和 URL。

## 实施中发现与计划修订（2026-09-16）

初版 0028 和 ORM 将 `knowledge_points.code` 设为全表唯一，与“归档旧版、沿用稳定编码发布新版”的维护目标冲突。此处修订为目录内唯一，在受管临时数据库构造同 code 的归档版和 active 版，核对仓储始终只选择 active 版；不对共享、开发或生产库执行 schema 修复。0028 仍未对真实数据库执行，测试数据和 Demo 快照均由隔离迁移重建。分析用例的目录端口也必须为必需依赖，不能在缺失时静默退回 code 标签。医学资料复核发现 S02 不直接定义梗死，补充 NLM MeSH 的 S14，给第 25–27 条边提供逐边直接依据；来源总数因此由 13 调整为 14。

收尾审计又发现仓储曾把 `len(modules)==5`、`len(points)==30` 当成运行时完整性条件。该限制仅适用于 v4 基线测试，不适用于后续 active 版本。实施时移除固定数量判断，并用在受管临时数据库为 active 目录新增有来源、有材料的有效节点的测试证明动态读取；继续拒绝空目录、无来源、缺材料、悬空或循环关系。

同一收尾审计发现“有关联来源”不足以证明来源元数据可追溯。实施补充来源 key/标题/发布者、HTTPS URL 和访问日期校验，以及模块、点、材料关键文本校验；测试故意破坏已关联来源，证明所有目录读取显式失败。

最终运行时检索又发现测试专用 `LocalMockGateway` 在请求没有 `goal_point_codes` 时，会把固定的炎症血管反应编码写入诊断结果。即使该 gateway 仅用于本地 API 测试，也不得把静态编码伪装成由 active catalog 解析出的知识薄弱点。实施改为：只有请求携带已由应用层目录校验的目标编码时才生成知识薄弱点；没有目标时返回空 `knowledge_gaps`，不得选择固定节点或目录首节点作为 fallback。Demo 中明确标注并经目录快照校验的演示记录不属于该运行时 fallback。

前端收尾检索还发现教师展示 mapper 会在服务端缺少 `target_label` 时，用源码内单个知识点映射补标题；Demo 动态任务生成也以条件表达式复制该标题。教师展示改为只接受服务端持久化快照标题，缺失时使用不声称具体知识点的中性文案；Demo 动态任务标题从迁移导出的 `pathologyCatalog.generated.json` 解析。固定演示记录可以保存其创建时标题快照，但不得作为运行时知识目录或通用 label fallback。
