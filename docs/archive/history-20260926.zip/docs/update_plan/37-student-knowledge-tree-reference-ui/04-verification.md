# 验证与验收

## 静态与逻辑

- T37 范围 Prettier 与 `git diff --check`。
- `npm run lint`。
- `npm run type-check`。
- `npx vitest run src/components/student/PathologyKnowledgeMap.spec.ts src/pages/student/question/question.behavior.spec.ts src/pages/student/information-architecture.spec.ts`。
- `node scripts/frontend-boundaries.mjs --self-test` 与实际边界检查。
- SVG XML 解析。
- 两项项目 Skill 自检/检索测试。
- `npm run build:mp-weixin`。

## 微信开发者工具 Demo

1. 显式 `$env:VITE_APP_MODE='demo'; npm run dev:mp-weixin`，等待 watcher 完整构建。
2. 只加载 `D:\CODE\weixin\wxprogrom7.15\dist\dev\mp-weixin`，调用 `simulator_refresh` 普通刷新并运行 doctor。
3. Demo 学生登录，从“学习 → 知识点清单 → 全部知识点”真实进入知识点树。
4. 审阅原生标题、头图、推荐卡、模块轨、工具条、图谱、图例、材料说明和固定底栏。
5. 真实点击另一模块、查看全树、缩小、放大、复位、拖动图谱和知识点节点；核对路由与返回。
6. 截取首屏、图谱中部/底部和交互状态；检查 console error。

## 视觉验收矩阵

| 项目   | 通过条件                                                          |
| ------ | ----------------------------------------------------------------- |
| 层级   | 推荐行动清楚，原生标题不在正文重复                                |
| 字体   | 标题、说明、模块、节点、元数据至少两项维度区分，长中文不重叠      |
| 密度   | 首屏能理解主干、模块和至少一段路径；不存在当前 92% 导致的过度放大 |
| 控件   | 横轨、模式、缩放、复位和节点触达明确，圆角/边框/阴影一致          |
| 运行时 | 页面与图谱滚动不冲突，固定底栏不遮挡图例和说明，无横向页面溢出    |

## 外部未验收

- 微信真机触摸、双指缩放、读屏与不同 DPR。
- 真实 API、远程服务、生产数据和生产部署。
- 开发者工具不能稳定模拟的设备宽度保留为未验收，不用 H5 替代。
