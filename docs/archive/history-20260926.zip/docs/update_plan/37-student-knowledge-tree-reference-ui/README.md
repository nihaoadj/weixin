# T37 学生知识点树参考图视觉迭代

状态：仓库内实施与微信开发者工具 Demo 验收完成

## 当前事实

- 学习主页通过 `ROUTES.studentCases?view=knowledge` 进入 `pages/student/question/question`，知识模式由 `PathologyKnowledgeMap.vue` 渲染。
- 页面只经 `features/learning/public.ts` 调用 `getKnowledgeMap()` 与 `buildKnowledgeGraph()`；当前已有推荐模块、查看全树、缩放、复位、单指拖动、双指缩放、节点跳转、加载/错误/空态。
- 现有实现使用绿色全局令牌、直角模块页签和线框工具栏，顶部还有父页面的橙色安全提示；与参考图的蓝青医学头图、图标模块卡、圆角工具条、渐变根/模块节点和底部材料说明差距明显。
- 工作区已有大量未提交和未跟踪改动。本次只逐 hunk 修改 T37 范围，不 reset、clean、checkout、提交、推送或恢复既有文件。

## 目标

1. 将知识模式原生标题调整为“知识点树”，按参考图重组为：医学头图 → 推荐卡 → 模块横轨 → 模式/缩放工具条 → 网格知识树 → 状态图例与材料说明。
2. 使用深海军蓝、医疗蓝、青色、极浅蓝与白色建立与 T33–T36 一致的学生端视觉语言。
3. 保留所有真实知识图数据和既有交互语义；默认聚焦推荐分支时采用参考图约 60% 的视觉密度，让多层关系在首屏可读。
4. 为五个知识模块提供本地矢量医学图标，不引入远程字体、图片或依赖。

## 非目标

- 不修改知识目录、知识状态、推荐算法、图构建算法、学习证据或节点详情页。
- 不修改后端、OpenAPI、数据库、迁移、权限、API/Demo 装配、Demo seed/store/adapter。
- 不把打开节点伪装为掌握度变化，不伪造模块数量、稳定数量或学习状态。
- 不执行真机、真实 API、真实微信登录或生产验收。

## 计划索引

- [当前审计](01-current-audit.md)
- [设计与交互合同](02-design-contract.md)
- [实施顺序](03-implementation.md)
- [验证与验收](04-verification.md)
- [风险与回退](05-risks-rollback.md)
- [交付模板](deliveries/template.md)
- [T37 交付记录](deliveries/T37.md)

## 接口与数据影响

- 继续使用现有 learning feature public API；不新增页面仓储、请求、storage key 或 DTO。
- `view=knowledge` 路由兼容不变，仅可见原生标题从“知识地图”调整为“知识点树”。
- 不改变 API/Demo 选择、错误边界、权限范围和敏感数据处理。

## 完成条件

- UpdatePlan 的格式、链接、尾随空白、工程 Skill 自检和 UI 检索测试通过后再修改运行时代码。
- 相关格式、Lint、类型、组件测试、页面行为测试、前端边界和小程序构建通过。
- Demo watcher 显式使用 `VITE_APP_MODE=demo`；开发者工具只加载 `dist/dev/mp-weixin` 并普通编译。
- 从学习主页真实进入知识点树，检查模块切换、推荐/全树、缩小/放大/复位、拖动、节点点击、长图滚动、固定底栏和截图；不能执行的状态明确保留为未验收。
