# T44 需求与实施追踪

状态：本表证明文档覆盖，不证明运行实现。所有功能状态目前为待实施。

| ID  | 用户需求/必要工程结果                          | 设计依据                                                             | 实施步骤       | 验收证据                   |
| --- | ---------------------------------------------- | -------------------------------------------------------------------- | -------------- | -------------------------- |
| R01 | 课堂及自主只进行一轮研讨后学习                 | [流程](02-product-workflows.md)                                      | P2/P3/P6       | B01/B11+退役审计           |
| R02 | 研讨完成AI自动生成并发布路线                   | [生成事务](04-domain-state-machines.md)                              | P2.3–P2.5      | B01–B04                    |
| R03 | 资料/病例依据真实弱点，未审核直接学习          | [AI来源](06-ai-sources-review.md)                                    | P2.2/P2.4      | B02/B04                    |
| R04 | 现有权威来源+AI导读，不伪造来源或审核          | [AI来源](06-ai-sources-review.md)                                    | P2.2           | B04+UI资料                 |
| R05 | 阅读前台计时、手动确认、不设最低时长           | [状态机](04-domain-state-machines.md)                                | P3.1           | B05                        |
| R06 | AI病例三阶段多轮合格后放行，不打分             | [病例流程](02-product-workflows.md)及[合同](06-ai-sources-review.md) | P3.2           | B06/B07+UI01/UI02          |
| R07 | 路线完成才能测试                               | [解锁](04-domain-state-machines.md)                                  | P3.3           | B08+UI03                   |
| R08 | 课堂最终测试教师审阅后开放；只审一份分析和题目 | [API](05-api-data-contracts.md)                                      | P4.1/P4.2/P5.6 | B09+UI02                   |
| R09 | 自主测试直接开放，全部私有不送教师             | [流程](02-product-workflows.md)                                      | P2.4/P3.5/P4.4 | B02/B12/B13                |
| R10 | 单选题，一次提交，正确率计分，无达标线         | [测试规则](02-product-workflows.md)                                  | P3.3–P3.5      | B10/B11                    |
| R11 | 只有最终测试计分，无补考或二轮任务             | [统计](04-domain-state-machines.md)                                  | P3.5/P4.4/P6   | B11/B13+退役审计           |
| R12 | 待完成任务显示真实计划并进入新页面             | [页面](03-pages-navigation.md)                                       | P5.1/P5.2/P5.5 | UI01/UI02+首页spec         |
| R13 | 清除旧研讨、二轮和关联结果/证据                | [清理](07-migration-cleanup.md)                                      | P1/P6          | DB03/DB05/DB08/DB09        |
| R14 | 保留账号/班级/知识库/独立病例/题库             | [保留证明](07-migration-cleanup.md)                                  | P1.2–P1.7      | DB04/DB06/DB07             |
| R15 | Demo可直接展示并完整体验新流程                 | [Demo](08-demo-scenarios.md)                                         | P5.7           | B16+UI01–UI06              |
| R16 | 步骤明确，只在少数重要节点标准验收             | [实施](09-implementation-steps.md)及[退出](10-verification-exit.md)  | P0–P7/G0–G3    | 节点记录、无改动不重复全量 |
| R17 | public边界、API/Demo隔离、生成物同步           | [接口](05-api-data-contracts.md)                                     | P4.5/P4.6/P6.5 | G2/G3边界/契约             |
| R18 | 幂等/并发/失败恢复/答案不泄漏/结果唯一         | [事务](04-domain-state-machines.md)                                  | P2/P3/P4       | B01/B07/B09/B10/B12        |
| R19 | 实际工具渲染与外部边界分别报告，不无限测试     | [验收](10-verification-exit.md)及[风险](11-risks-rollback.md)        | P7             | UI证据/失败项/停止记录     |

文档交付审计须确认R01–R19均有对应章节、实施步骤和验收项，不能只列需求标题。实施完成时将每项实际证据链接追加，不提前修改“待实施”状态。
