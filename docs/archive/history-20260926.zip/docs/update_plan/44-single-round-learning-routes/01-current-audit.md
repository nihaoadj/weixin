# 01 当前实现与影响审计

状态：2026-09-26 只读审计；以下路径已在工作树核对，新路径在其他文档中标为待新增。

## 1. 工作树与事实来源

分支 `dev`，相对 `github/dev` ahead 8；存在约千项既有修改/未跟踪文件。基线以本次只读 `git status --short --branch` 为准，不以 Git HEAD 代替当前工作树。禁止 reset、clean、整体恢复、代提交或删除他人文件，尤其不得恢复已删除 `docs/update/README.md`。

当前工程边界读取[架构](../../architecture.md)、[数据层](../../data-layer.md)、[数据库](../../backend/database.md)、[安全](../../governance/security.md)、[后端模块](../../backend/module-map.md)、[前端公开接口](../../frontend/public-interfaces.md)。计划文件解释目标和历史证据，不替代代码事实。

T43 收尾结论来源为[现行交接](../43-classroom-task-package-reports/11-remaining-work-handoff.md)和[实施记录](../43-classroom-task-package-reports/deliveries/implementation-progress.md)。最近完整后端快照为 334 passed、88.01%；前端全局覆盖率未达 85%/85%/80%，最终完整门禁未执行。这些是历史记录，不是 T44 检查结果。

## 2. 学生现有入口

| 当前文件                                             | 已核实行为                                                                                                         | 本轮修改                                                               |
| ---------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------ | ---------------------------------------------------------------------- |
| `src/pages/student/learning/index.vue`               | 合并 active 课堂包与非 stable 知识点；知识点固定记为 1 项任务；`openDashboardTask` 按 classroom/knowledge 前缀分流 | 改为真实学习路线列表，卡片统一进入新计划详情，移除知识点伪任务与包跳转 |
| `src/components/student/PblTaskList.vue`             | 混合外部卡片与旧正式计划执行；显示轮次、第二轮锁定和耗尽                                                           | 改为路线摘要展示，不内嵌旧任务执行；“全部任务”进入列表                 |
| `src/pages/student/learning/knowledge-node.vue`      | 研讨完成后生成自主练习，首轮错题可触发第二轮                                                                       | 移除旧练习区，保留资料与研讨入口，展示真实关联计划                     |
| `src/pages/student/learning/classroom-package.vue`   | 正式包按轮次和 position 执行                                                                                       | 退役；原链接不能继续旧双轮流程                                         |
| `src/pages/student/pbl/pbl.vue`                      | 四阶段研讨、逐消息回应方式、完成后私人续问                                                                         | 完成结果增加 plan locator；冻结和私人消息边界保持                      |
| `src/pages/student/insights/index.vue`、`detail.vue` | 本人课堂/研讨结果及双轮历史展示                                                                                    | 改接新学习结果，去掉轮次改善与达标标签                                 |

截图中的“细胞适应 / 可逆性损伤 / 坏死”卡片来自知识点列表投影，不证明这些节点已有研讨或计划。新卡片必须来自 route API，不能仅把旧 card 的跳转地址改成新页面。

## 3. 前端数据与装配

| 当前范围                                                                                     | 需要修改的事实                                                                |
| -------------------------------------------------------------------------------------------- | ----------------------------------------------------------------------------- |
| `src/features/learning/public.ts`、`domain/ports.ts`                                         | 增加路线、步骤、病例、测试、结果能力；移除旧 cycle 输入和旧包公开能力         |
| `src/types/study.ts`、`src/types/learning.ts`                                                | 旧 practice group 的 cycle/canRetest/exhausted 退役；新类型归 learning domain |
| `src/features/learning/infrastructure/apiLearningRepository.ts`、`demoLearningRepository.ts` | 增加同合同 adapter，删除旧双轮分支，不允许 API 错误回退 Demo                  |
| `classroomPackages.ts`、`classroomFinalReports.ts` 及其 tests                                | 退役包专用 mapper/生命周期，替换为 route/result mapper 与对照测试             |
| `src/features/pbl/public.ts` 及 API/Demo repository                                          | 完成 locator、教师审阅入口与进度引用改为新路线/测试，不外发自主数据           |
| `src/features/analytics`                                                                     | 结果合同从双轮达标改为单次完成/成绩/知识正确率                                |
| `src/bootstrap/wiring.ts`、Demo seed/store                                                   | 显式装配新 port，业务存储版本升级，构造全流程合成场景                         |
| `src/platform/navigation`、`src/pages.json`                                                  | 注册新页面，替换任务/通知/结果深链                                            |
| `src/platform/contracts`、`src/data/contracts/openapi.generated.ts`                          | 新 Zod/mapper、生成类型；OpenAPI 生成物不手改                                 |

## 4. 后端现有链路

| 当前文件/模块                                                                                  | 已核实事实                                                                        | 本轮修改                                                    |
| ---------------------------------------------------------------------------------------------- | --------------------------------------------------------------------------------- | ----------------------------------------------------------- |
| `learning/application/study.py`                                                                | `generate` 只接受 1/2；第二轮要求首轮完整且有错题；读模型有 can_retest/exhausted  | 退役自主练习生成与答题合同，保留知识材料/创建研讨的公开能力 |
| `learning/infrastructure/study_models.py`                                                      | study_paths、study_practice_groups、study_practice_attempts；组按 path+cycle 唯一 | 清理后删旧专用表；新路线独立建模                            |
| `learning/infrastructure/pbl_mastery.py`                                                       | 首轮失败激活失败目标；二轮失败 needs_reinforcement+automation_exhausted           | 删除 PBL 双轮判定与通知路径                                 |
| `learning/infrastructure/package_models.py`、`classroom_packages.py`、`classroom_execution.py` | 包、两轮候选、发布冻结、关联正式 plan、唯一终态报告                               | 新 route/test/result 替代；旧包 API 和对象退役              |
| `pbl/application/use_cases.py`                                                                 | 完成课堂生成知识卡草稿；自主完成写个人证据；保存唯一完成快照                      | 完成后创建新计划并自动生成；停止自动卡审核链                |
| `pbl/infrastructure/provider_schema.py` 与 providers                                           | v7 task 必须有 1/2 两个变式；课堂资源引用须已审                                   | 新 v8 仅诊断；路线和测试使用独立合同，不要求双变式          |
| `pbl/infrastructure/study_dialogues.py`                                                        | 当前完成判定支持历史 v3–v7                                                        | 新运行路径使用 v8；保留离线迁移事实，不能回退旧 schema 执行 |
| `content/infrastructure/question_bank_models.py`                                               | 题库 revision/receipt 强制 FK 到 classroom_package_items                          | 先建立通用来源桥接/脱钩，保留独立副本                       |
| `content/infrastructure/question_review_models.py`                                             | 独立 classroom_question_reviews 按包题 digest 医学审核                            | 清理旧关联并退役该专用审核，不影响独立资源医学审核          |
| `training/infrastructure/models.py`                                                            | case_attempts、ai_call_logs 可引用 learning_tasks                                 | 精确删旧任务派生记录，保留独立训练                          |
| `analytics/application/classroom_reports.py`                                                   | 当前教师正式学情主要读完成课堂包报告                                              | 改为完成课堂 route result，禁止加回过程病例计分             |
| `bootstrap/model_registry.py`、`composition.py`、各 wiring                                     | 中央 metadata 与跨模块组合                                                        | 注册新对象，删旧装配；边界经 public/port 保持               |

上表后端相对路径均位于 `backend/app/modules/`，bootstrap 位于 `backend/app/bootstrap/`。具体新增文件组织由[实施章节](09-implementation-steps.md)规定。

## 5. 数据、接口与生成物影响

已有 head `20260924_0032`；计划新增 0033/0034，完整 revision ID 在实施时使用日期前缀并从实际唯一 head 接链。不得把文档编号当作已存在迁移。

影响旧 study、classroom package、PBL suggestion/plan/result API，新 route/test API、PBL 完成响应、教师 dashboard 和 analytics DTO。`docs/openapi.json`、生成 TypeScript、契约 fixtures 和生成 Demo catalog 均通过 `npm run contract:generate` 工作流同步；catalog 本身不改为静态来源。

旧两轮也存在于 seed、脚本、旧报告修复器、通知、review items、测试和文档。源码退役检索必须覆盖这些消费者；只删 UI 按钮不满足更新目标。

## 6. 不在此次文档任务执行的动作

本轮不运行后端全量测试、业务构建、真实 Coze、watcher、开发者工具或数据库迁移。不清除本机真实数据，不修复历史 secret 指纹，不补 T43 完整验收。后续功能执行必须使用本计划的 G0–G3，不能把此审计当作运行验收。
