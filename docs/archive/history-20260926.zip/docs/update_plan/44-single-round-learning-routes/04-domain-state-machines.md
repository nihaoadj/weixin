# 04 领域对象、状态机与事务

状态：T44 计划目标；本章新表与字段尚不存在。内部 PK 使用整数，外部新资源 locator 使用不可猜测 UUID 字符串，禁止旧整数路径误指向新对象。

## 1. 所有权与新对象

以下对象归 learning；pbl 只负责源会话、完成快照和课堂权限，content 只负责知识来源/题库。route 病例不创建公共 Problem/正式 CaseAssessment。

| 新表                         | 最小持久化内容                                                                                                                                                                          | 唯一/一致性约束                                                         |
| ---------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ----------------------------------------------------------------------- |
| `learning_routes`            | public_id、student_id、source_participation_id、session_id、completion_snapshot_id、source_kind、class_id/teacher_id、主要目标、诊断摘要、生成状态/claim、内容版本/digest、published_at | public_id、participation 唯一；课堂归属完整，自主 class/teacher 为 NULL |
| `learning_route_steps`       | public_id、route_id、position、kind、目标、来源快照、导读或病例定义、status、completed_at                                                                                               | route+position 唯一，kind 仅 reading/case；发布后内容不可改             |
| `route_reading_progress`     | step_id、student_id、active lease、last_seen_at、accumulated_seconds、最后请求 identity                                                                                                 | step+student 唯一；时长非负；旧 lease 不累计                            |
| `route_case_sessions`        | public_id、step_id、student_id、phase、revision、phase_started_revision、status、completed_at                                                                                           | step 唯一；仅本人；三阶段相邻推进                                       |
| `route_case_messages`        | case_session_id、sequence、role、content、client_message_id、request revision、processing status、payload digest                                                                        | case+sequence、case+client_message_id 唯一                              |
| `route_case_phase_decisions` | case_session_id、message/revision、phase、decision、证据 message IDs、目标满足项、缺失项、安全状态                                                                                      | case+revision 唯一；不包含数字分数                                      |
| `route_final_tests`          | public_id、route_id、generation claim/state、review_state、version、draft_digest、released_version/digest、released_at、reviewer_id                                                     | route 唯一；自主 released 时 reviewer=NULL、review_kind=ai_direct       |
| `route_test_questions`       | public_id、test_id、stable_key、position、primary_point_code、题干、四选项、correct_option、解析                                                                                        | test+stable_key、test+position 唯一；答案为 0–3；独立私有评分字段       |
| `route_test_attempts`        | public_id、test_id、student_id、draft_version、题目 ID→选择、status、submission identity/digest、correct_count、question_count、score、submitted_at                                     | test+student 唯一；submitted 后不可改；提交时冻结试题版本               |
| `route_learning_results`     | public_id、route_id、attempt_id、source_kind、原归属、policy_version、source digest、结果快照、completed_at                                                                             | route、attempt 唯一；只存在 completed 结果，不存在二轮状态              |
| `route_test_review_events`   | test_id、teacher_id、action、version/digest、可选短反馈、时间                                                                                                                           | 开放绑定唯一版本；不复制完整聊天或病例答案                              |
| `route_command_receipts`     | actor、operation、client_request_id、payload digest、关联资源、结果版本/locator                                                                                                         | actor+operation+request 唯一；只保存最小回执                            |

生成状态、claim、error code 分别存在 route/test；route 发布版本与 test 审核版本彼此独立。公共来源内容按版本快照保存，目录后来变更不悄悄改变已发布路线。

source_kind 固定为 classroom/autonomous，由原 session_kind=classroom/student_initiated 映射，不由客户端或 AI 决定。测试 generation_state 与 review_state 分开；未生成成功的题目不能被标为已审阅。

## 2. 源对象一致性

建计划时验证 completion snapshot 属于 participation、snapshot revision 等于 evidence_completed_revision，且诊断 ready、安全 educational、阶段 completed。目标来自有效目录；自主所有权和课堂归属不得由请求提供。

每个 participation 一份 route，因此一个课堂一个学生仍只有一个正式路线。学生不能通过换 client ID 再建同来源计划。发布路线不需要医学审核标志；reviewer/class 等字段不能从 AI JSON 映射。

原研讨完成后私人续问仍保存原独立 scope，其内容不进入 route generation、case learning、test generation 或 score。

## 3. 路线与步骤状态

路线生成：`pending → generating → published`；失败为 `generation_failed`。失败、过期 claim，以及进程中断后未开始且无有效 claim 的 pending 可以恢复；published 无 regeneration 动作。有效生成 claim 尚在运行时不得抢占或重复调用。

步骤：最初第一条 available，后续 locked；开始可标 in_progress；阅读确认或病例三阶段完成标 completed，并原子开放下一步。最后一步完成形成 `route_completed_at`，不产生测试成绩或最终结果。

步骤回看只读，不改变累计完成数。病例安全阻塞标 blocked，仍不能开放下一步；重试恢复需要重新取得合法结构化判定，不能由页面直接解除。

计划展示状态由生成、步骤、测试和 attempt 投影：generating、generation_failed、learning、waiting_test_generation、waiting_teacher、ready_for_test、testing、completed。该投影不作可写枚举，不允许客户端 PATCH 状态。

## 4. 阅读时间

前台开始领取 lease；每 15 秒发送 heartbeat，pause/complete 时补一次。服务器只累计同一有效 lease 从上次 heartbeat 至本次的 UTC 间隔，单次最多 30 秒；第一个 heartbeat 不回填长时间历史。超过 30 秒未心跳视为暂停，恢复重新领取 lease。

重复 request_id 不重复累计；新页面领取 lease 使旧页 heartbeat 无效，避免多窗口相加。客户端 elapsed/时间戳不作权威时长。网络离线期间本期不补计，UI 可说明保存中断；时长不决定完成，学生仍可在恢复后确认学习。

阅读完成只校验本人、route/step 关联、步骤已开放及未完成；重复确认返回同一 completed 状态。确认失败不解锁下一步。

## 5. 病例交互与证据

阶段编码：`pathology_recognition → mechanism_explanation → evidence_judgment → completed`。AI 的 decision 仅 stay/advance/complete：前两阶段不能 complete，第三阶段不能 advance。

有效证据来自当前阶段起点之后、同一 case session、真实 student 消息。每阶段有至少一条有效回答且该阶段目标全部有结构化满足判定才可推进。字数、消息次数、AI 输出文本或空的“合格”字段不能代替目标证据。

提交流程：

1. 验证开放步骤、本人、client_message_id+内容 digest；重复同内容复用，异内容冲突。
2. 固定请求 revision 并持久化消息/processing claim，短事务提交。
3. 调用独立病例 gateway；只传本病例必要公开情境、阶段目标和有限本人历史。
4. 校验响应 phase/revision、消息引用和安全状态。
5. CAS 保存 decision、assistant 消息与相邻阶段转换。迟到响应不能覆盖新状态。
6. 最后阶段合格时同事务完成病例步骤并开放后续条件；未合格只更新反馈。

同一 case 一次只允许一个活动消息请求；并发冲突明确返回，不把两条消息都当推进证据。provider 失败保存 error code，原消息可幂等重试，不重复插入或跳阶段。

## 6. 生成事务与失败恢复

研讨 completion snapshot 与 route shell 在同一原数据库事务中提交，pbl 通过 learning 的 `CompletionLearningRoutePort` 写 shell，不穿透 ORM。外部内容生成在提交后触发，不能持锁等待 AI。

route 生成成功原子写全步骤+source snapshot+digest+published_at；内容缺失不部分发布。之后生成 test。route 成功、test 失败可继续学习；route 失败则 test 保持 pending，避免无路线的孤立审核。

生成 claim 包含 token、expires_at、version；有效期为对应已配置 provider 请求超时加 30 秒。只有 claim holder 能写结果，过期返回不能覆盖新重试。请求完成触发一次自动生成，不新增 cron/outbox worker；进程中断后的过期状态通过显式重试恢复，GET 不触发写操作或 AI 调用。

shell 创建后、开始 claim 前或 route 发布后、test 开始前发生进程中断时，pending 必须可显式恢复。route 的 pending 无有效 claim 可领取；test 的 pending 要求 route 已发布且无有效 test claim。重试组件先 CAS 领取同一资源，不能重新建 shell，避免无队列环境永久卡住。

重试组件是 route 或 test，成功组件不能重新生成。无 provider fallback，不创建固定虚假内容。完成消息重放会返回同一个 route locator，而不会自动反复调用生成。

## 7. 教师测试审阅

generation_state=pending/generating/ready/generation_failed；ready 后 review_state 为课堂 pending_review、自主 released。课堂可 `pending_review ↔ needs_changes`，最终到 released；同一份记录不删后再新建。

保存需 expected version、完整题目集合与 digest，验证 1–12 题、四选项、唯一答案、主要目标覆盖；保存递增版本并使旧开放请求失效。

开放同时验证原课堂 teacher owner、班级有效、学生仍为成员、测试 ready、version/digest 一致；冻结 questions/released_version/digest，追加 review event/receipt 和必要站内通知。released 不可再次编辑或重新开放不同内容；同一请求重放返回原结果。

自主 AI 直接开放由服务器设置 review_kind=ai_direct，不填 reviewer；未审核信息必须保留，不能套用课堂教学审阅属性。

## 8. 双条件解锁与唯一作答

`can_start_test = route published AND all required steps completed AND test ready/released AND actor owns route`。课堂 released 必须包含真实教师回执。由后端投影给 UI，进入、读取、保存、提交 API 均复核。

首次合法 GET final-test 创建或恢复唯一 attempt 的动作改由明确 POST start 完成；GET 保持只读。start 使用唯一约束防双 attempt；页面随后 GET 恢复作答。

草稿版本初始 1，每次合法保存递增；答案只能引用当前冻结 test question ID 与选项 0–3。提交携带 expected draft version、released digest、完整答案及 submission ID。服务端校验全部题已答、没有额外题和 stale digest，CAS in_progress→submitted。

一次事务中计算正确数、100 制 score、存固定 answers/result、追加唯一证据、更新计划完成事实与通知。score 以十进制定点规则 ROUND_HALF_UP 保留一位，正确数/总数作为原始权威值。重复提交同 payload 返回同结果，异 payload 返回冲突；已提交不能保存草稿或重启。

## 9. 结果与统计证据

结果 policy_version=`single-final-test-v1`；快照只组合固定诊断摘要、路线步骤完成、最终题目版本、本人选择/解析和得分。学生可见解析仅在提交后，教师不需要完整学生病例聊天。

仅最终提交写 assessment 证据：课堂 source_type=`classroom_final_test`、authority=`pbl_formal`、visibility=`class_detail`；自主 source_type=`private_final_test`、authority=`personal_unverified`、visibility=`student_only`、class=NULL。事件 source_id 指向 result public ID，dedupe_key 为 `final-test-result:<public_id>:v1`。

每主知识点聚合该点题目的正确率为 knowledge metric，不给无题知识点填 0；result=`observed`，不制造 passed/failed 门槛。一个题只计主知识点，合计每份结果一次。阅读/病例不写 scored metric，必要进度仅业务表保存。

analytics 通过新 `LearningRouteResultReadPort` 读取已完成课堂结果，原包报告读取器退出；课堂完成率是已交最终测试人数/具有已发布路线的学生人数，无分数者为 NULL。不创建六维能力分、全局综合分或排名。

原班 owner 仍可读其归属课堂历史结果；学生换班不转移结果归属。日期窗口沿用上海自然日、UTC 查询边界和稳定分页规则，不能把 source_kind=autonomous 数据加入教师聚合。
