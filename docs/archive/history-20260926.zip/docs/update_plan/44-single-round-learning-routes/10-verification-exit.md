# 10 有限验证、标准节点与退出条件

状态：T44 验收计划，除文档 delivery 外全部待执行。目的为证明规定行为，不把测试数量、截图数量或不断重跑当作完成标准。

## 1. 执行节奏

只设 G0 文档、G1 数据安全、G2 业务合同、G3 最终集成四个节点。**全量测试、全局覆盖率和标准小程序交付验收集中在 G3。** P2–P6 小修改使用最小受影响检查，通过后进入下一步。

不默认执行 npm run check:all：它链式失败会阻止后续检查，且容易重复多个阶段已做的事项。G3 将标准命令分别执行并记录，不能重复跑 backend:test 和 backend:check 以获得同一全量结论。

测试文件下文凡标“待新增”均是计划目标，不代表当前存在或已经通过；实施时登记实际文件和用例数。

## 2. G0 文档门禁

范围仅本计划、索引、摘要与根规则计划入口：

```text
npx prettier --check docs/update_plan/44-single-round-learning-routes docs/update_plan/README.md docs/update_plan/summary.md AGENTS.md
python .agents/skills/wx-engineering-standards/scripts/self_check.py --self-test
python .agents/skills/wx-engineering-standards/scripts/self_check.py
git diff --check -- AGENTS.md docs/update_plan/README.md docs/update_plan/summary.md
```

另用临时只读脚本检查新文档相对链接、尾随空白、文件目录、需求追踪和各阶段/节点引用；新未跟踪文件不能只靠 git diff --check。该脚本不写源文件，不访问网络。

G0 通过只说明文档结构和需求完整，不说明运行流程、迁移、AI、UI 或安全已验收。

## 3. G1 数据与清理安全

现有安全入口：`npm run backend:test:safety`、`npm run backend:test:migrations`。新增定向 `test_t44_migration.py`、`test_t44_cleanup.py`、`test_t44_bank_source_detachment.py`（均待新增）在 launcher-owned 临时 SQLite 中验证：

| ID   | 必须证明                                                           |
| ---- | ------------------------------------------------------------------ |
| DB01 | 空库到 head 与真实0032 fixture→0033→清理→0034都成功，head唯一      |
| DB02 | 非本人/未知/生产/shared资源、链接边界、错误marker、缺备份拒绝      |
| DB03 | 默认dry-run不写数据库、不生成AI、不seed；manifest改变拒绝apply     |
| DB04 | 题库内容/版本保留、旧FK解除、独立病例/资源/班级/知识目录不减少     |
| DB05 | 清理旧研讨、私人续问、两个轮次、报告、证据及通知复习关联，无悬空FK |
| DB06 | 同整数ID不同source_type不误删；保留对象进入closure时拒绝           |
| DB07 | 中途注入错误全部rollback；备份可读并在独立临时位置完成恢复演练     |
| DB08 | 0034旧数据残留拒绝；新数据存在降级拒绝；不通过删新数据制造可回退   |
| DB09 | session等旧数字ID高水位保留，新对象UUID不与旧链接串号              |
| DB10 | 本次证据清理例外不开放普通DELETE，不改变append-only运行写约束      |

安全/迁移检查发生新修改才定向复跑相关项。真实受管开发库 apply/恢复另列证据；不存在明确目标时标外部待执行，不能让测试fixture清理冒充开发库清理。

## 4. G2 业务合同验收矩阵

| ID  | 场景/预期                                                         | 建议定向测试组，待新增            |
| --- | ----------------------------------------------------------------- | --------------------------------- |
| B01 | completion重复/并发仅一route，snapshot/revision冻结               | t44_completion/routes             |
| B02 | 路线直接发布，课堂test待审、自主直接开放                          | t44_generation/review             |
| B03 | route失败不回滚研讨；test失败不挡已发布route                      | t44_generation                    |
| B04 | 无效目标/来源/schema/unsafe不能发布，无provider fallback          | t44_provider_contracts            |
| B05 | reading顺序、手动完成、heartbeat去重/后台不累计，无最低时长       | t44_reading                       |
| B06 | 病例三阶段、至少当前学生证据、无越级/旧assistant证据，无分数      | t44_case_learning                 |
| B07 | case消息重试不重复，迟到response不覆盖，安全阻塞不放行            | t44_case_learning                 |
| B08 | route/test任一未满足拒读题/开始/保存/提交，直连API不能绕过        | t44_final_tests                   |
| B09 | 教师owned class、失效成员、version/digest、开放冻结               | t44_teacher_review                |
| B10 | 唯一attempt、draft恢复、答案全集、并发重复submit仅一result        | t44_final_tests                   |
| B11 | 2/3=66.7、0分completed、未交NULL；无达标线/二轮/补考              | t44_result_rules                  |
| B12 | 未交不泄答案，完成解析本人可见，自主任何教师query均不可见         | t44_permissions                   |
| B13 | 仅最终test scored evidence，analytics只计完成课堂result，无六维分 | t44_analytics                     |
| B14 | 题库明确入库、独立编辑/归档，不改变已开放test                     | t44_bank_sources                  |
| B15 | 源时区/日期首尾、稳定分页、身份切换/晚响应、cache失效             | t44_reads/adapters                |
| B16 | API/Demo同合同与上述状态差异，同一request重放一致                 | frontend route/test/case adapters |

后端定向用例通过根 `npm run backend:test -- tests/<实际文件> -q` 或 backend 工作目录 `python -m pytest tests/<实际文件> -q` 执行，仍由当前安全fixture接管数据库；不用未知engine。

前端 `npm run test -- <实际受影响spec路径>`；schema/mapper稳定后运行 `npm run contract:check`、`node scripts/frontend-boundaries.mjs`、`python backend/scripts/check_boundaries.py`。若bootstrap/public types变化，运行 `npm run type-check`，不默认全局coverage。

G2过关需矩阵关键项有真实证据，不能只mock用例方法调用来证明授权/事务，也不能仅用组件DOM测试证明微信实际渲染。

B03额外覆盖两处进程中断：shell提交后尚未领取生成claim、route发布后test尚未开始。两者都能恢复同一pending对象，不能永久卡住或重复创建；有效claim未过期时仍拒绝抢占。

## 5. P5/P6 局部检查规则

纯文案/样式：改动文件Prettier、Lint；可见变化按需在当前Demo编译检查对应页面，不全站回归。交互变化：受影响页面behavior spec和adapter定向用例；数据/schema变化：对应用例/mapper/contract。迁移/测试资源/bootstrap变动：对应安全/迁移；权限变化：负向范围用例。

已通过状态未受影响不重复截图。小修引入新的共享导航/身份影响或已有证据外溢时扩大到相关流程，仍不自动重跑每个历史阶段。

## 6. G3 标准完整命令

在功能和退役完成后执行一次，分别登记时间、退出码和失败类别：

```text
npm run format:check
npm run lint
npm run type-check
npm run test:coverage
npm run build:mp-weixin
npm run contract:check
npm run backend:check
node scripts/frontend-boundaries.mjs
python backend/scripts/check_boundaries.py
npm run security:secrets
```

backend安全/迁移已在G1证明，G3 backend完整suite仍包含对应用例，不另外再运行一次相同完整backend:test。若fixture/migration在G1后有新改动，先补定向安全检查。

无依赖或构建依赖变更，本轮不为纯业务重复audit:all/prod/backend:audit；若实施新增/更新依赖则先更新计划并纳入审计。禁止用增加allowlist规避问题。

前端门槛保留当前statements/lines/functions85%、branches80%，后端保留现有85%门槛，不降低、不移除合理coverage范围。历史覆盖率不足或secret3项指纹不能倒写为通过；标注当前结果与既有外部责任项，不无休止追加与本功能无关测试。

## 7. 微信开发者工具最小完整验收

```powershell
$env:VITE_APP_MODE='demo'
$env:WECHATIDE_CLI_PATH='D:\codeapp\微信web开发者工具\wechatide.cmd'
$env:WECHATIDE_CLIENT='Codex'
npm run dev:mp-weixin
```

保持watcher，等待 `Build complete. Watching for changes...`，另一个设置同CLI变量的终端通过支持的工具打开并刷新唯一开发目录 `D:\CODE\weixin\wxprogrom7.15\dist\dev\mp-weixin`，执行 `npm run test:mp:doctor` 获取SDKVersion。不得用生产目录替代。

只用 automation_element_action 真实tap/input/scroll和 simulator_screenshot 后台内部通道。无setData、页面方法、旧App.* WebSocket、系统鼠标键盘、清理工具数据或关闭安全校验。

| UI ID | 操作及证明                                                                   |
| ----- | ---------------------------------------------------------------------------- |
| UI01  | 自主完成研讨→任务卡真实进入新计划→资料确认→病例三个阶段→最终测试→结果        |
| UI02  | 课堂完成研讨后路线立即可学；教师同一分析编辑/保存/开放；学生双条件满足后测试 |
| UI03  | 路线已完但教师未审，真实等待状态；开放后返回保留进度                         |
| UI04  | 测试草稿退出恢复、一次提交后无重考；课堂结果在教师进度/巩固/学情只计一份     |
| UI05  | 一个代表生成/回复失败状态及可见恢复；空任务/完成记录有正确入口               |
| UI06  | 默认视口长资料/对话/解析和固定栏；窄屏抽查case键盘与长题，实际scroll/返回    |

主线使用默认视口，窄屏320逻辑宽抽查受影响输入/固定栏，不做全站多宽度矩阵。非整数分/零分可由真实新Demo状态或逻辑证据覆盖；不为每个seed强制拍图。

先用watcher/产物/WXML/元素属性/真实断言确认状态，只在必须证明可见结果时截图。每页面每状态默认一张当次代表性图；损坏/关键区域缺失/真实新状态才补拍并记原因。正常返回不要求重复截图。截图须逐张审阅，敏感答案/隐藏病例不纳入证据输出。

构建、逻辑、握手、交互、截图渲染分别报告。工具未就绪、无法真实点击或无可审阅截图时对应项待验收，不用源码/DOM/旧截图补成通过。本次不执行真机。

## 8. 停止规则

1. G3首先完整执行一轮各标准项，不因一个失败跳过其他独立项的记录。
2. 失败先定位本次范围或既有基线；修复后只复跑失败/受影响检查。
3. 仅实质代码/schema变更使原集成结论失效时，补一次完整复验；无改动不重复全量。
4. 若仍有覆盖率/外部/工具阻塞，记录明确未通过、影响和解除条件，完成交接并停止本轮验收。不新增无限回归队列，不标全绿。
5. 修纯文案、等待用户状态或观察同状态不触发新的全量/近似截图。达到当前验收目的立即停止。

## 9. 交付判定

完整仓库内与工具所测范围完成：需求追踪全部实现，G0/G1/G2/G3按范围通过，Demo两条真实主线和当次渲染证据完备，旧二轮无运行入口，清理在受管测试资源证明，保留项完整。

主要功能已实施/验收未完成：核心实现有证据但任一必要门禁、工具流程或可见状态未通过，明确列出缺口；不能宣称完整验收。实际开发库清理、真实Coze、专家医学质量、PostgreSQL/生产与真机分别列外部状态。

文档完成：仅G0和文档需求追踪通过，P1–P7保持待执行。当前这次任务适用该结论，不需要为文档执行运行门禁。
