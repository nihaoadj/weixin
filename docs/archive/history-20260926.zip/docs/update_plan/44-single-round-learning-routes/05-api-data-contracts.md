# 05 API、公开接口与数据合同

状态：T44 待实现合同。路径均为业务 path，不含应用统一 API 前缀。API/Demo 必须同形，不允许客户端绕过服务器推断状态。

## 1. 通用约定

- 新 route/step/case/test/question/attempt/result 外部 ID 为 UUID 字符串；内部整数 ID 不暴露。源 PBL locator 沿用经过授权的来源合同。
- actor 来源为登录身份，body 不接受 student_id、teacher_id、class_id 或 released 标志用于授权。
- 写入 `client_request_id` 长度 1–100，消息使用 client_message_id，最终提交使用 client_submission_id；相同身份+operation+ID 的异 payload 返回 409。
- UTC ISO 时间，显示时按上海时区；空分数/时间/归属用 NULL，不填 0/空日期。
- 列表 `{items,total,limit,offset}`，默认 20、最大 100，稳定排序 updated_at DESC,id DESC。
- 读取是纯 GET；进入测试会产生 attempt，因此单独使用 POST start，不在 GET 偷写。
- version 为正整数，答案 index 严格整数 0–3。拒绝 extra 字段和 bool 冒充整数。

retry-generation 的可恢复范围包括失败、过期 claim，以及无有效 claim 的未成功 pending；恢复 test 还要求 route 已发布。不能重试成功内容或抢占仍有效的生成请求。

## 2. 学生 API

| Method / path                                           | 请求重点                                                         | 响应/规则                                                 |
| ------------------------------------------------------- | ---------------------------------------------------------------- | --------------------------------------------------------- |
| GET `/learning/routes`                                  | status=active/completed, limit, offset                           | 本人 RouteSummaryPage；active 包括生成失败与等待审核      |
| GET `/learning/routes/{route_id}`                       | UUID                                                             | RouteDetail，不返回锁定测试题/答案                        |
| POST `/learning/routes/{route_id}/retry-generation`     | component=route/test, client_request_id                          | 同 route detail/locator；只恢复未成功组件，含中断 pending |
| GET `/learning/route-steps/{step_id}`                   | UUID                                                             | 本人已开放步骤；验证所属 route；locked 返回冲突           |
| POST `/learning/route-steps/{step_id}/reading-progress` | action=start/heartbeat/pause, lease_token?, client_request_id    | ReadingProgress；服务器累计有效时长                       |
| POST `/learning/route-steps/{step_id}/complete-reading` | client_request_id                                                | 更新 RouteDetail；不能由 body 传 completed_at             |
| GET `/learning/route-cases/{case_id}`                   | UUID                                                             | 本人病例公开情境、三阶段状态、本人分页/有限历史           |
| POST `/learning/route-cases/{case_id}/messages`         | client_message_id, content, expected_revision                    | CaseMessageResult；合法结构化反馈和进度                   |
| POST `/learning/final-tests/{test_id}/start`            | client_request_id                                                | 已解锁时创建/恢复唯一 attempt locator                     |
| GET `/learning/routes/{route_id}/final-test`            | UUID                                                             | 已解锁 test public+attempt；未解锁不返回 questions        |
| PUT `/learning/final-tests/{test_id}/draft`             | client_request_id, expected_version, released_digest, answers    | TestAttemptRead；允许合法部分答案                         |
| POST `/learning/final-tests/{test_id}/submit`           | client_submission_id, expected_version, released_digest, answers | LearningResult；整份一次提交                              |
| GET `/learning/routes/{route_id}/result`                | UUID                                                             | 本人提交后的唯一结果；未提交返回明确无结果                |

final-test GET 在合法解锁且尚无 attempt 时可返回 test 与 attempt=null；页面先 start 再读取或由 start 响应获取相同 public test。读题本身不开放新测试。

## 3. 教师 API

| Method / path                                                   | 请求重点                                                       | 响应/规则                                             |
| --------------------------------------------------------------- | -------------------------------------------------------------- | ----------------------------------------------------- |
| GET `/learning/teacher/final-tests`                             | class_id, session_id?, status?, limit, offset                  | owned class 审阅列表，仅 classroom                    |
| GET `/learning/teacher/final-tests/{test_id}`                   | UUID                                                           | 固定研讨分析及当前一份测试，含答案/解析               |
| PUT `/learning/teacher/final-tests/{test_id}`                   | client_request_id, expected_version, questions, feedback_draft | 完整草稿保存；1–12题，主要目标全覆盖                  |
| POST `/learning/teacher/final-tests/{test_id}/request-changes`  | client_request_id, expected_version, note?                     | 同一份测试标记 needs_changes，不重建待办              |
| POST `/learning/teacher/final-tests/{test_id}/retry-generation` | client_request_id                                              | 在 owned class 范围重试失败题目，不重新生成已发布路线 |
| POST `/learning/teacher/final-tests/{test_id}/release`          | client_request_id, expected_version, draft_digest, feedback?   | ReleaseReceipt；冻结当前题目版本                      |
| GET `/learning/teacher/route-results`                           | class_id, session_id?, student_id?, 日期, 分页                 | 完成课堂结果摘要；授权来自服务器                      |
| GET `/learning/teacher/route-results/{result_id}`               | UUID                                                           | 课堂唯一结果，不返回病例对话/私人续问                 |

content 的现有题库 API 更改 source locator 为 type+ID+digest 的通用来源；新增支持 `route_test_question`。题库 public API 继续单独负责列表/筛选/编辑/归档，不把入库嵌入 release 事务。

教师待办和 PBL diagnostic detail 可通过组合 port 显示 test locator，不能从旧 suggestion ID 拼测试 URL。课堂 dashboard 复用已授权课堂 endpoint，响应增加 route/test/result 状态，删除 max_cycles 等字段。

## 4. DTO 的最小明确形状

| DTO               | 必须有的字段                                                                                                  | 明确排除                                                |
| ----------------- | ------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------- |
| RouteSummary      | id,title,source_kind,session_locator?,主要目标,status,next_action,progress,updated_at,test_summary,result_id? | 全题、答案、病例对话、teacher metadata、自主班级归属    |
| RouteDetail       | summary,固定本人分析摘要,steps,test_summary,can_start_test,lock_reasons,route_version                         | 模型 raw payload、完整原研讨、私人续问                  |
| StepSummary       | id,position,kind,title,目标,status,completed_at?                                                              | 不可读步骤的正文、评分或答案                            |
| ReadingStep       | step summary,sources,ai_guide,sections,learning_points,reading_progress                                       | AI 新造来源、专家签署的虚假标签                         |
| CaseRead          | id,step_id,synthetic_case,phase,revision,status,目标,本人 messages,next_prompt,安全提示                       | private completion rubric、参考推理、原课堂隐藏病例字段 |
| CaseMessageResult | accepted message identity,reply,phase,revision,decision,missing_elements,status                               | provider secret/DTO、内部 prompt、数字成绩              |
| TestSummary       | id,title,question_count,generation_state,review_state,review_kind,can_start,lock_reason                       | questions,correct_option,explanation                    |
| StudentTest       | id,released_version/digest,questions[{id,position,point_code,prompt,options}],attempt                         | correct_option,explanation,review internal note         |
| TeacherTest       | test metadata,分析摘要,完整 editable questions,version,draft_digest                                           | 自主数据、原研讨完整聊天、路线病例回答                  |
| TestAttemptRead   | id,status,version,本人 draft answers,保存/提交时间                                                            | 未提交正确项及得分                                      |
| LearningResult    | id,source_kind,目标,路线摘要,correct_count,question_count,score,submitted_at,逐题本人选择+答案解析            | 第二轮、补考、达标阈值、他人数据                        |

progress 为 `{completed_steps,total_steps}`，不把最终测试混入路线步数。next_action 是服务端枚举 reading/case/test/wait_teacher/retry_route/retry_test/view_result，不由 title 判断导航。

## 5. 后端 public port

在 learning public 暴露以下窄能力，具体实现由 wiring 注入：

- `CompletionLearningRoutePort`：从已验证 PBL completion command 幂等创建 shell，提交后触发一次生成并返回 locator；不接受任意聊天文本。
- `LearningRouteProgressReadPort`：读取 classroom scope 内路线/测试/结果摘要，禁止完整病例消息。
- `LearningRouteResultReadPort`：按 owned class/date/student/session 读取已完成课堂结果及统计事实。
- `RouteTestQuestionSourcePort`：供 content 导入教师题库，返回无学生材料的题目快照+digest，授权由源与题库双方验证。
- `LearningRouteInferencePort`：路线、最终题目、病例回应三种结构化调用；通过 pbl provider wiring/现有受管 transport 装配，不暴露 HTTP DTO 到 application。

pbl public 提供完成上下文与固定分析读取；content public 提供目录、source/material snapshot。不能从 learning infrastructure 直接 import pbl/content 的 api，不能给架构 allowlist 增加例外掩盖依赖。

## 6. 前端 public 能力与 adapter

新类型集中在 `src/features/learning/domain/learningRoutes.ts`、`finalTests.ts`、`routeCases.ts`；端口增加相同能力，页面只 import public：

```text
getLearningRoutes / getLearningRoute / retryLearningRouteGeneration
getLearningRouteStep / saveRouteReadingProgress / completeRouteReading
getRouteCase / sendRouteCaseMessage
startFinalTest / getFinalTest / saveFinalTestDraft / submitFinalTest
getLearningRouteResult
getTeacherFinalTests / getTeacherFinalTest / saveTeacherFinalTest
requestTeacherTestChanges / retryTeacherTestGeneration / releaseTeacherFinalTest
getTeacherRouteResults / getTeacherRouteResult
```

PBL 完成响应增加 nullable learning_route_id 与生成状态，完成后必须有有效 shell ID；旧 study start 仅负责建立研讨、返回关联路径信息，不再返回 practice_unlocked/canRetest。

API adapter：平台 HTTP→Zod→显式 mapper→领域对象；Demo adapter 实现同一 port、状态机、幂等与失败形态，只有合成身份和模型结果不同。wiring 显式按 VITE_APP_MODE 装配，不存在异常 fallback。

## 7. 错误、缓存与身份切换

| HTTP / 稳定码                                                              | 情形                              | UI 恢复                              |
| -------------------------------------------------------------------------- | --------------------------------- | ------------------------------------ |
| 404 RESOURCE_NOT_FOUND                                                     | 非本人、非 owned class、已清理 ID | 通用无资源状态，不能暴露是否存在     |
| 409 STATE_CONFLICT + reason=STEP_LOCKED/ROUTE_INCOMPLETE/TEST_NOT_RELEASED | 合法本人但前置未满足              | 显示服务端原因，返回计划             |
| 409 STATE_CONFLICT + VERSION_CONFLICT                                      | 陈旧草稿/释放 digest              | 保留输入，重新加载后再明确提交       |
| 409 STATE_CONFLICT + ALREADY_SUBMITTED/IDEMPOTENCY_MISMATCH                | 已提交异 payload/幂等冲突         | 读取既有结果，不新建 attempt         |
| 422 VALIDATION_ERROR                                                       | 答案索引、缺题、额外题或目标无效  | 校正输入；不能部分计分               |
| 503 SERVICE_ERROR + generation/case failure code                           | provider、schema、安全或超时      | 保留成功组件、重试本组件；不透传原文 |

reason 使用受控字段，不依赖解析 error message。401 沿用身份失效处理。

读取缓存按 user identity+resource+version；阅读完成、病例推进、release、draft、submit 成功后精准失效对应 detail/list/test/result。教师开放不会清除学生学习步骤。角色切换与登出清空当前请求作用域；晚响应不能写入新用户状态。

生成、case message、最终提交一律不使用平台自动重复写重试；业务 receipt 决定可安全重放。日志只记 metadata、错误码、request identity 摘要、耗时，不写 answers/prompt/聊天。

## 8. 旧合同退役与生成

旧 self-practice 写接口、PBL learning-task submit、suggestion adopt、双轮包 save/medical-review/publish、旧 report repair 路径统一退役：经身份校验的旧 mutation 返回 409 RETIRED_FLOW；被清理具体资源的 read 返回 404，旧集合 read 返回空的明确退役合同或由新客户端移除消费者，不继续返回旧计划。

后端 Pydantic/schema 先完成；运行 `npm run contract:generate` 更新 OpenAPI、generated TypeScript 和该流程自动生成的 fixtures/catalog；随后改 Zod、mapper、API/Demo 与 contract tests，再运行 `npm run contract:check`。不得手改生成物或为了通过暂留 cycle=1/2 的执行分支。
