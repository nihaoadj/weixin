# 09 分步骤、分节点实施

状态：全部运行实施步骤待执行。本章是后续执行队列，不能因为文档完成把 P1–P7 标绿。每阶段失败先修本阶段，不回到已通过且未受影响的步骤重复验收。

## 1. 四个检查节点

| 节点        | 时点                      | 范围                                                            | 不执行                                   |
| ----------- | ------------------------- | --------------------------------------------------------------- | ---------------------------------------- |
| G0 文档门禁 | P0 完成                   | 文档格式/相对链接/空白、工程 self-check、需求追踪               | 全量测试、构建、Demo                     |
| G1 数据安全 | P1 模型/迁移/清理方案完成 | 临时库安全、0033/0034/清理保留项/拒绝与恢复                     | 前端全量、全站工具验收、真实库默认 apply |
| G2 业务合同 | P2–P4 主业务合并完成      | 新业务定向用例、权限/并发/provider/评分/API-Demo 合同、模块边界 | 全局覆盖率、完整跨角色工具回归           |
| G3 最终集成 | P5/P6 页面与退役完成      | 一次标准完整门禁、一次受影响 Demo 交互/渲染、交付               | 旧 T43 全量验收队列、真机、生产          |

P1 可先在隔离迁移环境验证完整 schema，运行模块在 P2–P6 对齐；若 0034 因旧 consumers 尚未退役只能先验证 0033/清理，则 G1 如实标“部分”，P6 仅补 0034 差异用例后关闭，不重复全部 G1。未关闭 G1 不进入最终交付。

## 2. P0 文档、事实和执行基线

| 步骤 | 操作                                               | 产物/完成条件                               |
| ---- | -------------------------------------------------- | ------------------------------------------- |
| P0.1 | 读取根规则、适用权威文档、git status，保护已改文件 | 当前审计和既有改动范围清楚                  |
| P0.2 | 写本计划各章、用户决定、需求追踪和清理边界         | 不留课堂/自主、成绩、审核、历史处理决策缺口 |
| P0.3 | 明确 schema/head、old/new 接口和代码改动位置       | 执行者无需另查流程归属才能开始              |
| P0.4 | 更新计划索引、压缩 T42、保留已有未跟踪目录         | 当前索引 T44/T43，不恢复 T43 验收           |
| P0.5 | 执行 G0，写文档 delivery                           | G0 通过；代码仍未实施                       |

## 3. P1 数据、迁移与清理

| 步骤 | 具体修改                                                                                       | 产物/完成条件                                        |
| ---- | ---------------------------------------------------------------------------------------------- | ---------------------------------------------------- |
| P1.1 | learning 新 route_models.py 与 domain 状态规则，注册 metadata；所有新 source/scope/unique 约束 | 一来源一计划、一测试一次提交被数据库保护             |
| P1.2 | content 题库通用来源字段、mapper/import receipt，旧 FK 可脱钩                                  | 内容/版本保留，旧来源不可回查学生                    |
| P1.3 | 0033、新 schema/default、source 映射、cutover manifest、旧 ID 单调保护                         | 0032→0033 与空库均验证；不删除业务数据               |
| P1.4 | cleanup_t44_learning.py，默认 dry-run、备份、digest、关联 closure、停写和事务校验              | 目标/保留清单可审阅；歧义或备份失败拒绝              |
| P1.5 | 0034 的旧结构预检与退役；保留独立 training/shared learning                                     | 有旧记录拒绝、清理后允许；downgrade 不假恢复         |
| P1.6 | fixture/测试种子适配新 head，旧 schema 迁移 fixture 独立保存                                   | 不对真实 dev.db 执行测试，不 create_all 冒充历史升级 |
| P1.7 | G1，记录每个检查结果                                                                           | 清理和保留项在受管临时库证明；实际目标 apply 另记    |

P1 不自动执行受管开发库 apply。实际资源具备后按第07章一次切换，不用反复全量测试代替资源核实。

## 4. P2 AI 与完成后自动生成

| 步骤 | 具体修改                                                                          | 产物/完成条件                                  |
| ---- | --------------------------------------------------------------------------------- | ---------------------------------------------- |
| P2.1 | PBL schema v8、request builder、checked gateway、Bot/Workflow/parser/开发 adapter | 保留四阶段/回应方式，删除双轮候选和自动补充卡  |
| P2.2 | 新 route/test/case strict inference schema 与最小输入 mapper                      | 来源/目标/证据 allowlist，无学生身份或私密外发 |
| P2.3 | pbl completion 用例注入 learning completion port，创建 route/test shell locator   | completion 与 shell 同事务；外部失败不回滚完成 |
| P2.4 | claim、事务外 route 生成、原子发布、再 test 生成与来源审核状态                    | 成功路线不被 test 失败阻塞；自主直接/课堂待审  |
| P2.5 | 分组件 retry 与过期 claim，重复完成回调不再生成                                   | 同来源只有一份对象，GET 无副作用，无 fallback  |
| P2.6 | 对应 provider/幂等/失败恢复定向检查                                               | 此阶段不跑全量 backend/frontend                |

## 5. P3 路线学习、病例、测试与结果

| 步骤 | 具体修改                                                              | 产物/完成条件                            |
| ---- | --------------------------------------------------------------------- | ---------------------------------------- |
| P3.1 | route list/detail 和 reading step 用例/API、前台 heartbeat/complete   | 顺序和本人校验，时长只记进度，失败不解锁 |
| P3.2 | case start/read/message repository、strict phase checks、revision CAS | 三阶段逐个学习，无数字评分、无聊天泄漏   |
| P3.3 | test 双条件 read/start、唯一 attempt、draft 版本保存                  | 两个条件任一缺失都不读题/不作答          |
| P3.4 | 最终 submit、确定性正确率、result freeze、receipt/证据                | 一次整份提交；未交无分数，零分 completed |
| P3.5 | 新证据 source 与正式/私人范围、结果读取                               | 路线无分，课堂 formal、自主 student_only |
| P3.6 | 状态/并发/事务/权限/答案负向定向检查                                  | 修失败项，不在小修改后跑全局覆盖率       |

## 6. P4 教师审阅、题库、学情与公开合同

| 步骤 | 具体修改                                                                | 产物/完成条件                                |
| ---- | ----------------------------------------------------------------------- | -------------------------------------------- |
| P4.1 | teacher test list/detail/save/request-changes/retry/release 用例及 port | 同一分析和测试，无逐题医学审核；owned class  |
| P4.2 | 问题覆盖、version/digest、开放原子回执、反馈和通知                      | released 不可改，不重复开放/工作项           |
| P4.3 | content 题库新来源桥接、导入/编辑/归档                                  | 无学生材料，副本不改变已开放题               |
| P4.4 | classroom dashboard/progress 与 analytics result read port              | 只计完成课堂结果，过程/自主不计正式成绩      |
| P4.5 | frontend domain/ports/public、API/Demo adapters、Zod/mapper/wiring      | 页面无需绕过 public；API 显式错误无 fallback |
| P4.6 | contract:generate，同步所有生成产物及相关 fixtures                      | 不手改 OpenAPI/types；catalog 仍来自数据库   |
| P4.7 | G2：定向业务包+contract check+前后端 boundaries                         | 关闭关键状态/权限/计分/来源；不全量验收      |

## 7. P5 页面、任务入口与 Demo

| 步骤 | 具体修改                                                  | 产物/完成条件                           |
| ---- | --------------------------------------------------------- | --------------------------------------- |
| P5.1 | 注册六个新 student learning 页面和导航常量                | 参数/身份保护、原生返回和来源上下文     |
| P5.2 | learning 首页与 PblTaskList 真实 route card、全部任务列表 | 知识点不伪任务，卡片进入 plan-detail    |
| P5.3 | reading/case 交互、timer、键盘、安全区、错误/恢复         | 可顺序真实学习，过程不出现分数          |
| P5.4 | final-test/result，draft/submit feedback 和解析           | 提交前无答案，提交后只读，无再测        |
| P5.5 | knowledge-node、PBL completion、student insights 深链     | 移除旧练习，指向同 route/result         |
| P5.6 | teacher diagnostic/progress/follow-up/analytics 页面替换  | 单份审阅/单份结果，无旧轮次/阈值        |
| P5.7 | Demo 业务版本、D01–D10，真实可走课堂/自主                 | 清理旧集合但保留资源；刷新不 reset 进度 |
| P5.8 | 页面行为、adapter、类型、改动文件 Lint/格式定向检查       | 本阶段不重复全部页面截图或全局测试      |

必须在 G3 前完成 Demo，不接受“API 已改，Demo 待以后同步”的交付。

## 8. P6 旧逻辑彻底退役

| 步骤 | 具体修改                                                                                 | 产物/完成条件                                             |
| ---- | ---------------------------------------------------------------------------------------- | --------------------------------------------------------- |
| P6.1 | 删除旧 study practice、PBL mastery/intervention、classroom package 执行与公开能力        | 无第二轮生成/激活/提交路径；独立病例能力保留              |
| P6.2 | 退役 suggestion adopt、包 publish/medical-review、旧 plan submit/report repair API与脚本 | 旧 mutation 明确 RETIRED_FLOW，旧 read 无串新数据         |
| P6.3 | 去旧模型 registry/re-export/schema/default/seed，完成0034                                | 新 head、空库/旧库升级/保留证明一致                       |
| P6.4 | 清除 UI cycle/达标/改善/耗尽、通知深链、过期测试断言                                     | 不靠只删文字掩盖仍运行的双轮逻辑                          |
| P6.5 | 更新相关架构/数据/接口/数据库/安全/开发/设计文档                                         | 根据实际完成证据改当前规则；历史迁移不改写                |
| P6.6 | rg 残留审计和最小退役断言；有0034差异补 G1 对应项                                        | 剩余 cycle 只允许原PBL多轮对话/独立通用语义或历史迁移记录 |

退役检索至少含：`can_retest/canRetest`、`max_cycles/maxCycles`、`current_cycle/currentCycle`、`automation_exhausted/automationExhausted`、`next_cycle_activated`、双变式生成、PBL mastery 阈值、旧报告 repair。逐个分类，不能要求历史文档和迁移中所有“第二轮”字样消失。

## 9. P7 最终交付节点

1. 核对需求追踪每项有实际实现证据、G0/G1/G2 无未处理关键失败。
2. 执行 G3 一轮标准完整检查，分项记录结果，避免 wrapper 失败后其他项未执行却标绿。
3. 显式 Demo watcher、dev 项目普通编译、doctor，真实走自主和课堂主线；截图最少充分并逐张审阅。
4. 修本次出现的问题，只重跑受影响失败项；如果代码变化实质影响集成结论才补一次完整复验。
5. 停止验收，写完成范围、失败项、外部项及回退。未达门槛则结论为主要功能已实施/验收未完成，不继续无限追加测试。
6. 只有用户明确授权才提交/推送；本次文档或实施授权不自动授权提交、部署、生产清理或外部平台变更。

## 10. 阶段记录规则

每个 P/G 更新 [实施记录](deliveries/implementation-progress.md)：修改范围、命令/UTC或上海时间、退出码、结果、未执行与原因、实际资源、下一步。没有命令/交互证据的状态不能写通过。纯局部样式/文案修复只记录受影响检查，不建立新的全量节点。
