# T43 实施进度记录

状态：进行中，仅记录本工作树已执行的步骤；未达到 T43 功能交付。

## P0 基线与门禁

- 日期：2026-09-23，Asia/Shanghai；分支 `dev`，HEAD `5c961ead8df6030e605aa7a651e8b4ebdcd72055`。
- 工作树已有大量他人或历史未提交改动，尤其 PBL、learning、content、analytics 和前端文件。本次保留全部既有改动，不 reset、clean、提交或推送。
- 核对运行时缺少 T43 的包、最终报告和题库表；迁移原 head 为 `20260919_0030`。阅读 01–10、根规则及工程/UI skill。
- 文档 Prettier、工程 skill 两项 self-check、现有规则文档 `git diff --check` 退出码均为 0；没有把文档门禁当成功能验收。

## P1 已写入的实现

- learning 新增课堂包、两轮题目、最终报告、发布回执及历史映射模型；content 新增教师题库项、不可变 revision 及入库回执模型。PBL 反馈增添可空包引用。
- 新增 Alembic `20260923_0031`，兼容当前 metadata 首迁移和既有 `0030` 数据库；包含唯一约束、状态约束、索引及有数据拒绝降级。内容模块现有医学审核之外新增按题目摘要冻结的课堂客观题审核记录。未对开发或生产数据库执行迁移。
- 新增纯规则：课堂目标覆盖与两轮配对；最终报告从持久化评价确定性组装，并白名单排除答案和评分内部字段。
- `backend/tests/test_migrations.py` 的 head 断言更新为 `0031`；针对旧库升级、空降级、有数据拒绝、包唯一性、草稿覆盖、首轮/二轮报告新增定向测试。
- 已把模型和纯规则接入课堂包草稿、发布、客观题提交与终态报告事务；并发发布的独立多连接压测、病例任务回调及完整报告恢复重建仍未验收，不能把 P1 标记完成。

## P2 已写入的实现

- 新增独立 `ProviderPayloadV7` 和候选两轮变式的严格 schema，以及无明确薄弱点和错误输出的定向测试。
- Coze bot/workflow、开发 provider 的请求与解析已可显式选择 v7；CheckedGateway 校验课堂目标、私人研讨边界与服务端资源允许列表。v7 诊断结论和候选两轮题已可保存于完成快照；迁移补齐旧库字段，禁止在 v7 数据存在时降级。
- 新建课堂/自主研讨 session 固定 v7；既有 session 在迁移时固定为 v6，历史四阶段和建议发布测试以明确 v6 会话继续复验。受控 local mock 提供 v7 合成诊断，分别覆盖有薄弱点和无明确薄弱点；不会把该演示断言为真实 Coze 医学准确性。content 已增加病例与推理蓝图版本/医学审核引用核验，实际病例任务仍待闭环。

## P3 已写入的实现

- 教师经原有诊断授权后，可对 v7 课堂完成快照调用 ensure 草稿，按学生与课堂唯一约束建立一个包；重复请求返回原包，旧课堂已有正式计划时拒绝新包。草稿题目包含首轮与第二轮，答案解析仅在教师详情返回。
- 新增教师草稿 GET/PUT；PUT 用版本条件更新，禁止改任务归属、变式身份和评分类型，保存后清除审阅确认并使内容维持待医学审核。教师间资源标识返回 404。
- 客观题医学审核新增教师按版本提交、专家队列及一次审批接口；审核记录只含去身份的题目内容，题面修改会使旧审批对当前摘要失效。审核权限与题目版本在服务端核验，不允许普通教师自行批准。
- 整包发布检查课堂/学生归属、两轮目标覆盖、当前题目医学审批和教师确认摘要，事务内写入唯一正式计划、固定接收者任务、学生通知、幂等回执及显式发送的反馈。发布先占用草稿版本，发布后草稿 PUT 拒绝；旧建议发布代码对 v7 快照保持拒绝。
- 内容模块新增教师个人题库入库/本人列表与筛选/详情/编辑新 revision/归档接口。入库从学习模块只读端口取得已授权题目及来源摘要，由教师明确确认去标识化并提交白名单副本；源版本重复请求返回同一题库项，后续编辑不改来源任务且医学状态回到待审核。当前只有客观题的医学审核适配，micro_drill/病例资源验证、草稿删非必需候选及前端入口仍缺失，因此 P3 未完成。

## P4 已写入的实现

- 学生可只读查询本人已发布课堂包并提交客观题、讨论题；未激活第二轮题面不返回。旧独立 PBL 计划提交路径保持原状。课堂包任务沿用版本化两轮判定，首轮不达标只激活失败目标对应变式。
- 首轮达标或第二轮结束后，在同一提交事务从已保存的 evaluation 构建唯一、不可含答案/私有评分规则的最终报告；重复同键同答案只返回同一结果。教师可按本人班级读取报告，其他教师得到 404。专门测试通过首轮达标、二轮耗尽、单轮不提前生成和重复提交。
- 学生课堂病例任务现有 `start` 路由，基于任务身份复用唯一病例 attempt；未激活第二轮、非本人及非病例任务拒绝启动。病例 assessment 后经 learning 回调生成包内任务证据、推进两轮判定，并在终态生成一份报告；重复回调不重复生成任务 attempt 或报告。
- 独立病例完成后不再自动创建正式学习计划；其 approved assessment 仅写 `student_only` 证据，包内病例不另写教师可见病例证据。示例数据移除旧自动建计划调用。完整报告恢复重建、病例五阶段 API 至报告的端到端测试、训练前端反馈、旧结果统计切换、学生/教师小程序页面及 Demo 仍未完成，不能把 P4 标记完成。
- 自主研讨完成后学生过程学习报告仍须可读；报告投影已接纳 v7 快照，定向复测通过。旧 v6 逐建议发布的历史用例与新 v7 课堂目标不应混为同一验收路径。

## P5 已写入的部分后端实现

- learning 新增教师班级授权的 `FinalReportReadPort`，只读终态报告和发布包进度；报告查询再次核对包/计划/学生/课堂归属，不把独立病例、任务 attempt、轮次或旧 evidence 直接作为结果。analytics 新增 `schema_version=2` 服务，按上海自然日从最终报告计算总览、学生列表/综合详情、知识与能力投影；进行中进度另按发布窗统计，旧单病例教师详情在授权后返回退役冲突。
- 原 `/analytics/overview`、`/analytics/students/{id}`、`/analytics/classes/{id}/knowledge` 已切换到新版响应，并新增 `/analytics/students`、`/analytics/classroom-progress`。受管临时数据库的定向测试覆盖空报告、进行中不计结果、终态报告、上海日期与跨教师 404；OpenAPI/TS 生成及 `contract:check` 通过。
- 此为后端部分路径，不是 P5 出口。后续已补学情 v2 前端局部接线，见下方“前端增量”；PBL 巩固报告、完整 Demo seed/store 与微信页面验收仍未同步。旧 analytics 方法仍存在，PBL 巩固详情在 API 模式可能因旧合同解析失败。旧全量分析测试仍按被替换的旧病例/证据口径断言，需要按 T43 新合同更新并复跑。
- 2026-09-23 文档复核发现当时课堂进度只有四项聚合计数，没有第 03 册要求的逐学生未发布/进行中/逾期/已完成列表；第 05 册补充独立明细合同。2026-09-24 的局部实现见下方记录，不能把这项历史差距当作最新现状。

## 仓库内验证

命令均在仓库根目录运行，除注明 `cd backend` 外；退出码为实测。测试使用受管临时 SQLite。

| 命令或范围                                                                                                                                                             | 退出码 | 结果                                                                      |
| ---------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ------ | ------------------------------------------------------------------------- |
| `npm run backend:test:safety`                                                                                                                                          | 0      | 14 passed；现存 SQLAlchemy FK 排序警告                                    |
| `npm run backend:test:migrations`（反馈 FK 调整后复跑）                                                                                                                | 0      | 22 passed；现存 SQLAlchemy FK 排序警告                                    |
| `cd backend; python -m pytest tests/test_t43_migration.py tests/test_t43_package_schema.py tests/test_t43_package_coverage.py tests/test_t43_final_report_rules.py -q` | 0      | 14 passed                                                                 |
| `cd backend; python -m pytest tests/test_t43_provider_schema.py -q`                                                                                                    | 0      | 9 passed，含 v7 快照往返与权限范围                                        |
| `python -m pytest backend/tests/test_t43_package_draft.py backend/tests/test_t43_final_report_rules.py backend/tests/test_t14_automatic_mastery.py -q`                 | 0      | 20 passed，含审核、发布、首轮/二轮、报告隔离及旧两轮规则                  |
| `npm run contract:generate`、`npm run contract:check`                                                                                                                  | 0      | 新增草稿接口生成物同步并逐字节校验                                        |
| `npm run type-check`                                                                                                                                                   | 0      | 前端及脚本类型检查通过                                                    |
| `python backend/scripts/check_boundaries.py`                                                                                                                           | 0      | 9 个模块边界通过                                                          |
| `cd backend; python -m alembic heads`                                                                                                                                  | 0      | 单一 head `20260923_0031`                                                 |
| 受影响 Python 文件 Ruff lint/format                                                                                                                                    | 0      | 已检查与格式化；后续修改须复查                                            |
| 本轮 T43 文档 Prettier、相对链接、尾随空白                                                                                                                             | 0      | 14 份文档、14 个相对链接有效                                              |
| `npm run backend:test:safety`（医学审核表及发布/提交后复跑）                                                                                                           | 0      | 14 passed；现存 SQLAlchemy FK 排序警告                                    |
| `npm run backend:test:migrations`（医学审核表及发布/提交后复跑）                                                                                                       | 0      | 22 passed；现存 SQLAlchemy FK 排序警告                                    |
| `python -m pytest backend/tests/test_t43_migration.py -q`                                                                                                              | 0      | 旧库升级、空降级、有数据拒绝通过                                          |
| `npm run contract:generate`、`npm run contract:check`（审核与发布接口后）                                                                                              | 0      | 生成快照逐字节一致；学生及报告接口新增后仍须复查                          |
| `python backend/scripts/check_boundaries.py`（发布反馈/提交后）                                                                                                        | 0      | 9 个模块边界通过                                                          |
| `python -m pytest backend/tests/test_t43_question_bank.py -q`                                                                                                          | 0      | 1 passed，入库幂等、本人隔离、版本与归档                                  |
| `python -m pytest backend/tests/test_t43_migration.py -q`（题库归档回执后）                                                                                            | 0      | 1 passed，旧库/空降级/非空拒绝                                            |
| `npm run contract:generate`（题库接口后）                                                                                                                              | 0      | OpenAPI 与 TS 类型已更新；仍须 contract:check                             |
| `python -m pytest backend/tests/test_t43_live_dialogue.py -q`                                                                                                          | 0      | 2 passed，新课堂 v7 两种诊断结论及草稿                                    |
| `python -m pytest backend/tests/test_t11_pbl_integration.py backend/tests/test_t43_provider_schema.py backend/tests/test_t43_migration.py -q`                          | 0      | 21 passed，历史 v6 闭环、v7 合同及迁移                                    |
| `cd backend; python -m pytest tests/test_t43_classroom_case_callback.py -q`                                                                                            | 0      | 2 passed，病例任务启动/回调/报告幂等、独立病例无新计划                    |
| `cd backend; python -m pytest tests/test_case_hardening.py tests/test_case_training.py tests/test_t43_classroom_case_callback.py -q`                                   | 0      | 7 passed；病例证据合同修正后复测                                          |
| `npm run contract:generate`、`npm run contract:check`（病例 start 路由及 v7 工作项变动后）                                                                             | 0 / 0  | OpenAPI、TS 类型及 fixture 同步并逐字节校验                               |
| `npm run backend:test:migrations`（会话 schema 版本列后）                                                                                                              | 0      | 22 passed                                                                 |
| `npm run backend:test:safety`（示例数据移除旧自动建计划后）                                                                                                            | 0      | 14 passed；此前修正前运行曾失败，不计入本次通过                           |
| `npm run type-check`、`python backend/scripts/check_boundaries.py`                                                                                                     | 0 / 0  | 类型检查与 9 模块边界通过                                                 |
| `npm run backend:test`（修正途中启动，不能作为修正后全量结果）                                                                                                         | 1      | 285 passed、16 failed；需更新旧功能断言并修复真实回归后重跑，不得宣称全绿 |

补充定向复测：`cd backend; python -m pytest tests/test_t17_unified_dialogues.py::test_both_styles_enter_the_same_teacher_and_learning_loop -q` 退出码 0，2 passed；`cd backend; python -m pytest tests/test_test_seed.py -q` 退出码 0，1 passed。两者不能代替全量复跑。

P5 后端定向复测：`cd backend; python -m pytest tests/test_t43_report_analytics.py tests/test_t43_package_draft.py -q` 退出码 0，8 passed；`npm run contract:generate`、`npm run contract:check`、`python backend/scripts/check_boundaries.py` 均退出码 0。此证据不覆盖前端合同、Demo 或完整后端回归。

2026-09-23 后续后端复核：`published_for_teacher` 增加正式计划来源类型、包 ID 与学生身份关联条件，避免错关联计划进入课堂进度；`test_t43_report_analytics.py` 增加负向断言及终态学生列表断言。`cd backend; python -m pytest tests/test_t43_report_analytics.py -q` 退出 0，1 passed；受影响文件 Ruff check/format 退出 0。`npm run backend:test` 在这些旧测试修订前启动并完成，退出 1，原始结果为 292 passed、10 failed；失败集中于退役的独立病例自动建计划、旧 analytics 病例口径和把新 v7 课堂当 v6 逐建议发布的历史用例。随后更新 `test_characterization.py`、`test_second_phase.py` 的新口径断言，并把 `test_pbl_api.py`、`test_t21_teacher_pbl_feedback.py` 明确固定为旧 v6 兼容测试；`test_t17_unified_dialogues.py` 改验 v7 合成回复。相关 9 项定向复测退出 0。`test_personalized.py` 与 `test_t04_concurrency.py` 中仍有 4 项旧独立病例建计划预期未迁移，尚未进行修订后的全量复跑；不能将全量结果标为通过。

上述后端修订后，`python backend/scripts/check_boundaries.py` 退出 0；受影响 Python 文件 `ruff check` 退出 0，3 个旧测试文件经 `ruff format` 后退出 0；T43 文档 Prettier 检查退出 0。该段记录的是当时后端修订，不能覆盖其后的前端工作。

### 2026-09-23 学情 v2 前端增量（未达到 P5/P6 出口）

- 新增 `classroomReports.ts` 领域类型、`classroomReports.ts` Zod 合同、显式 mapper 与 API 仓储方法；`analytics/public.ts` 暴露总览、学生列表/详情、进度和知识查询。`conformance.ts` 不再断言已退役的旧 analytics 生成 schema，改为核对 T43 schema。
- 学情工作区现有“总览/学习进度/知识掌握/学生学情”页内标签；新增只读课堂报告结果组件与学生综合详情，学生旧深链不再直接转 PBL 巩固。病例单项教师详情改为退役提示。页面使用新 public API，但报告列表尚无打开本课完整报告的入口，分页失败的局部恢复仍待完善。
- Demo 仓储接入同形状的**空报告**结果，未把 T42 独立病例证据冒充课堂最终报告。尚未提供终态报告、两轮任务、题库等可交互种子；PBL 巩固详情仍是旧计划加近 30 天综合学情，学生任务包与题库 UI 尚未迁移。
- 已执行 `npm run type-check`、`npm run lint`、`node scripts/frontend-boundaries.mjs`，退出码均为 0；定向 Vitest `classroomReports.spec.ts`、`teacher-workspace-alignment.behavior.spec.ts`、`page-navigation.spec.ts` 合计 29 项通过。此为局部检查，不代替全量测试。
- 显式 `VITE_APP_MODE=demo` 的 `npm run dev:mp-weixin` watcher 已输出 `Build complete. Watching for changes...`；开发者工具在规定 `dist/dev/mp-weixin` 目录打开并执行 `simulator_refresh`，`npm run test:mp:doctor` 退出 0。已通过真实 tap 选择教师角色，并以页面 WXML 核对学情空结果文字。精确点击学情标签的自动化选择器未定位到组件内部元素；未取得当次必要截图，也未完成学生详情/报告真实交互。因此普通编译之后的可见流程及渲染仍是待验收，不宣称微信验收通过。

### 2026-09-23 本课堂最终报告前端接线（未达到 P5/P6 出口）

- learning public/repository 新增教师按班级、课堂、学生筛选最终报告列表及按报告 ID 读取详情；platform Zod 校验后显式映射冻结报告，核对包、课堂、结论、策略及完成时间身份一致，不输出答案或私有评分规则。生成 OpenAPI 未手改，`contract:check` 复跑退出 0。
- 教师 PBL 首页“巩固跟进”改为仅展示本课堂终态报告；报告读取失败在该分区单独提示，不遮挡诊断记录。详情页不再调用旧计划与近 30 天 analytics，展示本课结论、目标和两轮评价；旧 `planId` 深链提示旧版任务而不伪称新报告。学情综合详情的每份报告可进入同一详情，分页失败不清除已有报告；返回路径按来源恢复。原生页标题改为“课堂最终报告”。
- Demo learning 仓储新增同形状的教师报告空列表与不存在详情，不从旧病例/计划合成终态报告；Demo 教师身份按 `demo_teacher` 与受管演示班 1 校验。开发者工具曾显示“班级不存在”，查明 Demo 教师会话不提供 `classIds` 后修正并刷新，随后 WXML 确认该错误消失。完整有报告/两轮 Demo 种子尚缺，不能视为 API/Demo 完成。
- `npm run type-check`、`npm run lint`、`node scripts/frontend-boundaries.mjs` 退出 0；前端边界检查曾发现 platform 反向依赖 feature 的临时写法，已改为 `platform/contracts/classroomFinalReports.ts` 并复跑通过。报告合同与 PBL 首页/导航等定向 42 项通过；`npm run contract:check` 退出 0。`npm test -- --run` 退出 1：340 passed、1 failed，唯一失败为已有学生 learning 通知导航旧断言，不能称全量全绿。后端全量失败状态未改变。
- 显式 Demo watcher 会话持续运行，最新增量输出 `Build complete. Watching for changes...`；规定开发目录执行 `simulator_refresh`。开发者工具可用真实 tap 选择教师角色；自定义组件内 PBL 标签的 selector `tap` 返回 `no such element`，因此巩固分区真实点击仍待验收。使用 `simulator_open_page` 直接打开不存在的 `reportId=999`，WXML 确认失败文案，内部截图 `C:/Users/adj/AppData/Local/Temp/wechatide-simulator-screenshot-1790166542134-a58axw.jpg` 已审阅：原生标题、错误、重试/返回控件可见且未遮挡。该截图仅证明错误态视觉，不证明真实点击或有报告态。真机按用户要求未执行。

### 2026-09-24 逐学生课堂进度增量（未达到 P5/P6 出口）

- 后端新增 `GET /teacher/classes/{class_id}/classroom-task-progress-items`，按课堂参与者与本课堂已发布包学生并集形成逐学生列表；仅课堂所属教师可读。分别呈现未发布、进行中、逾期、已完成和终态报告暂不可用；过滤只接受前四类，最后一类可在全部列表看到。进度与最终报告经 learning 只读端口核对包、正式计划、学生和课堂身份，不改变仅以最终报告统计结果的口径。
- 前端 analytics 公开 API、Zod 合同、显式 mapper、API/Demo 仓储和 `teacherPblProgress` 二级页面已接线；PBL 课堂页提供入口，已完成且有报告时进入本课报告，报告页支持返回课堂进度。Demo 目前只返回诚实空列表，尚无已发布包、有报告或两轮结束的可交互种子。
- `cd backend; python -m pytest tests/test_t43_report_analytics.py tests/test_t43_package_draft.py -q` 退出码 0，11 passed；受影响文件 `python -m ruff check`、`python -m ruff format --check` 退出码 0；`python backend/scripts/check_boundaries.py` 退出码 0，9 个模块通过。`npm run contract:generate`、`npm run contract:check` 退出码均为 0，生成物已同步。
- 前端 `npm run type-check`、`npm run lint`、`node scripts/frontend-boundaries.mjs` 退出码均为 0；定向 Vitest 3 个文件共 24 项通过。此前后端全量 303 项和前端全量 345 项是在本增量之前通过的，不能代替增量后的全量复测。
- 显式 Demo watcher 持续输出 `Build complete. Watching for changes...`，规定开发目录曾执行 `simulator_refresh`；随后一次 `npm run test:mp:doctor` 退出 1，提示运行时查询未触达模拟器。该环境状态尚待重查，真实 tap/input/scroll、筛选、分页、报告返回和必要截图均未验收；不能声称微信页面通过。

## 下一步与限制

### 2026-09-24 学生任务包前端局部接线（未达到 P4/P6 出口）

- learning public/repository 新增学生正式课堂任务包列表、详情、客观/文本任务提交、课堂病例启动及本人最终报告读取；API 响应经独立 Zod 合同校验，再显式映射到学生域模型。映射只输出学生可见的题目字段，不传递 `answer_key` 等私有定义；进度、完成结论与报告 ID、冻结报告身份相互矛盾时显式失败。
- 学生“学习”页新增按课堂独立列出的已发布任务包入口，详情页按课堂知识节点组织当前可见的两轮任务，提供选择/文本作答、病例任务启动、提交失败保留回答、返回后刷新及终态报告展示。未激活或已跳过的第二轮任务由服务端不列入可见任务和完成分母。页面目前尚未经过真实学生角色 tap/input/scroll 与完成态渲染验收，不能视为完整流程。
- Demo 对新接口仅返回如实为空的课堂任务列表和不存在详情，没有伪造正式任务或教师报告；它还不能演示整包发布、两轮练习和最终报告。旧 v6 正式计划现以每份计划一条“历史课堂 · 旧版任务”卡保留原执行流程，不再按知识节点与新包合并；即使新包与旧计划命中同一知识节点，两者也分开显示。旧历史数据迁移及完整交互仍待验证。
- `npx vitest run src/features/learning/infrastructure/classroomPackages.spec.ts` 退出码 0，2 项通过，覆盖公开字段投影和矛盾终态拒绝；`npm run type-check`、`npm run lint`、`node scripts/frontend-boundaries.mjs` 退出码均为 0。这些定向检查不覆盖端到端提交、病例五阶段、API/Demo 合同或小程序真实交互；后续全量前端结果见下一条。
- 旧新版任务分离后，`npm test -- --run` 退出码 0，69 个文件、345 项通过；旧通知导航断言已替换为现有课堂任务入口断言，历史计划组件断言更新为实际分离行为，并增加同节点新旧任务不合并测试。此全量前端通过不覆盖后端失败项或微信完成态。
- 显式 Demo watcher `VITE_APP_MODE=demo; npm run dev:mp-weixin` 已输出 `Build complete. Watching for changes...`；规定 `dist/dev/mp-weixin` 项目窗口 `simulator_refresh`、`npm run test:mp:doctor` 退出码均为 0，基础库 3.16.3。真实 tap 选择学生角色成功；打开学习页后 WXML 显示“待完成任务”与自主节点，当前 Demo 无正式包，不能以该页证明新旧包同时展示。直接打开 `packageId=1` 的不存在详情，WXML 与当次内部截图 `C:/Users/adj/AppData/Local/Temp/wechatide-simulator-screenshot-1790228485389-xls0eb.jpg` 已审阅：标题、错误说明及重试/返回按钮可见且无遮挡；自定义组件内部按钮 selector 返回 `no such element`，重试点击和真实入口流程仍未验收。真机未执行。
- `npm run backend:test` 复跑退出码 1：298 passed、4 failed、301 warnings，测试耗时 459.58 秒。失败为 `test_personalized.py::test_plan_tasks_notifications_and_idempotency` 与 `test_t04_concurrency.py` 的建计划并发、微任务启动并发、通知失败回滚三项；错误堆栈确认这些旧用例仍从独立病例 assessment 调用已明确拒绝的 `ensure_for_assessment`，或预期 `/learning-plans/current` 自动出现。不能仅删除测试以伪造全绿；须把独立病例负向合同保留，并将仍有价值的并发/回滚检验移到新课堂整包发布和病例任务路径。
- 随后 `test_personalized.py` 改为独立病例完成后的学生 assessment 可读、正式计划不存在、旧建计划 POST 稳定拒绝及重复完成仍可读；`cd backend; python -m pytest tests/test_personalized.py -q` 退出码 0，1 passed。此修订发生在上列全量运行之后，尚未重新全量复跑；另外 3 项旧并发/回滚测试仍失败，不能宣称后端全绿。

### 2026-09-24 后端并发验收修复与全量复测

- 将 T04 旧“独立病例并发生成计划、微训练启动、通知失败回滚”测试的验证意图移至当前 T43 路径：整包同请求并发发布只创建一份计划与通知；教师反馈写入故障时版本、计划、通知整体回滚，原幂等键重试只写一次；课堂病例任务并发启动只创建一个 attempt。旧文件保留独立病例评估创建并发，以及两个旧建计划请求并发时均返回 409、不产生正式计划的负向测试。没有以 skip/xfail 掩盖退役逻辑。
- `cd backend; python -m pytest tests/test_t04_concurrency.py tests/test_t43_package_draft.py tests/test_t43_classroom_case_callback.py tests/test_personalized.py -q` 退出 0，15 passed。首次后端全量复跑退出 1，302 passed、1 failed：新病例并发测试跨线程读取同一个已过期 ORM fixture 对象，触发 SQLAlchemy `InvalidRequestError`；这是测试夹具线程共享，不是病例任务产生重复 attempt。在线程启动前提取整数学生/任务 ID 后，该并发测试独立连续 5 次退出 0。
- 最终 `npm run backend:test` 退出码 **0**：303 passed、302 warnings，耗时 454.17 秒。警告为测试清表时既有 SQLAlchemy 外键循环排序警告；这不证明 PostgreSQL/生产迁移。受影响测试文件 `python -m ruff format` 与 `python -m ruff check` 退出 0。此次只改测试与文档，没有修改运行时 API、schema、迁移或 Demo；全量后端通过仍不能代替病例五阶段 API 到最终报告、修复工具、微信交互、真实 Coze 与外部医学验收。

继续完成 P2–P6：复核真实 v7 资源完整性，补病例五阶段 API 端到端、报告修复工具的真实受管库演练；完成学生任务包与逐学生课堂进度的有数据交互验收、题库页面，补全 Demo 各终态、旧入口收敛和历史迁移。当前学情与 PBL 终态报告已有局部合同/页面和空状态证据，但有报告状态、真实点击、完整 API/Demo 跨端合同、小程序完成态渲染，以及真实 Coze、真机、生产迁移、医学专家签署均未验收。逐学生进度增量之前的全量前后端测试曾通过，但不能把本记录作为该增量或 T43 功能交付证据。

### 接手执行顺序与停止条件（2026-09-23 文档复核）

1. **复核当前代码和契约**：先只读检查工作树及 `20260923_0031` head；按第 05 册逐端点核对实际 router/Pydantic、生成快照与前端消费者。最近的 v7 教师诊断/工作项状态改动之后，重新执行 `contract:generate`（审查写入差异）和 `contract:check`；迁移新增 `ai_schema_version` 后重新执行 `backend:test:safety` 与 `backend:test:migrations`。任一失败先修复，不宣称 P1/P2 完成。
2. **完成 P2/P3 资源和发布门禁**：以已批准病例及推理蓝图做真实资源引用的定向集成测试，覆盖版本变动、目标不匹配、医学审核拒绝、草稿删可选候选后仍满足覆盖、双请求并发发布及通知只发一次。资源或事务不能复核时停止发布路径，不用 local mock 代替医学事实。
3. **完成 P4 学生病例与报告**：现有课堂病例启动/回调已通过模型级定向测试；仍须补 `start → 五阶段作答 → assessment → 任务完成 → 报告` 的真实 API 闭环和并发/失败注入，确保独立病例仍只产学生训练分析；加入终态报告缺失时的默认只读预检和受控重建工具。A08–A12、A24 未通过前不得称统一报告闭环完成。
4. **完成 P5/P6 页面和口径**：在已写入的学情 v2 合同、学生任务包与课堂进度局部页面之上，复核分页局部失败、报告入口和旧方法消费者；教师 PBL 巩固跟进只显示本课最终报告，进行中归课堂进度。学生学习一课堂一包，内容页提供题库并移除 PBL 逐题教学发布旁路。补齐有数据的 public API、API/Demo seed/store/adapter 和旧深链，逐页面验证空、错误、返回及权限状态。
5. **完成 P7/P8 验收交付**：按第 09 册逐项填写 A01–A24 的 Pass/Fail/Unverified，不以局部测试推断整条链；Demo watcher、规定开发目录的普通编译、真实 tap/input/scroll 和必要截图分别取证。最后才更新权威运行文档及根规则；真机、真实 Coze、医学专家、PostgreSQL/生产继续单列外部待验收。

以上是未完成任务清单，不是已执行命令记录。若实际代码/合同与本清单冲突，先在第 01/05/08 册修订设计并说明原因，再继续实施。

### 2026-09-24 受控终态报告修复增量（P4 仍未完成）

- learning 新增应用层修复用例，扫描课堂包并复用运行时的确定性报告构建器；只接受已发布包、同学生关联的已完成正式计划和完整终态评价。默认只读预检，对缺证据计数但不补造分数；既有报告的摘要、内容、身份或结论不一致时显式冲突，绝不覆盖。`backend/scripts/rebuild_t43_reports.py` 为非生产 SQLite 命令，要求显式数据库；`--apply` 另需 `--confirm-development` 与新的 `--backup` 路径，先备份并检查完整性，再单事务写入。未增加教师公开重建按钮，也未触碰任何实际开发、共享或生产数据库。
- 新增 `test_t43_report_rebuild.py`，覆盖干跑不写、一次恢复与重复跳过、摘要冲突、缺评价跳过、CLI 参数门禁和备份文件。首次测试因本机 pytest `tmp_path` 所用通用临时目录权限不足而失败（1 passed、1 error）；测试改用已有受管测试资源目录后，`python -m pytest backend/tests/test_t43_report_rebuild.py backend/tests/test_t43_package_draft.py -q` 退出 0，12 passed、11 个既有 SQLAlchemy FK 排序警告。首次失败的受管测试资源按测试安全规则保留用于诊断，未手动删除。
- 后续安全复核收紧了修复前的包/班级/课堂/快照/教师来源身份核对；SQLAlchemy 写入异常在命令层统一转为不含 SQL 参数的错误，避免堆栈输出报告内容。新增来源错配拒绝和数据库异常脱敏测试；修订后 `python -m pytest backend/tests/test_t43_report_rebuild.py -q` 退出 0，5 passed、4 个既有 FK 排序警告。先前 12 项定向结果不覆盖这两项新断言。
- 该命令的 apply 仅在受管 pytest SQLite 上复验；尚未在真实受管开发库执行 dry-run、备份恢复演练或核对运营窗口。病例五阶段 API 至最终报告、报告缺失的生产历史、真实 PostgreSQL 与外部验收均不由这些测试证明。受影响文件 `python -m ruff check`、`python -m ruff format --check`、`python backend/scripts/check_boundaries.py`、T43 文档 Prettier/链接/尾随空白及工程 skill 双自检均退出 0；没有变更公开 API/schema、迁移或 Demo 可见行为，故本增量不触发契约生成或小程序重编译。
- 一次 `npm run backend:test` 在新增来源身份校验和测试夹具修订**同时进行**期间启动，退出 1，结果 305 passed、2 failed、306 warnings，耗时 621.60 秒。失败均是该进程已收集旧测试夹具、却在执行阶段读到新校验后得到 `incomplete_evidence`；不能把混合版本运行当成最终代码回归。修正后定向 5 项通过。固定代码后重新执行 `npm run backend:test`，退出码 **0**，309 passed、308 warnings，耗时 546.06 秒；警告仍为现存 SQLAlchemy FK 排序警告。该全量结果覆盖本次修复用例，但不能代替真实数据库演练或 T43 完整产品验收。

回退需只针对本次新增模型、迁移、测试和相关小 hunk；既有工作树改动保持原样。若任何库已写入 T43 数据，迁移明确拒绝降级，应先在受管备份中验证前向修复。

### 2026-09-24 Demo 学情、旧数据审计与最终仓库复测（T43 仍未完成）

- learning Demo 新增窄范围 `readDemoClassroomReportFacts()` 只读投影；analytics Demo 从正式包执行状态/最终报告读模型派生班级总览、学生综合详情、知识结果和逐学生课堂进度。不读取旧病例 assessment 或独立练习，不伪造报告。v7 无明确薄弱点演示路径现在能从教师发布，经学生两轮任务，把唯一终态报告同步到 PBL/课堂进度与“学情”综合详情；题库 Demo 已能显式复制来源、查看/筛选/编辑新 revision/归档。
- 修正 Demo 学生任务包 `dueAt` 每次读取都以“现在 + 7 天”重算的问题：现在固定以包的 `publishedAt + 7 天` 为截止，避免刷新时期限漂移。生命周期测试增加锚定断言。教师课堂进度导航测试覆盖实际挂载的 PBL 本课进度按钮到 `{classId, sessionId}`；旧 `TeacherPblClassrooms` 的内部 dashboard/旧计划跟进分支仅在 `createOnly=false` 时显示，而官方 workspace 仅以 `createOnly` 挂载，本轮确认可见 PBL 主流程使用现有 T43 `openProgress` 入口，不把不可达分支误记为用户路径。
- 新增 `backend/scripts/transition_t43_packages.py` 只读历史审计命令及 `test_t43_legacy_audit.py`：要求显式既有本地 SQLite，输出汇总分类，不含学生标识/正文；任何 `--apply` 都明确拒绝。自动历史转换关闭是第07册批准的安全政策，不改旧 plan、不复制 attempt/answers、不补评分、不通知。一次测试首次运行碰到通用 `tmp_path` 权限错误，改用项目受管测试资源目录后最终通过；遵守测试安全规则，未删除首次运行保留的临时资源。没有对任何真实、共享或生产数据库运行审计、迁移或 apply。
- 文档状态校准：更新 README、事实审计、第05/08/09/11册、根 `AGENTS.md` 与本记录，标出旧 handoff 表是历史快照，并明确只读转换政策、当前已接入页面/合同和未验收项。`npm run contract:generate` 退出 0，按生成链更新 `docs/openapi.json`、`src/data/contracts/openapi.generated.ts` 及公开病理目录生成数据；审阅后 `npm run contract:check` 退出 0。没有手改生成物，也没有运行数据库迁移。

| 命令                                                      |           退出码 | 结果                                                                                                                                                                       |
| --------------------------------------------------------- | ---------------: | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `npm run backend:test`                                    |                0 | 314 passed；313 个既有 SQLAlchemy FK 循环 drop 警告；642.29 秒                                                                                                             |
| `npm run backend:check`                                   |                0 | Ruff 通过；314 passed；总覆盖率 88.25%，达到配置的 85% 门槛；313 个同类 FK 排序警告；685.36 秒                                                                             |
| `npm run backend:test:safety`                             |                0 | 14 passed；13 个同类警告；98.95 秒                                                                                                                                         |
| `npm run backend:test:migrations`                         |                0 | 22 passed；21 个同类警告；200.23 秒                                                                                                                                        |
| `npm test -- --run`                                       |                0 | 72 个测试文件、353 passed；15.82 秒；Vue 测试环境仍有若干原生 picker/scroll-view 解析提示                                                                                  |
| `npm run test:coverage`                                   |                1 | 72 files / 353 tests 全通过，但全局 lines/statements/functions 为 60.05%/60.05%/60.08%（要求 85%），branches 77.06%（要求 80%）；覆盖门槛失败，不调整阈值                  |
| `npm run lint` / `npm run type-check`                     |            0 / 0 | ESLint 与 Vue/TypeScript 检查通过                                                                                                                                          |
| `node scripts/frontend-boundaries.mjs`                    |                0 | 203 个实现文件通过                                                                                                                                                         |
| `python backend/scripts/check_boundaries.py`              |                0 | 9 个模块通过                                                                                                                                                               |
| `npm run contract:generate` / `npm run contract:check`    |            0 / 0 | 生成快照与当前 router 一致                                                                                                                                                 |
| `npm run build:mp-weixin`                                 |                0 | 生产目录编译完成；只作为构建检查，不刷新开发目录                                                                                                                           |
| `$env:VITE_APP_MODE='demo'; npm run dev:mp-weixin`        | watcher 持续运行 | 规定的 `dist/dev/mp-weixin` 编译完成，输出 `Build complete. Watching for changes...`                                                                                       |
| `npm run test:mp:doctor`                                  |                1 | 缺少 `WECHATIDE_CLI_PATH`；常见安装位置只读查找未找到 `wechatide.cmd`。当前会话也没有 Developer Tools 内部 tap/screenshot tool；未执行普通编译后的真实小程序交互或截图审阅 |
| `npm run security:secrets`                                |                1 | 扫描只返回 `miniprogram/pages/student/chat/` 历史范围 3 个 `generic-api-key` 指纹；本轮不改/不输出这些源码值，需在原有安全工作中确认与处置                                 |
| `python -m alembic heads`（backend）                      |                0 | 唯一 head `20260923_0031`；只读查询，未应用到任何受管库                                                                                                                    |
| 工程 skill `self_check.py --self-test` 与 `self_check.py` |            0 / 0 | 规则负向自测和工程目录/路由自检通过                                                                                                                                        |

**尚未通过 T43 总体出口：** A01–A24 未逐层全部关闭；Demo 只有一个合成主生命周期，病例任务 `startClassroomCaseTask` 仍拒绝；首轮直接达标、第二轮耗尽、逾期、报告暂缺等有数据状态和 API/Demo 同合同未全覆盖。题库、学生任务包、进度、学情、报告虽有局部页面/测试，真实微信 tap/input/scroll、窄屏/终态渲染与当次截图均为 Unverified。报告修复工具真实受管开发库 dry-run/备份恢复、真实 Coze v7、授权医学专家签署、PostgreSQL/生产迁移、真机未执行；T43 必须继续标为进行中。

### 2026-09-24 Luna 接手前文档一致性复核

- 未修改运行时代码。修订 T43 README、01、09、11 与文档交付记录：早期审计和旧 handoff 表均显式标成历史；最新全量结果以本记录中的后端 314、前端 353 为准；已接入的教师整包审阅、题库 UI、病例回程、报告/进度/学情页面改列为复核项，而非待重建项。
- 剩余实现断点仍包括 Demo `startClassroomCaseTask` 拒绝调用且缺有数据 `focused_retry` fixture；Demo 首轮直达达标、二轮耗尽、逾期、`report_unavailable`、身份隔离等状态未覆盖；病例回调故障重放、报告事务回滚等路径未闭合。第11册补充了该 Demo 端口、task-id 幂等、attempt 上下文授权、assessment 回包和包级报告时点合同，并规定新增独立 `90004` 合成病例场景且保持 `90003` 无薄弱点流程不变。此文档变更不改变这些状态，也未声称 T43 总体验收通过。
- 核对现有病例训练页后，修正上下文合同为“本人拥有的进行中/已完成 attempt 均可读取来源”，以支持中断返回；病例报告页另行核验 assessment 和任务完成。上下文只读、仍由服务端 attempt→task→package 关联得出，不信任 URL。
- 文档门禁最终复跑：Prettier 对根规则、计划索引/阶段概述和 T43 全目录退出 0；PowerShell 相对链接/尾随空白检查覆盖 16 份 Markdown、52 个相对链接并退出 0；`git diff --check`、工程 skill `self_check.py --self-test` 与 `self_check.py` 均退出 0。新增 W8 验收复跑：`npm run backend:check` 退出 0，314 passed、88.25% coverage；`npm run test:coverage` 退出 1，72 files/353 tests 全通过但全局覆盖率门槛失败（lines/statements/functions 60.05%/60.05%/60.08%，branches 77.06%，阈值 85%/80%）。没有应用数据库迁移、操作真实库、调用真实 Coze、提交或推送。

### 2026-09-24 Luna 后续实施：Demo 病例闭环与终态状态集（T43 仍未完成）

- 保留原有 `90003` 无明确薄弱点路径和 `90004` 合成病例路径；新增 `90005` 首轮直接达标、`90006` 二轮耗尽合成诊断。病例资源继续映射到 Demo case catalog 显式资源，标记 `demo_approved` 并提示不是真实 AI/专家审核。
- Demo learning repository 经 `bootstrap/wiring.ts` 注入 training port 启动与读取本人 attempt/assessment；内部病例 attempt ID 支持 `string | number`，API 正整数 schema 未放宽。按 student+task 关联，task ID 是幂等键，重复/并发 start 复用 attempt；只有本人已发布且当前激活的 focused-retry 可启动。本人进行中/已完成 attempt 可查询回程 context，独立病例 false/null，异学生读取 404。assessment 取目标维度分数，缺证据按未达标；读后 reconciliation 不重复写任务/报告。
- Demo 测试覆盖病例首轮失败→第二轮达标且报告只在整包终态生成、首轮直接通过、第二轮耗尽 `needs_reinforcement`、逾期、报告暂不可用、学生隔离，以及题库空→active→编辑→archived。report_unavailable 是非公开测试故障注入，不构造伪报告 ID。
- W5 静态搜索核对：活跃 PBL 巩固列表由 `TeacherPblHome` 读本课最终报告；`TeacherPblClassrooms` 当前仅以 create-only 挂载，其旧 dashboard/follow-up 分支未进入正式导航；`getTeacherPblFollowUps`、`task_published`、`createLearningPlan` 保留给 legacy port、v6 状态、未挂接旧组件或兼容测试，v7 发布由整包 API 完成。保留兼容代码，不机械删除。
- T43 README、01/05/08/09/10/11、计划索引/阶段概述及根 `AGENTS.md` 已同步当前实现与门禁。旧实施表和早期审计保留作历史证据，不作为当前缺口判断。

| 命令                                                                                                                                                                                                                          |           退出码 | 结果                                                                                                                              |
| ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ---------------: | --------------------------------------------------------------------------------------------------------------------------------- |
| `npm run backend:check`                                                                                                                                                                                                       |                0 | Ruff 通过；314 passed；88.25% backend coverage（本轮前最新后端快照；本轮无后端代码改动）                                          |
| `npx vitest run src/features/learning/infrastructure/demoLearningRepository.classroomPackages.spec.ts src/features/pbl/infrastructure/demoPblRepository.spec.ts src/features/content/infrastructure/demoQuestionBank.spec.ts` |                0 | 3 个文件、11 tests passed                                                                                                         |
| `npm test -- --run`                                                                                                                                                                                                           |                0 | 72 个文件、355 passed                                                                                                             |
| `npm run test:coverage`                                                                                                                                                                                                       |                1 | 72 个文件/355 项测试全通过；lines/statements 60.46%、functions 60.30%、branches 77.62%，未达 85%/80% 门槛。未调整阈值             |
| `npm run type-check` / `npm run lint`                                                                                                                                                                                         |            0 / 0 | Vue/TypeScript 与 ESLint 通过                                                                                                     |
| `node scripts/frontend-boundaries.mjs`                                                                                                                                                                                        |                0 | 203 implementation files 通过                                                                                                     |
| `npm run contract:check`                                                                                                                                                                                                      |                0 | OpenAPI、生成 TS 与 fixture 快照一致                                                                                              |
| `npm run build:mp-weixin`                                                                                                                                                                                                     |                0 | 生产目录小程序构建通过；不是 DevTools 验收                                                                                        |
| `$env:VITE_APP_MODE='demo'; npm run dev:mp-weixin`                                                                                                                                                                            | watcher 持续运行 | 最后代码变更后重启，`dist/dev/mp-weixin` 输出 `Build complete. Watching for changes...`                                           |
| `npm run test:mp:doctor`                                                                                                                                                                                                      |                1 | 未设置 `WECHATIDE_CLI_PATH`；允许查找的常见根未找到 `wechatide.cmd`。无内部 DevTools tap/screenshot tool，未做普通编译后交互/截图 |
| `npm run security:secrets`                                                                                                                                                                                                    |                1 | 3 个历史 `generic-api-key` 指纹位于 `miniprogram/pages/student/chat/`；未读/改匹配源码，待安全责任人复核                          |
| `python backend/scripts/transition_t43_packages.py --database .\unopened-t43-fixture.sqlite --apply`                                                                                                                          |                1 | 按策略在打开数据库前拒绝 `--apply`；无数据库连接/创建                                                                             |

未运行新迁移、未连接真实/共享/生产数据库、未调用真实 Coze、未执行医学专家签署或真机。未关闭项：前端覆盖率门槛、安全指纹责任人处置、最终报告写入异常事务回滚独立测试、Developer Tools 正常编译/真实流程/截图、受管开发库报告修复备份恢复演练；Coze/医学专家/生产/真机仍属外部验收。T43 不得标记完成。

### 2026-09-24 暂停前续验：病例回调边界补齐

用户要求本轮暂时收尾、次日继续。按请求停止了正在运行的 backend 全量检查和 Demo watcher；未将被中断的检查记为通过。暂停前针对第11册 W4 增加“病例评价已完成但同轮其他 active 题未完成”后端 API 场景，并扩展 Demo 对目标维度缺失、assessment 读取瞬时失败、后续重试不重复回写的覆盖。没有改业务代码逻辑、接口或数据库 schema。

| 命令                                                                                                                                                 | 退出码 | 结果                                                                    |
| ---------------------------------------------------------------------------------------------------------------------------------------------------- | -----: | ----------------------------------------------------------------------- |
| `npm test -- --run src/features/learning/infrastructure/demoLearningRepository.classroomPackages.spec.ts`                                            |      0 | 1 文件、3 项测试通过；含病例目标维度缺失、assessment 读取重试/幂等断言  |
| `npm run backend:test -- tests/test_t43_classroom_case_callback.py::test_case_assessment_waits_for_other_active_package_task_before_final_report -q` |      0 | 新增病例同轮其他题未完成场景 1 项通过                                   |
| `npm test -- --run`                                                                                                                                  |      0 | 全量前端 72 个文件、355 项通过                                          |
| `npm run backend:check`（上次完整结果，新增病例 API 测试之前）                                                                                       |      0 | Ruff 通过；315 passed；backend coverage 88.26%                          |
| `npm run backend:check`（新增病例 API 测试之后，本轮用户要求暂停）                                                                                   |      1 | 在 pytest 汇总前 Ctrl-C；无本轮全量计数/coverage，续工必须重跑          |
| `$env:VITE_APP_MODE='demo'; npm run dev:mp-weixin`                                                                                                   | 已停止 | watcher 曾输出 `Build complete. Watching for changes...`；暂停时 Ctrl-C |

之前最近一次 `npm run test:coverage` 为 72 个文件/355 tests 全通过、但 coverage 门槛退出 1（lines/statements 60.46%、functions 60.30%、branches 77.62%，要求 85%/80%）；本次没有重跑该命令。此前 `npm run security:secrets` 仍以退出 1 报告 3 个历史 `generic-api-key` 指纹，未读取或编辑匹配源码，待安全责任人复核。`npm run test:mp:doctor` 因没有 `WECHATIDE_CLI_PATH`/`wechatide.cmd` 退出 1；没有 DevTools 内部交互或截图能力，本轮未执行普通编译和真实点击。没有应用迁移、连接真实数据库、真实 Coze、生产、真机或专家医学审核。

次日最短接续：先对当前工作树完整运行 `npm run backend:check` 并记录新测试计数；再运行计划要求的前端 coverage 与文档门禁。然后按解除条件处理安全指纹和 Developer Tools；无受管开发库时把报告修复备份/恢复演练保留为明确外部待验收。不得调低 coverage 阈值、改写被中断检查结果、使用未授权真实服务或将 T43 标为完成。

### 2026-09-25 暂停交接：全量后端门禁仍待续跑

用户准备次日继续，要求本次暂时收尾。恢复工作后重新启动 `npm run backend:check`；Ruff 显示通过，pytest 已开始运行，但在汇总前按用户收尾要求 Ctrl-C，命令退出码 1，不能作为全量通过或失败计数。今天没有新增业务代码改动；没有启动 Demo watcher，也没有运行迁移或连接数据库。此前可用的最近完整后端基线仍是 315 passed / 88.26%，但它不包含之后新增的病例边界测试。

| 命令                                             | 退出码 | 结果                                                                                     |
| ------------------------------------------------ | -----: | ---------------------------------------------------------------------------------------- |
| `npm run backend:check`（2026-09-25 收尾时中止） |      1 | Ruff 通过；pytest 汇总前按用户要求 Ctrl-C；无本轮完整计数/coverage，明日必须重新完整运行 |

明日续做入口：先读取第11册并重核 `git status --short`，然后完整运行 `npm run backend:check`；记录新测试数/覆盖率后再按第09册与第11册推进剩余 A01–A24 和环境门禁。2026-09-25 这次中断不替代此前 2026-09-24 的中断记录，也不得改写为通过。T43、API/Demo 完整同态及微信真交互仍未完成。

### 2026-09-25 续跑：后端门禁完成、前端行为补强（T43 仍未完成）

先重读 T43 计划、工作交接册和工程约束，再在保留现有脏工作树的前提下续做。全量后端门禁现已完成，替代前两次暂停时的未汇总结果。行为复核新增六个前端测试文件：`TeacherClassroomPackageReview.behavior.spec.ts` 4 项、`question-bank.behavior.spec.ts` 4 项、`pbl-diagnostic-detail.behavior.spec.ts` 2 项、`pbl-progress.behavior.spec.ts` 2 项、`classroom-package.behavior.spec.ts` 2 项、`student-detail.behavior.spec.ts` 2 项。题库筛选测试先失败并证实实际竞态：在列表请求未完成时切换筛选会被 `loading` guard 忽略。修复 `load()` 只在非 reset 的 load-more 请求期间拦截 loading，筛选/重载可启动新 token 并使旧响应失效；同次全量测试通过。没有修改 API、schema、数据库或迁移。

| 命令                                                                                                                                                                                                                                                                                           |   退出码 | 结果                                                                                                                                           |
| ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | -------: | ---------------------------------------------------------------------------------------------------------------------------------------------- |
| `npm run backend:check`                                                                                                                                                                                                                                                                        |        0 | Ruff 通过；316 passed；backend coverage 88.26%，高于后端 85% 门槛；运行时约 493 秒，日志包含 SQLAlchemy 外键排序警告                           |
| `npm run test:coverage`                                                                                                                                                                                                                                                                        |        1 | 78 test files / 371 tests 全通过；全局 lines/statements 66.63%、functions 60.20%、branches 76.45%，低于配置的 85%/85%/80% 门槛；不得调低门槛   |
| `npm test -- src/components/teacher/TeacherClassroomPackageReview.behavior.spec.ts src/pages/teacher/question-bank/question-bank.behavior.spec.ts src/pages/teacher/pbl-diagnostic-detail/pbl-diagnostic-detail.behavior.spec.ts src/pages/teacher/pbl-progress/pbl-progress.behavior.spec.ts` |        0 | 4 个文件、12 项通过                                                                                                                            |
| `npm test -- src/pages/teacher/pbl-progress/pbl-progress.behavior.spec.ts`                                                                                                                                                                                                                     |        0 | 1 文件、2 项通过；覆盖所有逐学生进度态、仅完成态报告入口、返回上下文、逾期筛选与空态                                                           |
| `npm test -- src/pages/student/learning/classroom-package.behavior.spec.ts src/pages/teacher/analytics/student-detail.behavior.spec.ts`                                                                                                                                                        |        0 | 2 个文件、4 项通过；覆盖课堂任务分组与提交后报告读取、综合学情范围/报告返回/分页                                                               |
| `npm run lint`                                                                                                                                                                                                                                                                                 |        0 | ESLint 通过                                                                                                                                    |
| `npm run type-check`                                                                                                                                                                                                                                                                           |        0 | Vue/TypeScript 检查通过                                                                                                                        |
| `node scripts/frontend-boundaries.mjs`                                                                                                                                                                                                                                                         |        0 | 203 implementation files 通过                                                                                                                  |
| `npm run contract:check`                                                                                                                                                                                                                                                                       |        0 | 运行时代码最近变更后已通过；本轮其后仅增加测试与文档                                                                                           |
| `npm run build:mp-weixin`                                                                                                                                                                                                                                                                      |        0 | 运行时代码最近变更后小程序生产构建通过；不等同 DevTools 编译/交互                                                                              |
| `$env:VITE_APP_MODE='demo'; npm run dev:mp-weixin`                                                                                                                                                                                                                                             | 持续运行 | 显式 Demo watcher 输出 `Build complete. Watching for changes...`，目标为 `dist/dev/mp-weixin`；没有进入 Developer Tools 执行普通编译或真实交互 |
| `npm run test:mp:doctor`                                                                                                                                                                                                                                                                       |        1 | 未设置 `WECHATIDE_CLI_PATH`，本机未找到 `wechatide.cmd`；未运行 tap/input/scroll 或内部截图                                                    |
| `npm run security:secrets`                                                                                                                                                                                                                                                                     |        1 | 输出仅指向 `miniprogram/pages/student/chat/` 的 3 项历史 `generic-api-key` 指纹；未读取、输出或编辑匹配源码，需安全责任人复核                  |
| `git diff --check`                                                                                                                                                                                                                                                                             |        0 | 无空白错误；只显示既有文件 CRLF→LF 提示                                                                                                        |

完整 Vitest 由 coverage 命令执行并通过 78/371；Lint、type-check、边界检查和 diff 检查均通过。`contract:check` 与小程序生产构建是在题库运行时代码最后一次变更后、仅新增测试/文档之前完成的，因此不需要为仅测试文档改动重跑。此前安全/迁移测试为 14/22 passed；本轮无数据库代码变更。T43 仍未达交付：全局前端覆盖率、secret-scan 安全责任人结论、Developer Tools 普通编译/真实交互/截图、真实受管库报告修复工具 dry-run 与备份恢复演练未完成；真实 Coze、专家医学审核、PostgreSQL/生产、真机也未验收。没有应用迁移、连接真实/共享/生产数据库、调用真实 Coze、提交或推送。不得将本轮局部行为测试或后端全量通过表述成 T43 完成。

文档门禁：`npx --no-install prettier --check AGENTS.md docs/update_plan/README.md docs/update_plan/43-classroom-task-package-reports` 退出 0；工程 skill `self_check.py --self-test` 与 `self_check.py` 退出 0；逐文件 Markdown 相对链接/尾随空白复核覆盖 17 个文件、63 个相对链接、1421 行，issues=0；`git diff --check` 退出 0。

### 2026-09-25 续做：学生提交重试与学情分页竞态

按 W4/W5 复核真实页面数据时定位并修复两处请求竞态，均未改变 API、schema、权限、统计口径或数据库：

- 学生任务页此前在提交结果未确认后仍允许改答案，但重试继续复用同一个 `client_submission_id`。后端对相同标识要求答案完全一致，否则稳定返回 409。现在页面冻结未确认的答案与请求标识，重试始终发送原 payload；显式刷新并由服务端确认该题仍为 pending 后，才清除旧请求状态并允许修改答案。
- 教师学情详情的“加载更多”可能在日期范围刷新后返回，并把旧范围报告追加到新范围。现在全量刷新会递增请求代次并取消当前分页显示态；分页结果、错误及 finally 状态仅在同一代次写入，刷新期间不允许启动分页。
- 教师更换账号后返回学情详情页，旧页面没有重新确认教师身份，可能继续显示前一账号的汇总；在旧请求仍 pending 时也可能回写。现在 onShow 及读请求回包都会校验会话 role/openid；变化时先清空旧详情、作废请求代次，并显示明确阻断状态后返回无旧班级参数的学情入口。

| 命令                                                                                                                                                                                                                                                                                                                                                                                                                                             |               退出码 | 结果                                                                                                                                           |
| ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ | -------------------: | ---------------------------------------------------------------------------------------------------------------------------------------------- |
| `npm run backend:test -- tests/test_t43_package_draft.py tests/test_t43_question_bank.py tests/test_t43_package_coverage.py tests/test_t43_final_report_rules.py tests/test_t43_report_analytics.py tests/test_t43_classroom_case_callback.py tests/test_t43_report_rebuild.py -q`                                                                                                                                                               |                    0 | 36 passed；包括发布事务、题库隔离、两轮与报告、病例回调、统计及修复工具定向用例；SQLAlchemy 测试清理输出 35 条既有 FK 排序警告                 |
| `npm run backend:test -- tests/test_t43_report_rebuild.py tests/test_t43_report_analytics.py tests/test_t43_question_bank.py tests/test_t43_provider_schema.py tests/test_t43_package_schema.py tests/test_t43_package_draft.py tests/test_t43_package_coverage.py tests/test_t43_migration.py tests/test_t43_live_dialogue.py tests/test_t43_legacy_audit.py tests/test_t43_final_report_rules.py tests/test_t43_classroom_case_callback.py -q` |                    0 | 全部 12 个 T43 后端专项测试文件、52 passed；测试清理阶段有 51 项 SQLAlchemy 外键排序警告。未运行真实数据库                                     |
| `npx vitest run src/pages/student/learning/classroom-package.behavior.spec.ts src/pages/teacher/analytics/student-detail.behavior.spec.ts`                                                                                                                                                                                                                                                                                                       |                    0 | 2 个文件、8 项通过；含原标识/答案重试、刷新后编辑、改时间范围时丢弃旧分页响应、教师身份切换后清除旧数据/阻断及舍弃旧详情请求                   |
| `npx vitest run src/features/learning/infrastructure/demoLearningRepository.classroomPackages.spec.ts src/features/learning/infrastructure/classroomPackages.spec.ts src/features/learning/infrastructure/classroomFinalReports.spec.ts src/features/analytics/infrastructure/classroomReports.spec.ts src/features/content/infrastructure/apiQuestionBank.spec.ts src/features/content/infrastructure/demoQuestionBank.spec.ts`                 |                    0 | 6 个文件、13 项通过；复验 Demo 包/病例回写/终态报告、学情统计和题库 API/Demo adapter 合同                                                      |
| `npm run test:coverage`                                                                                                                                                                                                                                                                                                                                                                                                                          |                    1 | 78 files / 375 tests 全通过；lines/statements 66.71%、functions 60.41%、branches 76.53%，全局 coverage 门槛 85%/85%/80% 未达；不可降门槛       |
| `npm run lint`                                                                                                                                                                                                                                                                                                                                                                                                                                   |                    0 | ESLint 通过                                                                                                                                    |
| `npm run type-check`                                                                                                                                                                                                                                                                                                                                                                                                                             |                    0 | Vue/TypeScript 检查通过                                                                                                                        |
| `node scripts/frontend-boundaries.mjs`                                                                                                                                                                                                                                                                                                                                                                                                           |                    0 | 203 implementation files 通过                                                                                                                  |
| `git diff --check`                                                                                                                                                                                                                                                                                                                                                                                                                               |                    0 | 无空白错误；Git 提示若干既有文件未来写入时 CRLF→LF                                                                                             |
| `$env:VITE_APP_MODE='demo'; npm run dev:mp-weixin`                                                                                                                                                                                                                                                                                                                                                                                               | 启动成功（随后停止） | 最新改动后重新编译并输出 `Build complete. Watching for changes...`；产物可见任务页恢复动作及学情页教师身份校验/账号变更阻断状态；未手改 `dist` |
| `npm run test:mp:doctor`                                                                                                                                                                                                                                                                                                                                                                                                                         |                    1 | 缺少 `WECHATIDE_CLI_PATH`；没有 DevTools 普通编译、真实 tap/input/scroll 或内部截图审阅                                                        |

本轮另运行 6 个 Demo/API feature adapter 测试文件，13 项通过，涵盖课堂包/病例回写/终态报告、学情统计及题库 adapter。前端全量 coverage 为 78 files / 375 tests 全通过，但全局 coverage lines/statements 66.71%、functions 60.41%、branches 76.53% 低于门槛。新增的学生提交恢复、学情分页过期和教师身份切换行为断言已包含在这次全量运行中；覆盖率门槛仍未达标。T43 仍未完成：A01–A24 端到端证据、API/Demo 全状态同态、其他角色切换与加载失败矩阵、DevTools 可见交互、前端全局 coverage、安全历史指纹责任人结论、真实受管开发库报告修复恢复演练、真实 Coze、专家审核、PostgreSQL/生产及真机验收仍未关闭。未应用迁移、访问真实数据库、调用真实 Coze、提交或推送。

### 2026-09-25 续跑：题库身份边界与最新前端门禁（T43 仍未完成）

继续按 W3/W5 复核题库和教师学情页面时，发现题库列表、详情页把返回 `false` 的 `requireRole('teacher')` 放在 `try/catch` 中；角色守卫不抛异常，因此拒绝后仍可能调用题库 API。两页现改为布尔拒绝即早退。详情页另校验当前教师会话：账号变化时清空题目/编辑副本与错误态、递增请求代次、忽略旧账号 GET/写入回包，并返回无旧身份上下文的个人题库入口。新增覆盖守卫拒绝不触发 list/get、账号切换丢弃 pending detail GET；同一行为套件现 6 项通过。

学生课堂包、教师学情详情、教师题库三份页面行为测试共 14 项通过：课堂包 4、学情详情 4、题库 6。lint 首次因新测试未使用局部变量失败；删除无用绑定后复跑通过。测试内容及其边界不改 API/schema、数据库、授权策略或统计口径。

| 命令                                                                                                                                                                                                      |         退出码 | 结果                                                                                                                           |
| --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | -------------: | ------------------------------------------------------------------------------------------------------------------------------ |
| `npx vitest run src/pages/student/learning/classroom-package.behavior.spec.ts src/pages/teacher/analytics/student-detail.behavior.spec.ts src/pages/teacher/question-bank/question-bank.behavior.spec.ts` |              0 | 3 files / 14 tests passed。                                                                                                    |
| `npm run lint`                                                                                                                                                                                            |              0 | ESLint 通过；修复新增测试的 unused variable 后复跑。                                                                           |
| `npm run type-check`                                                                                                                                                                                      |              0 | Vue/TypeScript 检查通过。                                                                                                      |
| `node scripts/frontend-boundaries.mjs`                                                                                                                                                                    |              0 | 203 implementation files 通过。                                                                                                |
| `npm run test:coverage`                                                                                                                                                                                   |              1 | 78 files / 377 tests 全通过；lines/statements 66.77%、functions 60.47%、branches 76.61%，低于 85%/85%/80% 门槛；不得降门槛。   |
| `npm run contract:check`                                                                                                                                                                                  |              0 | 在隔离临时目录核对 OpenAPI、生成 TS、fixture 与迁移链；没有应用迁移到外部数据库。                                              |
| `npm run build:mp-weixin`                                                                                                                                                                                 |              0 | `dist/build/mp-weixin` 生产构建完成。                                                                                          |
| `$env:VITE_APP_MODE='demo'; npm run dev:mp-weixin`                                                                                                                                                        | 启动成功后停止 | 显式 Demo watcher 完成 `dist/dev/mp-weixin` 编译；产物可找到学生提交恢复文案及教师学情/题库账号变更阻断状态，没有改写 `dist`。 |
| `npm run test:mp:doctor`                                                                                                                                                                                  |              1 | 未配置 `WECHATIDE_CLI_PATH`；没有 DevTools 普通编译、tap/input/scroll 或内部截图审阅。                                         |
| `git diff --check`                                                                                                                                                                                        |              0 | 无空白错误；仅有既有 CRLF→LF 提示。                                                                                            |

T43 继续未达交付：前端 coverage gate、A01–A24 全链路证据、DevTools 交互/渲染/截图、历史 secret-scan 指纹的安全责任人结论、受管非生产开发库上的报告修复 dry-run 与备份恢复演练仍开放；Coze、授权医学专家、PostgreSQL/生产与真机仍属外部验收。没有应用迁移、访问真实/共享/生产数据库、调用真实 Coze、提交或推送。

本次续跑重执行 `npm run security:secrets`，exit 1；扫描仍只归类出 `miniprogram/pages/student/chat/` 历史范围 3 个 `generic-api-key` 指纹。此处不展示原始匹配内容、不读取或修改相关源码，需安全责任人复核后才能关闭。

### 2026-09-25 续跑：课堂包与终态报告 API adapter 合同测试

对覆盖率报告中直接承载 T43 的 `classroomPackages.ts`（此前约 11.8% 行覆盖）和 `classroomFinalReports.ts`（约 72.2%）做定向分析后，新增整包 API adapter 测试，并扩展教师终态报告 adapter 测试。现在验证教师草稿/已发布冻结身份、两轮成对、未成对及非法草稿/发布状态拒绝；资源两轮映射与格式错误的可选展示字段过滤；保存时版本、反馈、私密 rubric/resource ref 映射；医学提交与固定目标发布 receipt；题库来源；学生列表/详情/稳定 submission ID、病例启动、独立病例不泄露课堂关联、课堂病例关联不完整拒绝；学生最终报告 frozen envelope 校验。教师最终报告查询还验证班级/课堂/学生范围与分页参数，映射拒绝各类冻结身份不一致并规范化历史可空摘要数组。

`classroomPackages.api.spec.ts` 9 项、`classroomPackages.spec.ts` 2 项、`classroomFinalReports.spec.ts` 6 项，共 17 项定向 adapter 测试通过。完整 coverage 报告中的 `classroomPackages.ts` 为 99.28% lines、100% functions、90.91% branches；`classroomFinalReports.ts` 为 100%/100%/100%。这是这两个适配器的局部覆盖率，不代表全局门禁通过。

| 命令                                                                                                                                                                                                                  | 退出码 | 结果                                                                                                                   |
| --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | -----: | ---------------------------------------------------------------------------------------------------------------------- |
| `npx vitest run src/features/learning/infrastructure/classroomPackages.spec.ts src/features/learning/infrastructure/classroomPackages.api.spec.ts src/features/learning/infrastructure/classroomFinalReports.spec.ts` |      0 | 3 files / 17 tests passed。                                                                                            |
| `npm run lint` / `npm run type-check`                                                                                                                                                                                 |  0 / 0 | ESLint 与 Vue/TypeScript 检查通过。                                                                                    |
| `npm run test:coverage`                                                                                                                                                                                               |      1 | 79 files / 390 tests 全通过；lines/statements 68.11%、functions 61.71%、branches 76.90%，未满足 85%/85%/80% 全局门槛。 |

本次增量仅新增/扩展测试，不改运行时代码、API、schema、迁移、Demo seed 或页面状态；因此此前成功的 contract/build/Demo 编译仍对应同一运行时代码。本次没有重做真实微信交互。coverage gate 仍开放，不调低阈值。

最终文档门禁：`npx --no-install prettier --check AGENTS.md docs/update_plan/README.md docs/update_plan/43-classroom-task-package-reports src/features/learning/infrastructure/classroomPackages.api.spec.ts src/features/learning/infrastructure/classroomFinalReports.spec.ts` exit 0；只读 Markdown 相对链接检查 62 条、0 断链；工程 skill `self_check.py --self-test` 与 `self_check.py` 均 exit 0；`git diff --check` exit 0（Git 输出既有 CRLF→LF 提示）。

### 2026-09-25 续跑：教师整包审阅切换课堂时的异步回包隔离

复核 `TeacherClassroomPackageReview` 时发现，教师切换当前诊断后，旧课堂尚未完成的草稿保存结果/错误、取回最新版、医学审核提交及发布后的 refresh 可能写入新课堂页面；题库来源/入库请求也需明确绑定预览时的任务包版本。现按诊断快照、会话、学生、班级对页面上下文生成代次；每类回写同时校验包 ID、版本、digest 和诊断归属。换课堂即清除旧预览、入库忙碌和操作错误。教师已明确确认并发出的题库入库请求在服务端无法被撤销，但切换后其迟到回包不再显示旧上下文成功提示、错误或覆盖新包。

新增教师整包审阅组件行为用例 7 项，连同已有 4 项共 11 项；诊断详情路由旧 v6/v7 分支 2 项。新增竞态用例先在旧实现下运行：5 项失败，具体复现延迟保存覆盖、旧错误留存、旧 latest 覆盖、医学提交后读取旧包、发布后读取旧包；题库来源延迟响应按新 item id 隐藏，但随后仍补足请求代次保护与入库迟到回包用例。修复后两个文件 13/13 通过。

| 命令                                                                                                                                                                  |                     退出码 | 结果                                                                                                                              |
| --------------------------------------------------------------------------------------------------------------------------------------------------------------------- | -------------------------: | --------------------------------------------------------------------------------------------------------------------------------- |
| `npx vitest run src/components/teacher/TeacherClassroomPackageReview.behavior.spec.ts src/pages/teacher/pbl-diagnostic-detail/pbl-diagnostic-detail.behavior.spec.ts` |                          0 | 2 files / 13 tests passed（组件 11、诊断路由 2）。                                                                                |
| `npm run test:coverage`                                                                                                                                               |                          1 | 79 files / 397 tests 全通过；lines/statements 68.38%、functions 62.12%、branches 76.93%，仍低于仓库要求 85%/85%/80%，未调低门槛。 |
| `npm run lint`                                                                                                                                                        |                          0 | ESLint 通过。                                                                                                                     |
| `npm run type-check`                                                                                                                                                  |                          0 | Vue/TypeScript 检查通过。                                                                                                         |
| `node scripts/frontend-boundaries.mjs`                                                                                                                                |                          0 | 203 implementation files 通过。                                                                                                   |
| `npx --no-install prettier --check src/components/teacher/TeacherClassroomPackageReview.vue src/components/teacher/TeacherClassroomPackageReview.behavior.spec.ts`    |                          0 | 两个受影响源文件格式通过。                                                                                                        |
| `npm run build:mp-weixin`                                                                                                                                             |                          0 | 小程序生产目标构建完成；不等同 DevTools 普通编译或渲染验收。                                                                      |
| `$env:VITE_APP_MODE='demo'; npm run dev:mp-weixin`                                                                                                                    | watcher 成功后 Ctrl+C 停止 | 输出 `Build complete. Watching for changes...`，更新 `dist/dev/mp-weixin`；检查生成组件含任务包身份校验，不手工修改产物。         |
| `npm run test:mp:doctor`                                                                                                                                              |                          1 | 未设置 `WECHATIDE_CLI_PATH`；无微信开发者工具普通编译、真实 tap/input/scroll 或内部截图。                                         |

本轮没有更改 API/OpenAPI、schema、数据库、迁移、权限合同或统计口径；因此没有重跑 contract check 和后端门禁。此前全量后端 `backend:check` 316 passed / 88.26% 与 12 个 T43 专项文件 52 passed 的证据保持不变。当前仍未关闭的项：A01–A24 全链路与 API/Demo 同态，前端全局 coverage，历史 secret-scan 指纹的安全责任人结论，受管非生产开发库的报告修复 dry-run/备份恢复演练，Developer Tools 真实页面交互/渲染/截图，真实 Coze、授权医学专家、PostgreSQL/生产与真机。没有执行迁移、访问真实数据库/Coze、提交或推送。

### 2026-09-25 续跑：教师身份失效与账号切换后的 T43 页面隔离

复核 W5 时发现教师工作区更换 `openid` 后会复用旧班级和待办状态；若 `requireRole('teacher')` 拒绝，教师诊断、课堂进度和本课报告页虽停止新请求，却仍可能显示上一访问者的数据，且旧请求没有统一作废。现在教师工作区按当前教师身份递增代次、清空班级/待办/审核权限、丢弃旧账号请求并 key-remount 懒加载子页面；失去教师权限时显示安全状态。PBL 诊断、课堂进度、本课报告在失权时清除诊断学生、进度记录或报告并递增请求代次。诊断页反馈提交在权限/页面代次变化后不再清空输入、toast 或触发旧详情重载。整包审阅组件卸载也递增代次并清空题库预览，已送达服务器的教师题库写入不撤销，但旧回执/错误不会显示到新路由。按 W2 补全发布确认弹窗：逐项列明固定接收学生、课堂、首/二轮题数与激活条件、草稿版本及完整 digest。

新增教师工作区、课堂进度、本课报告各 2/2/2 项身份行为测试，并扩展诊断详情至 3 项、整包审阅至 12 项。五个定向套件共 23 项通过。一次 ESLint 首跑曾因新增 workspace key 属性顺序 warning 退出 1；修正并复跑后通过。一次 Prettier 检查在格式化新测试/模板前发现 4 个文件需格式化，执行 Prettier 后最终检查通过。

| 命令                                                                                                                                                                                                                                                                                                                                                           |                     退出码 | 结果                                                                                                             |
| -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | -------------------------: | ---------------------------------------------------------------------------------------------------------------- |
| `npx vitest run src/components/teacher/TeacherClassroomPackageReview.behavior.spec.ts src/pages/teacher/index/index.behavior.spec.ts src/pages/teacher/pbl-diagnostic-detail/pbl-diagnostic-detail.behavior.spec.ts src/pages/teacher/pbl-progress/pbl-progress.behavior.spec.ts src/pages/teacher/pbl-follow-up-detail/pbl-follow-up-detail.behavior.spec.ts` |                          0 | 5 files / 23 tests passed。                                                                                      |
| `npm run test:coverage`                                                                                                                                                                                                                                                                                                                                        |                          1 | 81 files / 405 tests 全通过；lines/statements 69.90%、functions 61.24%、branches 76.63%，未达 85%/85%/80%。      |
| `npm run lint`                                                                                                                                                                                                                                                                                                                                                 |                          0 | ESLint 通过。                                                                                                    |
| `npm run type-check`                                                                                                                                                                                                                                                                                                                                           |                          0 | Vue/TypeScript 检查通过。                                                                                        |
| `node scripts/frontend-boundaries.mjs`                                                                                                                                                                                                                                                                                                                         |                          0 | 203 implementation files 通过。                                                                                  |
| `npx --no-install prettier --check`（5 受影响页面、5 行为测试）                                                                                                                                                                                                                                                                                                |                          0 | 当前源文件格式通过。                                                                                             |
| `npm run build:mp-weixin`                                                                                                                                                                                                                                                                                                                                      |                          0 | 微信小程序生产构建通过。                                                                                         |
| `$env:VITE_APP_MODE='demo'; npm run dev:mp-weixin`                                                                                                                                                                                                                                                                                                             | watcher 成功后 Ctrl+C 停止 | Demo `dist/dev/mp-weixin` 完成编译；产物含各页“教师身份已变化”状态和整包 package identity guard，不手改 `dist`。 |
| `npm run test:mp:doctor`                                                                                                                                                                                                                                                                                                                                       |                          1 | 未设置 `WECHATIDE_CLI_PATH`；没有 DevTools 普通编译、真实 tap/input/scroll、页面渲染或截图审阅。                 |
| `git diff --check -- AGENTS.md docs/update_plan/43-classroom-task-package-reports`                                                                                                                                                                                                                                                                             |                          0 | 现有差异空白检查通过；未跟踪文件仍需逐文件格式/尾随空白检查覆盖。                                                |

仍不代表 T43 完成：A01–A24 及 API/Demo 全合同未整体验证，全局 coverage、安全历史指纹责任人复核、受管非生产数据库报告修复演练、DevTools 交互/渲染、真实 Coze/医学专家/PostgreSQL/生产/真机仍开放。上一完整后端门禁 316 passed / 88.26%、T43 后端专项 52 passed 没有因本轮前端改动重跑。无 API/backend/schema/迁移更改，无真实数据库或 Coze 调用，未提交或推送。

### 2026-09-25 续跑：发布确认包内容核验

按 W2 确认弹窗门禁补全发布摘要，教师在最终确认时现在可核对目标学生、课堂、首轮/第二轮题数、第二轮只对首轮未达标目标激活、草稿版本与完整 digest；任务仍一次发布且发布后冻结。组件行为测试对该确认文案逐项精确断言，五个教师页面行为套件仍 23/23 通过。

最后完整前端门禁：`npm run test:coverage` 81 files / 405 tests 全通过，exit 1（lines/statements 69.90%、functions 61.24%、branches 76.63%，阈值 85%/85%/80%）；lint、type-check、前端边界和受影响源文件 Prettier 均 exit 0。`npm run build:mp-weixin` exit 0；显式 Demo watcher 输出 `Build complete. Watching for changes...` 后停止，`dist/dev/mp-weixin` 可核实任务数量/摘要值和教师失权状态。`npm run test:mp:doctor` exit 1（缺少 `WECHATIDE_CLI_PATH`），无普通编译、tap/input/scroll 或截图审阅。没有接口/后端/迁移变化；T43 仍未完成。

### 2026-09-25 续跑：学生端身份切换与迟到响应隔离

按 W4/W5 检查发现学生切换账号或权限后，学习首页的课堂包/知识点、包详情、病例训练和学生病例分析报告可能短暂保留旧身份数据，旧 GET/提交回包也可能在页面离开后更新原实例。上述四个页面现在绑定当前学生 `openid + role`：身份无效或变化时清除页面私有状态、作废请求代次并显示明确状态；迟到的包读取、报告读取、病例阶段/完成回包不会更新 UI 或触发旧身份导航。学生病例分析仍仅是学生训练反馈，不产生教师报告或统计；包详情仍只在课堂包终态读取唯一最终报告。

| 命令                                                                                                                                                                                                                                                                          |                     退出码 | 结果                                                                                                                                                     |
| ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | -------------------------: | -------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `npx vitest run src/pages/student/learning/classroom-package.behavior.spec.ts src/pages/student/learning/index.classroom-packages.behavior.spec.ts src/pages/student/case-training/case-training.behavior.spec.ts src/pages/student/case-report/case-report.behavior.spec.ts` |                          0 | 4 files / 12 tests passed；覆盖身份变化清除旧包/病例/个人报告、作废迟到 GET/提交回包。                                                                   |
| `npm run lint`                                                                                                                                                                                                                                                                |                          0 | ESLint 全仓通过。                                                                                                                                        |
| `npm run type-check`                                                                                                                                                                                                                                                          |                          0 | Vue/TypeScript 检查通过。                                                                                                                                |
| `node scripts/frontend-boundaries.mjs`                                                                                                                                                                                                                                        |                          0 | 203 implementation files 通过。                                                                                                                          |
| `npm run test:coverage`                                                                                                                                                                                                                                                       |                          1 | 83 files / 411 tests 全通过；lines/statements 71.44%、functions 60.71%、branches 76.51%，低于固定 85%/85%/80% 全局门槛。                                 |
| `npm run build:mp-weixin`                                                                                                                                                                                                                                                     |                          0 | 小程序生产构建通过。                                                                                                                                     |
| `$env:VITE_APP_MODE='demo'; npm run dev:mp-weixin`                                                                                                                                                                                                                            | watcher 成功后 Ctrl+C 停止 | `dist/dev/mp-weixin` watcher 输出 `Build complete. Watching for changes...`；产物检查确认首页、任务包、病例训练和病例报告身份状态已编译，未手改 `dist`。 |
| `npm run test:mp:doctor`                                                                                                                                                                                                                                                      |                          1 | 缺少 `WECHATIDE_CLI_PATH`；无开发者工具普通编译、真实 tap/input/scroll、渲染或截图验收。                                                                 |

无 API/OpenAPI、后端、schema、迁移、授权或统计口径变化；本轮未重跑 contract/backend，最近后端全量仍是 316 passed / 88.26%（2026-09-25），本次没有覆盖它。无真实数据库、Coze、专家或生产操作，未提交/推送。T43 仍未完成：A01–A24 与 API/Demo 同态、coverage gate、安全历史指纹责任人复核、受管开发库 dry-run/备份恢复演练、DevTools 页面验收和外部环境事项继续开放。

### 2026-09-25 续跑：课堂病例评分资源目标与来源绑定

按 W1 对 API/资源路径做服务端复核后，确认病例重练和推理微训练虽已验证“病例获批、版本/digest 当前”，却未再次约束病例与任务 `primary_point_code` 的 knowledge link 一致，也未在 PUT 时核对 resource ID 是否仍为该完成诊断 session 绑定的病例；微训练审核蓝图查询缺完整 objective/options，保存分支没有持久化服务端 `criteria`，最终状态会回落 `pending_review`。本轮修复：

- `case_digest` 纳入排序知识节点关联。关联变化后旧摘要失效；没有改写历史审核行。
- content resource query 与 scoring resolver 对病例重练/微训练强制目标节点精确关联；未关联时不返回列表资源，伪造 PUT 返回 409。
- 新增 PBL-owned `PblClassroomPackageContextPort`，从 `(completion_snapshot_id, session_id)` 读取服务端 `session.case_id`。草稿保存、详情医疗状态、题库预览、发布前复核仅接受该课堂绑定病例 ID；同目标但跨课堂的另一批准病例也拒绝。
- 微训练资源变式补全 objective/options，PUT 用审核资源重新解析得到的 criteria 保存；无资源引用时客户端不能修改 criteria，引用有效时也不能覆盖服务端 rubric。
- Demo 90004 仍只覆盖目标病例重练，没有微训练资源选择 fixture；API 微训练资源链路已测，但 API/Demo 微训练同态继续列为 W1/W3 未完成，不将后端测试冒充 Demo 验收。

| 命令                                                                                                                                           | 退出码 | 结果                                                                                                |
| ---------------------------------------------------------------------------------------------------------------------------------------------- | -----: | --------------------------------------------------------------------------------------------------- |
| `python -m ruff check .`（`backend/`工作目录）                                                                                                 |      0 | Ruff 全量通过。                                                                                     |
| `npm run backend:test -- tests/test_t43_package_draft.py::test_case_scoring_resource_must_match_the_package_point_and_approved_link_digest -q` |      0 | 1 passed；覆盖目标/病例绑定拒绝及匹配病例双轮资源。                                                 |
| `npm run backend:test -- tests/test_t43_package_draft.py -q`                                                                                   |      0 | 14 passed。                                                                                         |
| `npm run backend:test:safety`                                                                                                                  |      0 | 14 passed；项目受管隔离 fixture。                                                                   |
| `npm run backend:test:migrations`                                                                                                              |      0 | 22 passed；未连接真实数据库、未执行 migration。                                                     |
| `npm run backend:check`                                                                                                                        |      0 | Ruff 通过；318 passed、coverage 88.70%，约 503 秒；317 条既有 SQLite 循环 FK 清理警告，无测试失败。 |

本轮无新增/修改数据库迁移、API DTO、OpenAPI、前端或 Demo 文件；因此未运行 contract、前端、构建或 watcher。旧 `MedicalReview` digest 在新算法下变为 stale 是预期 fail-closed：记录保留，新的 T43 病例评分用途需授权复审；不得自动更新批准记录。没有访问共享/真实/生产数据库、调用 Coze、签发医学审核、提交或推送。

本轮结束仍未关闭：前端 83 files/411 tests 虽全通过，但 coverage gate exit 1（lines/statements 71.44%、functions 60.71%、branches 76.51%，阈值 85%/85%/80%）；Demo/API 完整错误、权限和资源变化同态仍待对照；DevTools CLI 缺失导致指定目录普通编译后 tap/input/scroll 与截图未验；历史 secret scan 3 项待安全责任人复核；报告修复真实受管开发库备份/恢复演练、Coze、授权医学专家、PostgreSQL/生产与真机未验收。因此 T43 仍进行中。

### 2026-09-25 后续：Demo 推理微训练

将 Demo 90004 扩展为病例重练与两轮推理微训练目标。教师查询会返回标记为合成的两轮 reasoning blueprint，保存时以服务端 Demo rubric 作为最终评分依据；学生端使用既有文本作答控件，Demo adapter按关键词权重演示 70 分阈值和失败目标第二轮激活。病例目标和微训练目标均完成后才生成一份课堂报告。`npx vitest run src/features/learning/infrastructure/demoLearningRepository.classroomPackages.spec.ts` 退出 0，3 passed；本轮没有运行全量 coverage、构建或 Developer Tools，实际小程序交互仍待验收。文档中先前“Demo 缺微训练 fixture”的记录视为此增量前的状态，当前剩余重点是完整 API/Demo 错误/权限/资源分支同态及外部/微信门禁。

### 2026-09-25 后续：课堂任务包候选软排除

按 P3/W2 对“教师审阅后删去非必需候选”的实现约束，新增 `classroom_package_items.included_in_package` 和迁移 `20260924_0032`。教师仍提交当前草稿全部 item，但按 `stable_key` 成对切换首轮/第二轮纳入状态；保存时把纳入状态纳入 digest 和版本，清除旧审阅确认。服务端与 Demo 均拒绝半对选择、移除所有必要课堂目标验证或缺少必要推理目标覆盖。被排除题目不物理删除，题库来源与历史回执关系得以保留；医学新提交、发布验证、正式计划、学生任务、评分和报告仅使用纳入项。发布后继续冻结全部内容。迁移既有记录默认纳入，downgrade 在存在已排除记录时拒绝，以避免信息丢失。没有在真实或共享数据库应用迁移。

| 命令                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 |             退出码 | 结果                                                                                                       |
| -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | -----------------: | ---------------------------------------------------------------------------------------------------------- |
| `npm run backend:test -- tests/test_t43_package_draft.py tests/test_t43_migration.py -q`                                                                                                                                                                                                                                                                                                                                                                                                                             |                  0 | 16 passed；覆盖软排除/恢复、半对与覆盖拒绝、旧记录默认纳入、非空降级保护。                                 |
| `npm run backend:test:safety`                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        |                  0 | 14 passed。                                                                                                |
| `npm run backend:test:migrations`                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    |                  0 | 22 passed；本地受管临时数据库测试，不代表真实数据库已升级。                                                |
| `npx vitest run src/components/teacher/TeacherClassroomPackageReview.behavior.spec.ts src/features/learning/infrastructure/demoLearningRepository.classroomPackages.spec.ts src/features/learning/infrastructure/classroomPackages.api.spec.ts src/features/learning/infrastructure/classroomPackages.spec.ts`                                                                                                                                                                                                       |                  0 | 4 files / 27 tests passed；覆盖 API/Demo 映射、成对移除/恢复、发布后学生仅获纳入任务。                     |
| `npm run type-check`                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 |                  0 | Vue/TypeScript 检查通过。                                                                                  |
| `npm run contract:generate` / `npm run contract:check`                                                                                                                                                                                                                                                                                                                                                                                                                                                               |              0 / 0 | 生成 OpenAPI/TS 契约后校验通过；生成文件未手改。                                                           |
| `npx eslint src/components/teacher/TeacherClassroomPackageReview.vue src/components/teacher/TeacherClassroomPackageReview.behavior.spec.ts src/features/learning/domain/classroomPackages.ts src/features/learning/infrastructure/classroomPackages.api.spec.ts src/features/learning/infrastructure/classroomPackages.spec.ts src/features/learning/infrastructure/demoLearningRepository.ts src/features/learning/infrastructure/demoLearningRepository.classroomPackages.spec.ts src/features/learning/public.ts` |                  0 | 8 个受影响 Vue/TS 文件定向 ESLint 通过。                                                                   |
| `$env:VITE_APP_MODE='demo'; npm run dev:mp-weixin`                                                                                                                                                                                                                                                                                                                                                                                                                                                                   | watcher 完成后停止 | 显式 Demo 模式编译到 `dist/dev/mp-weixin` 并观察到 `Build complete. Watching for changes...`；未手改产物。 |
| `npm run test:mp:doctor`                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             |                  1 | 缺少 `WECHATIDE_CLI_PATH`；未进行 Developer Tools 普通编译、真实 tap/input/scroll 或截图。                 |

本增量未重跑全量 `backend:check` 或前端 `test:coverage`；最近完整前端 coverage 仍是 83 files / 411 tests 全通过但命令 exit 1（71.44%/60.71%/76.51%，低于固定 85%/85%/80%）。文档格式修复后 `npx --no-install prettier --check` 对本次更新的三份 Markdown 退出 0；工程 self-check 退出 0；定向 ESLint 退出 0。新增加的 Markdown 段落无尾随空白；相对链接均指向本计划现有文件。T43 仍未完成；A01–A27 全链路/API-Demo 同态、DevTools、历史安全指纹责任人复核、报告修复真实受管非生产库恢复演练，以及 Coze/医学专家/PostgreSQL/生产/真机仍开放。没有访问真实数据库、调用真实 Coze、提交或推送。

### 2026-09-25 后续：过期资源不应阻止排除候选

W1/P3 定向复核发现：已选择的客观审核资源在草稿保存前过期时，服务端会以 409 拒绝整份 PUT，即使教师已经将该题的首/二轮成对排除。这会阻止教师绕开不可发布候选。先补回归用例并确认旧逻辑失败，再调整行为：排除项不属于实际发布集，因此保存时不重新解析/审批其资源；若本次提交尝试为排除项绑定了新资源引用，则不持久化该新绑定，保留此前已存来源引用。项目日后恢复该题时仍走原有实时资源、目标、版本和摘要校验；纳入项资源过期仍明确 409。Demo 对该规则保持相同的排除/资源引用行为。

| 命令                                                                                                                                                            |    退出码 | 结果                                                                                                       |
| --------------------------------------------------------------------------------------------------------------------------------------------------------------- | --------: | ---------------------------------------------------------------------------------------------------------- |
| 旧逻辑回归：`npm run backend:test -- tests/test_t43_package_draft.py::test_reviewed_objective_resources_reject_stale_included_refs_but_allow_excluding_pair -q` | 1（预期） | 新断言先失败，复现“排除 stale 候选也被资源 digest 409 阻断”。pytest 仅创建了项目所有权标记的临时测试资源。 |
| 修复后同一后端回归用例                                                                                                                                          |         0 | 1 passed；仍断言同一 stale 资源用于纳入题时拒绝，排除成对候选则保存成功并保留必需覆盖。                    |
| `npm run backend:test -- tests/test_t43_package_draft.py -q`                                                                                                    |         0 | 15 passed、14 条既有 SQLite 循环外键清理警告；整包草稿/资源测试文件通过。                                  |
| `npx vitest run src/features/learning/infrastructure/demoLearningRepository.classroomPackages.spec.ts`                                                          |         0 | 1 file / 3 tests passed；覆盖排除项资源引用处理、学生不接收排除任务及原双轮生命周期。                      |
| `npm run type-check` / 定向 ESLint（Demo repository 与对应 spec）/ 定向 Ruff                                                                                    | 0 / 0 / 0 | Vue/TypeScript、两个受影响前端文件及两个后端文件检查通过。                                                 |

中间的一次修复尝试将“排除项不得更换资源引用”直接拒绝为 409，回归测试因此再次失败；按预期改成不持久化排除项本次新绑定、保留原来源后，用例通过。此记录用于说明修复过程，不是当前开放缺陷。

本次只针对草稿保存边界做了后端及 Demo 定向检查；没有重跑全部 coverage、全量后端、迁移、契约或小程序交互。代码中的一次格式化调用先因工作目录相对路径不匹配退出 1，改用 `backend/` 下的正确相对路径后 `ruff format` 成功；不是测试失败。文档门禁：对本次更新的六份 Markdown 执行 `npx --no-install prettier --check` 退出 0；工程 `self_check.py` 退出 0；更新文档无尾随空格、相对链接目标存在，`git diff --check -- AGENTS.md` 退出 0。T43 与 W1 仍未完成。

### 2026-09-25 后续：拒绝空白幂等请求标识

W1 接口复核发现 API 的 `min_length=1` 会接受纯空格请求标识，且 Demo 的任务包 ensure、医学审核提交和发布没有统一 100 字上限校验。现统一在 API 请求模型和 Demo 操作边界拒绝全空白标识，并保持原值作为幂等键；既有 1–100 字长度限制不变。没有新增存储层重复校验或改变 OpenAPI 字段形状。

| 命令                                                                                                      | 退出码 | 结果                                                                               |
| --------------------------------------------------------------------------------------------------------- | -----: | ---------------------------------------------------------------------------------- |
| `npm run backend:test -- tests/test_t43_package_draft.py -k commands_reject_blank_request_ids -q`         |      0 | 1 passed；ensure、医学提交、发布的空白标识均为 422，任务包仍为草稿且没有正式计划。 |
| `npm test -- --run src/features/learning/infrastructure/demoLearningRepository.classroomPackages.spec.ts` |      0 | 1 文件、3 项通过；覆盖 Demo ensure、医学提交和发布的一致拒绝。                     |
| `npm run contract:check`                                                                                  |      0 | OpenAPI 与生成类型同步；请求模型仅增加运行时空白校验，字段 schema 未变化。         |
| `npm run type-check`                                                                                      |      0 | Vue 与 TypeScript 类型检查通过。                                                   |
| `npx --no-install prettier --check`（本节更新的两份 Markdown）                                            |      0 | 计划合同与本交付记录格式通过。                                                     |

本次只跑直接相关后端用例、Demo 任务包生命周期、契约和类型检查；未重跑全量后端、coverage、迁移、构建或 Developer Tools。API/Demo 对齐、T43 与 W1–W8 仍未完成。

### 2026-09-25 后续：Demo 正式任务提交标识与 API 对齐

W4/A23 对照发现：后端正式任务提交拒绝全空白或超过 100 字的 `client_submission_id`，Demo adapter 之前未执行同一合同。Demo `submitClassroomTask` 现在复用任务包已使用的请求标识校验；不改服务端接口、计分、任务状态或合法请求的幂等语义。

| 命令                                                                                                      |                 退出码 | 结果                                                                                                      |
| --------------------------------------------------------------------------------------------------------- | ---------------------: | --------------------------------------------------------------------------------------------------------- |
| `npm test -- --run src/features/learning/infrastructure/demoLearningRepository.classroomPackages.spec.ts` |                      0 | 1 文件、3 项通过；新增空白/101 字标识拒绝，随后合法提交仍按原双轮流程完成。                               |
| `npm run type-check`                                                                                      |                      0 | Vue 与 TypeScript 类型检查通过。                                                                          |
| `$env:VITE_APP_MODE='demo'; npm run dev:mp-weixin`                                                        | watcher 完成后手动停止 | 显式 Demo 模式构建到 `dist/dev/mp-weixin`，观察到 `Build complete. Watching for changes...`；未编辑产物。 |
| `npm run test:mp:doctor`                                                                                  |                      1 | 未设置 `WECHATIDE_CLI_PATH`；因此没有 Developer Tools 普通编译、真实点击/输入/滚动或截图审阅。            |

未重跑全量前端/后端套件。小程序交互保持未验收；本次不改变其页面可见内容。W4/A23 其他场景与 T43 整体验收仍开放。

### 2026-09-25 后续：旧诊断只读与单题发布旁路退役

W2/A23 复核发现旧教师诊断详情对 v6 历史诊断仍加载同班名单并暴露反馈/关闭/单题发布控件；后端 v6 `task_published` 与建议 edit/adopt 也仍可产生正式计划。现 v7 课堂诊断继续进入固定学生整包审阅；v3–v6 与其他旧分支仅显示历史诊断，不加载同班名单、不提供编辑、反馈、关闭、改接收者或发布操作。旧 suggestion edit/adopt API 对 v7 返回整包流程 409，对历史版本返回只读 409；旧 `task_published` 在 v7 返回整包流程 409；v3–v6 的新 feedback/close 请求拒绝，完全相同的既有幂等反馈请求仍返回旧回执。API 与 Demo 的旧写入入口保持同一拒绝行为。学生未完成的历史任务仍按既有历史任务入口执行，本次未改变旧学习计划读写。

| 命令                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          |                 退出码 | 结果                                                                                              |
| --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ---------------------: | ------------------------------------------------------------------------------------------------- |
| `npm run backend:test -- tests/test_pbl_api.py::test_pbl_legacy_suggestion_edit_and_adoption_are_read_only tests/test_t11_pbl_integration.py::test_legacy_suggestion_actions_do_not_create_learning_plans tests/test_t11_pbl_integration.py::test_t11_closed_history_scope_phase_and_invalid_targets tests/test_t11_pbl_integration.py::test_legacy_case_retry_cannot_create_a_plan tests/test_t11_pbl_integration.py::test_legacy_publish_cannot_activate_either_task_cycle tests/test_t11_pbl_integration.py::test_t11_conversion_preserves_pbl_mixed_and_original_records tests/test_t21_teacher_pbl_feedback.py::test_v6_diagnostic_feedback_is_read_only_and_scoped_to_the_owner tests/test_t21_teacher_pbl_feedback.py::test_legacy_single_question_publish_is_rejected_for_a_v6_classroom tests/test_t21_teacher_pbl_feedback.py::test_classroom_dashboard_tracks_work_item_status -q` |                      0 | 9 passed；旧 v6 写动作被拒绝且没有创建计划/反馈，旧历史读取与转换测试保持通过。                   |
| `npm test -- --run src/pages/teacher/pbl-diagnostic-detail/pbl-diagnostic-detail.behavior.spec.ts src/components/teacher/teacher-pbl-diagnostic-detail.behavior.spec.ts src/features/pbl/infrastructure/demoPblRepository.spec.ts`                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            |                      0 | 3 files / 19 tests passed；新版入口选整包审阅，旧诊断只读，API/Demo 旧建议变更和单题发布拒绝。    |
| `npm run type-check` / 定向 ESLint / 后端定向 Ruff 与 `ruff format --check`                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   |                      0 | 受影响的 TypeScript/Vue 与 Python 文件检查通过。                                                  |
| `$env:VITE_APP_MODE='demo'; npm run dev:mp-weixin`                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            | watcher 完成后手动停止 | 观察到 `Build complete. Watching for changes...`，输出为 `dist/dev/mp-weixin`；没有修改编译产物。 |
| `npm run test:mp:doctor`                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      |                      1 | 缺少 `WECHATIDE_CLI_PATH`；因此没有 Developer Tools 普通编译、tap/input/scroll 或截图审阅。       |

只运行上述受影响的后端、前端行为与静态检查，未重跑全量后端/coverage/迁移/契约。没有 API DTO、数据库或 OpenAPI schema 变更。旧路由保留为稳定冲突响应；历史真实计划与学生侧“历史任务”路径未改。T43 其它阶段、A01–A27 完整矩阵和真实/外部验收仍开放。

### 2026-09-25 后续：Demo 课堂任务提交顺序与 API 对齐

W4/A23 对照发现，API 会拒绝同一轮中尚未完成前序任务时提交后续任务，但 Demo 之前只验证轮次激活状态。Demo 现在按任务包内位置检查当前轮较早且已激活的任务：只有前序项完成或跳过后才接受当前提交；第二轮未激活项不阻塞提交。新增 API 回归用例覆盖两题任务包的提前提交拒绝及随后按序提交成功，并扩展 Demo 包生命周期测试检查冲突后任务仍为 pending。该增量不改变 API/schema、计分规则或题目内容。

| 命令                                                                                                                | 退出码 | 结果                                                               |
| ------------------------------------------------------------------------------------------------------------------- | -----: | ------------------------------------------------------------------ |
| `npm run backend:test -- tests/test_t43_package_draft.py::test_student_cannot_submit_a_later_package_task_first -q` |      0 | 1 passed；提前提交返回冲突、任务状态保持 pending，前序提交仍成功。 |
| `npm test -- --run src/features/learning/infrastructure/demoLearningRepository.classroomPackages.spec.ts`           |      0 | 1 文件、3 项通过；新增同轮不可越序提交断言。                       |
| `npm run type-check` 与受影响文件 ESLint                                                                            |      0 | TypeScript 类型与相关 lint 检查通过。                              |

未重跑全量前端/后端、coverage、迁移或小程序构建；本增量不改变可见页面。此结果仅关闭同轮任务顺序这一项已发现的 API/Demo 差异，A23 其余状态/错误/权限矩阵仍开放。

### 2026-09-25 后续：Demo discussion 任务按证据而非分数判定

W4/A23 复核发现 API 与第04/06册合同一致：discussion 接受 1–4000 字回答，只验证完成证据、不生成分数；但 Demo 会把它按客观题读取 `selected_option`，并将 null 分数判为失败。Demo 现按文本提交校验，终态检查使用 `threshold=null`、`score=null`、`evidence_present=true`、`passed=true`；第一轮其他目标失败时也保留第二轮 discussion 的既定激活规则。90005 fixture 增加一组正式讨论双轮题。定向用例覆盖首轮客观题与 discussion 都通过后生成改进报告，以及空白讨论答案被拒绝；discussion 二轮激活仍留在 A23 完整复核，不把代码路径等同于该分支已有独立回归断言。

| 命令                                                                                                                                                                      |                 退出码 | 结果                                                                                                           |
| ------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ---------------------: | -------------------------------------------------------------------------------------------------------------- |
| `npm test -- --run src/features/learning/infrastructure/demoLearningRepository.classroomPackages.spec.ts`                                                                 |                      0 | 1 文件、3 项通过；discussion 首轮按证据通过并进入唯一最终报告。                                                |
| `npm run type-check`                                                                                                                                                      |                      0 | Vue/TypeScript 类型检查通过。                                                                                  |
| `npm exec eslint -- src/features/learning/infrastructure/demoLearningRepository.ts src/features/learning/infrastructure/demoLearningRepository.classroomPackages.spec.ts` |                      0 | 两个受影响文件 lint 通过。                                                                                     |
| `$env:VITE_APP_MODE='demo'; npm run dev:mp-weixin`                                                                                                                        | watcher 完成后手动停止 | `dist/dev/mp-weixin` 编译完成并观察到 `Build complete. Watching for changes...`；按常驻 watcher 预期手动停止。 |

未重跑全量前端/后端、coverage、迁移或完整 A23 矩阵。当时执行 doctor 的进程未注入 `WECHATIDE_CLI_PATH`；该工具状态已由下方复核记录更正。T43 与 A23 整体仍未完成。

### 2026-09-25 后续：微信开发者工具路径复核更正

此前 doctor 退出 1 的直接原因是执行命令的 Codex PowerShell 没有 `WECHATIDE_CLI_PATH`，并非开发者工具未安装或用户设置错误。已从[微信验收规范](../../../operations/wechat-validation.md)核实并使用本机实际安装路径 `D:\codeapp\微信web开发者工具\wechatide.cmd`，仅在本次命令进程设置变量，没有修改用户/系统环境变量。

| 命令                                                                                             | 退出码 | 结果                                              |
| ------------------------------------------------------------------------------------------------ | -----: | ------------------------------------------------- |
| `wechatide.cmd -c Codex open_project_window --project dist/dev/mp-weixin --window-mode liteMode` |      0 | 复用已打开项目窗口成功。                          |
| `wechatide.cmd -c Codex simulator_refresh --project dist/dev/mp-weixin`                          |      0 | 模拟器刷新成功。                                  |
| `npm run test:mp:doctor`（同一进程已设置 `WECHATIDE_CLI_PATH` 与 `WECHATIDE_CLIENT`）            |      0 | CLI 连接、项目与 URL 安全检查通过，SDK `3.16.3`。 |
| `wechatide.cmd -c Codex simulator_screenshot --project dist/dev/mp-weixin`                       |      0 | 内部截图成功并审阅当前页面；未保存到仓库。        |
| `automation_element_action --action tap --selector .role-button.student`                         |      0 | 真实点击学生入口成功并进入学生端。                |

更正后结论：开发者工具启动和 doctor 已通过；本次尚未走到 T43 任务包/教师报告页面，不能据此关闭对应的实际交互与渲染验收。随后一次无匹配元素的只读 selector 查询和一次不受支持的 `nth-child` selector 没有触发页面动作，不是产品失败；不据此扩大验收范围。之后如需操作，按当前终端进程设置已安装 CLI 路径即可，无需改开发者工具设置。

### 2026-09-25 后续：Demo discussion 第二轮激活与工具刷新

新增 Demo fixture `90007`，覆盖首轮知识题未达标、discussion 首轮完成后，第二轮只激活失败知识目标变式并同时出现 discussion 变式；知识目标通过后，报告仍保持不可用，直到 discussion 变式也提交，随后只形成一份第二轮终态报告。该用例证明 Demo 这一具体生命周期分支，不替代第09册其余 API/Demo 矩阵。

| 命令                                                                                                      |         退出码 | 结果                                                                                           |
| --------------------------------------------------------------------------------------------------------- | -------------: | ---------------------------------------------------------------------------------------------- |
| `npm test -- --run src/features/learning/infrastructure/demoLearningRepository.classroomPackages.spec.ts` |              0 | 1 文件、4 项通过，包含 discussion 第二轮激活与报告时点断言。                                   |
| 受影响文件 ESLint 与 Prettier 检查                                                                        |              0 | Demo repository 与 lifecycle 测试文件检查通过。                                                |
| `$env:VITE_APP_MODE='demo'; npm run dev:mp-weixin`                                                        | 完成后手动停止 | watcher 已完成 `dist/dev/mp-weixin` 开发构建；本轮只含 Demo fixture/逻辑，无新增可见页面状态。 |
| `wechatide.cmd -c Codex simulator_refresh --project dist/dev/mp-weixin`                                   |              0 | 已对正确开发目录执行模拟器刷新。                                                               |
| `npm run test:mp:doctor`（同一 PowerShell 进程显式设置 CLI 路径与客户端名）                               |              0 | CLI 可用，项目与 URL 安全检查通过，SDK `3.16.3`。                                              |

未重跑全量前后端、coverage、迁移或完整 A23 矩阵；也未对任务包/教师报告页面进行新的可见交互。开发者工具路径问题已解决，T43 对应页面真实点按/渲染仍按第11册保留待验收。

### 2026-09-25 后续：开发者工具实际页面入口复核

确认本轮登录后点击学生身份入口成功，模拟器进入已有的学生 PBL 研讨页面；该页面截图已通过开发者工具内部接口取得并审阅，但不是 T43 任务包页面。受支持的 `automation_navigate --action switchTab --url /pages/student/learning/index` 返回 `Uncaught [object Object]`，任务列表组件的直接只读选择器查询也返回 `no such element`，页面未发生跳转或数据修改。该情况与本仓库历史记录的 uni-app 页面导航/自定义组件元素定位限制一致，不是 CLI 路径或开发者工具设置缺失，也不能算作学生任务流程通过。停止重复尝试相同调用；需要人工开发者工具点击或支持组件穿透/导航的受支持自动化能力后，再验收任务包和教师报告页面。

### 2026-09-25 后续：API discussion 第二轮与现行文档收敛

在 `backend/tests/test_t43_package_draft.py` 增加 API 用例：首轮知识目标题未达标且 discussion 已完成时，第二轮同时激活失败知识目标及 discussion 变式；知识题通过后报告仍不可用，discussion 提交后仅形成一份终态报告。`npm run backend:test -- tests/test_t43_package_draft.py::test_second_cycle_activates_discussion_and_waits_for_it_before_one_report -q` 退出 0，1 passed（4.28 秒）。只验证该定向分支，不声明完整后端回归。

将第11册旧交接流水归档至 `deliveries/11-handoff-history-20260925.md`，新第11册改为完成摘要和 W1–W8 当前执行单；T43 总览及根规则同步纠正开发者工具现状。此次仅新增后端测试与文档，不修改运行时代码、接口、迁移或 Demo 可见状态；未据此重跑 watcher/全量门禁。

收束检查：`python -m ruff check backend/tests/test_t43_package_draft.py` 退出 0（修正新增用例的未用变量及两处超长行）；相关 Markdown 的 Prettier 检查通过，局部相对链接检查通过；工程 skill `self_check.py --self-test` 与正常检查均退出 0。`git diff --check` 未报空白错误，仅对工作树内其他既有文件提示 CRLF/LF 转换。此时尚未运行完整后端、前端覆盖率或微信流程；后端随后补跑，结果见下节。

### 2026-09-25 后续：`0032` 后完整后端门禁

随后只补跑一次 `npm run backend:check`，退出 0：Ruff 通过、pytest 322 passed、321 warnings、总覆盖率 87.78%（要求 85%），耗时 462.93 秒。该结果包含 `0032` 迁移和上述新增 discussion API 用例，取代先前 318 passed/88.70% 的迁移前快照。没有因此宣称前端覆盖率、API/Demo 全矩阵、小程序实际交互或外部验收通过；后续运行时代码变更再按影响范围决定复测。

### 2026-09-25 后续：W3 题库权限与幂等负向断言

在 `backend/tests/test_t43_question_bank.py` 补充跨教师 PUT/归档统一 404、同一入库请求键携带不同题干返回 409，以及题库编辑/归档后来源课堂候选题面保持不变的断言。`npm run backend:test -- tests/test_t43_question_bank.py -q` 退出 0（1 passed）；`python -m ruff check backend/tests/test_t43_question_bank.py` 与 `python backend/scripts/check_boundaries.py` 分别退出 0。Demo 题库用例补同键异内容冲突，`npx vitest run src/features/content/infrastructure/demoQuestionBank.spec.ts` 退出 0（1 passed），受影响 ESLint 与 Prettier 检查退出 0。仅新增测试，不改运行时代码或可见 Demo；先前 322 项完整后端结果早于本增量，后续合并完成时按 W8 复核。题库编辑不影响**已发布**任务及历史最终报告的组合证据仍未补齐，W3 保持开放。

### 2026-09-25 后续：W3 已发布任务与最终报告冻结

新增 `test_bank_revision_does_not_rewrite_published_task_or_terminal_report`：教师完成整包医学审阅并发布、学生完成首轮形成最终报告后，教师复制题目进个人题库并编辑/归档；比较前后学习任务的公开定义、学生任务 DTO、最终报告持久化 payload 和教师报告 DTO。首次运行退出 1 是测试基线误取学生提交前的 `pending` 状态，并非产品行为失败；改为提交后且题库变更前取快照，复跑 `npm run backend:test -- tests/test_t43_question_bank.py -q` 退出 0（2 passed、1 条既有 SQLite 表排序警告）。`python -m ruff check backend/tests/test_t43_question_bank.py`、`python backend/scripts/check_boundaries.py` 均退出 0。失败 pytest 临时资源由测试框架保留供诊断，本轮未手动清理。仅新增仓库测试，未改运行时、Demo、API 或 schema；W3 的页面权限/版本及小程序实交互仍开放，不重复运行全量后端。

### 2026-09-25 后续：W7 历史审计口径与深链兼容

发现第09册 A18 仍误列“重复 apply、转换备份恢复”，第07册结尾仍写“重复转换”，均与 T43 本期**不转换**的已批准策略冲突；已修订为重复只读审计、`--apply` 打开数据库前拒绝，并将受控最终报告修复工具的备份恢复与历史转换区分。A13 的“转换报告计数”改为旧计划/独立病例排除。

`backend/tests/test_t43_legacy_audit.py` 新增重复审计结果稳定、无新包/报告和不存在数据库路径的 `--apply` 拒绝用例；`npm run backend:test -- tests/test_t43_legacy_audit.py -q` 退出 0（3 passed、2 条既有 SQLite 表排序警告），`python -m ruff check backend/tests/test_t43_legacy_audit.py` 退出 0。教师本课报告页新增旧 `planId` 深链测试，断言显示历史说明、不调用最终报告 GET，操作后返回 PBL 巩固入口；`npx vitest run src/pages/teacher/pbl-follow-up-detail/pbl-follow-up-detail.behavior.spec.ts` 退出 0（3 passed），受影响 ESLint/Prettier 退出 0。仅新增测试和文档，未改运行时代码、迁移或 Demo 可见状态；真实受管非生产 SQLite 的只读 CLI 双跑和实际旧任务入口仍未验收。

### 2026-09-25 后续：开发者工具有限页面实看与交接单修订

显式设置 `VITE_APP_MODE=demo` 运行 `npm run dev:mp-weixin`，观察到 `Build complete. Watching for changes...`；仅使用 `dist/dev/mp-weixin`。已安装 CLI 的 `open_project_window`、`simulator_refresh` 均退出 0；同一 PowerShell 进程设置 `WECHATIDE_CLI_PATH` 与 `WECHATIDE_CLIENT` 后，`npm run test:mp:doctor` 退出 0，SDK `3.16.3`。开发者工具内部截图已人工审阅，不进入仓库。

`automation_element_action` 真实 tap 学生、教师身份入口各成功一次；工具的 `simulator_open_page` 编译打开学生学习首页和教师 `snapshotId=90003` 诊断详情。学习首页可见待完成任务区及空发布状态；诊断首屏可见“无明确薄弱点”说明、整包候选和首轮题面。这只证明两个页面的当前可见状态，不证明从工作区导航进入。`automation_element_action` 查找子组件中的学生主导航与发布确认 checkbox 返回 `no such element`；对诊断根元素 `scrollTo` 返回成功，但内部截图画面未变。此前 `switchTab` 导航也报错。本轮没有发布任务、填写答案、完成报告或教师学情真实流程；保持 W8 待验收，后续使用允许的人工开发者工具交互或获得受支持的组件定位能力。

因此第11册将已完成内容压缩为当前事实，并把 W8 的真实入口、发布、学生两轮、教师本课/综合报告按顺序列为明确待办。此次仅更新计划、交付记录和根规则事实描述，未改运行时代码、Demo 状态、API 或迁移；不为文档改动重复全量测试。

### 2026-09-26 后续：学生任务空状态口径修正

核对 T43 病例回包与最终报告路径后，发现学生学习页待完成任务空状态仍称“完成病例评估后”会出现下一步，容易把独立病例误认为新课堂任务来源。`PblTaskList.vue` 已改为仅说明教师发布课堂任务包会出现待完成任务，并明示独立病例训练分析不会生成课堂任务。原检索命中的 `ChatWelcome.vue` 只有组件测试引用、没有运行时页面引用，本轮不改无消费者的组件。

| 检查                                                                                        |           退出码 | 结果                                                          |
| ------------------------------------------------------------------------------------------- | ---------------: | ------------------------------------------------------------- |
| `npx vitest run src/components/student/pbl-task-list.behavior.spec.ts`                      |                0 | 1 文件、4 项通过；新增空状态文案断言。                        |
| 受影响两文件 Prettier 检查及 ESLint                                                         |                0 | 格式和 lint 通过。                                            |
| `$env:VITE_APP_MODE='demo'; npm run dev:mp-weixin`                                          | watcher 编译完成 | `Build complete. Watching for changes...`，输出正确开发目录。 |
| `wechatide.cmd -c Codex open_project_window`、`simulator_refresh`、`npm run test:mp:doctor` |                0 | 正确 Demo 项目打开并刷新，doctor 返回 SDK `3.16.3`。          |

本次 Demo 中知识点待办始终存在，未到达任务区完全空的可见状态；组件断言和构建不能替代该状态的实际渲染审阅，W8 保留此项。未改 API、数据、迁移或 Demo seed；不为一句空状态文案重跑全量后端/前端与截图。回退仅撤销本次文案和对应测试。

同轮代码审计还发现一个未修复的医学审核差距：`SqlClassroomTaskPackageRepository._medical_state` 在 `focused_retry` 资源引用有效时返回病例的医学审核状态，但未对教师可编辑的任务标题、题干、目标说明做独立摘要审核；第06册要求医学措辞/题干变化使旧批准失效。已把修复顺序、API/Demo 和最小负向用例写入第11册 W1。此项目前是**待实施**，不把上述文案测试或历史病例审核测试当作关闭证据。

### 2026-09-26 后续：病例任务题面独立医学审核

接续处理上段缺口。`focused_retry` 发布门禁先核病例本体的当前批准版本与摘要，再核该轮实际发布题面/目标的独立审核摘要；两轮分别审核，改写题面后旧摘要失效。教师审阅组件保留病例引用、显示两个审核事实并可提交题面审核；Demo 编辑后转为待审核且阻止发布，不模拟专家批准。第06册和第11册已同步明确此边界。没有修改数据库迁移或 API schema 形状。

| 检查                                                         | 退出码 | 结果                                                                                                      |
| ------------------------------------------------------------ | -----: | --------------------------------------------------------------------------------------------------------- |
| `npm run backend:test -- tests/test_t43_package_draft.py -q` |      0 | 18 passed；其中覆盖病例获批、题面未批阻止发布，以及改题后重新批准才能发布。17 条既有 SQLite FK 排序警告。 |
| `npx vitest run` 三个受影响的整包审阅/Demo 用例文件          |      0 | 3 files、19 tests passed；包含两轮题面提交审核与 Demo 编辑阻塞。                                          |
| `npm run type-check`                                         |      0 | Vue/TypeScript 类型检查通过。                                                                             |
| 受影响 Python Ruff、前端 ESLint/Prettier、后端边界脚本       |      0 | 定向静态检查通过。                                                                                        |

这仅关闭病例题面旧批准可复用的具体缺口，不代表 W1 所有资源、并发与事务分支、真实医学专家审核或 W8 小程序交互已通过。本轮不因局部修复重跑全量后端/前端覆盖率门禁；当前完整门禁快照仍以前文为准。可见审核阻塞提示需按 W8 在正确 Demo 开发目录复核。

显式 `VITE_APP_MODE=demo` 的 `npm run dev:mp-weixin` 已输出 `Build complete. Watching for changes...`；用已安装的 `wechatide.cmd` 打开 `dist/dev/mp-weixin`、刷新模拟器、执行 `npm run test:mp:doctor` 均退出 0，SDK `3.16.3`。编译直开教师 `snapshotId=90004` 诊断页成功，内部截图显示病例任务的诊断与首轮题面正常出现在首屏；审阅/医学提示位于更下方，本轮未通过真实滚动抵达，不能把这张截图当作新阻塞文案或发布操作已验收。真实教师入口、题面编辑/提交审核/发布的工具交互仍归 W8。

### 2026-09-26 后续：W1 主节点资源与课堂节点范围

代码审计发现资源 GET 用 `point_code in item.point_codes` 筛选，而草稿 PUT 对已审核资源始终以 `primary_point_code` 解析；多节点题因此可能列出无法保存的次要节点资源。已将 API/Demo GET 改为只匹配主节点，无对应纳入候选时统一返回 `RESOURCE_NOT_FOUND`。领域 coverage 现在拒绝任何不属于该课堂目标的次要节点；Demo 的包覆盖校验同步。第05册与第11册已记录此合同，未改 schema、迁移、路由形状或生成契约。

| 检查                                                             |                      退出码 | 结果                                                                                    |
| ---------------------------------------------------------------- | --------------------------: | --------------------------------------------------------------------------------------- |
| `npm run backend:test -- tests/test_t43_package_draft.py -q`     |                           0 | 20 passed，包含新增课外次要节点与错误主节点资源查询断言；19 条既有 SQLite FK 排序警告。 |
| `npx vitest run` 两个受影响 Demo 整包文件                        |                           0 | 2 files、5 tests passed，包含无匹配主节点时的错误码。                                   |
| `npm run type-check`、受影响 Ruff/ESLint/Prettier                |                           0 | 类型、静态规则和格式检查通过。                                                          |
| 前后端边界脚本                                                   |                           0 | 后端 9 个模块、前端 203 个实现文件通过。                                                |
| 显式 Demo watcher、开发者工具打开/刷新、`npm run test:mp:doctor` | 0（watcher 编译完成后停止） | 正确开发目录完成普通编译等价刷新；SDK `3.16.3`。                                        |

现有 Demo 课堂仅有单一主节点，不能直接呈现这次多节点选择边界；本轮不重复截取无变化页面。真实多节点教师选资源流程和 W1 其余资源/并发事务分支仍待 W8/后续定向验收；上述局部结果不能替代全量覆盖率或真实医学审核。回退为撤销本轮主节点筛选及节点集合校验和对应测试，不涉及数据库清理。

### 2026-09-26 后续：W1 发布时复核、并发与事务失败

在现有整包用例中补齐三条此前缺少的直接断言：已绑定的客观资源在保存后、发布前变更摘要时，发布返回 409 且不创建计划；不同发布请求键并发只能有一份正式计划和通知，失败键不能在胜者发布后再次创建；发布后不能重新提交医学审核。另以一次性注入通知写入失败证明包版本、计划、通知回滚，同请求标识重试成功。反馈写入失败的既有用例已经断言通知回滚。未改运行时代码、API/DTO、迁移或 Demo。

| 命令                                                         |           退出码 | 结果                                                                                                                                                                  |
| ------------------------------------------------------------ | ---------------: | --------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| 发布时资源失效定向 pytest                                    |                0 | 1 passed；旧摘要导致 409，包仍为草稿且计划数为 0。                                                                                                                    |
| 同/异请求键并发定向 pytest                                   |                0 | 2 passed；异键一成功一冲突，只有一份计划和通知。                                                                                                                      |
| 通知故障定向 pytest                                          | 初次 1，修正后 0 | 首次注入误打到 fixture Session 而非请求 Session，未触发故障；改为拦截实际使用的 `Session.add` 后 1 passed。首次失败的临时 pytest 资源按框架策略保留，本轮未手工清理。 |
| `npm run backend:test -- tests/test_t43_package_draft.py -q` |                0 | 22 passed、21 条既有 SQLite FK 排序警告；包含发布后医学提交拒绝。                                                                                                     |

W1 的仓库内关键分支已具备定向证据，下一步转 W2 教师诊断页面与旧入口；真实专家、工具内多节点实际交互和 W6 全量同态仍待验收。没有为测试增量重跑全量后端、前端覆盖率或 Demo watcher；回退仅撤销新增断言，不影响业务数据。

### 2026-09-26 后续：W2 教师整包资源选择器状态

检查教师诊断审阅组件时发现资源请求虽已返回，选择器却可能一直显示“读取中”：新建资源状态对象后持有原始对象引用，异步回写不稳定触发 Vue 渲染。现统一从 `reactive` 容器重新取代理再写入；同组重复请求被抑制。资源 picker 在保存/发布中及已发布冻结后禁用，方法入口也拒绝迟到事件；排除一组候选清除其旧选项。应用资源前先核两轮均存在，异常资源不会部分改写首轮。

| 检查                                                                                   |           退出码 | 结果                                                                                   |
| -------------------------------------------------------------------------------------- | ---------------: | -------------------------------------------------------------------------------------- |
| `npx vitest run src/components/teacher/TeacherClassroomPackageReview.behavior.spec.ts` |                0 | 16 passed，新增资源请求后可见、缺轮不部分写入及保存中选择事件无效。                    |
| 受影响 ESLint、Prettier                                                                |                0 | 组件与测试静态检查通过。                                                               |
| `npm run type-check`                                                                   | 初次 1，修正后 0 | 首次测试断言对 `get()` 返回类型误用 `.exists()`；改为直接 `get()` 后通过，非产品缺陷。 |

组件测试证明交互逻辑，不证明小程序真实 picker、滚动或冻结渲染；这些仍需 W8 在正确 Demo 目录实际操作。此处不改服务端/API schema、迁移或 Demo 业务规则；回退仅撤销本次组件状态和对应测试。完整前端覆盖率门禁仍沿用此前失败快照，待 W8 集中复核。

随后显式 `VITE_APP_MODE=demo` 的 watcher 输出 `Build complete. Watching for changes...`；`wechatide.cmd` 对 `dist/dev/mp-weixin` 的打开、模拟器刷新和 `npm run test:mp:doctor` 均退出 0，SDK `3.16.3`。本轮没有在工具里完成子组件 picker 的真实选择；既有自动化对该子组件返回 `no such element`，不重复相同失败调用或截图。此项仍为 W8 的实际交互/可见状态待验收，不能由编译与 doctor 代替。

### 2026-09-26 后续：W2 旧反馈写入口收敛

服务端原本只拒绝 v7 课堂通过旧入口 `task_published`，仍允许 `feedback_only` 和 `closed` 新写入，与整包审阅一次发布的规则冲突。现 v7 课堂三种旧动作均返回 `STATE_CONFLICT` 409；Demo 仓储同步拒绝，不再新建旧反馈、通知或关闭诊断。既有同键回执仍按原有幂等逻辑只读返回；历史记录与 v3–v6 只读展示不清理。未改路由形状、DTO、数据库或迁移。

| 检查                                                                                                                                                                     | 退出码 | 结果                                                                 |
| ------------------------------------------------------------------------------------------------------------------------------------------------------------------------ | -----: | -------------------------------------------------------------------- |
| `npm run backend:test -- tests/test_t43_package_draft.py::test_package_api_uses_teacher_snapshot_scope_and_hides_other_owners tests/test_t21_teacher_pbl_feedback.py -q` |      0 | 4 passed；v7 三种旧动作均拒绝，草稿与旧反馈表不变；v6 兼容用例通过。 |
| `npm test -- src/features/pbl/infrastructure/demoPblRepository.spec.ts`                                                                                                  |      0 | 6 passed；Demo v7 三种旧动作拒绝且不写反馈。                         |
| `npm run type-check`、受影响 ESLint、Ruff                                                                                                                                |      0 | 类型和静态检查通过。                                                 |

误试的 `npm run test:unit` 退出 1，原因是仓库无此脚本；已改用 `npm test -- ...` 成功。这里没有重新运行全量覆盖率或真实工具内交互；W2 页面状态和 W8 小程序整包流程仍待执行。若需回退，仅恢复该旧写入口的新建逻辑与对应断言，不涉及数据删除。

显式 `VITE_APP_MODE=demo` watcher 输出 `Build complete. Watching for changes...`，工具对 `dist/dev/mp-weixin` 项目复用打开和 `simulator_refresh` 均成功。第一次紧接刷新执行 doctor 退出 1（模拟器运行时尚未响应），同一开发目录重试退出 0，URL 校验开启、SDK `3.16.3`；随后停止 watcher。旧反馈写入口在新版教师页面不可见，本轮没有新增可见状态，因此未重复截图；此证据只证明编译/工具连接，不替代 W8 的真实整包流程。

### 2026-09-26 后续：W3 教师个人题库本地边界

核对题库页面和 API/Demo adapter 后，在现有 Demo 题库场景中补入跨教师 GET、PUT、archive 负向断言及旧版本更新冲突断言。服务端隔离、去标识副本、同键幂等/异内容冲突、历史版本、归档以及题库编辑不回写已发布任务和报告已由既有后端组合测试覆盖；API adapter 和题库列表/详情页面行为用例也一并纳入本次定向复核。没有修改运行时代码、API/schema 或迁移。

| 检查                                                         |                   退出码 | 结果                                                                                   |
| ------------------------------------------------------------ | -----------------------: | -------------------------------------------------------------------------------------- |
| 四份题库/整包相关 Vitest spec                                |                        0 | 4 files / 24 tests passed；包括 API adapter、Demo 题库权限与版本、题库页面、整包审阅。 |
| `npm run backend:test -- tests/test_t43_question_bank.py -q` |                        0 | 2 passed；1 条既有 SQLite 外键排序警告。                                               |
| 受影响 ESLint 与 Prettier                                    | 初次格式检查 1，修正后 0 | 测试文件按仓库格式化后静态检查通过。                                                   |

W3 仓库内代码证据闭合。题库真实小程序路径（入口、筛选、保存新版本、归档、返回）并入 W8 一次操作；本轮未重跑全量测试、覆盖率或 DevTools，也没有新增截图。

### 2026-09-26 后续：计划收敛与 C1 四项执行缺口

根规则明确小改动只做定向检查，全量测试安排在阶段集成/发布检查点；不降低安全和覆盖率门槛。第08/11册只保留剩余动作，已完成项移入 `completed-summary.md`，原文件保存在 deliveries 历史快照中。第05册明确当前微训练只从已验证可见 text 评分，完整原请求仍用于幂等比对。

修复四项已确认问题：Demo 病例前置顺序只计已激活任务（与提交一致）；课堂47加入教师进度 roster；独立病例 context 验证本人实际 attempt 后才返回非课堂；API 微训练评分不再采纳正文外额外字段。病例顺序提取为一个领域函数，避免两处规则漂移。没有改变公开 DTO/schema、数据库模型或迁移，也没有重生成契约。

| 检查                                                                                                                                                        | 退出码 | 结果                                                                      |
| ----------------------------------------------------------------------------------------------------------------------------------------------------------- | -----: | ------------------------------------------------------------------------- |
| `npm test -- src/features/learning/domain/classroomTaskOrder.spec.ts src/features/learning/infrastructure/demoLearningRepository.classroomPackages.spec.ts` |      0 | 2 files / 6 tests；跳过题不阻塞、激活题仍阻塞、课堂47进度和独立病例越权。 |
| `npm run backend:test -- tests/test_t43_classroom_case_callback.py::test_micro_drill_scores_only_the_visible_text_and_keeps_the_original_retry_payload -q`  |      0 | 1 passed；额外关键字不提分，原请求幂等保持。                              |
| 类型、受影响 ESLint/Ruff/格式、前后端边界                                                                                                                   |      0 | 前端204实现文件、后端9模块通过。                                          |
| `npm run contract:check`                                                                                                                                    |      0 | 临时目录核对，无源契约改写。                                              |
| 显式 Demo watcher、项目打开/刷新、doctor                                                                                                                    |      0 | `dist/dev/mp-weixin`，SDK3.16.3；watcher 输出完整编译。                   |
| 文档格式、相对链接、工程 skill 两项自检及范围内 diff check                                                                                                  |      0 | 计划门禁时36条相对链接有效；纯文档整理未跑业务全量。                      |

真实子组件交互与完整师生路径仍待 W8；没有新增截图，不以 doctor 替代交互/渲染结论。W4 既有仓库定向验证另有后端12项、前端4文件21项通过，仅作本地证据，不称真实受管库演练。回退只撤销上述局部代码/断言；不删除业务数据、不执行数据库回退。

### 2026-09-26 后续：C2 上海日期及空窗分页边界

在已有报告统计集成用例补入上海午夜首/尾微秒、前后相邻日排除、报告详情末尾分页总数不变、空时间窗保留学生及无结果口径。不改变运行时代码、Demo、schema 或数据库。

`npm run backend:test -- tests/test_t43_report_analytics.py::test_teacher_analytics_only_uses_terminal_report_and_shanghai_day -q` 退出0：1 passed（5.07秒）。此前 PowerShell 对通配路径直接 rg 以及读取误记文件名退出1，均为只读路径查询错误，改用目录加 glob 与实际 `test_t43_report_analytics.py` 后正常；没有数据影响。小程序返回/渲染和 Demo 日期同态仍保留待办，未重跑全量。

继续核 Demo 发现 `isInPeriod` 截取 UTC 日期会误计上海凌晨，先更新本册方案并通过格式/skill检查后改为时间戳加8小时取上海日期。新增同一组 UTC 边界同时核 overview/student/progress，`npm test -- src/features/analytics/infrastructure/classroomReports.spec.ts` 退出0（5 tests）；受影响 ESLint、`npm run type-check`、Ruff和范围内 diff check 均退出0。计划初次格式检查提示警告，格式化后修正，不改变产品合同。

复用显式 Demo watcher 完成增量编译。首次 CLI 误用 `--client` 返回 `ok:false/missing_client`（虽进程退出0，记录为操作失败），改用 `-c Codex` 后 `simulator_refresh` 返回 `ok:true/success:true`、退出0。未通过直接业务方法模拟操作，未新增近似截图；真实日期控件切换留在 W8。回退仅撤销日期投影与其定向断言，无数据库变化。

### 2026-09-26 后续：C2 非法日期同态与 API 读取证据

Demo 日期解析先验证结束日，再推导默认起始日，拒绝 JS 自动归一化的不存在日期；日期格式、倒序和366天跨度统一返回 `INVALID_DATE_RANGE`。先在第11册记录差异与方案，格式和工程skill两项自检通过后实施；完成后从待办移入摘要。不改服务端行为、公开接口/schema、数据库或生成物。

| 检查                                                                                                                      |                    退出码 | 结果                                                                                                                               |
| ------------------------------------------------------------------------------------------------------------------------- | ------------------------: | ---------------------------------------------------------------------------------------------------------------------------------- |
| `npm test -- src/features/analytics/infrastructure/classroomReports.spec.ts`                                              |                         0 | 10 tests，包含5种非法范围和上海日边界。                                                                                            |
| `npm run backend:test -- tests/test_t43_report_analytics.py::test_teacher_report_period_rejects_invalid_calendar_days -q` |                         0 | 5 passed，4条既有SQLite FK排序警告。                                                                                               |
| `npm test -- src/features/analytics/infrastructure/apiClassroomReports.spec.ts`                                           |                         0 | 5 tests；实际传入的schema解析响应，覆盖六个新读取方法的参数与映射、旧来源拒绝和服务端错误原样传播。                                |
| 受影响 ESLint、Ruff、`npm run type-check`                                                                                 | 类型初次1，修正后0；其他0 | 新测试误把仅响应状态 report_unavailable 当成公开筛选参数；依既有合同改为无筛选读取，该暂缺状态仍作响应断言，不扩张运行时公开能力。 |
| 显式 Demo watcher + `simulator_refresh -c Codex`                                                                          |                         0 | 正确开发目录完整编译、刷新 success；只读currentPage定位到登录页，无完整业务操作或新增截图。                                        |

后续全局覆盖率继续按C3/C4集中检查，不把新增5项adapter用例称为全局达标。回退仅涉及 Demo 日期验证函数和新增局部测试，无数据删除或DB操作。真实日期切换、分页返回、发布作答和报告链路仍开放。

### 2026-09-26 后续：综合详情收尾及学情检查点

修正综合详情加载更多使用已显示 `detail.period`，日期草稿未提交时不混入新范围报告。该页新增空窗、首次失败重试、追加失败保持可查看/重试同offset、无效链接同班返回及日期草稿分支，共9项通过。当前使用的 `TeacherClassroomReportAnalytics.vue` 新增6项真实挂载行为：空结果、进度分离、选班前不读学生、无报告学生可进入详情、分页/重试、切班丢弃旧响应和目标分离。两文件集中15项通过，ESLint及类型检查退出0。仅一处页面内部参数来源变化，无DTO、API、数据库或装配修改。

本阶段稳定后集中运行一次 `npm run test:coverage`，退出1：72.02%行/statement、62.99%函数、77.6%分支，仍低于原门槛。最新lcov用于下一批定位，不重复全量。读取Vitest历史results cache发现已不存在的旧失败路径，尝试该路径定向执行退出1（No test files found）；随后确认缓存包含历史条目，不能据其推断本次测试失败数量，不用旧cache作验收证据。

随后新增学生学情首页4项实际挂载用例，`npm test -- src/pages/student/insights/index.behavior.spec.ts` 退出0：空记录入口、读取失败重试、缺掌握度/薄弱点如实显示、报告和任务分别导航、角色拒绝不读取。此增量尚未更新全量覆盖率，不宣称达到门槛。DOM环境提示原生picker/scroll-view无法解析的既有局限，与小程序渲染证据分开记录。

显式Demo watcher完整编译，普通工具刷新成功。教师按钮首次tap超时（CLI退出0但ok:false），核doctor和当前页后，使用wait-for-selector重试成功，真实进入教师首页；SDK3.16.3、URL校验开启。只读query确认页面根无button、子组件导航控件存在于当前编译WXML，但跨组件选择器未返回元素，未setData/调业务方法/截系统画面。已请求用户在当前工具手动进入PBL诊断页，以继续实际流程；并未将工具限制当作未安装。无新增重复截图，仍未验收整包发布和作答。

回退仅撤销本轮分页参数来源与新增行为断言，不动用户其他改动或业务数据。后端全套、迁移、生产构建和秘密扫描未重复执行，留在最终集中检查点。

### 2026-09-26 后续：人工协助90003发布与当次报告读取

用户在工具内进入PBL并人工完成审阅发布，随后协助进入学生任务卡。自动化仅用受支持真实身份tap、导航、元素读取和内部截图，无业务方法或data修改。90003实际发布后页面显示“任务已发布”、固定演示学生及冻结版本；学生首页仅一张课堂43卡（2项），任务包43001显示2/2完成、已达标与最终报告。未直接取证两次作答和部分完成边界，不能倒推已验证；其他二轮/病例场景仍开放。

教师经CLI正常深链到班级1/课堂43进度，真实tap `.report-link` 进入报告143001；检查目标100分、首轮已评价、未激活题不计未完成及本课堂报告边界。同班学生综合详情显示完成1节/达标1节/100%，知识按1份报告计数，不按两道题或目标重复计数。综合详情目前是合法深链读取，尚不能证明学情列表入口/筛选返回。

当次已审阅截图（528×1142，均内部通道临时文件）：

| 状态              | 文件                                                                                      |
| ----------------- | ----------------------------------------------------------------------------------------- |
| PBL课堂首页       | `C:\Users\adj\AppData\Local\Temp\wechatide-simulator-screenshot-1790404680370-tokn7f.jpg` |
| 90003草稿首屏     | `C:\Users\adj\AppData\Local\Temp\wechatide-simulator-screenshot-1790404740663-qhhrh5.jpg` |
| 90003发布冻结说明 | `C:\Users\adj\AppData\Local\Temp\wechatide-simulator-screenshot-1790404915290-j5ebt3.jpg` |
| 学生首页课堂卡    | `C:\Users\adj\AppData\Local\Temp\wechatide-simulator-screenshot-1790404994118-75eevs.jpg` |
| 学生包43001终态   | `C:\Users\adj\AppData\Local\Temp\wechatide-simulator-screenshot-1790405078960-1vxruh.jpg` |
| 教师课堂43进度    | `C:\Users\adj\AppData\Local\Temp\wechatide-simulator-screenshot-1790405166664-imqnc6.jpg` |
| 本课报告143001    | `C:\Users\adj\AppData\Local\Temp\wechatide-simulator-screenshot-1790405180764-7iafqb.jpg` |
| 学生综合详情      | `C:\Users\adj\AppData\Local\Temp\wechatide-simulator-screenshot-1790405286418-ari49g.jpg` |

用户发布后首次截图发现已返回原PBL首页（`1790404893726-rpy3u9.jpg`），该重复首页不作为发布证据；重新进入详情才取得冻结状态。报告截图覆盖目标/历史/边界，但首屏结果总览尚未取证。CLI多参数URL直接包含&曾被batch解释（整体退出1），保留嵌入双引号后已由currentPage确认正确classId/sessionId。进度nth-child筛选tap返回success，但实际仍选“全部”；空态读取一次no such element、受支持等待超时，已记失败且停止重试，不以工具success冒充真实筛选通过。

这批操作未刷新编译或清空Demo数据；共用当前显式watcher和SDK3.16.3。截图仅为合成演示、无真实学生回答或生产教学证据。

### 2026-09-26 后续：后端完整检查结束与学生详情测试

本轮集中 `npm run backend:check` 已完整结束，退出0：Ruff通过、334 passed、333 warnings、88.01%覆盖率，耗时549.09秒。达到原85%门槛，替代322项旧快照；未修改门槛。无需为随后仅新增前端测试重复后端全套。

新增 `src/pages/student/insights/detail.behavior.spec.ts`，定向用例现为6项通过：无效深链/角色拒绝不读取证据、私人和空任务真实展示并正确导航、对话读取失败不遮挡报告、报告失败重试，以及带两轮目标/任务/反馈/对话/时间线的详情展示。DOM原生scroll-view解析警告不作为小程序证据。

教师题库列表行为再增加3项真实挂载测试，定向 `npm test -- src/pages/teacher/question-bank/question-bank.behavior.spec.ts` 退出0（9 tests）：搜索两字段trim并从offset0读取、切换归档状态后正确呈现状态专属空态、追加页失败保留原列表且重试重新加载第一页。仅测试变化，未计入全局覆盖率。页面已有编辑/归档权限、版本及确认测试，未重做。

继续使用同一 Demo watcher，受支持深链打开 `/pages/teacher/question-bank/index`；当次内部截图 `C:\Users\adj\AppData\Local\Temp\wechatide-simulator-screenshot-1790405873816-dmn9v3.jpg` 已审阅。528×1142 页面正确显示教师个人题库、搜索/知识点/题型筛选及“不可组卷或面向全班发布”边界；一条副本标为 `Demo 合成状态（非专家签署）`，没有真实专家审核暗示。页面由深链到达，只证明该页渲染，不证明教师菜单入口。

自动 tap `.status-tabs button:nth-of-type(2)` 曾返回success但页面仍在“在用”，不作通过证据。用户从真实教师入口进入后手动点“已归档”，CLI读取活动tab为“已归档”、结果标题为“已归档题目0道”、空态为“暂无归档题目。”，真实筛选通过。当次变化状态内部截图 `C:\Users\adj\AppData\Local\Temp\wechatide-simulator-screenshot-1790406866410-4icgj1.jpg` 已审阅；详情、编辑、归档操作仍待验收。

按用户协助操作，先从题库页返回，再经教师页面实际入口进入个人题库；用户确认“已进入”，CLI currentPage 当前为 `/pages/teacher/question-bank/index?status=active`，人工菜单入口已确认。没有再截取与前一张同状态截图相同的画面。

### 2026-09-26 后续：PBL 页面边界用例与局部覆盖

新增 `src/pages/student/pbl/pbl.behavior.spec.ts` 四项真实挂载测试：无题目时自主研讨私有提示、选点限制、创建失败重试沿用同一会话标识；消息失败时保留文字并以同一消息ID/回应方式重试；完成后续问保留私人提示且不新建诊断；新建页取消并切换已有会话/填充参考写法。定向测试通过（4 tests）。首次使用单行`input` stub无法表达多行草稿，经核对ChatComposer合同后改为`textarea` stub；覆盖实际multiline输入，不改运行时代码。

连同学生详情6项、题库页9项，三份定向 spec 共19 tests 全部通过。局部覆盖命令只纳入四个相关页面，Vitest汇总为73.23%行/语句、78.90%分支、75%函数，命令因仓库固定全局阈值套用局部集合而退出1；页面分项为 PBL 39.85%行/79.22%分支/61.53%函数、学生详情96.88%/81.19%/83.33%、题库列表93.56%/87.93%/83.33%、题库详情88.37%/69.89%/81.25%。这不是全局覆盖率或全局门槛结论；PBL页仍有大量会话分支未覆盖，C3继续保持开放。没有更改阈值或 include/exclude。受影响 ESLint 与最终 `npm run type-check` 均退出0（一次初始类型检查曾报 textarea元素类型推断错误，按现有测试写法补显式DOM类型后通过）。

学生详情及题库两页定向合计15项测试通过。限定三个运行页的覆盖率检查显示：学生详情96.88%行、81.19%分支、83.33%函数；题库列表93.56%行、87.93%分支、83.33%函数；题库详情88.37%行、69.89%分支、81.25%函数。`npm test -- --coverage --coverage.include=... <两个相关spec>` 退出1，因为仓库全局阈值仍套用于这个局部覆盖率集合（82.51%/63.04%/74.20%），不代表这15项测试失败，也不代表全局门槛；没有改阈值。受影响 ESLint 和 `npm run type-check` 均退出0。下次全局检查仍安排在C3稳定后。

### 2026-09-26 后续：题库合成副本保存与归档

用户经教师真实菜单进入个人题库并完成该唯一 Demo 合成副本的编辑保存，确认回答为“已保存”；工具详情页标题显示追加的“T43”标记。随后用户确认该副本“已经归档成功”。因此题库副本编辑保存与归档操作均记为用户确认完成，不代表专家医学审核；版本号、保存后的医学状态及归档只读详情字段未独立读取，但不再据此要求重复操作。整个操作不触及课堂正式任务或最终报告。此项是 Demo 手工交互，本次未改运行代码、未增加测试、未运行全量门禁。

### 2026-09-26 后续：学生 PBL 定向行为覆盖

在既有四项真实挂载用例基础上，新增入口 starter/知识点恢复、研讨加载失败后由页面重试、无效 dialogue 深链显式阻止误开新会话三项行为测试。`npm test -- src/pages/student/pbl/pbl.behavior.spec.ts` 退出0（1 file / 7 tests）；同文件 ESLint 退出0。Vue 测试环境仍提示小程序 `scroll-view`/文本 selection 原生元素未解析的既有警告；这些不是渲染证据。未改业务代码、未运行全局覆盖或全量门禁；C3整体覆盖率仍待稳定后集中运行。

### 2026-09-26 后续：已发布正式任务入口回归

在学生 PBL 行为 spec 中新增一项：完成后的研讨从 submission 返回 `teacherStatus=task_published` 时，点击“查看历史正式任务”必须使用该记录的 `planId` 导航。`npm test -- src/pages/student/pbl/pbl.behavior.spec.ts` 退出0（1 file / 8 tests），同文件 ESLint 退出0。仅增加前端行为测试，未改业务逻辑；未运行全局覆盖率或全量门禁，沿用稳定检查点策略。

### 2026-09-26 后续：Demo 任务包发布冻结对照

在 `demoLearningRepository.classroomPackages.spec.ts` 的整包生命周期用例中新增两条断言：旧草稿版本保存必须冲突且不改变当前草稿；发布后编辑正式题必须冲突且已发布题包完全不变。与后端 `test_save_checks_version_and_keeps_task_target_identity`、`test_publish_freezes_one_package_after_both_variants_are_approved` 对照，Demo 有意保留 `demo_approved` 合成医学状态，不模拟专家签署。定向命令 `npm test -- src/features/learning/infrastructure/demoLearningRepository.classroomPackages.spec.ts` 退出0（1 file / 4 tests），同文件 ESLint 退出0。基于代码与现有测试关闭 W6 API/Demo 主要状态同态对照；真实页面仍按 W8 验收，本次未跑全量门禁。

### 2026-09-26 后续：课堂进度分页恢复与题库入库交互状态

新增 `pbl-progress.behavior.spec.ts` 用例，验证课堂进度追加页失败时保留已显示学生、重试仍请求原 offset，并成功追加下一页。`npm test -- src/pages/teacher/pbl-progress/pbl-progress.behavior.spec.ts` 退出0（1 file / 5 tests），同文件 ESLint 退出0。用户明确说明教师从诊断审阅页主动加入个人题库的交互此前已经测试；本轮不重复要求该动作，工作单将其移出未完成项。此记录依据用户确认，不声称本轮开发者工具重新观察；尚待实测的 W8 项目继续保留。

本轮更新后的计划/摘要和受影响 spec 执行 Prettier 检查及 `git diff --check` 均退出0。未运行全量测试或全局覆盖率。
