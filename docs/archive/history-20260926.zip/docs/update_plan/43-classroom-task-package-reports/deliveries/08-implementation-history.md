# 历史分步骤实施与交接（2026-09-26 归档）

本文件保留原 P0–P8 实施方案和历史快照，不是当前执行清单。当前只执行[未完成步骤](../08-implementation-steps.md)和[剩余工作单](../11-remaining-work-handoff.md)，已完成摘要和命令见本目录中的交付记录。

`0032` 后完整后端门禁已通过：322 passed、87.78%。前端 83 files/411 tests 通过但覆盖率命令退出 1。开发者工具 CLI 和 doctor 已通过，T43 页面真实交互与截图仍待完成。下文各阶段内带日期的旧续跑记录仅作历史证据，不覆盖此处当前状态。

## P0 接手与计划门禁

阅读01–10及根规则；记录实际分支、HEAD、工作树状态和目标哈希。核查路径、现有接口和迁移head。验证计划格式、链接、尾随空白和工程self-check。出口：无未决产品选择，既有改动已辨认；文档检查通过。冲突不可判定归属时停止相关文件编辑。

## P1 数据模型和纯规则

实现包/题目/报告/题库版本/回执及迁移，扩展source_type；建立纯目标覆盖、两轮激活、最终报告组装规则。先用受管fixture验证唯一性、并发版本与终态；引入跨模块public port而非ORM穿透。

出口：空升级/降级、非空拒降级、旧数据保留通过；一个student/session只能一包。先运行backend:test:safety和backend:test:migrations，再领域测试及后端边界检查。

## P2 v7诊断与两轮草稿

更新provider schema、checked gateway、Coze请求/解析、开发provider和测试stub。无薄弱点路径完成且不造卡。实现可重试草稿构建及资源医学状态验证，保持私人续问隔离。补充待审核客观资源的医学审核适配，医学权限仍独立。

出口：identified_gaps/no_clear_gaps/insufficient/unavailable四类均有测试；两轮资源实际可预览，缺资源只阻塞草稿。真实Coze不在本地测试中调用。

## P3 集中发布和教师题库

实现整包GET/PUT/publish及版本/摘要确认、固定学生范围、一次事务和通知；关闭单建议发布旁路。实现题库入库预览、幂等、本人查询、编辑revision和归档。保存反馈与发布反馈使用同一课堂诊断身份。

题目选择使用软排除：新增 `included_in_package`，PUT 仍要求提交全部题目，按 `stable_key` 整对切换 cycle 1/2；不得物理删除，因为题库 revision/入库回执外键依赖来源题目行。发布、医学新提交和学生任务仅消费 included 项；题目原文和入库来源追溯保留。迁移 `20260924_0032` 为历史题目默认 true；覆盖校验仍强制每个课堂目标/推理目标至少保留一组完整双轮题。变更纳入草稿 digest 并清除旧整包确认，发布后冻结。排除项的旧资源版本不阻塞保存；新选择的资源引用不会写入排除项，既有引用保留，重新纳入仍验证当前授权、目标、版本和 digest。

出口：同键重试、异payload、双键并发、跨班/跨学生/跨教师、医学状态变化、事务失败注入均覆盖；无部分发布或重复通知。

2026-09-25 状态复核：v7 课堂诊断详情通过 `TeacherClassroomPackageReview` 执行 ensure → GET/PUT → 必要医学审核提交 → 整包发布；固定诊断学生，不显示全班/改接收者控件。v3–v6 历史分支只展示诊断记录，不加载同班名单、不显示反馈编辑、建议编辑、关闭或发布控件。教师题库已接入 content public、API/Demo adapter、内容入口、列表和详情编辑/归档。P3 主要代码已存在；仍须按 W1/W2/W3 复核资源版本、冲突保留输入、并发/事务、题库权限和 API/Demo 同态测试，未达到这些出口前不标 P3 完成。

2026-09-25 W2 增量：旧 suggestion edit/adopt API 对 v7 新课堂与 v3–v6 历史均返回 409；v7 的旧 `task_published` feedback 返回整包发布冲突，v3–v6 的新 feedback/close 返回历史只读冲突。Demo 相同拒绝。既有完全相同的 feedback 幂等请求仍可返回原回执。定向后端 9 项、前端 19 项通过；页面 Demo watcher 构建通过。Developer Tools 环境缺少 `WECHATIDE_CLI_PATH`，普通编译、真实点按与截图仍未验收。

## P4 学生任务执行与最终报告

学习首页改为一课堂一包，节点只在包内分组；实现新任务接口与病例回调幂等。独立病例反馈改名，停止新自动个性化正式计划。评价完成事务同步保存最终报告；新增只读最终报告查询及受控幂等修复工具。修复工具已局部写入并通过定向测试，真实受管开发库备份/恢复演练、病例五阶段 API 全流程及页面验收仍未完成。

出口：单题完成不生成报告；首轮通过/第二轮通过/第二轮耗尽分别一份报告；重试无重复；inactive不计分母；病例已提交而回调失败可恢复。

2026-09-24 一项真实 HTTP 五阶段病例至报告定向用例通过；它只覆盖该用例执行到的分支，仍须单独断言首轮达标、二轮达标、二轮耗尽、回调失败重放、并发及报告写入故障。后续新增测试确认病例完成但同轮其他 active 题仍 pending 时不生成报告，且补充 Demo 缺目标维度和临时读取失败的幂等重放断言。报告修复命令的 pytest SQLite 测试不等于真实受管库备份/恢复演练，详见第11册 W4。

学生病例页面现读取 attempt 的服务端 classroom context；URL `packageId` 只作为失败时返回提示，完成后重新读取本人任务包。独立病例仍回病例列表并保留学生训练分析，不创建教师报告。Demo `startClassroomCaseTask` 已通过 bootstrap 注入的 training port 启动病例 attempt，并按 `(student, task)` 幂等；本人 attempt 来源可用于中断返回，独立病例仍 false/null，异学生读取为 404。病例 assessment 对目标 dimension 评分后仅回写包任务结果，缺证据视为未达标；刷新 reconciler 幂等，首轮失败只激活目标并在第二轮终结后生成唯一包报告。最终报告构建异常回滚、病例报告等待同轮其他 active 任务、缺目标维度与 assessment 读取错误后重放均有定向测试。最新完整 `backend:check` 已于 2026-09-25 退出 0（316 passed / 88.26%），包括新增后端边界测试。真实受管库修复工具备份/恢复演练仍未做。

2026-09-25 P4/A23 增量：API/Demo 顺序合同对照发现，API 会拒绝学生先提交同一轮中位置靠后的题目，而 Demo 之前允许。Demo 现检查同包、同轮、更早且已激活的任务是否完成或跳过；第二轮只检查实际激活的目标。新增 Demo 与 API 回归用例，断言提前提交返回冲突且任务仍 pending，随后可正常提交第一题。定向后端 1 项、Demo 课堂包 3 项、类型检查和 ESLint 通过。该证据只关闭“同轮不可越序提交”这一具体差异，不代表 A23 全部 API/Demo 状态已对齐。

2026-09-25 P4/A23 增量：按第04/06册规则，discussion 任务只校验 1–4000 字文本并记录证据，不产生分数；首轮有其他失败目标时，第二轮 discussion 仍按既有规则激活。API 已符合该规则，Demo 之前错误地按客观题处理且把 null 分数判为失败。Demo 现保留 null score/null threshold，以是否有已验证提交证据判定 discussion，并在报告检查中显示 evidence_present=true、passed=true。Demo 90005 增加正式讨论验证题；后续新增隔离 fixture 90007，覆盖首轮其他目标失败时只激活目标变式并同时激活 discussion 二轮变式，二轮两项提交后才形成报告。该具体生命周期分支已有定向回归；A23 其余 API/Demo 权限、错误和资源变更矩阵仍须复核。

## P5 教师学情与页面通路

analytics 后端已接入 FinalReportReadPort 并提供 v2 结果/进度计数和逐学生课堂进度。前端已有学情工作区/学生综合详情、PBL 本课报告和课堂进度入口；Demo analytics 从 learning 持有的包/报告读模型计算，不再固定为空结果。v7 教师诊断详情已切换整包审阅，内容页已有题库入口。P5 仍需逐消费者搜索 `getTeacherPblFollowUps`、旧 `task_published`、旧病例 analytics 和历史 `planId`，核验新旧版本分流、分页/返回/局部失败/缓存失效、报告缺失阻断和身份切换。真实小程序筛选、报告返回与学情导航尚未验收；组件测试或 WXML 不等于实际渲染通过。

出口：所有页面查同一身份和统计口径，无旧 evidence 混计；进行中及未发布学生仍能在课堂进度看到，且不会出现在巩固结果中。完成页面及导航行为测试。当前有后端计数、逐学生进度接口/局部页、学情与 PBL 报告局部前端合同/导航定向证据，但逐学生进度真实交互、完整 Demo 和有报告状态未达到出口。

2026-09-24 静态审计：`getTeacherPblFollowUps` 仍存在于旧 port/API/Demo repository，并被旧 `TeacherPblFollowUps.vue`、旧测试及 `TeacherPblClassrooms.vue` 中未挂接的阶段看板函数引用；官方 PBL 首页实际“巩固跟进”由 `TeacherPblHome.vue` 通过最终报告 public API 加载，`TeacherPblClassrooms` 当前仅以 `create-only` 挂载，因此旧按钮/回访逻辑未进入当前正式路径。`task_published` 可继续作为既有 v6/历史工作项状态展示，但旧 suggestion edit/adopt 和单题发布写接口已拒绝新写；历史诊断官方详情只读，v3–v6 新 feedback/close 也拒绝。v7 页面由整包组件处理。`createLearningPlan` 仍留在 learning legacy public/API adapter/旧兼容测试，不在学生课堂包页面或病例训练页面发起；独立病例保留学生私有分析，不创建教师正式计划。学生历史详情中的旧 status 文案仅渲染已有个人历史。以上 consumer 暂保留兼容，不机械删除；后续任何新导航不得重新暴露旧路径。教师学情的学生综合页保留在“学情”，PBL 巩固只显示本课报告；具体返回、分页、缓存、深链场景见第11册 W5。真实操作仍待 DevTools。

## P6 契约、Demo与历史转换

接口已进入 OpenAPI/TypeScript；Zod、mapper、public、wiring、题库/报告 Demo adapter 已有接线。P6 Demo 现覆盖首轮直接达标、失败后目标变式、二轮耗尽、病例回包、逾期、报告暂不可用故障 fixture 和空/active/archived 题库；并通过 task-ID 幂等和身份隔离断言。剩余工作是复核全部 API/Demo 状态映射、错误恢复及每个可见状态的 UI 路径，补齐 report-write rollback。T43 历史策略不是转换：第07册 `transition_t43_packages.py` 为只读审计器，`--apply` 在打开数据库前拒绝并以非零状态退出，这是批准的安全策略，不在此实现迁移。

出口：contract:check、API/Demo 合同与迁移/只读审计测试通过；旧数据不丢失、不冒充新报告。只验证历史审计只读、无敏感明细泄漏、`--apply` 稳定拒绝；不转换旧计划。契约与 Demo 应随前面各阶段持续更新，本阶段是最后完整校验。

## P7 整体验证

按第09册运行格式、Lint、类型、定向与全量测试、边界、契约、后端安全/迁移和构建。本次跨模块/共享导航改动触发相关核心闭环回归；不沿用已禁用WebSocket脚本。启动显式Demo watcher，规定目录普通编译，真实完成教师审阅入库发布、学生两轮、教师报告与学情通路。

2026-09-25 最新完整门禁快照：全量 `npm run backend:check` 退出 0（318 passed，88.70% backend coverage，Ruff 通过）；数据库安全 14 passed、迁移 22 passed，T43 病例/蓝图资源专项 14 passed。最新前端 `npm run test:coverage` 为 83 files/411 tests 全通过，但命令因全局 coverage 退出 1（lines/statements 71.44%、functions 60.71%、branches 76.51%，门槛 85%/85%/80%）；不得调低门槛掩盖缺口。学生首页、任务包、病例训练、病例分析报告身份隔离行为用例 12 项通过；`npm run lint`、`npm run type-check`、前端边界检查退出 0。后端仅改变内部内容 digest/评分资源校验，没有 API/schema/OpenAPI/DB schema/迁移字段变化；本次无需生成合同或 Demo watcher。前端上一次显式 Demo watcher输出 `Build complete. Watching for changes...`，但 Developer Tools doctor 因未配置 `WECHATIDE_CLI_PATH` 退出 1；规定目录普通编译/真实交互/渲染仍未验收。secret scan 仍有历史指纹待安全责任人复核。逐命令证据见交付记录。

### 2026-09-25 后续：整包审阅与教师页面身份隔离

教师诊断详情复核发现组件在切换选中课堂时，未完成的草稿保存/失败、取回最新版、医学审核提交、发布后刷新及题库预览/入库回包可能继续更新新课堂页面。现在按诊断快照、会话、学生、班级的页面代次隔离请求；写回前再核对任务包 ID、版本、摘要和来源身份，卸载也废弃待处理响应。旧课堂已确认发起的题库写入不可取消，但其回包不再弹出旧上下文成功提示或污染新页面。教师工作区换账号时清空旧班级/待办并重建子页；诊断、课堂进度和报告路由失权时清空旧数据并忽略 pending 请求。五个教师页面套件 23 项行为测试通过。

此次最新全量前端 coverage 为 81 files / 405 tests 全通过，coverage gate exit 1（lines/statements 69.90%、functions 61.24%、branches 76.63%，未达 85%/85%/80%）。Lint、type-check、203 implementation files 前端边界、五个页面行为套件及 Prettier 检查通过；`npm run build:mp-weixin` exit 0。显式 Demo watcher 已按规则输出 `Build complete. Watching for changes...`，产物可查到教师失权提示和任务包身份校验；`npm run test:mp:doctor` exit 1（未设置 `WECHATIDE_CLI_PATH`），所以没有规定开发目录的微信开发者工具普通编译、真实 tap/input/scroll 或内部截图。没有改 API/schema/迁移，也未访问真实数据库或 Coze。完整命令与退出码见[实施进度记录](implementation-progress.md)。

出口：每项Pass/Fail/Unverified有证据；失败不关闭门禁。无法真实点选或截图则相关验收待办，不能把元素数据当渲染通过。

## P8 文档与交付

更新architecture/data-layer/frontend public/backend module-map/database/security/design等权威文档为真实已实现合同，根T43摘要准确取代旧规则。写各阶段交付、最终复验和回退。明确实际migration head，真实Coze/医学专家/生产/真机待验收范围。不提交推送，除非另有用户授权。

## 阶段交接格式

每阶段使用deliveries/template.md；列完成符号、生成物、命令、退出码和测试文件，给出下一阶段入口及剩余失败。不能仅写“后端完成”“测试全绿”。接手者复核当前工作树，不以先前执行者结论替代事实。

原建议文件名不构成必须命名合同。当前已有 `backend/tests/test_t43_package_draft.py`、`test_t43_question_bank.py`、`test_t43_migration.py` 等定向测试；接手者按实际文件和命令记录退出码。新增前端测试按 feature 与页面放相邻 spec，不得把拟建文件写入已执行命令记录。
