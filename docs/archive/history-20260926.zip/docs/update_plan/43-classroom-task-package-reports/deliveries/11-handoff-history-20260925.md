# T43 历史交接记录（2026-09-25）

本文件保留当时的执行快照，包含已被后续证据取代的工具和测试状态。当前事实与剩余步骤请以[现行交接单](../11-remaining-work-handoff.md)为准；“缺少 CLI”等表述只代表当时的终端状态。

核验日期：2026-09-25。目的：让下一执行者在**不重新决定产品规则**的前提下完成剩余实现。本册是工作树快照，不是功能验收证明；接手时先重查代码与测试，再更新本册的证据状态。以下“已写入”仅指当前工作树存在代码；“通过”须注明具体命令和时间；“未验收”不能推定为失败，也不能推定为通过。

## 一、先守住六条不可变边界

1. 教师创建的课堂 PBL 才产生教师诊断和正式任务包。自主研讨、完成后私人续问、普通答疑与独立病例不产生 T43 教师最终报告。
2. 正式任务身份是 `(student_id, classroom_session_id)`，一个学生一个课堂最多一个包；节点只是包内分组，跨课堂同节点绝不合并。首轮和第二轮所有变式都在发布前审阅；发布后不得追加必做题。
3. 发布动作只针对诊断对应学生，不能选择全班或其他学生。教学反馈可以为空；医学审核独立且必须满足发布时的资源版本/摘要检查。重复请求、超时重试、并发不能重复计划、通知或报告。
4. 首轮全部达标或第二轮结束都进入包终态并形成唯一最终报告。`completed` 与 `improved` 不同；第二轮未达标是 `needs_reinforcement`，未激活/跳过任务不算未完成。
5. 教师 PBL“巩固跟进”仅是**本课堂最终报告**；未发布、进行中、逾期、终态报告缺失由课堂进度承载。教师“学情”是**跨课堂学生综合学情**，只聚合有权班级的已完成包，不混入独立病例或旧证据。
6. 题库只归教师本人，入库必须由教师主动触发并去标识化；编辑题库副本不改冻结任务或报告。本期只有查看、筛选、编辑、归档，不组卷、不向全班发布。

如果拟议修改违反上述任一项，先停止并修订产品计划取得确认，不用旧流程或 Demo 假数据作为捷径。

## 二、当前可信基线与明确断点

工作树位于 `dev`、核验时 HEAD 为 `5c961ea`，有大量用户既有改动。T43 计划目录、部分代码和测试仍有未跟踪/暂存/未暂存状态；不能用 HEAD 覆盖工作树，不 `reset`、`clean`、恢复、删除或代提交。迁移单一 head `20260924_0032` 已写入，**没有证据表明任何真实开发、共享或生产数据库已应用**。

2026-09-25 后续增量：`classroom_package_items.included_in_package` 已把非必需候选的移除/恢复落成软排除，API/Demo teacher item DTO、PUT 和审阅组件同步；保存/发布拒绝半对选择与目标覆盖缺失，发布和医学新提交仅消费 included 项，题库来源行保留。随后发现过期审核资源曾阻止排除候选；现在排除项不会实时解析资源，新绑定不落库，既有来源保留，重新纳入仍校验当前授权/目标/版本/digest。新增后端草稿资源文件 15 项与 Demo 包生命周期 3 项通过；此前 package/migration 16 项、安全 14 项、迁移套件 22 项及 API/Demo/教师组件 27 项通过；类型检查、contract:check、定向 lint 通过。Demo watcher 完成 `dist/dev/mp-weixin` 构建；doctor 因缺 `WECHATIDE_CLI_PATH` 退出 1，故没有 DevTools 普通编译、tap/input/scroll 或截图。详细证据追加在实施进度记录，不能将这一增量视为关闭 W1–W8。

### 2026-09-25 最新续跑结果

此前两次用户要求收尾时的中断均作为历史记录保留；当前全量后端门禁已重新完整运行并退出 0：`backend:check` 318 passed、88.70% backend coverage。前端行为测试新增 6 个文件/16 项，覆盖教师整包审阅/发布确认、题库筛选请求竞态与副本版本生命周期、v7/v6 诊断路由、逐学生课堂进度状态/报告返回/状态筛选、学生任务包分组与提交后统一报告、学情详情报告范围/分页。题库筛选测试实际发现并修复旧请求 pending 时筛选切换被忽略的问题；现在 reset 请求可 supersede 旧请求，request token 阻止旧结果覆盖新结果。之后新增的评分资源核验全量后端门禁仍为 318 passed / 88.70%；病例/蓝图资源定向测试 14 passed。

此前 `npm run test:coverage` 的 79 files / 390 tests 全通过快照已被后续结果取代。当前全量为 83 files / 411 tests 全通过，但 coverage 命令 exit 1：lines/statements 71.44%、functions 60.71%、branches 76.51%，低于 85%/85%/80% 全局门槛。Lint、type-check、前端边界检查通过。学生身份隔离四页新增/扩展行为用例 12 项通过。DevTools doctor 因缺少 `WECHATIDE_CLI_PATH`/`wechatide.cmd` 仍不可用；没有规定目录普通编译、真实点击/输入/滚动或截图审阅。安全扫描历史指纹复核未关闭。当前工作树不应用任何迁移、不连接真实数据库/Coze；受管开发库报告修复恢复演练、专家、PostgreSQL/生产、真机仍待验收。详细命令见[实施进度记录](implementation-progress.md)。

#### 当日后续增量复核

之后先运行 W4/W5 定向后端子集 36 passed，继而全部 12 个 T43 后端专项测试文件共 52 passed（测试清理阶段有 51 项 SQLAlchemy FK 排序警告）；6 个 Demo/API adapter 测试文件另有 13 项通过。学生课堂任务提交和教师学情分页刷新路径已修复两项请求竞态；两个页面行为测试文件共 8 项通过，覆盖教师账号切换时清除旧数据并阻止未完成请求回写。lint/type-check/前端边界/diff 均通过。显式 Demo watcher 编译了最新改动。提交未确认后答案与 request ID 固定，服务端刷新确认仍 pending 后可清除并编辑；学情换日期时旧分页 response/error/finally 不再写入新请求状态。最新 `npm run test:mp:doctor` 仍因缺少 `WECHATIDE_CLI_PATH` 退出 1；真实交互与截图没有执行。该次完整 coverage 为 78/375 tests 全通过但覆盖率门槛失败；后续重点仍是其他角色切换与局部失败、API/Demo 全合同、完整矩阵和外部门禁。

### 历史记录：2026-09-25 暂停时基线

2026-09-25 恢复任务后重启 `npm run backend:check`：Ruff 通过，pytest 已启动；用户要求本次收尾后在 pytest 汇总前 Ctrl-C，退出码 1。该次没有完整测试计数或覆盖率，不构成门禁通过；下一次必须从完整重跑开始。除上述续跑外，今天没有新增业务代码、迁移或 Demo 构建。

### 2026-09-25 当前已核实代码基线（取代下方旧表的“仍缺”列）

下方原表保留为先前接手快照，不再代表当前差距。当前代码事实以本段和最新[实施进度记录](implementation-progress.md)为准；执行者应再次运行只读核验。

| 领域                 | 当前工作树事实                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                | 剩余任务 / 不可误报项                                                                                                                                                                                                                                                                                                                                                                           |
| -------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| 模型、规则、迁移     | T43 包/任务/报告/题库模型、迁移 `20260923_0031` 与软排除迁移 `20260924_0032` 存在；当前迁移链工作树单一 head 为 `0032`。最新一次完整 `backend:check`（在新增 `0032` 前）为 318 passed / 88.70%；新增迁移后的 package/migration 定向 16 项、数据库安全 14 项、迁移套件 22 项通过。                                                                                                                                                                                                                             | 未对真实开发/共享/生产库运行迁移。PostgreSQL 与运营恢复流程仍外部待验收；本轮增量未重跑完整 `backend:check`。                                                                                                                                                                                                                                                                                   |
| 诊断、资源、教师整包 | 新课堂 v7、旧课堂 v6 固定兼容；整包 ensure/GET/PUT/医学提交/publish、两轮审核资源查询和版本核验已有后端路径。v7 详情走 `TeacherClassroomPackageReview`，固定来源学生；v3–v6 详情为只读历史，不加载同班名单或展示旧反馈/编辑/关闭/发布控件。旧 suggestion edit/adopt 写接口与单题发布返回 409；v3–v6 新 feedback/close 也返回 409，Demo 同态。                                                                                                                                                                 | 复核全部资源类别、两轮配对、审批状态变化、版本/摘要冲突、并发/回滚和其它 API/Demo 状态同态。真实 Coze v7 bot/workflow 和授权专家审核仍不能由 mock/单测证明；Developer Tools 页面普通编译与实际操作仍待验收。                                                                                                                                                                                    |
| 教师题库             | content public、API/Demo adapter、内容入口、列表/详情编辑归档及显式来源预览已存在。                                                                                                                                                                                                                                                                                                                                                                                                                           | 复核本人/跨教师隔离、来源去标识白名单、同源幂等、题库编辑不反写冻结任务；微信交互未验收。不增加组卷或班级发布。                                                                                                                                                                                                                                                                                 |
| 学生任务、病例、报告 | 学生课堂包列表/详情/提交、病例启动 API、服务端 attempt context、学生病例回包、终态报告读写和受控报告修复脚本存在。Demo 已注入 training port，按本人任务做幂等启动并把 assessment 仅回写到包内任务；同轮前序任务未完成时，API 与 Demo 均拒绝越序提交；discussion 文本提交在 Demo 记为无分学习证据。90007 定向生命周期测试已覆盖首轮目标失败后仅激活目标变式与 discussion 二轮，且必须提交完两项才生成唯一报告。学习首页、任务包详情、病例训练和病例分析报告现按学生身份隔离数据/请求；四页行为测试 12 项通过。 | 最终报告 builder 故障回滚与同提交标识重试测试已有定向证据；报告修复工具真实受管开发库 dry-run/备份恢复演练未做；病例 callback 与 API/Demo 全状态仍按故障矩阵复核。学生任务页实际交互未验收：角色入口 tap 成功，但页面导航工具的 `switchTab` 返回 `Uncaught [object Object]`，任务列表位于自定义组件内且元素选择器未命中；需在工具支持的人工点击/组件穿透路径下完成，而非重复重试同一 selector。 |
| 教师阅读与导航       | analytics v2 从最终报告统计；有 PBL 本课报告列表/详情、逐学生课堂进度、学情学生综合详情接线。新增行为测试覆盖进度状态、仅完成态可打开报告、上下文返回参数/分页、逾期筛选，以及日期范围切换时舍弃旧分页响应；学情分页状态现使用请求代次隔离。旧 plan 深链显示历史兼容提示；旧 follow-ups/status/API 路径已分类为 v6 或未挂接兼容。                                                                                                                                                                             | 局部失败、角色切换/缓存完整矩阵、返回筛选状态恢复及有数据/报告缺失的实交互仍需补。Developer Tools 连接/doctor 已通过；教师报告页面实际点击与渲染仍未验收。                                                                                                                                                                                                                                      |

| Demo / 合同 | Demo 有 `90003` 无薄弱点、`90004` 病例与微训练目标补强、`90005` 首轮达标、`90006` 二轮耗尽；覆盖微训练两轮资源选择/保存、文本评分及失败目标二轮激活、病例 task-id 启动幂等/学生隔离、逾期、报告暂不可用、题库空/active/archived 与 analytics 同步。软排除增量的 API/Demo/教师组件定向用例包含在 27 项通过中；contract generation/check 通过。 | API/Demo 每个错误、权限和资源变化分支的完整同态仍需逐项对照第09册。Demo 不证明真实授权/医学审核/AI/数据库。 |
| 历史兼容 | `transition_t43_packages.py` 已实现为只读聚合审计；`--apply` 故意拒绝。旧 `T43LegacyPlanMapping` 保留空表，不生成新包/报告/评分/通知。 | W7 的批准策略是只验证审计安全与稳定拒写，不实施旧数据转换。旧数据保留只读且排除新报告统计；如以后确需转换，另立计划。 |

### 2026-09-25 微信工具状态更正

曾将 doctor 的 `WECHATIDE_CLI_PATH` 报错误判为本机没有开发者工具。复核确认工具运行正常，实际原因是 Codex PowerShell 未继承该变量。按微信验收规范在当前进程传入已安装路径后，`open_project_window`、`simulator_refresh` 和 `npm run test:mp:doctor` 均退出 0；doctor 返回 SDK `3.16.3`。真实学生身份 tap 成功并进入学生端，但还没有走到 T43 课堂任务包或教师报告页面；这两条受影响流程的实际页面验收仍待完成。

历史注记（2026-09-24）：当时最近完整复测为后端 `backend:check` 315 passed / 88.26%、前端全量 355 passed。之后新增一项后端病例边界测试及 Demo 缺目标维度/读取失败重放测试均定向通过；随后用户要求暂停，后端全量复跑在汇总前中断。该中断已由本册上方 2026-09-25 续跑结果取代；详细历史和当前门禁见[实施进度记录](implementation-progress.md)。

### 历史接手表（已被上方当前复核基线取代；不要按“仍缺”列重复实施）

下表保留在本册仅用于解释 2026-09-24 早期接手判断。后续实现已关闭其中多项差距，例如整包诊断页面、审核资源查询、题库前端、病例服务端上下文、Demo 终态报告和历史只读审计。当前剩余项以“本轮复核基线”表和第08册状态为准。

| 领域          | 已在工作树观察到                                                                                                                                                                                         | 仍缺的最小闭环                                                                                                                                                             |
| ------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| 后端模型/规则 | 包、两轮任务、终态报告、题库、发布/回执、报告修复脚本和定向测试存在；最近一次固定代码后的后端全量为 `309 passed`                                                                                         | 真实已审核资源选择查询、旧数据受控转换、所有并发/故障/API 路径复验；全量结果不代表外部服务或 UI                                                                            |
| AI/诊断       | 新课堂 v7、旧课堂 v6 固定兼容与 no-clear-gaps 路径已有实现                                                                                                                                               | 真实 Coze v7 bot/workflow 契约、真实资源与医学版本联动、失败与重试的跨模块检查                                                                                             |
| 教师诊断页面  | `src/pages/teacher/pbl-diagnostic-detail/pbl-diagnostic-detail.vue` 仍调用旧 `getTeacherPblWorkItem` / `sendTeacherPblFeedback`，`TeacherPblWorkItemDetail.vue` 仍可选学生/全班并逐建议 `task_published` | 将该页面及 pbl public/仓储/API/Demo 合同接到整包 ensure → GET → PUT → 医审 → 发布；旧 v7 单题发布旁路移除，旧 v6 历史只读兼容                                              |
| 医学审核      | `backend/app/modules/content/api/medical_review.py` 有课堂客观题审核队列；包提交医学审核路由存在                                                                                                         | 第05册计划的 `GET /teacher/classroom-task-packages/{id}/reviewed-resources` 未在 PBL 路由查到；需实现/契约化并校验两轮资源归属、版本及授权；页面能读阻塞并进入合法审核入口 |
| 教师题库      | `backend/app/modules/content/api/question_bank.py` 有入库、列表、详情、更新、归档                                                                                                                        | `src/features/content/public.ts` 无题库 API；`src/pages.json` 无题库页。需补前端领域/adapter/Demo、内容入口、列表/详情/编辑/归档与权限状态                                 |
| 学生执行      | `src/pages/student/learning/classroom-package.vue` 与 learning public/API 已有包/提交/病例启动/本人报告局部接线                                                                                          | Demo 仍为空包；病例启动传出的 `packageId` 未被训练页读取，病例分析仍回旧病例列表并显示旧个性化计划按钮；真实学生完成态与终态报告未验收                                     |
| 教师阅读      | PBL 本课报告列表/详情、课堂逐学生进度、学情 v2 与综合详情已有局部页面和后端读口                                                                                                                          | 有数据流程、筛选/分页/返回/切换身份/缓存失效/缺报告状态及开发者工具真实交互未验收；旧消费者仍需逐一收敛                                                                    |
| Demo          | 报告/进度适配器诚实返回空结果，未把旧病例伪装成 T43 报告                                                                                                                                                 | 无诊断整包、可发布题库、两轮任务、终态报告的贯通种子和状态演示；API/Demo 同合同尚未成立                                                                                    |
| 历史转换      | 结构迁移与报告修复命令存在                                                                                                                                                                               | 第07册 `transition_t43_packages.py` 仅为计划文件，工作树未找到；旧 planId 目前是退役提示，转换映射/历史只读回访待实现或按明确不转换策略落实                                |

最近一项额外定向验证：`python -m pytest backend/tests/test_t43_classroom_case_callback.py::test_classroom_case_five_stage_api_completes_one_final_report -q`，退出码 0、`1 passed`。它覆盖一条真实 HTTP 病例五阶段至报告链，**不覆盖全部首轮/次轮分支、并发、故障注入、真实医学专家或生产数据**。该测试文件当时未跟踪；接手者先保护它，再核对全量回归。

## 三、按顺序实施的工作单

每张工作单完成后在 `implementation-progress.md` 追加日期、文件范围、实际命令/退出码、未通过项、下一步；不改写旧记录来伪造连续成功。接口/权限/迁移变更先补定向测试，前端变更同批更新 Demo 和页面行为测试。`docs/openapi.json` 与生成 TS 只通过生成命令改动。

### W0 重新确认接手基线与计划门禁

前置：只读 `git status --short`、分支/HEAD、`alembic heads` 或迁移链检查；阅读根规则及第01–10册、权威数据层/安全/微信验收文档。记录哪些 T43 文件是用户既有改动，不操作无关文件。核对第05册每个接口是否真在路由、Pydantic、OpenAPI、前端 public、Demo 各层存在。先运行**已有**定向检查并记录基线，不把此前的 `309/345 passed` 当成本轮复测。

出口：形成“已实现/待补/冲突”的短表及受影响文件清单；若实际产品事实与本计划冲突，先更新对应设计册，不在代码里临时另定方案。

### W1 复核发布资源与后端事务门禁（P2/P3；主要接口已实现）

当前事实：后端整包资源查询、草稿保存/医学提交/发布路径已在工作树存在并有定向测试。不要重复建立 `reviewed-resources` 端点。2026-09-25 续跑新增服务端目标绑定：病例审核 digest 纳入排序后的知识节点关联；病例重练与推理微训练的资源查询、保存和报告前医疗状态复核，均要求资源病例同时匹配诊断快照所属课堂 session 与题目主知识节点。PBL-owned package context port 提供权威病例 ID，不信任 PUT 中的资源 ID。微训练资源保存保留由病例审核蓝图决定的两轮题面及私有评分 criteria，编辑者不能自行改 rubric。定向 `test_t43_package_draft.py` 当前 15 passed；上一完整 `backend:check`（在软排除迁移前）318 passed、88.70%；新增迁移后 package/migration 定向 16 项、数据库安全 14 项、迁移套件 22 项通过。不要重复建立端点。Demo `90004` 已有微训练两轮资源选择/保存、文本评分及失败目标二轮激活的可复验 fixture；排除项对过期资源的保存边界也有 Demo 定向用例。仍需对照第09册逐项复核 API/Demo 错误、权限与资源变化分支。不得调用真实未受管数据库或真实 Coze；优先复核 `backend/app/modules/pbl/api/routes.py`、PBL package application/port、content public 医审端口与对应测试。资源列表必须限定诊断所属教师、本课堂目标、本题型、两轮成对、医学批准且版本/摘要有效；仅暴露教师合法可见摘要，不泄露隐藏病例。GET 不自动替换草稿；教师选择后 PUT 和最终发布事务都必须再次校验目标、版本、digest。若某资源类别不满足合同，先修订第05/06册并记录阻塞，不把待审资源说成已审。旧 `MedicalReview` 摘要不包含知识节点关联，升级后不会被静默重写或当作新算法下已审；它们须走正式复审流程才能用于新的课堂评分资源，seed 仅可按既有开发测试路径新增合成审阅记录。

2026-09-25 后续更新：Demo `90004` 的推理微训练两轮资源选择/保存、文本评分及失败目标二轮激活已纳入上述当前事实，生命周期定向测试 3 项通过。开放项是 API/Demo 完整错误、权限和资源变化分支的逐合同核对。

验证至少覆盖：资源已批准→可选→保存→发布；审批拒绝/过期/摘要或目录变化→明确 `blocking_issues`/409；第一轮与第二轮缺一→不可发布；跨教师/班/课堂资源→404或403且不泄露；不同请求键并发发布、通知写入失败→整事务回滚；同键同内容重试返回同回执。保留已有整包后端，不重新引入逐题 plan。

### W2 复核教师诊断详情整包审阅（P3/P5；主路径已接入）

当前事实：新课堂 v7 详情已通过 `TeacherClassroomPackageReview` 与 learning public/API/Demo 路径执行 ensure → GET/PUT → 医学审核提交 → 固定学生整包发布；保留的逐建议组件只用于兼容分支。候选题以 `includedInPackage` 成对软排除/恢复，源行保留用于追溯和题库来源；发布确认只计入纳入项，必要课堂目标覆盖由后端再次校验。不要重建页面或删除 v6 兼容。按已有组件、repository 和 behavior specs 复核以下门禁：页面只经 feature public API，不直接 `uni.request`；完整显示首/二轮及阻塞；保存未成功时不得发布；PUT 成功更新 version/digest 并清除审阅确认；409 保留输入且明确取回/比对，不静默覆盖。

发布确认固定诊断学生；无选人、全班、跨班控件。反馈文本可空；确认框展示学生、课堂、首轮数、第二轮条件、版本与摘要。只有教师勾选完整两轮审阅、服务端无阻塞时调用单次 publish；超时用同一 client_request_id 查询状态/重试，避免新键重发。成功转冻结只读，刷新课堂进度、学生包和待办。医学审核队列对有 `medical_review` 权限者有入口；普通教师只能提交审核、看阻塞，不能自行批准。

清除旧版单建议发布 UI 及 `selectedTargetIds` / `wholeClass` 分支；保留旧诊断只读查询与学生未完成历史任务的原合法执行入口，教师侧 v3–v6 feedback/close、suggestion edit/adopt 与单题发布均拒绝新写入，不得错误调用 v7 ensure。定向 Vue/仓储测试需真实断言多建议只出现一个包、完整两轮可读、空反馈可发、跨学生控件不存在、版本冲突不丢输入、重复点击只一回执。诊断列表/待办入口也要回归。

### W3 复核教师题库前端与医学审核边界（P3/P5；主 UI 已接入）

当前事实：question bank 后端端点、content public、API/Demo adapter、内容入口、列表/详情编辑归档和诊断来源预览已存在。不要重复加页面/端点。按 A16/A17 继续验证教师本人隔离、跨教师 ID、入库白名单、同源幂等、版本与归档，以及客户端不得声称专家已批准。任何缺陷修复都必须保证去标识化副本不回写 package item、已发布任务或最终报告；题库仍不提供组卷/全班发布，也不提供未批准的医学权限。

### W4 学生两轮执行、病例回包和最终报告（P4）

前置：W2 能发布有可执行资源包；先用受管后端 fixture。学生学习首页一个课堂一条包，包内按本课堂节点分组；始终以服务端 `execution_status/current_cycle/progress` 为准，不在页面用题数猜完成。学生未作答不见答案、评分规则、未激活第二轮题面。客观/文本题提交使用稳定 submission ID，失败保留输入；病例 `start` 用稳定 request ID，跳病例五阶段后回来读取包，不能把病例训练分析当教师报告。只有包终态才显示本人最终报告入口；单题 AI 分析只给学生。

当前事实：病例训练页已通过服务端 attempt context 判断课堂来源；URL `packageId` 只作失败/返回提示，病例完成后重新读取本人课堂包。独立病例保留学生训练分析并回病例列表，不创建教师报告或新正式计划。Demo `startClassroomCaseTask` 已接通：bootstrap 注入 training feature port；按本人任务、病例类型、轮次激活与顺序校验，按 `(student, task)` 幂等启动；保存 attempt→task/package 关联；assessment 对目标 dimension 评分后以幂等方式回写包任务，缺证据按未达标处理。`90004` 合成病例路径已从 start 到二轮报告贯通。

实现保留 `90003` 现有 `no_clear_gaps` 验证题；新增 `snapshot=90004, student=2, session=44` 的 `identified_gaps → focused_retry` 病例路径。继续增加 `90005` 首轮达标与 `90006` 二轮耗尽两个隔离无薄弱点课堂。每个题目和分析明确标注 Demo 合成，不是真实 AI/医学审核。病例资源只能来自 Demo case catalog 中显式允许的资源，标签 `demo_approved`；不得复用 v6 的 `90002` 逐建议历史诊断。

具体实现约束：

1. `LearningRepository.startClassroomCaseTask` 的 API 合同仍为正整数 `case_attempt_id`；因现有 Demo `CaseAttempt.id` 是字符串，内部领域返回型需明确支持 `string | number`，API adapter 不放宽 Zod/OpenAPI 正整数 schema。学生页面只把该值序列化为路由字符串；后续查询一律通过 training feature，不在 learning 直接访问 storage 或训练实现。
2. 在 `bootstrap/wiring.ts` 从 Demo training 注入最小 `DemoClassroomCasePort`（启动、按本人读取 attempt/assessment）；learning Demo 仅保存 attempt 与 `(student external id, task id, package id)` 的关联。启动先校验学生角色、任务属于本人已发布包、task type=`focused_retry`、轮次已激活且包未终态；使用 task ID 作为幂等身份，重复 start 返回已有 attempt，不能创建第二份病例记录。`clientRequestId` 做格式校验/审计，不用它替代本人授权。
3. `getStudentClassroomCaseAttemptContext` 从该关联读身份；本人拥有的进行中或已完成 attempt 均可返回 `isClassroomTask=true` 与真实 task/package ID，因为训练页需要在中断时安全回程，报告页会另行验证 attempt assessment 与已完成 task。本人独立病例返回 false/null；关联存在但 attempt 不属于当前学生时返回与 API 等价的 404，不能泄露包 ID。严禁信任 URL query。
4. 病例五阶段分析仍只形成学生可见 `CaseAssessment`。学生回课堂包后，learning Demo 通过注入 port 检查绑定 attempt 的 assessment，取任务目标 `dimensionId` 对应的分数，按 focused-retry 阈值 70 记录一次任务证据；目标维度/证据缺失按未达标而非伪造通过。读后 reconciliation 必须幂等。只有包中当前轮所有激活题完成时才判轮次；只有首轮全部达标或第二轮激活题全部提交后才调用唯一报告构建器。病例单独完成、独立病例分析不得建立教师报告或教师统计。
5. 已有 Demo 定向测试覆盖有效/并发重复 start 只一个 attempt、未激活轮拒绝、异学生 context 404、独立病例 false/null、病例完成后进度刷新、首轮失败→二轮病例任务达标并只生成包报告；另覆盖客观题首轮达标/二轮耗尽、逾期和报告暂不可用。后端新增报告 builder 故障回滚/同请求重试 API 测试并定向通过。仍须补充课堂病例 assessment 目标 dimension 缺失、病例完成但包内其他任务未完成、服务/读取异常后的 reconciliation 重放断言；Developer Tools 真实走通因 CLI 不可用标为 Unverified。后端已有 case callback 重试/并发与五阶段 API 证据；本轮完整回归结果待记录。

复核后端 API 测试矩阵：首轮全过、首轮部分未完成、首轮失败仅失败目标激活、第二轮通过、第二轮未通过、病例五阶段、病例完成后回调故障重放、相同/异 payload 重试、最终报告 builder 抛错的事务回滚/同 submission 重试、病例完成但同轮另一 active 任务未完成，以及并发只一报告。报告 builder 故障和新增病例等待其他任务的用例已有定向测试；最新完整 `backend:check` 为 316 passed / 88.26%，包含新增病例边界测试。报告修复命令默认 dry-run；另在**明确受管、非共享、非生产**的真实开发库上经批准备份/恢复演练，逐条核对包/计划/评价身份和摘要；若无这种环境，标记外部待验收而不是把 pytest 临时 SQLite 叫真实库。

### W5 复核教师学情、PBL 进度与旧入口（P5；新页面已有局部实现）

当前事实：PBL 本课报告、逐学生课堂进度和 analytics v2/学生综合详情均已接入局部页面；进度和报告读口由服务端按当前教师范围核对。剩余任务不是重新创建页面，而是补/复验未发布、进行中、逾期、已完成和 `report_unavailable` 状态；筛选/分页/返回恢复；学情学生列表含无报告学生而结果只汇总终态报告；旧 plan 深链不能猜 report ID；局部分析加载失败不能遮挡本课报告。跨入口必须保持“PBL=本课堂报告/进度，学情=跨课堂综合学情”。

2026-09-24 静态搜索结果已记录：`getTeacherPblFollowUps` 仍由旧 port/API/Demo repository 支持，并出现在旧 `TeacherPblFollowUps.vue`、行为测试以及 `TeacherPblClassrooms.vue` 的阶段看板方法；但官方 `TeacherPblHome` 当前只以 `create-only` 挂载后者，活跃巩固列表使用 learning final-report API，旧跟进组件无正式导航入口。`task_published` 是 v6/历史 work-item 状态，v7 新发布经 `TeacherClassroomPackageReview`；API/Demo 对 v7 旧发布动作显式拒绝。`createLearningPlan` 仍在 legacy public/API/Demo adapter 和兼容测试中，学生课堂包/病例页面没有调用它。未发现新版学生病例独立分析自动进入教师报告的可见入口。以上保留兼容，后续不得通过新增导航重新暴露旧路径。当前 `src/pages/teacher/analytics/student-detail.vue` 保留学生综合学情职责，不改作 PBL 跟进。历史 `planId` 无自动转换映射，旧深链只说明历史/退役并返回，不猜 `reportId`。分页/返回/局部失败/缓存身份切换仍要进一步验证；DevTools 缺失前真实交互保持 Unverified。

### W6 完整 Demo 与 API 合同（P6）

前置：W2–W5 页面/领域合同稳定。构造按教师、班级、课堂、学生隔离的版本化合成数据状态集，覆盖待生成、无明确薄弱点、待审核、可发布、首轮部分、首轮达标、首轮失败只激活目标、二轮达标、二轮仍需支持、报告暂不可用、独立病例学生分析、题库空/active/archived。当前 Demo 已有 `90003` 无薄弱点、`90004` 病例与微训练目标补强、`90005` 首轮达标、`90006` 二轮耗尽种子；微训练已覆盖审核蓝图两轮选择、保存、文本评分和失败目标激活。仍需补齐 API/Demo 错误、权限和资源变更分支的逐合同对照；不从旧病例 assessment 或旧 plan 推算新报告，不模拟真实医学专家结论。API 失败绝不回退 Demo。

已将 lifecycle 测试拓展为具名 fixture：`90003` 保留首轮失败→只激活目标变式→第二轮达标；`90004` 病例与微训练目标均可按各自评分规则进入二轮，并在两项终结后统一形成报告；`90005` 首轮直接达标；`90006` 二轮耗尽后 `needs_reinforcement`。另通过受控日期 mock 验证逾期，并通过非公开故障 fixture 验证已完成包进度保留、finalReportId 为空、报告读口返回 `SERVICE_UNAVAILABLE`、教师报告列表不伪造结果；该 fixture 仅用于测试注入，尚无产品 UI 开关。题库覆盖空列表、active 副本、编辑与 archived。真实微信验收仍必须由用户操作产生变化，不能页面 `setData` 或直接调用业务方法伪造点击。

后端 schema 变更后按 `npm run contract:generate` → 审查 OpenAPI/生成 TS/fixture 差异 → Zod/mapper → API/Demo conformance → `npm run contract:check`；不能手改生成物。Demo 侧重 UI/状态/幂等演示，不作真实授权、AI、医学或数据库验收证据。旧 Demo storage 仅迁移可证明身份关联数据；用户旧集合不清空。

### W7 历史审计与兼容（P6；不实施转换）

前置：新写入路径、报告重建与统计口径稳定。按第07册已批准策略运行只读 `backend/scripts/transition_t43_packages.py`，只接受显式已有本地 SQLite 路径；命令输出必须是聚合分类，不输出学生标识、回答、诊断或题目正文。审计分类覆盖缺来源、非课堂/范围冲突、同学生课堂多计划、非终态、缺失两轮/评价证据、审核资源版本/摘要无法证明、已有映射等类别。运行前先核对工具对 `--apply` 的拒绝行为和安全测试；不得尝试真实或未知库。

**本期不转换任何旧计划。** 即使工具把记录归为 `eligible_for_manual_review`，该标签也不授权克隆/转换；旧数据保留原样只读，排除 T43 新结果统计。检查 `--apply` 稳定非零拒绝且数据库字节/计数不变；执行前后可对同一受管测试库快照比较，禁止为此自行清理/删除数据库文件。历史 `planId` 深链不得猜 `reportId`；无映射时显示历史任务说明与返回入口。若产品未来要求转换，需另立 UpdatePlan、设计不改变旧证据的映射快照/授权与备份恢复门禁。

### W8 综合验证、微信交互与交付（P7/P8）

前置：W1–W7 各自出口通过或明确未验收。逐项填写第09册 A01–A24 的“代码测试、API/Demo、工具交互、外部”证据，不用某一层通过代替整条场景。运行受影响定向测试后再按第09册全量命令；先检查 `backend:test:safety`/`backend:test:migrations`，不能向未知数据库试迁移。跨模块/共享导航变化本次触发全量核心回归。失败要记录原始失败项、实际退出码与解除条件，不用 skip/xfail 或删测试做绿。

最近完整仓库复测：后端 `backend:check` 为 `316 passed / 88.26%`；之后全部 12 个 T43 后端专项测试文件 52 passed。最新前端 coverage 运行 79 files / 390 tests 全通过，但命令退出 1（lines/statements 68.11%、functions 61.71%、branches 76.90%，阈值 85%/85%/80%），不得调低门槛。Lint、type-check、frontend boundary 与 git diff check 退出 0；最近显式 Demo watcher 已编译最新前端代码，但 DevTools 交互仍 Unverified。`npm run security:secrets` 最近一次退出 1，扫描器只输出历史 `miniprogram/pages/student/chat/` 的 3 个 generic-api-key 指纹；本轮未读取或改动匹配源码，责任人复核前标记 **Fail / security gate open**。

软排除增量之后没有重跑全量 coverage 或完整后端门禁。其当前定向证据为 backend package/migration 16 passed、安全 14 passed、migration suite 22 passed；前端 API/Demo/审阅组件 27 tests passed，type-check、contract:check、定向 lint 通过。Demo watcher 完成开发目录编译；微信 Developer Tools doctor 仍因缺 `WECHATIDE_CLI_PATH` 退出 1，无普通编译、真实交互/截图。上述局部通过不关闭全量 coverage、A01–A27、API/Demo 全状态、外部审验等门禁。

小程序用显式 `VITE_APP_MODE=demo` 的 `npm run dev:mp-weixin` watcher，等 `Build complete. Watching for changes...`；微信开发者工具仅加载 `D:\CODE\weixin\wxprogrom7.15\dist\dev\mp-weixin`，普通编译、SDK doctor 后用真实 tap/input/scroll 走诊断编辑→审核→入库→发布→学生两轮→进度→本课报告→综合学情。按受影响可见状态取最少内部截图并审阅，逐状态记录，禁止 setData/业务方法/系统鼠标键盘替代操作。页面有数据终态、长题、窄宽屏、错误重试及返回都要看实际渲染。工具不可用则单列待验收，不能说小程序通过。真实 Coze、真机、医学专家、PostgreSQL、生产迁移/数据另列外部待验收。

本轮 `npm run test:mp:doctor` 因未设置 `WECHATIDE_CLI_PATH` 退出 1；在规则允许的常见安装根未找到 `wechatide.cmd`，当前会话也无 Developer Tools 内部交互/截图工具。显式 Demo watcher 持续运行且生产构建曾通过，但不等于普通编译或小程序验收。恢复条件是提供受支持的安装 CLI，再按根规则执行 doctor、规定目录普通编译、真实 tap/input/scroll 和必要截图审阅；禁止换旧 WebSocket、系统鼠标键盘或其他项目目录。

最后按真实实现更新根规则及架构、数据层、前端和后端权威文档，填写交付模板；无用户授权不提交/推送。若任一必需功能未达到出口，不把 T43 标成“已完成”。

## 四、最小验收证据索引

| 场景组                    | 后端/契约必须给出的证据                                      | 前端/Demo/微信必须给出的证据                               |
| ------------------------- | ------------------------------------------------------------ | ---------------------------------------------------------- |
| 一包与整包发布 A01–A05    | 唯一约束、两轮覆盖、并发/幂等、冻结、资源版本及权限负向测试  | 诊断两轮编辑、固定学生、一次发布、冲突保留输入、发布后只读 |
| 诊断边界 A06–A07          | no-clear-gaps、insufficient/unavailable、自主/私人无教师资源 | 无薄弱点如实展示；失败不出现虚构任务或报告                 |
| 执行/报告 A08–A12/A24     | 首轮/二轮各终态、病例回调故障、独立病例排除、报告回滚/修复   | 一课堂一包、任务反馈、病例返回、终态报告/缺失态            |
| 统计/权限 A13–A15/A20–A21 | report-only 去重、日期边界、所有 ID 篡改、归档班级历史授权   | 学情与 PBL 各自职责、切换身份无旧数据闪回                  |
| 题库/审核 A16–A17         | 教师主动入库、去标识化、个人隔离、医学状态版本检查           | 题库筛选编辑归档、审核阻塞说明、无组卷/全班发布            |
| 迁移/导航 A18–A19/A22     | dry-run、备份恢复、重复 apply、跳过含糊旧数据                | 旧深链不伪造报告；正确返回学情/PBL/内容                    |
| 合同 A23                  | OpenAPI/生成类型/Zod/mapper/API-Demo 同态测试                | Demo 实际交互 + 普通编译 + 可见状态截图审阅                |

**交付判断**：某组只有单元测试、只有 Demo、只有 WXML 或只有历史截图，均不得标整组 Pass；逐层记 Partial/Unverified 并附具体缺口。当前最短关键路径是 W1 → W2 → W3/W4 → W5 → W6 → W7 → W8；W3 和 W4 可在 W2 稳定后分开推进，但同一工作树编辑前先核对文件归属。

### 2026-09-25 续跑后的最新接手快照（覆盖之前的 78/375 前端数据）

刚完成题库身份边界修正：`requireRole('teacher')` 返回 false 时，题库列表和详情不再发起读请求；详情页侦测教师账号切换后清空旧账号题目与表单、使 pending 回包失效并退出到个人题库入口。课堂任务/学情/题库三页行为共 14 tests passed。

当前本地复测：`npm run lint`、`npm run type-check`、`node scripts/frontend-boundaries.mjs`、`npm run contract:check`、`npm run build:mp-weixin` 均 exit 0；全量前端 79 files / 390 tests 通过，但 coverage exit 1（lines/statements 68.11%、functions 61.71%、branches 76.90%；门槛 85%/85%/80%）；Demo watcher 构建成功，开发者工具 doctor 因 `WECHATIDE_CLI_PATH` 缺失 exit 1。没有 DevTools 普通编译、真实点击/输入/滚动或截图审阅。后端最新全量仍为同日 `backend:check` 316 passed / 88.26%；随后 T43 专项 12 个测试文件 52 passed，本次未改后端。

明日/后续继续前先核对 `git status --short` 与本文件；不要覆盖/恢复其他人的脏改动。优先处理 W8 覆盖率门槛的基线与可承担的定向补测，保持 85%/85%/80% 不变；在提供受支持的 DevTools CLI 后补规定目录普通编译、真实受影响页面流程和最少截图审阅。secret-scan 历史指纹须由责任人复核，报告修复真实库演练需明确受管非生产库与获批备份/恢复窗口。T43 未达全部出口前，不标完成。

安全扫描本日复跑仍 exit 1，3 个指纹仍限于历史 `miniprogram/pages/student/chat/`；原始内容未显示，等安全责任人审核。

### 2026-09-25 adapter 测试后的接手增量

完成 T43 核心 learning adapters 的定向覆盖补强：相关 3 个测试文件 17 项通过；全量前端 79 files / 390 tests passed，coverage exit 1（68.11% lines/statements、61.71% functions、76.90% branches）。课堂包 adapter 当前约 99.28%/100%/90.91%，教师最终报告 adapter 100%/100%/100%。Lint/type-check 通过。此增量只有测试改动，未改 runtime/API/contract/Demo。

接续执行时不要把局部覆盖率提升或 390 项逻辑测试全绿当成 T43 完成；全局 coverage 门槛与 DevTools、责任人/真实环境验收仍开放。

### 2026-09-25 最新续跑快照：教师整包审阅上下文竞态复核

本节取代上文 390-test coverage 数值作为当前前端基线；历史数字保留说明此前状态。教师 `TeacherClassroomPackageReview` 现在按快照、会话、学生、班级变化隔离待完成异步请求，并在保存/取回/医学提交/发布/题库操作回写时核对任务包 ID、版本、digest 与上下文。换课堂废弃旧题库预览和本地忙碌状态。已被用户确认并发送的旧课堂题库写操作无法取消，但旧完成回包不会提示或改写新诊断页面。对应组件 11 项、诊断路由 2 项行为测试通过。

本轮最新 `npm run test:coverage` 是 79 files / 397 tests 全通过，命令仍 exit 1：lines/statements 68.38%、functions 62.12%、branches 76.93%，低于固定门槛 85%/85%/80%。`npm run lint`、`npm run type-check`、前端边界、受影响用例、Prettier 和 `npm run build:mp-weixin` 均 exit 0。显式 Demo watcher 完成 `dist/dev/mp-weixin` 编译；产物检查仅验证编译包含包身份校验。`npm run test:mp:doctor` exit 1，未配置 `WECHATIDE_CLI_PATH`，故 DevTools 普通编译、tap/input/scroll、可见渲染及截图仍 Unverified。没有重跑 contract/backend（本轮无接口/后端变更），此前完整后端 316 passed / 88.26%、T43 专项 52 passed 的证据未被本次覆盖。

接下来优先处理可本地完成的 W1–W7 矩阵缺项及全局 coverage（不得调低门槛），并在 Developer Tools CLI 可用后完成受影响页面实交互；另需等待安全责任人复核历史指纹，以及获批非生产受管库上的报告修复 dry-run/备份恢复演练。A01–A24、API/Demo 全同态、真实 Coze、授权医学专家、PostgreSQL/生产、真机仍未关闭。不要将本快照称为 T43 交付完成。

### 2026-09-25 最新增量：教师工作区、诊断与报告权限状态

本节取代上方 79/397 coverage 快照。复核进一步覆盖教师工作区、PBL 诊断、课堂进度和巩固跟进报告入口：教师角色失效后这些页面不保留上一用户可见数据，页面路由拒绝访问时作废待处理请求；工作区教师身份切换会清除班级/待办并重建子页。整包审阅切换课堂或卸载时也使保存、医学审核、发布、题库请求回包失效。题库写入已送达后仍可能由服务端完成，但不会把旧课堂回执呈现在新课堂。

`npm run test:coverage` 最新为 81 files / 405 tests 全通过，命令 exit 1：lines/statements 69.90%、functions 61.24%、branches 76.63%，全局门槛仍是 85%/85%/80%，不得降低。五个教师页面套件 23 项通过；lint、type-check、前端边界、定向行为、Prettier 和 `npm run build:mp-weixin` 通过。显式 Demo watcher 完成编译，产物检查不是页面可见验收。DevTools doctor 因缺少 `WECHATIDE_CLI_PATH` exit 1，普通编译/真实交互/渲染/截图为 Unverified。API、后端、迁移未变，上一完整后端证据仍为 316 passed / 88.26%、T43 专项 52 passed。

下一步继续按 W1–W7 补齐可验证矩阵及覆盖率，不用局部通过代替 A01–A24；DevTools、历史扫描指纹责任人结论、报告修复工具在获批受管非生产库的 dry-run/备份恢复演练、真实 Coze/专家/PostgreSQL/生产/真机均未关闭。PBL 巩固跟进仍只指向本课堂已完成报告，学生综合学情仍留在教师学情入口；本轮身份与请求隔离不改变这条产品归属。

### 2026-09-25 最新续跑：学生端身份与迟到响应隔离

学生“学习”首页、课堂任务包详情、病例训练和学生病例分析报告均绑定 session 的学生 `openid + role`。身份变化/失权时清除当前课堂包、作答、病例/报告、加载及来源上下文状态，并让旧身份异步读取、病例提交和完成回包失效；URL query 仍不能扩大服务端本人访问范围。独立病例分析仍只向学生提供训练反馈，不生成教师报告/结果统计；教师 PBL 巩固跟进仍是本课最终报告，学生综合学情仍在教师学情界面。四页相关行为用例 12 项通过。

本轮全量 coverage 为 83 files / 411 tests 全通过，但 coverage gate exit 1（71.44% lines/statements、60.71% functions、76.51% branches；门槛 85%/85%/80%）。Lint、type-check、frontend boundaries、小程序生产构建通过；Demo watcher 成功编译，但 `test:mp:doctor` 因 `WECHATIDE_CLI_PATH` 缺失 exit 1，没有普通编译后交互/截图。A21 仍未关闭全部角色/缓存矩阵，A22 仍缺页面实际导航/返回验收；A01–A24 跨层证据、coverage gate、安全责任人、受管非生产库报告修复演练和外部验收继续开放。命令证据见[实施进度记录](implementation-progress.md)。
