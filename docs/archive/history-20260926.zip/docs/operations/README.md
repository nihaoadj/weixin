# 运行与维护文档

本目录说明本地开发、构建、部署与依赖维护。[工程工作流](engineering-workflow.md)维护更新分流、数据库安全、验证与交付要求；权限和敏感数据规则见[安全边界](../governance/security.md)。

| 文档                                           | 内容                             |
| ---------------------------------------------- | -------------------------------- |
| [development.md](development.md)               | 开发规范、测试与 Git 注意事项    |
| [deployment.md](deployment.md)                 | 环境变量、构建与部署路径         |
| [dependency-upgrade.md](dependency-upgrade.md) | 依赖安全基线、兼容矩阵与维护流程 |
