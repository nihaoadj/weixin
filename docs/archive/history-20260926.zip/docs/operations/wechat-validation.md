# 微信开发者工具前端验收

微信小程序是唯一产品目标。T01–T36 阶段概况见 [阶段概述](../update_plan/summary.md)；未完成的开发者工具验证必须明确标为待验收，不能由历史 H5 结果补足。

## 开发环境

在仓库根目录执行：

```powershell
$env:VITE_APP_MODE='demo'
npm run dev:mp-weixin
```

保持 watcher 运行，等到 `Build complete. Watching for changes...`。开发者工具只导入 `D:\CODE\weixin\wxprogrom7.15\dist\dev\mp-weixin`，随后执行普通编译。`build:mp-weixin` 的生产目录不能刷新开发目录。

### 自动重编译与自动化连接（当前规则，2026-09-14）

工具不会自动监听 `dist`。每次可见改动取证前，保持 Demo watcher 运行至完整构建，再通过当前开发者工具支持的 `wechatide.cmd` 打开项目窗口并刷新模拟器：

```powershell
$env:WECHATIDE_CLI_PATH='d:\codeapp\微信web开发者工具\wechatide.cmd'
$env:WECHATIDE_CLIENT='Codex'
& $env:WECHATIDE_CLI_PATH -c $env:WECHATIDE_CLIENT open_project_window --project 'D:\CODE\weixin\wxprogrom7.15\dist\dev\mp-weixin' --window-mode liteMode
& $env:WECHATIDE_CLI_PATH -c $env:WECHATIDE_CLIENT simulator_refresh --project 'D:\CODE\weixin\wxprogrom7.15\dist\dev\mp-weixin'
npm run test:mp:doctor
```

- `test:mp:doctor` 通过 `automation_runtime_info --action systemInfo` 检查项目、URL 安全校验和 `SDKVersion`；它不执行页面用例，也不代表页面渲染通过。
- doctor 读取的是**启动该命令的当前终端进程**中的 `WECHATIDE_CLI_PATH`，不是微信开发者工具设置页里的某个开关。若 doctor 报 `Set WECHATIDE_CLI_PATH`，先在同一个 PowerShell 窗口设置已安装的 `wechatide.cmd` 路径后重跑；这不表示开发者工具未安装，也不要求改用户或系统级环境变量。
- 使用 `automation_element_action` 完成真实 tap/input/scroll，使用 `simulator_screenshot` 取证。每张截图仍须审阅文字、控件、滚动、固定栏和遮挡。
- 设置页的 9420 是 CLI/HTTP 服务端口。它**不是**旧 `App.*` WebSocket 端点；严禁使用 `--auto-port`、`WECHAT_AUTO_PORT`、`ws://127.0.0.1:*`、`Tool.getInfo` 或 `@weapp-vite/miniprogram-automator` 连接该端口。
- `scripts/wechat/*` 中保留的旧 WebSocket 脚本只作历史记录；其 npm 入口会明确失败，避免作为新的验收依据。不得手改 `dist`、复制生产目录、清理工具 storage 或关闭安全校验来替代编译。

## 选择验收范围

默认是**受影响流程验收**：一次页面、组件、文案、布局或局部导航改动，只运行对应的最小自动化脚本或手工流程；涉及实际视觉变化或不同验收状态时，再从受影响页面取得必要的当次后台截图。不要因为局部改动自动运行完整学生、教师、病例和 PBL 回归。

截图遵循**最小充分取证**，避免把截图本身变成无效的重复验收：

- 优先使用 watcher 完成信息、编译产物、WXML/元素属性和自动化断言确认代码与状态；截图用于审阅这些证据不能覆盖的实际视觉结果。
- 取证前先列出本次必须检查的可见状态；只有页面可见状态确实变化，或验收矩阵明确要求不同状态、滚动位置、模拟宽度时，才新增截图。同一页面的同一状态已有当次代表性截图时不再补拍；旧截图不能证明本次视觉变化后的状态。
- 禁止通过连续截取近似画面来等待编译、确认缓存或试探刷新是否成功。怀疑旧产物时，先检查 watcher、产物内容与 `simulator_refresh` 结果。
- 仅当截图文件损坏、关键区域不完整，或已确认重新编译/真实交互产生新状态时允许补拍；补拍原因应写入交付记录。达到当前验收目标后立即停止取证。

仅在以下情况运行**完整核心回归**：发布候选、共享导航/应用壳/构建改动、跨模块数据或身份改动、局部验收发现影响外溢，或用户明确提出。核心和专项脚本以当前 `package.json` 为准；所有脚本复用同一个已打开的开发者工具，必须串行；不得为运行脚本新开工具窗口、重登、抢占前台或清理工具数据。

## 交互与渲染

- 交互：真实点击、输入、提交、返回、刷新后状态及防重复操作；不得以 `setData` 或调用业务方法代替被测交互。
- 渲染：实际控件及文字可见，布局无重叠/遮挡、滚动到底可操作、固定栏正确；检查长内容、加载、空、失败状态和有代表性的模拟宽度。
- 截图：来自当次开发者工具实际页面的内部截图接口，后台运行，不依赖系统截屏、窗口置前、鼠标或键盘焦点；按上文最小充分原则逐张审阅。截图比较只证明稳定性。不要自动接受新基线或输出完整学生答案/隐藏病例。系统截图仅限用户明确要求查看工具窗口时使用，不能充当自动化验收截图。
- 模式：Demo 证明确定性界面合同；服务端权限和 API 不回退仍由独立受管测试验证，不能称作已完成小程序 API E2E。

## 完成口径

| 证据                         | 允许结论                               |
| ---------------------------- | -------------------------------------- |
| 格式、类型、Vitest           | 被覆盖逻辑/组件行为正常                |
| 小程序生产构建               | 可生成小程序产物                       |
| SDK 握手                     | 工具协议连接就绪                       |
| 开发者工具操作及实际截图审阅 | 所测状态在该工具/基础库/模拟宽度下通过 |
| 未执行真机                   | 本次不包含真机结论                     |

缺登录、缺自动化服务、编译未完成、用例失败，或需要视觉验收却未取得并审阅必要截图，均为对应范围的待验收；纯逻辑检查不因无视觉变化而强制新增截图，也不得因此宣称实际渲染通过。记录源码版本/工作区、模式、命令、构建完成时间、开发目录、普通编译、工具/基础库版本、角色/入口、流程、必要的截图路径、补拍原因、失败与解除条件。

桌面 runner 尚未部署。Ubuntu 静态 CI 或本地单元测试通过不能替代本节验收；不得给未运行的开发者工具测试标绿。真机按用户要求本次不执行，生产发布条件仍需另行验证。

## 历史 T26–T30 取证记录（不可复用为当前操作规则）

下列条目保留历史证据，不授权复用其中的 `--auto-port`、`WECHAT_AUTO_PORT`、`App.*` 或旧 WebSocket 命令。新验收一律遵守上文“自动重编译与自动化连接（当前规则）”。

## T28 教师视觉模块取证补充

- 三个重构页面（今日待办、正式任务跟进、诊断审阅）的取证脚本为 `scripts/wechat/t28-overview-evidence.mjs`、`t28-follow-up-evidence.mjs`、`t28-diagnostic-evidence.mjs`；学生端外溢抽查为 `t28-student-spillover.mjs`；全部使用真实 tap/输入/提交与内部截图通道。
- 本机工具 2.02.2608060 的自动化握手与取证统一使用 `--auto-port 9421`：9420 会被 IDE Express 服务绑定在 `127.0.0.1` 而遮蔽自动化 WS（握手失败属端口冲突，不是未就绪）。
- 该工具版本下 automator 的 `navigateTo`/`reLaunch` 全部以 `Uncaught [object Object]` 拒绝（真实 tap 导航与 `navigateBack` 不受影响）；深链类错误/无效状态无法自动化直达，记录为未取证，不得改用 setData 或业务方法伪造。
- 状态筛选等原生 picker 无法真实拨动，其空态/筛选结果截图记为未取证；组件级状态由 Vitest 覆盖。
- 跟进详情取证包含一次真实"发送补充反馈"（Demo 不持久化）；诊断详情取证包含一次真实"仅发送反馈"（会改变 Demo 工作项状态，取证后不清理工具数据）。
- 模块化视觉自评按 T28 06-verification.md §8 量表逐项 Pass/Fail/Unverified 记录；320/768/900px 宽度在该工具上不可控，保留为未验收项。

## T27 PBL 详情取证补充

- 从“内容 → 诊断建议”和“学情 → PBL 跟进”正常点击进入时，分别核对原生标题“诊断审阅”和“正式任务跟进”、微信原生返回箭头及返回后来源 section、筛选和滚动状态。
- 再从“PBL → 课堂阶段看板”进入两类详情，确认它们仍使用同一独立路由；不要以正文返回按钮或重启工作区替代页面栈返回。
- 无历史栈直达详情时，主页图标是平台语义。应检验无效 ID、读取失败和空对象状态的“返回诊断建议”或“返回 PBL 跟进”动作，不把没有原生箭头判为缺陷。
- 对 `MedState` 的双动作状态，在 320px 和默认模拟器宽度审阅等宽、文字居中、间距、长文案、单动作与 compact 状态。截图和操作仍必须来自当次开发者工具内部通道。

## T29 教师工作区与学生提交取证补充

- 取证脚本：`scripts/wechat/t29-baseline.mjs`（基线）、`scripts/wechat/t29-evidence.mjs`（待办四队列、学情/内容/PBL 分区、诊断详情、人工支持真实反馈、学生草稿报告与确认框）、`scripts/wechat/t29-evidence-teacher.mjs`（提交后待办计数、班级学习记录、报告详情对象摘要、真实批阅与原生返回）。
- 学生问答报告提交流程经"研讨 → 历史答疑 → 查看报告"真实 tap 进入；T29 草稿 fixture 由 `ensureDemoData` 幂等注入，不清理工具 storage。
- 本工具版本（2.02.2608060）下 `uni.showModal` 为原生层，automator 不可点击其按钮；确认框文案以截图审阅，取消/确认真实点击与 0/多班 picker 选择保留为真机/后续验收。会话断开时工具会自动确认未响应的 modal，本次提交闭环因此端到端完成，已如实记录。
- `navigateTo/reLaunch` 拒绝与宽度不可控的既有限制继续适用；旧深链规范化由 routing 表驱动测试覆盖。

## T30 本次工具环境记录

- Demo watcher 本次使用 `$env:VITE_APP_MODE='demo'; npm run dev:mp-weixin`，并确认输出 `Build complete. Watching for changes...`；开发目录为 `D:\CODE\weixin\wxprogrom7.15\dist\dev\mp-weixin`。
- 本机 CLI 为 `d:\codeapp\微信web开发者工具\cli.bat`，版本对应工具 `2.02.2608060`。按 `cli quit` 后重开、保持 URL 安全校验的流程执行了普通编译尝试。
- 该安装版 `cli auto --help` 不展示隐藏的 `--auto-port`，实际 `--auto-port`/`--port` 重开只建立 IDE HTTP 服务，未在等待 15–20 秒后提供可用的 `ws://127.0.0.1:<auto-port>` `App.*` 自动化握手；`npm run test:mp:doctor` 因此明确失败为 `Automation port unavailable`。曾检查 9420、9421 和 9422，未修改工具 storage、未关闭 URL 安全校验、未用系统截屏或业务方法代替交互。
- 因此 T30 的开发者工具真实点击、内部截图审阅和受影响页面渲染结论记录为待验收；不得用旧 T28/T29 截图替代。解除条件是修复/更换本机受控自动化服务后，重新从当前 Demo watcher 编译并逐项执行 T30 受影响流程。

## T31 本轮回应方式取证要求

- 只从显式 `VITE_APP_MODE=demo` watcher 的 `dist/dev/mp-weixin` 执行 `wechatide.cmd` 的项目窗口刷新；先由 doctor 确认 `SDKVersion`，再使用受支持的元素自动化完成 T31 当次流程。
- 取证必须通过真实 tap、原生 picker、input、send 与返回操作覆盖默认探究引导、切换直接讲解、草稿保留、混合历史、刷新恢复、长回复、完成锁定、键盘/滚动/固定输入区和遮挡；不得通过 setData 或直接调用业务方法制造状态。
- 截图只允许 `simulator_screenshot` 内部通道，且必须逐张审阅实际文字、控件和布局。若自定义组件隔离或原生 picker 限制导致某一步无法真实操作，记录该步骤与解除条件；不得回退到旧 `App.*` WebSocket 或复用 T28–T30 历史截图。
