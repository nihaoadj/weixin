# 架构设计

本页维护模块边界；下方阶段章节含历史设计，业务取代关系以[当前产品合同](product/features.md)为准，实施与验收状态查[计划索引](update_plan/README.md)。

微信小程序是唯一产品目标。T25 已按用户授权退役 H5 构建、浏览器 E2E 和 H5 专属实现；小程序验证缺口仍按 [微信开发者工具验收](operations/wechat-validation.md) 单独记录，不能由历史浏览器证据补足。

## 技术栈

```text
前端：uni-app + Vue 3 + TypeScript + Vite
后端：Python + FastAPI + SQLAlchemy + Alembic
数据库：SQLite（开发与受管测试）
AI：可选的服务端 gateway；测试禁用真实外部调用
```

## 总体架构

```text
微信小程序
        ↓
feature public API → bootstrap wiring → platform HTTP
        ↓
FastAPI HTTP API
        ↓
模块 application / domain / infrastructure
        ↓
SQLite（开发或 launcher-owned 临时测试库）
```

微信小程序只是客户端入口，不再绑定微信云函数作为核心后端。PostgreSQL、对象存储、生产 AI 网关和其他客户端接入是后续方向，不是当前运行调用链或发布承诺。

## 前端目录职责

```text
src/
├── pages/        路由入口，只组合公开 feature API、页面状态和交互
├── components/   可复用 UI，不直接写业务持久化逻辑
├── features/     identity/qa/reports/content/training/learning/classroom/analytics
│   ├── public.ts 对外稳定应用能力和展示类型
│   ├── presentation/（按需）页面/组件状态
│   ├── application/ 用例编排与窄 port
│   ├── domain/      领域 port、对象和纯规则
│   └── infrastructure API/Demo adapter、Zod、mapper、本地集合
├── platform/      runtime、HTTP/cache、底层 storage、导航、日志和契约
├── bootstrap/     唯一 API/Demo 组合根与 Demo 初始数据装配
├── shared/        有明确复用者的纯 mapper/status 工具
├── types/         兼容的纯领域/展示类型（不承载 I/O）
├── utils/         无状态纯函数
├── services/      不再承载运行时代码（历史测试已迁移到真实模块）
├── data/          仅保留 `contracts/openapi.generated.ts` 生成物
└── static/        图片等静态资源
```

前端数据访问规则：

- 页面只从 `src/features/*/public.ts` 引入业务能力；页面和组件不导入 feature 的 `application/domain/infrastructure`。
- `src/bootstrap/wiring.ts` 是唯一运行时组合根，按 `VITE_APP_MODE=demo|api` 装配每个 feature 的 port 实现；请求失败不会切换数据源。
- `src/platform/http/apiClient.ts` 负责 FastAPI 传输、token、错误、请求去重和显式内存缓存；身份失效通过平台 API 清理，不反向导入页面。
- `VITE_APP_MODE=demo|api` 显式决定运行模式，禁止请求失败时自动切换数据源。
- `src/platform/storage/storage.ts` 只提供底层存取、key 和运行时校验；身份迁移/会话格式由 `features/identity/infrastructure/sessionStorage.ts` 适配，QA、报告、内容和训练的实际本地 store 归各自 feature infrastructure。
- API/Demo adapter 只实现所属 feature 的窄 domain port。报告应用用例通过显式 persistence port 保证“先会话、后草稿”。
- `src/platform/contracts` 持有 Zod/契约 conformance；当前生成文件仍由既有工具写入 `src/data/contracts/openapi.generated.ts`，该文件是唯一生成物且禁止手改。
- 旧 `src/services/*` facade、旧 `src/data/*` aggregate/mapper 已无仓库内消费者并已删除；生成 OpenAPI 类型仍按既有命令保留在 `src/data/contracts/openapi.generated.ts`。
- 外部 JSON 先经过 Zod 边界校验，再由显式 mapper 转换为领域类型。
- 页面不直接散落 `uni.request`、storage key 或后端 URL。

完整的数据流、缓存和错误约定见 [data-layer.md](./data-layer.md)。
公开应用接口见 [frontend/public-interfaces.md](frontend/public-interfaces.md)；依赖门禁由 `scripts/frontend-boundaries.mjs` 和 `config/frontend-boundaries.json` 实施，直接运行脚本（尚无 npm alias）。

## 前端模块映射

| 业务模块  | 领域/应用拥有者                                         | API/Demo infrastructure                                                  | 页面公开入口                   |
| --------- | ------------------------------------------------------- | ------------------------------------------------------------------------ | ------------------------------ |
| identity  | `features/identity/domain`、`application/session.ts`    | `sessionDependencies.ts`、`remoteAuth.ts`                                | `features/identity/public.ts`  |
| qa        | `features/qa/domain`、`application/medicalAssistant.ts` | `apiQaRepository.ts`、`demoQaRepository.ts`、会话/问答 store             | `features/qa/public.ts`        |
| reports   | `features/reports/domain`、`application/reportDraft.ts` | `apiReportRepository.ts`、`demoReportRepository.ts`、report mapper/store | `features/reports/public.ts`   |
| content   | `features/content/domain`                               | `apiContentRepository.ts`、病例/题目 store、case mapper                  | `features/content/public.ts`   |
| training  | `features/training/domain`（含确定性评分）              | `apiTrainingRepository.ts`、`demoCaseStore.ts`、case mapper              | `features/training/public.ts`  |
| learning  | `features/learning/domain`                              | `apiLearningRepository.ts`、`demoLearningRepository.ts`                  | `features/learning/public.ts`  |
| classroom | `features/classroom/domain`                             | `apiClassroomRepository.ts`、`demoClassroomRepository.ts`                | `features/classroom/public.ts` |
| analytics | `features/analytics/domain`                             | `apiAnalyticsRepository.ts`、`demoAnalyticsRepository.ts`                | `features/analytics/public.ts` |
| pbl       | `features/pbl/domain`                                   | `apiPblRepository.ts`、`demoPblRepository.ts`                            | `features/pbl/public.ts`       |

跨模块依赖只向领域 port 或公开接口收敛；实际 API/Demo 选择和跨模块对象连接集中在 `bootstrap/wiring.ts`。`types/domain.ts` 的中文状态和 `types/records.ts` 的稳定英文状态由 `shared/mappers/presentation.ts` 转换，避免 DTO、存储值和页面标签混用。

## 后端目录职责

```text
backend/
├── app/modules/<module>/
│   ├── api/           FastAPI router 与该模块 HTTP schema
│   ├── application/   用例、port、事务编排与 record
│   ├── domain/        无框架状态、评分、安全与可见性策略
│   ├── infrastructure/ ORM、repository、query/外部服务 adapter
│   ├── public.py      跨模块公开合同与 view mapper
│   └── wiring.py      模块实现装配入口
├── app/bootstrap/    app/router、模型注册、开发 seed 与跨模块 composition root
├── app/platform/     数据库 Base、UoW/AI 等平台适配
├── app/shared/       Actor、AppError、稳定基础合同
├── app/api/          旧 HTTP 导入兼容 alias，不拥有路由实现
├── app/models/       旧 ORM 导入兼容 re-export，不定义表
├── app/schemas/      旧 schema 导入兼容 re-export，不定义合同
├── app/services/     旧 facade、测试/开发 seed 兼容入口，不是生产业务实现
├── app/db.py         数据库连接与 metadata 初始化入口
├── app/dependencies.py 认证依赖与 User→Actor 适配
└── tests/            后端 API、领域、迁移与安全测试
```

九个业务模块为 `identity`、`qa`、`reports`、`content`、`training`、`learning`、`classroom`、`analytics`、`pbl`。生产 `app.main` 直接装配各模块 `api` router；`app/bootstrap/model_registry.py` 是唯一跨模块 ORM metadata 注册汇合点。中央兼容目录仍因历史调用方存在，但没有 ORM/Pydantic 定义或生产业务逻辑。R05 进一步规定：一个模块的 `api` 只能由另一模块的 `api` 或 `wiring` 直接引用；application/domain/infrastructure 跨模块协作必须通过 `public.py` 合同或明确 port。`backend/scripts/check_boundaries.py` 与 `config/backend-boundaries.json` 负责检查这项规则。

## 当前接入状态

配置 `VITE_APP_MODE=api` 和 `VITE_API_BASE_URL` 后，前端以下链路会走 FastAPI：

- Demo 登录与 token 保存
- AI 问答
- 对话保存与历史记录
- 历史问答总结的学生只读回看；普通问答不再生成、提交或进入教师批阅
- 教师题目创建、编辑、发布、拒绝
- 学生题目列表与作答线程
- 结构化病例五阶段训练、医学审核和 clone version
- 班级管理、病例/学生学情分析与日期范围下钻
- 个性化学习计划、微训练、复盘和站内通知
- 题目统计中的作答数量

`VITE_APP_MODE=demo` 时前端使用确定性本地数据；两种模式不会在运行中混写。

# 第二阶段服务边界

`modules/classroom` 负责班级 owner/member 隔离；`modules/content` 负责病例审核状态机和 digest；`modules/analytics` 负责固定时间范围、eligible/started/completed pair 和 current/baseline assessment 口径。前端 `features/analytics` 只通过 infrastructure mapper 消费 DTO，统计结果由后端生成。旧 `app/services/analytics.py` 仅转发到 analytics application。

# V3 个性化训练编排

完整病例 assessment 完成后由 `modules/learning` application 幂等创建 `LearningPlan`，确定性选择目标维度和三项 `LearningTask`。任务启动按类型分流到完整 `CaseAttempt` 或唯一 `LearningTaskAttempt`；服务端状态机保证顺序解锁、重复提交幂等和 task-linked assessment 不递归创建新计划。learning 只依赖 `training.public.TrainingCasePort`，不穿透 training application。

`learning.infrastructure.practice_generator` 只接收审核蓝图的公开字段，输出结构化 public definition；AI 日志保存 task/blueprint/digest 元数据，不保存 prompt 原文。没有真实凭据时由 deterministic fallback 完成同一合同。训练 AI 候选只能更新经学生答案白名单校验的反馈/下一步，不能写入确定性分数、权重、总分或 evidence。

# T09：`pbl` 是独立业务模块，拥有课堂会话、参与记录、诊断快照和教师建议题；前端只能通过 `features/pbl/public.ts`，并由 `src/bootstrap/wiring.ts` 选择 API/Demo adapter。建议题发布走 content 的公开桥接，PBL 不直接管理正式题生命周期。

# T20：知识点 PBL 学习路径与私有练习

`content` 提供稳定知识点编码对应的版本化学习材料；`learning` 拥有学习路径、阶段解锁、自主练习、作答和复习到期时间；`pbl` 仍拥有四阶段研讨证据和学生明确提交教师的完成快照。组合根通过窄 port 装配这些能力，页面只调用 `features/learning/public.ts` 与 `features/pbl/public.ts`。

学生主动研讨默认私有，创建时不要求班级，完成后也不再产生新的教师提交；旧共享快照仅作为历史只读兼容数据。后续私有对话和练习不追加外发。课堂研讨继续遵循教师预先创建、班级 owner 和活动成员规则。未审核 AI 练习是 `learning` 的个人记录，独立于正式题、正式评分、知识点稳定状态和 T14 自动达标；教师采用发布仍是正式教学资源的唯一入口。

# T21：教师 PBL 工作区与反馈闭环

`pbl` 继续拥有诊断快照、教师反馈和教师可见性。教师 PBL 页面经同一 public port 组织为“待处理、课堂、跟进”：待处理只汇总当前教师有权读取的课堂诊断及学生明确提交的固定快照；课堂只读取本人班级的课堂 session 和聚合看板；跟进只读取已发布正式任务的进度。教师反馈是不可覆盖的记录，`feedback_only`、`task_published`、`closed` 由 application 在一次事务中写入；发布动作复用 T14 的教师采用和两轮正式任务创建，不能由 AI 自动完成。

历史共享快照的学生只读取面向本人的反馈摘要、状态和下一步。教师不能取得新的自主研讨、完整聊天或未审核个人练习；课堂 session 仍按原班级授权。`learning` 通知仅以 `pbl_session` 标识 PBL 反馈入口，不成为师生实时聊天通道。

# T22：教师工作区职责收敛

T22 只重组 T21 能力的前端归属：`problems` 默认承载“诊断建议”，并以“教学资源”分区保留题目、结构化病例、知识补充卡和医学审核入口；`reports` 默认承载“学情总览”，由 analytics 统计和必要下钻组成；`pbl` 组合课堂创建、运行、关闭、诊断审阅和巩固跟进。诊断与跟进虽然显示在其他工作区，领域所有权、公开 port、权限和隐私校验仍属于 `features/pbl`。

教师工作台根组件加载一次负责班级范围，并把同一筛选上下文传给诊断、跟进、统计与课堂容器。各分区首次打开才挂载，已打开分区通过 `v-show` 保留筛选、分页、详情和错误状态；列表与详情请求使用独立请求令牌，过期响应不能覆盖新筛选。旧 PBL section 在入口统一规范化，旧 analytics 页面只校验教师身份并跳转到 `reports&section=analytics`，不再渲染第二份统计页面。T22 不改变 API/Demo 装配、后端路由、schema、迁移、OpenAPI、AI 合同或 T14/T20/T21 业务规则。

# T14：PBL 参与级阶段与自动巩固

每个 `PblParticipation` 独立维护明确问题、提出假设、讨论证据、总结解释和完成状态。AI schema v3 只提出当前阶段的 `continue/advance/complete`，PBL application 与 repository 共同校验当前阶段开始后的学生消息证据和相邻推进；完成后新消息被锁定，相同消息 ID 仍返回原结果。

教师采用发布仍是医学教学内容进入学生端的唯一入口。content 通过数据库 active `pathology-general-v4` 目录和已批准卡片，在事务内提供两轮资源；learning 预建 cycle 1/2，cycle 2 初始 inactive。目录节点、材料、依赖和来源经 `KnowledgeCatalogPort` 提供给 content、learning、PBL、QA 与 analytics，页面和跨模块用例不得导入静态节点表。learning 的确定性 `pbl-mastery-v1` 按知识再测 100、推理微训练 70、病例目标维度 70 逐项判定，首轮失败仅激活失败目标，二轮失败进入耗尽且需要线下支持。教师结果区只读，旧阶段 PATCH 和 verify POST 仅保留 deprecated 冲突合同。

# T15：学生 PBL 学情报告读模型

`pbl` application 通过窄 port 读取本人 participation/阶段快照和本人 learning plans，将同一 session 的个人讨论、课堂共同训练、任务、attempt 与不可覆盖的轮次评价组装为只读报告。报告状态和说明由确定性规则生成，不调用 AI、不计算综合分。前端 `features/pbl` 的 API/Demo adapter 实现同一 `reports/report` 合同，“学情”总览与详情页面只经 `features/pbl/public.ts` 读取。

# T16：前端信息架构与导航

学生一级导航固定为课堂、学习、学情、答疑，对应 `StudentPrimaryRoute` 的四个根页面；病例训练、知识地图和练习题继续使用既有 `studentCases` 路径，但由 `view=cases|knowledge|questions` 在学习模块的二级资源页中切换。一级切换使用 `reLaunch`，一级进入详情使用 `navigateTo`，连续训练步骤使用 `redirectTo`；二级页通过明确的逻辑父页面处理直接打开和返回兜底。

教师工作区仍使用 `overview|reports|problems|pbl` 内部 key 和 `?tab=` 深链接，并以 `v-show` 保留切换状态；展示标签收敛为待办、学情、内容、PBL。微信原生导航栏是一级页面唯一可见标题，正文使用不可见页面标题和紧凑上下文条提供无障碍名称，不重复渲染同义 Hero。此变化只影响前端路由语义、页面组合和样式，不改变 feature API、API/Demo 装配、后端接口或数据合同。

# T17：统一学习研讨

`pbl` 继续是学生研讨会话的唯一业务拥有者。教师课堂和学生主动研讨共用 participation 级四阶段状态机、结构化诊断、教师采用发布、两轮巩固和学情报告；`guided`/`direct` 只是 participation 上固定的沟通策略，不形成第二套学习模式。前端只经 `features/pbl/public.ts` 使用统一会话能力，API/Demo 仍由 `bootstrap/wiring.ts` 唯一选择。

学生一级导航收敛为研讨、学习、学情。旧 `studentChat` 路径继续存在，但只读取旧 conversation；无 conversation ID 时转到研讨，续开只携带经目录确认的知识点和可编辑起始问题，旧消息不进入 PBL 证据链。

# T29:教师工作区闭环与问答报告班级范围（T30 已退役其新增写入规则）

普通问答报告（`reports.Report`）仍固定为 `report_kind=qa_learning_report`，T29 的 `class_id` 与提交时班级名称快照（Alembic 0024）继续保留历史数据。T30 后不再接受新的报告创建、提交或教师批阅；既有历史按学生只读和不可见规则处理。`GET /classes/my-active` 仅保留给其他兼容班级能力，不再用于报告提交。

教师工作区职责收敛：待办只聚合四类行动项并深链；学情只有"班级学情/学习记录"；内容只有正式教学资源；PBL 统一"课堂/诊断审阅/巩固跟进"（`TeacherPblWorkspace` 组合既有 pbl 公开能力，不复制数据）。导航类型集中在 `teacherWorkspaceContracts.ts`，`teacherWorkspaceRouting.ts` 负责 canonical query、T21/T22 旧链接一次性规范化和筛选白名单。页面只经 `features/reports|classroom|pbl/public.ts` 使用数据，API/Demo adapter 同合同，失败不回退。

# T30：统一学习证据、问答报告退役与 PBL 可见性收敛

T30 在当前代码中已实现：`learning` 拥有不可变的 `LearningEvidenceEvent`/`LearningEvidenceMetric` 账本和公开读写 port；病例评估、正式 PBL 任务/轮次、已审核复习及个人问答/自主 PBL 完成在可信完成时分别写入最小化证据。个人证据固定为 `personal_unverified + student_only`，教师 analytics 只读取 owned class 范围内的 `reviewed_practice/formal_instruction/pbl_formal` 与 `class_aggregate/class_detail` 事件，不提供 raw evidence API 或跨知识/能力综合分。

普通问答报告写入已退役：既有 `reports.Report` 仅保留学生本人历史只读，创建、提交、教师列表/详情/批阅均返回明确冲突或不可见；教师学情移除 records 面板，改为覆盖、完成、关注、知识、六维、活动来源和学生摘要。自主 PBL 创建始终私有且不带班级语义，新完成不再提交教师；旧共享快照仅可在显式历史筛选中只读回看，教师课堂 PBL 仍是唯一新的诊断工作项来源。

# T31：逐轮回应方式与结构化回复

`pbl` 继续拥有研讨状态机，并将 `guided | direct` 下沉为学生消息及诊断快照的逐轮事实；participation 上的值只表示最近一次已生效方式。application 在持久化学生消息后调用 provider，重试身份比较消息 ID、内容和方式；课堂首条消息可在完整权限检查后创建 participation。两种方式不分叉四阶段、证据窗口、安全规则或教师工作流。

provider schema v5 返回严格的 `learning_response`，纯 renderer 生成“回应 / 关键要点 / 下一步”文本。前端仅经 `features/pbl/public.ts` 显式传递方式，API 与 Demo adapter 实现相同幂等和历史语义；`ChatComposer` 只提供通用 context slot，不依赖 PBL 领域。

T40 将新 provider 结果升级为 schema v6，并增加与已确认 finding 和 active 知识点关联的知识补充卡建议。PBL application 只在课堂 participation 首次完成时调用 content 公布的 `PblKnowledgeCardPublicationPort`；content 拥有卡片草稿、来源幂等、医学审核和目标学生可见性，PBL 不直接写 content ORM。原学生是不可移除的默认目标，追加目标必须是教师本人课堂班级的有效成员；学生公开 view 不携带来源诊断或其他目标身份。自主 PBL 与 T32 私人续问仍不产生教师内容。

# T32：完成后私人续问与证据冻结

`PblParticipation` 在完成时固定 `completion_snapshot_id` 与 `evidence_completed_revision`；`PblMessage.turn_scope` 由 application 依据已持久化 participation 决定为 `evidence | private_follow_up`，每个 assistant reply 通过唯一 `reply_to_message_id` 关联其学生消息。完成后的消息只写 `PblPrivateFollowUpResult`，使用独立 provider schema 与有限、去标识化上下文，不创建诊断快照、建议、教师工作项或学习证据。完成课堂即使后来关闭，已有 participation 的学生仍可私人续问；未完成关闭课堂仍禁止写入。

前端把服务端返回的完成 locator、scope 和 `response_kind` 映射为稳定领域合同；同一会话的证据流后显示清楚的冻结/私人边界，私人消息仍可逐轮选择 guided/direct。进行中的课堂即使尚未有 participation，也允许首条消息创建参与记录，不能误显示为“课堂已关闭”。
