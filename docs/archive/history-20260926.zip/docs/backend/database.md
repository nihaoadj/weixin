# 数据库设计

## 当前数据库与迁移边界

开发数据库默认是 `backend/data/dev.db`（不进入 Git）。测试不得使用它：pytest 与本地 E2E 启动器在应用导入前创建带 marker/token 的随机临时 SQLite，并在每次清表、迁移和清理前校验规范临时路径、所有权与链接边界。

`20260823_0002_structured_cases` 为 `problems` 增加内容类型、版本和 JSON 病例字段，并创建 `case_attempts`、`case_attempt_messages`、`stage_submissions`、`case_assessments`、`ai_call_logs`。迁移按 inspector 检查对象，兼容初始迁移已按最新 metadata 建表的空库。

## 当前选择

开发阶段使用 SQLite：

```text
backend/data/dev.db
```

这个文件是本地开发数据，不进入 Git。

## 为什么先用 SQLite

- 不需要单独安装数据库服务
- 适合 Demo、开发和测试
- FastAPI + SQLAlchemy 支持成熟
- 后续可以迁移到 PostgreSQL

## 核心表

```text
users
conversations
messages
reports
classes
class_members
medical_reviews
case_attempts
case_assessments
learning_plans
learning_tasks
learning_task_attempts
student_notifications
problems
knowledge_card_contributions
pbl_sessions
pbl_participations
pbl_messages
pbl_diagnostic_snapshots
pbl_question_suggestions
pbl_teacher_feedbacks
learning_plan_evaluations
```

## users

保存用户身份。

```text
id
external_id
role
nickname
avatar_url
created_at
```

开发阶段 `external_id` 使用 `demo_student`、`demo_teacher`。正式阶段映射微信 openid 或统一账号 ID；角色和权限由服务端维护。

## conversations / messages

对话和消息拆表，方便查询、分页和审计。

```text
conversations: id, client_id, student_id, created_at, updated_at
messages: id, conversation_id, role, content, created_at
```

## reports

报告有明确状态流：

```text
draft
pending_review
reviewed
```

字段：

```text
conversation_id
student_id
status
ai_score
ai_summary
ai_analysis
teacher_score
teacher_feedback
class_id
class_name_snapshot
created_at
updated_at
```

`class_id` 与 `class_name_snapshot` 由 T29 引入：学生提交批阅时写入目标班级及提交时名称快照，草稿与无法证明归属的历史记录保持 NULL 且仅学生本人可见。数据库列为 nullable FK；非空约束由应用层在提交时保证。

## problems

题目表：

```text
type
title
description
target
target_label
target_ids
status
content_type
slug
specialty
difficulty
estimated_minutes
version
parent_problem_id
author_id
medical_review_status
capability_tags
case_definition
rubric
created_at
published_at
```

班级和定向发布已由第二阶段迁移实现：

```text
classes
class_members
problems.target/target_ids
```

## 当前迁移链、验证和回退

当前工作树的 Alembic head 是 `20260924_0032`；这只描述代码仓库的迁移链，不代表任何开发、共享或生产数据库已经升级。0015 建立 PBL 课堂、参与、诊断及建议的持久化；0016 规范化 PBL 消息并使学生提交可幂等；0017 增加课堂上下文、诊断请求/响应身份和独立 PBL 干预计划；0018 增加参与级阶段证据、两轮任务变式与自动判定字段；0019 新增 `learning_plan_evaluations`，以 `(plan_id, cycle_number)` 唯一约束保留每轮自动判定历史；0020 增加 session 来源、学生创建幂等键和 participation 固定沟通方式；0021 允许自主会话没有班级或教师，并保存不可覆盖的学生提交快照；0022 增加学习路径、未审核练习组与个人作答记录；0023 增加不可覆盖的 `pbl_teacher_feedbacks`，以 `(teacher_id, client_feedback_id)` 保证反馈请求幂等；0024 为 `reports` 增加 nullable `class_id`（FK → `classes.id`，具名 `fk_reports_class_id_classes`）、`class_name_snapshot` 与索引 `ix_reports_class_status_updated_id`；0025 新增 `learning_evidence_events`/`learning_evidence_metrics` append-only 证据账本；0026 为 `pbl_messages` 和 `pbl_diagnostic_snapshots` 增加非空 `interaction_style` 及枚举约束；0027 固定完成 snapshot/revision、为消息增加服务端 scope/reply link，并新增独立私人续问结果表；0028 新增持久化病理知识目录、模块、节点、学习材料、依赖、来源及关联表，并写入 `pathology-general-v4` 基线；0029 为每份学习材料持久化至少两个学习目标；0030 为 `knowledge_card_contributions` 增加 PBL 来源、原学生和定向学生字段及来源唯一约束；0031 新增课堂任务包、双轮题目、最终报告、教学回执、教师题库与题库来源记录；0032 为 `classroom_package_items` 增加非空 `included_in_package`，新旧候选默认包含。历史 item 升级时默认为 true；downgrade 仅当没有被排除题目时允许，避免丢失发布集合选择。

0028 的 active 目录是知识点与依赖关系的运行时唯一权威源。基线包含 5 个模块、30 个知识点、30 份材料、34 条依赖和 14 个来源；知识点 code 在目录版本内唯一，允许归档旧版与 active 新版复用稳定编码。节点与边均区分 `source_supported` 和 `pending_expert_review`。存在零个或多个 active 目录、悬空边、无来源边或有向环时应用显式拒绝目录读取。只有未发生审核或编辑的原始 v4 基线允许降级；真实审核后必须前向修复或从已验证备份恢复。详细合同见 [知识库设计](../knowledge-base/README.md)。

0024 在旧库上通过 SQLite batch 复制策略加列；新库由初始迁移的 metadata 直接携带两列与索引。downgrade 在任何 `reports.class_id` 非空时拒绝，必须前进修复或从 T29 前已验证备份恢复；仅当全部为 NULL 时才移除索引与两列。迁移测试覆盖 0023→0024 升级数据保留、空 class 降级、非空 class 降级拒绝与升-降-升循环。`backend/scripts/backfill_report_class_scope.py` 默认 dry-run，只回填可唯一证明的归属（reviewed 报告按 reviewer 拥有班级，其余非草稿按学生当前唯一成员班级）；零候选或多候选保持未归属，draft 与已有归属跳过且永不覆盖。apply 必须同时提供 `--confirm-development` 与未存在的 `--backup` 路径，仅面向受管非生产 SQLite；输出只有类别计数，不包含学生内容。

0025 只建表，不扫描或回写既有业务数据。事件表约束 `student_only` 与班级列互斥、个人未核验证据只能个人可见；指标表约束分数范围、同一事件的指标唯一和级联删除。空 evidence 表可降级，任一 evidence event/metric 非空时明确拒绝 downgrade，禁止通过删除数据制造可回退状态。`backend/scripts/backfill_learning_evidence.py` 默认 dry-run；只允许可唯一证明的已审核病例、正式 PBL 任务/轮次和审核练习，普通问答报告分数、自主诊断与缺少班级 provenance 的记录跳过。

0026 upgrade 从所属 participation 显式回填每条历史消息与快照的固定方式，不扫描外部数据。downgrade 前逐条验证消息和快照方式与 participation 一致；只要存在混合或不一致历史就抛出错误并保留列与数据。仓库测试只在带所有权标记的临时 SQLite 上执行 upgrade/downgrade；未对开发、共享、PostgreSQL 或生产数据库应用迁移。

0027 upgrade 先预检所有已完成 participation 是否能由完成学生消息和其结果快照唯一定位；不能定位即拒绝迁移，不猜测完成边界。通过预检后，历史消息回填为 `evidence`，完成 participation 写入唯一 completion locator，并建立 `pbl_private_follow_up_results`。downgrade 只在不存在私人 scope、私人结果和完成 locator 数据时允许；发现任一私有数据即拒绝，防止通过降级丢失隐私分段事实。迁移测试只使用 launcher-owned 临时 SQLite，未在开发、共享、PostgreSQL 或生产数据库执行。

0030 只为既有知识卡表增加可空来源/原学生字段、非空 JSON 目标字段、来源索引与 `(source_type, source_snapshot_id, source_position)` 唯一约束；历史人工卡保持来源为空和原有班级可见语义。只要存在任一 `source_type` 非空的 AI 卡，downgrade 就拒绝，避免丢失来源、默认接收者和定向发布事实；空数据时才允许移除新增结构。仓库测试覆盖新库、从 0029 升级、幂等来源和有数据拒绝降级，尚未在 PostgreSQL 或生产数据库执行。

0031 为课堂任务包与教师题库建立规范化数据模型、唯一性/状态约束、来源 FK 和报告表；并补充诊断候选字段。0032 增加 `classroom_package_items.included_in_package`，既有草稿题目默认为 true。草稿“移除”是软排除，不删除 item 行，因为题库 revision 与入库回执通过 RESTRICT 外键保存来源；在存在 excluded 行时 downgrade 0032 明确拒绝。升级/降级测试仅在 launcher-owned 临时 SQLite 上完成，未应用到开发、共享或生产数据库。

0018 downgrade 只允许数据库中不存在 schema v3 快照和 cycle 2 任务；否则必须从已验证的 T14 前备份恢复。`backend/scripts/transition_pbl_t14.py` 是独立历史转换工具，默认 dry-run；apply 必须同时提供 `--confirm-development` 与未存在的备份路径。它不应指向未知、共享或生产数据库。

0019 downgrade 只允许评价历史表为空；存在任何评价记录时会拒绝降级，必须从已验证的 T15 前备份恢复。`backend/scripts/backfill_pbl_evaluations.py` 默认 dry-run，只重建现有 task/attempt/`decision_basis` 能证明的轮次；旧人工结果只写 `record_source=legacy` 且不伪造成绩。apply 同样要求 `--confirm-development` 和新的备份路径。

0020 将历史 session/participation 回填为 `classroom`/`guided`，并以 `(created_by_student_id, client_session_id)` 保证学生主动创建幂等。downgrade 仅在不存在 `student_initiated` session 且所有 participation 均为 `guided` 时允许；否则拒绝降级，必须从已验证的 T17 前备份恢复。

0023 downgrade 仅在 `pbl_teacher_feedbacks` 为空时允许；发现任何教师反馈即拒绝降级，必须采用前进修复或从已验证的 T21 前备份恢复。它不会删除教师反馈、正式任务或通知来制造可降级状态。

可用安全入口：

```bash
npm run backend:test:safety
npm run backend:test:migrations
npm run backend:test
npm run backend:migrate
```

前 3 项仅使用受管测试资源；`backend:migrate` 会对当前 `DATABASE_URL` 执行 `upgrade head`，仅可用于已确认的受管开发/测试库，绝不能用作探测共享或生产库。`seed_test_data.py` 会先升级迁移，也只能指向已确认的非生产受管资源。

病理学目录转换使用 `python backend/scripts/transition_pathology.py --rehearse` 先在副本演练；只有受管本地开发库才可使用 `--apply --confirm-development`。实际转换先建立 SQLite 一致性备份并验证恢复，按明确的旧种子编码清理，不按标题关键词删除；结构迁移与业务清理保持分离。

## PostgreSQL 是待验证的生产目标

PostgreSQL 仍是生产目标，尚未完成兼容性、部署、保留和回退验收。连接字符串未来可能从：

```text
sqlite:///./data/dev.db
```

改为：

```text
postgresql+psycopg://user:password@host:5432/dbname
```

但仅改 URL 不构成迁移方案或生产授权。上线前必须由受权负责人以受管副本完成 upgrade/downgrade、数据保留、备份恢复、权限、性能与发布验证。

# 迁移链与兼容性

`20260823_0004_classes_review_analytics.py` 在 0003 基础上只做加法；`20260823_0005_classes_review_hardening.py` 补充 author FK、兼容回填和组合索引。审核记录没有更新/删除接口；旧 `class_ids` 保留并与 `class_members` 兼容合并。后续迁移链为 `0006_personalized_practice`、`0007_report_analysis`。

## 个性化训练迁移

`20260823_0006_personalized_practice.py` 新增 `problems.capability_tags`、`case_attempts.learning_task_id`、AI 蓝图审计字段，以及：

```text
learning_plans
learning_tasks
learning_task_attempts
student_notifications
```

计划以 `source_assessment_id` 唯一，学生最多一个 active 计划；任务以 `(plan_id, position)` 唯一，微训练 attempt 以 `task_id` 唯一。降级只移除 0006 对象和新增字段，不删除 legacy class_ids、班级或病例内容。`0007` 为 reports 增加 `ai_analysis`，回滚只移除该列。

迁移测试覆盖空库/0004 旧库升级、legacy class_ids 回填以及从 head 回滚到 0004；SQLite 回滚会先清理早期动态建表遗留索引。

## 摘要分页索引

`20260830_0008_data_layer_indexes.py` 接在 0007 后，为 conversations/reports 增加 `(updated_at, id)` 和 `(student_id, updated_at, id)` 索引。升级和降级均检查索引存在性，降级只移除这四个索引，不删除业务记录。会话消息更新显式更新父会话时间，确保分页排序反映最近活动。
