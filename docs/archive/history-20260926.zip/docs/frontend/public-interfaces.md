# 前端模块公开接口

本文件是 T03 的页面调用合同。页面和共享组件只从下表的 `public.ts` 引入业务能力；`domain`、`application` 和 `infrastructure` 是模块内部实现，不能作为页面依赖。公开函数返回稳定的页面 view 或稳定领域 record，不暴露 OpenAPI DTO、Zod schema、StorageGateway 或 adapter 实例。

## 公开入口

| 模块      | 入口                               | 公开能力                                                                                                                                                                    |
| --------- | ---------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| identity  | `src/features/identity/public.ts`  | `getSession`、`getRole`、`saveSession`、`clearSession`、`requireRole`、`logout`、`isApiRuntime`、`isDemoRuntime`、微信/Demo 登录同步                                        |
| qa        | `src/features/qa/public.ts`        | 对话列表/摘要/详情/保存、学生题目和作答线程、医学助手、Demo 数据初始化                                                                                                      |
| reports   | `src/features/reports/public.ts`   | 既有问答总结的学生只读详情查找；不暴露报告创建、提交、教师列表或批阅写能力                                                                                                  |
| content   | `src/features/content/public.ts`   | 题目 CRUD、发布/拒绝、病例 authoring、clone、医学审核和保存                                                                                                                 |
| training  | `src/features/training/public.ts`  | 五阶段病例 attempt、患者消息、阶段提交和 assessment                                                                                                                         |
| learning  | `src/features/learning/public.ts`  | 画像、计划、任务、微训练 attempt、通知、复盘、知识图、知识点学习路径与个人未审核练习                                                                                        |
| classroom | `src/features/classroom/public.ts` | 教师班级、学生列表、加退班、班级更新与学生本人有效班级 `getStudentActiveClasses()`                                                                                          |
| analytics | `src/features/analytics/public.ts` | 总览、病例下钻和学生下钻                                                                                                                                                    |
| pbl       | `src/features/pbl/public.ts`       | 学生逐轮回应方式与消息、个人阶段、历史共享快照只读兼容、教师课堂诊断工作项/反馈、课堂看板、只读巩固跟进、教师建议发布、两轮任务、自动结果、课堂汇总及本人 PBL 学情总览/详情 |

所有入口内部通过 `src/bootstrap/wiring.ts` 取得已装配的 port。调用者不选择 API/Demo、不拼接 URL、不读写 storage；API 失败会保留明确错误，不会切换到 Demo。

## 页面导航合同

- 学生一级导航只包含 `pbl | learning | insights | chat`，分别显示为课堂、学习、学情、答疑；`StudentPrimaryRoute` 只接受这四个根路由。
- `ROUTES.studentCases` 保留公开兼容路径，但属于学习的二级资源页；主学习页分别用 `view=cases|knowledge|questions` 直达病例、知识或练习，二级页不再提供页内互切，非法值回退到病例。
- `ROUTES.studentKnowledgeNode` 为知识点学习页，必须携带已编码的 `topicCode`；非法或不存在编码显示可恢复错误并返回 `studentCases?view=knowledge`。知识图纯函数只消费 `getKnowledgeMap()` 的公开视图，不改变 `LearningRepository` 合同。
- 一级页面切换经 `goPrimary`/`reLaunch`，一级到详情经 `goDetail`/`navigateTo`，连续训练替换经 `replaceDetail`/`redirectTo`。二级页返回失败时必须回到其逻辑父页面。
- 教师 workspace 公开 key 仍为 `overview | reports | problems | pbl`，显示为待办、学情、内容、PBL。学情 section 仅为 `analytics`，旧 `records` 只规范化到 analytics，页内只显示总览、学习进度和知识掌握；内容只有 `resources`（教学内容），PBL section 为 `classrooms | diagnostics | follow-ups`（默认课堂）；导航类型集中在 `src/components/teacher/teacherWorkspaceContracts.ts`。
- 旧 T21/T22 section（`pbl&section=work-items|diagnostics|results|sessions`、`problems&section=pbl-diagnostics`、`reports&section=pbl-follow-ups`）一次性规范化到 PBL 归属分区；`workStatus`/`followUpStatus` 白名单仅在对应 PBL 分区生效。旧 `ROUTES.teacherAnalytics` 只保留为教师身份校验后的兼容重定向入口（落到班级学情）。
- 旧 `/pages/teacher/analytics/student-detail` 只作为历史深链兼容入口，教师身份校验后立即转向当前班级 `teacherWorkspace?tab=pbl&section=follow-ups`；它不调用 `getAnalyticsStudent`、不渲染学生档案，也不把旧 `studentId` 转成未受支持的跟进筛选。病例分析仅展示只读学生表现并提供模块级巩固跟进入口。
- 页面组件只使用导航平台公开函数，不直接拼接页面 URL 或调用散落的 `uni.navigate*`。

## 数据与身份边界

- API DTO 只在 `src/platform/contracts` 和所属 infrastructure mapper 中出现。生成类型的唯一现有输出仍是 `src/data/contracts/openapi.generated.ts`，由 `npm run contract:generate` 管理，禁止手改。
- `src/types/records.ts` 使用稳定英文状态，`src/types/domain.ts` 是旧页面中文 view；公开入口在边界完成 `shared/mappers/presentation.ts` 转换。
- 问题/题目 `type` 是后端可扩展的非空展示标签；公开接口保留已知标签的类型提示，不因历史或新增题型（例如“病例单选”）拒绝整批内容。
- Demo 业务集合由所属 feature 的 infrastructure store 读取，私有对话、问答线程、病例 attempt 和 assessment 使用既有 user-scoped key；API 业务响应只进入内存 cache。
- 会话保存、退出、token 清理和 401 失效由 identity port 与 `platform/http` 协作；页面不直接操作 `apiAccessToken` 或身份 key。
- 学生公开病例只通过 content/training 的公开结果获取；隐藏事实、参考推理、rubric、审核 digest 和内部字段不进入学生公开 DTO。
- PBL 页面只消费个人阶段、阶段缺失要素、任务 cycle/variant 和阈值结果；不暴露正确答案、私有 rubric、完整模型提示或隐藏病例事实。教师工作区没有阶段切换和结果重判公开函数。
- `sendPblMessage(sessionId, content, clientMessageId, interactionStyle)` 要求调用方显式提供下一轮方式；`PblMessage.interactionStyle` 和诊断方式来自 API/Demo adapter 的规范字段，mapper 不以 guided 默认值掩盖畸形 API 响应。页面不直接保存 style，也不选择 adapter。
- T32 后 `sendPblMessage` 返回显式 `PblMessageSubmission`：`responseKind`、`turnScope`、完成 locator 和（仅私人回应时）最小 `privateFollowUp` 结果均由服务端确定。`PblMessage.turnScope`、`replyToMessageId` 与 `PblParticipation.conversationMode` 仅可由 adapter 映射，页面不能传入或推断 scope；完成后的私人消息仍只经当前学生会话读取。
- 知识节点只从 learning 公开接口读取材料、路径和个人练习；未完成四阶段时只显示研讨入口。个人 AI 练习读取时没有参考答案和解析，作答后才显示“按 AI 参考答案”的反馈；它不复用正式成绩或知识点状态接口。
- 教师知识卡接口可读取 AI 标题、来源类型、原学生和目标学生，以支持审核与定向发布；更新 AI 卡必须提交目标学生集合。学生读取同一已批准卡片时只获得学习内容，adapter 不映射来源 snapshot、finding、原学生或其他目标 ID。Demo 使用同一默认原学生和同班追加规则，不以本地数据扩大真实授权。
- 学情页面通过 analytics public API 读取班级证据聚合，不再渲染可见的学生摘要列表；不显示普通问答报告、原始证据事件、自主 PBL 内容或班级排名。教师 PBL 巩固详情允许复用 `getAnalyticsStudent` 展示当前学生近 30 天整体正式学情，但必须先读取有权限的 follow-up plan，再使用 plan 内 `student_id + class_id` 发起查询；路由 studentId/classId 不能作为数据授权依据，analytics 局部失败不能阻断 PBL 详情。学生 PBL 学情仍通过 `getPblLearningReports`/`getPblLearningReport` 读取确定性本人视图；分页汇总中的 `dashboard` 提供本人本周正式评价掌握度、活动区间估算时长、计划完成率、已掌握知识点、结构化诊断次数、四周趋势、薄弱点与确定性总结，并以 `dataBasis` 区分真实证据和 Demo 合成数据。详情保留 `visibility=private|classroom|legacy_shared`，并只映射当前报告相关教师反馈的 `id/planId/actionType/body/createdAt`；任务公开题面、本人得分与反馈不包含原始答案、正确选项、其他学生薄弱点、教师/学生/班级 ID、建议 ID、客户端幂等键或 provider failure。
- 教师端 PBL 通过 `getTeacherPblWorkItems`、`getTeacherPblSessions` 和 `getTeacherPblFollowUps` 读取课堂诊断与正式计划；只有诊断审阅公开反馈写能力。巩固详情只读，`src/features/pbl/public.ts` 不导出跟进反馈写函数；底层历史兼容 port/route 不属于官方页面合同。学生 PBL 页只读取本人提交快照的反馈摘要与下一行动，不能传入 student、class、snapshot 或 session 以扩大数据范围。

## 兼容入口与仓内证据

旧 `src/services/*` facade、旧 `src/data/*` aggregate/mapper/repository 已确认没有仓库内消费者：测试先迁移到真实 feature/platform 模块，再删除这些运行时文件。当前不以“仓库外消费者”作为保留理由，也不假设外部调用者永久依赖旧路径；若未来确有外部调用者，须由统筹提出带具体调用方、版本窗口和移除日期的单独兼容变更。

唯一保留的 `src/data/contracts/openapi.generated.ts` 是既有 OpenAPI 生成输出，不是业务 facade；它由 `npm run contract:generate` 管理，禁止手改。仓内证据可用以下检查复验：

```bash
rg "@/services|@/data" src e2e --glob '!src/data/contracts/openapi.generated.ts'
rg --files src/services src/data
```

预期分别是无旧运行时引用（平台契约对生成物的引用除外）以及仅列出生成 OpenAPI 类型文件。

## 变更规则

新增页面能力时先在所属 feature 的 domain port 定义最小合同，再由 API/Demo adapter 实现，最后在 `public.ts` 暴露稳定函数。跨模块流程上移到 application 或 bootstrap 注入 port；不得通过 `shared` 大包、循环导入或兼容 facade 隐藏未迁移实现。每次变更运行：

```bash
node scripts/frontend-boundaries.mjs --self-test
node scripts/frontend-boundaries.mjs
npm run type-check
npm test
```

上述边界脚本是当前事实，但尚未作为 `frontend:boundaries` 写入 `package.json`；S3 结构调整应直接调用它们。完整发布门禁、远程 CI 和目标 Node 22 环境仍由统筹与平台另行验收。
