# 数据层工程规范

本页维护数据访问合同；业务状态与阶段规则的后续取代关系见[当前产品合同](product/features.md)，实际实施和验收证据查[计划索引](update_plan/README.md)。

## 数据流与边界

```text
Page / Component
  → feature public API
  → bootstrap-assembled application port
  → API adapter or Demo adapter
  → explicit DTO/view mapper
  → platform HTTP or feature-owned local store
  → validated OpenAPI DTO / validated local storage
```

- 页面只能依赖 `src/features/*/public.ts` 和共享 UI/纯工具，不得直接调用 `uni.request`、拼接后端地址或读取 storage key。
- `src/bootstrap/wiring.ts` 在当前运行模式下装配各模块 adapter；API 失败不得回退到 Demo，也不得在 adapter 内自行选择模式。
- 前端 feature 只能按 `public → presentation/application → domain` 和 `infrastructure → domain` 的许可方向依赖；`scripts/frontend-boundaries.mjs` 检查 alias、相对、type-only、re-export、动态导入、平台 I/O 与循环。它目前直接运行，不是假定存在的 npm script。
- `docs/openapi.json` 是可审查的服务端契约快照，`src/data/contracts/openapi.generated.ts` 由它生成，二者禁止手改。
- DTO 在 HTTP 边界使用 Zod 校验；snake_case 到领域字段的转换必须在端点 mapper 中显式完成。
- `src/main.ts` 必须先引入 `src/platform/contracts/validationRuntime.ts`，再装载业务模块。该模块将 Zod 设为 `jitless`，使用解释执行避免微信沙箱不支持的动态 `Function` 编译；它不跳过 schema 校验，不改变 DTO、存储格式、API/Demo 装配或错误边界。相关回归位于 `validationRuntime.spec.ts`。
- `src/features/*/domain/ports.ts` 是按职责拆开的领域契约；`src/types/records.ts` 保留稳定 record，`types/domain.ts` 保留旧页面 view。中文标签由 `src/shared/mappers` 转换。
- `features/reports` 当前只保留学生历史只读查找；普通问答不再创建报告、提交报告或进入教师批阅。训练评分位于 `features/training/domain/scoring.ts`，不复制到 Demo/API 两套实现。
- `src/platform/contracts/conformance.ts` 在类型检查时验证 Zod 输出与生成 DTO 的兼容性；病例推理、阶段答案、学习计划任务和任务启动结果均有嵌套校验。

## 缓存和隐私

- 只有 GET 可以缓存，相同用户、方法、路径和查询参数的并发请求共享一个 Promise。
- 普通列表/详情缓存 30 秒，题目线程缓存 15 秒，分析数据最长 60 秒；未声明 TTL 的请求不缓存。
- 写操作按资源前缀失效缓存；保存或清除 token、401 失效和退出登录会清空全部内存缓存。
- 并发去重共享底层网络 Promise，每个调用者仍校验自己的 schema。缓存上限 128 项。用户变更使用会话版本号拒绝旧结果；资源失效后尚未完成的旧 GET 不得重新填充缓存。
- API 业务响应不得写入本地持久存储。日志只允许记录方法、路由、状态和耗时，不得记录 token、消息、报告或病例隐藏字段。

## 本地存储

- 底层 key、schema version 和 `StoragePort` 由 `src/platform/storage/storage.ts` 管理；学生私有集合仍必须使用用户作用域 key。身份会话的迁移与格式组合位于 `features/identity/infrastructure/sessionStorage.ts`，应用层只依赖 `SessionStoragePort`；其他业务 schema/store 位于所属 feature infrastructure，训练 schema 位于 `platform/storage/caseSchemas.ts` 作为当前兼容集中存储契约。
- 读写都执行运行时 schema 校验。损坏或旧格式值不能进入领域层；迁移必须幂等并保留当前 v2 数据兼容。
- 当前 schema version 为 3。增加字段或改变结构时必须同时新增迁移测试并提升版本。
- 损坏原值保留以便恢复，不用空数组覆盖。旧私有集合仅在验证成功并写入作用域 key 后删除旧 key；API 模式不迁移 Demo 业务集合。

## 错误与兼容

- 后端错误结构为 `{ detail: { code, message } }`；UI 根据稳定 `code` 决定行为，根据 `message` 展示信息。
- 前端过渡期兼容旧的字符串 `detail`，但新增后端代码必须使用统一异常处理器。
- 旧资源列表接口暂时保留；历史记录、报告队列和学生题目优先使用轻量摘要接口。移除旧接口前必须确认无调用方并单独发布弃用说明。
- 查询不存在返回 `undefined`，旧的可空写操作保持 `null`；权限及非法状态转换抛 `AppError`，不能当成空数据。API 404 与旧字符串错误均统一处理。
- Demo 的班级写入和个性化计划写入本轮不模拟服务端能力，显式抛 `UNSUPPORTED_OPERATION`；对应读取保持空模型。核心会话/报告/题目行为由同一组适配器测试验证。
- 报告 client ID 仅在学生范围内唯一；教师按 client ID 命中多条时返回 409，必须改用摘要中的 report ID。学生页使用明确的 `findReportByConversationAsync`，避免纯数字 client ID 与报告 ID 混淆。

旧 `src/services`、`src/data` 运行时入口已清理，仓库内测试已迁移到真实 feature/platform 模块；仅生成 OpenAPI 类型保留在 `src/data/contracts/openapi.generated.ts`。新代码不得继续引用已删除路径。

# T30：证据账本与读模型

`learning_evidence_events` 与 `learning_evidence_metrics` 是 T30 的 append-only 最小事实账本（Alembic `20260913_0025`）。事件只保存来源、版本、权威级别、可见范围、时间和统计指标；不保存回答、题干、prompt、rubric、隐藏病例事实、nickname 或教师自由文本。唯一 `dedupe_key` 保证重试不重复计数；非空 evidence 表 downgrade 必须拒绝，migration 本身不扫描或回写业务数据。

来源 application 依据服务端事实构造证据：个人问答、自主 PBL 和未审核 AI 练习为 `personal_unverified/student_only`；审核病例、教师采用的 PBL 任务与轮次评价才可进入教师统计。analytics 通过 `LearningEvidenceReadPort` 读取并过滤 owned class、时间、authority 和 visibility；个人事件不进入教师 overview、知识排名、关注学生或学生的教师详情。小于 5 名参与学生继续隐藏知识薄弱排名，缺少分数保持 NULL，不以零填补。

API 与 Demo 都经各自 feature adapter 返回同一 analytics 统计合同。教师端不提供 evidence 事件列表；学情页面只显示聚合、来源、更新时间和必要下钻。回填脚本 `backend/scripts/backfill_learning_evidence.py` 默认 dry-run，apply 必须显式开发环境确认与新备份路径，生产、未知数据库、普通问答报告分数和自主诊断均不在允许范围内。

## 分页和查询预算

- 会话/报告摘要为 `{ items, total, limit, offset }`，默认 20、最大 100，按 `updated_at DESC, id DESC` 稳定排序；预览最多 160 字。报告计数是全部可见数据的计数，不是当前页计数。
- 学生题目 feed 返回全部可见普通题目的轻量数组，SQL 使用集合/EXISTS 查询，HTTP 为单次请求；不附带消息或病例隐藏事实。
- 分页刷新增加请求版本保护，追加页去重并保留已加载记录；追加失败允许再次点击加载更多。页码式 offset 不承诺写入期间的快照隔离，刷新可重新取得最新排序。

## 稳定错误码

| code                                  | 含义                             |
| ------------------------------------- | -------------------------------- |
| AUTH_REQUIRED / ROLE_REQUIRED         | 未登录、身份失效或需要指定角色   |
| FORBIDDEN                             | 没有访问权限                     |
| RESOURCE_NOT_FOUND                    | 不存在或对当前角色不可见         |
| STATE_CONFLICT                        | 状态冲突或查询标识不唯一         |
| VALIDATION_ERROR / INVALID_DATE_RANGE | 输入校验失败                     |
| SERVICE_ERROR                         | 服务端异常（不泄漏内部错误内容） |
| CONTRACT_ERROR                        | 前端拒绝异常 DTO                 |
| NETWORK_ERROR / API_CONFIG_ERROR      | 网络或配置异常                   |
| STALE_SESSION                         | 请求属于已失效的旧会话           |
| UNSUPPORTED_OPERATION                 | 当前适配器未提供该能力           |

## 契约工作流

修改 Pydantic schema 或路由后，在审阅生成差异的工作树执行：

```bash
npm run contract:generate
npm run contract:check
```

`contract:generate` 会写入 `docs/openapi.json`、`src/data/contracts/openapi.generated.ts` 与 fixture；`contract:check` 在系统临时目录生成并按内容比较，不改写快照。远程 CI 是否已接入仍须由平台证据确认。提交必须同时包含后端改动、OpenAPI 快照、生成类型、mapper 和契约测试。

# T14：PBL 当前合同

PBL 诊断快照沿用版本化 schema，知识薄弱点只能引用数据库 active `pathology-general-v4` 的稳定知识点编码，推理问题单独引用能力维度。provider 的 `allowed_points`、服务端结果校验和报告标签都从同一 `KnowledgeCatalogPort` 读取，不存在静态目录 fallback。请求携带 participation 当前阶段和证据起始 revision；响应的阶段证据只允许引用当前窗口内的学生消息。教师队列按最新有效诊断分页（每页 20 条），详情保留 revision。

知识目录通过 content application port 暴露。API、PBL、学习证据、普通问答、内容发布和统计不得直接查询目录表，也不得导入 Python/TypeScript 节点常量。`prerequisite_codes` 从持久化依赖边投影；结构化 `dependencies` 同时返回关系类型、机制摘要、限定条件、可信度、来源和审核状态。Demo 快照从迁移后的隔离数据库导出，仍不代表生产数据或专家审核。

采用发布在一个事务中写入编辑后的正式题、来源、两轮任务和通知；两轮资源不完整时原子失败。`client_message_id` 返回同一次处理结果，不以最新快照替代重试结果。学习计划保持 `(student_id, source_type, source_id)` 唯一约束，并在同一计划内以 cycle 和 variant 字段区分两轮。API 与 Demo adapter 都返回个人阶段、逐项判定依据和耗尽状态；API 错误不回退 Demo。

# T15：PBL 学情报告合同

`GET /student/pbl-learning-reports` 和 `GET /student/pbl-learning-reports/{session_id}` 按当前学生聚合 PBL 报告。即使本人没有 participation，只要本人收到该课堂的学习计划，也会得到标记为“课堂共同训练”的报告；其他学生的诊断不会进入响应。总览按 session 输出状态统计、下一行动、本人反复出现的目标和最近课堂，详情输出四阶段证据、个人薄弱点、任务、两轮目标对照和判定时间线，并返回 `private|classroom|legacy_shared` 可见范围。详情可返回当前报告快照已有的教师反馈正文，但仅序列化 `id`、关联计划、动作类型、正文和时间；教师/学生/班级身份、建议 ID 和客户端幂等键仍不得进入响应。

前端 `reportContract.ts` 对 API DTO 做 Zod 校验和显式 mapper，Demo repository 返回相同领域合同。报告只包含任务公开题面、本人得分/反馈和证据是否存在，不包含完整消息、原始答案、正确选项、private rubric、模型提示、隐藏病例事实、教师 ID 或 provider failure；API 请求失败仍不得切换 Demo。

# T17：统一研讨合同

学生统一入口使用 `GET /student/classes` 和 `/student/learning-dialogues` 的列表、创建、start、详情及消息接口。学生主动研讨创建以学生范围内的 `client_session_id` 幂等，班级可为空；提供班级时服务端校验有效范围。课堂研讨仍要求有效班级。教师课堂通过 start 首次写入 `interaction_style`，相同方式幂等、不同方式冲突。消息仍以 `client_message_id` 幂等，并保持完成锁定。

新 AI 推理只产生 schema v4，请求与响应均携带 `interaction_style`。CheckedGateway 拒绝方式不匹配、非当前阶段学生消息证据和越级完成；direct 的首问只能得到解释与理解检验，不能单凭提问进入 ready。schema v3 历史诊断仍可查看和采用。旧 QA 接口继续兼容但标记 deprecated，旧 conversation/report 数据不自动写入 PBL session、snapshot 或 learning plan。

# T31：逐轮方式、幂等与 schema v5

`POST /student/learning-dialogues/{session_id}/messages` 接受可选 `interaction_style`；旧客户端省略时使用 participation 最近一次已生效方式或 guided 默认。规范响应在 participation、每条消息和诊断快照上返回非空方式。相同 `client_message_id` 只有内容与方式均相同才返回原结果，任一变化均为 409；provider 请求方式来自已持久化消息，不从后来变化的页面状态推断。

新推理只产生 schema v5，并以严格 `learning_response.opening/key_points/next_step` 通过运行时校验；服务端确定性渲染三段文本。schema v3/v4 历史仍可读取。直接讲解只改变教学表达，不改变证据来源、相邻阶段推进、完成锁定、教师范围或 T30 自主私有规则。

# T32：完成边界与私人续问合同

完成 participation 必须有唯一的 `completion_snapshot_id` 和 `evidence_completed_revision`；消息持久化 `turn_scope`，assistant reply 以唯一 `reply_to_message_id` 建立一对一关联。新请求先按 `client_message_id` 查询既有结果：触发完成的同 ID 重试仍返回 `evidence_assessment`，只有完成后新的 ID 才成为 `private_follow_up`。同 ID 的内容、方式或已保存 scope 不一致统一冲突。

私人结果写入独立表并返回 `response_kind=private_follow_up`、`private_follow_up` 状态及冻结 participation；它不写 `PblDiagnosticSnapshot`、建议题、教师工作项或 `learning_evidence_events`。API mapper 对 completed、locator、scope 与 result 的组合执行运行时校验，页面和 Demo 都不得从页面状态推断或提交 scope。

# T40：课堂 PBL 知识补充卡与定向发布合同

新推理产生 schema v6；在 schema v5 的统一 `learning_response` 基础上增加严格的 `recommended_knowledge_cards`。每张卡必须引用当前结果中已确认的 finding、引用 active 知识目录 point code，并提供标题、回忆提示与解释。只有 `session_kind=classroom`、完成且 `ready` 的证据结果会通过 `PblKnowledgeCardPublicationPort` 写入 content；自主研讨、provider failure、未完成轮次和 `private_follow_up` 都不产生卡片。

content 以来源 snapshot 和 position 保证幂等，初始状态为 draft，目标学生默认只有原学生。教师更新 AI 卡时必须保留原学生，新增目标只能来自本人拥有课堂的有效班级成员；提交后沿用既有医学审核，批准后学生列表按 `target_student_ids` 过滤。教师 API 可返回来源与目标以供审核，学生 DTO 必须移除来源 snapshot、finding、原学生和目标列表。API/Demo adapter 使用同一字段和选择边界，API 失败不回退 Demo。

# T20：私有提交与自主练习合同

`GET/POST /student/learning-dialogues/{session_id}/submission` 是 deprecated 兼容入口：只有既有共享快照可由本人只读返回，新自主研讨稳定返回冲突且不写入。教师诊断列表默认只读取课堂 ready snapshot；历史共享记录必须显式筛选且只读，后续私有快照不扩大可见性。课堂反馈、采用和正式任务仍由服务端按班级 owner 与课堂来源校验。

`/learning/knowledge-points/{point_code}/study` 读取版本化材料和学习路径，`start` 幂等创建或续接关联研讨。只有合法 PBL 完成证据或历史正式入口才开放后续练习。`/learning/study-paths/{path_id}/practices` 与 `/learning/self-practices/*` 仅验证本人归属；读取题目不返回参考答案和解析，作答后才返回“按 AI 参考答案”的个人反馈。题目、作答和到期复习独立保存，不写入正式成绩、掌握度或 T14 判定。

# T21：教师 PBL 工作区与反馈合同

`GET /teacher/pbl-work-items`、详情和 `/feedback` 只允许接收教师读取。工作项状态由快照建议和不可覆盖的反馈记录推导为 `pending`、`responded`、`task_published` 或 `closed`，状态过滤在分页之前完成。反馈正文限制为 1–1000 个字符，`client_feedback_id` 在教师范围内幂等；`task_published` 在同一事务内完成反馈、建议采用、两轮正式任务和通知，失败时整体回滚。关闭后的项目拒绝后续反馈和旧采用入口。

`GET /teacher/pbl-sessions` 与班级 session dashboard 仅接受教师拥有的有效班级和课堂 session；看板以批量快照反馈、建议状态和既有学习计划聚合学生进度。`GET /teacher/pbl-follow-ups` 与详情只返回正式任务已发布的记录。学生提交读取接口只返回本人固定提交快照对应的反馈时间线、教师状态和下一行动，不返回教师内部字段、答案或未提交记录。API 与 Demo 都通过 `features/pbl` port 返回同一领域合同，失败不会回退数据源。

# T29：问答报告班级合同

`ReportRead`/`ReportSummaryRead` 固定返回 `report_kind=qa_learning_report`、`class_id`、`class_name`（提交时快照）；运行时 Zod 用 literal 校验 kind，未知 kind、非法 class 形态直接拒绝。`GET /reports/summaries` 与 `GET /reports` 支持可选 `class_id`：教师筛选本人班级（非本人班级 404 而非空集合），计数与列表来自同一可见集合。`POST /reports/{id}/submit` 必须带 `{class_id}`，服务端校验 active membership 后原子写入班级与 `pending_review`；换班/重复提交为 409。Demo adapter 同合同：教师列表只返回本人 Demo 班级中已归属的非草稿报告，提交校验 `getStudentActiveClasses()`，本地 `reportSchema` 以 literal default 兼容旧数据（无需提升 storage version）。公开查询选项统一为 `getReportSummariesAsync({limit?, offset?, classId?})` 与 `submitReportForReviewAsync(conversationId, classId)`。
