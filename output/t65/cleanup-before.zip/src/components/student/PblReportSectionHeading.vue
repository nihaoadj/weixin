<template>
  <view class="section-heading">
    <text class="section-kicker">{{ kicker }}</text>
    <text class="section-title">{{ title }}</text>
    <text class="section-note">{{ note }}</text>
  </view>
</template>

<script setup lang="ts">
defineProps<{
  kicker: string
  title: string
  note: string
}>()
</script>

<style scoped>
.section-heading {
  display: flex;
  width: 100%;
  min-width: 0;
  padding-bottom: 22rpx;
  box-sizing: border-box;
  flex-direction: column;
  gap: 8rpx;
  border-bottom: 1rpx solid var(--med-divider);
}
.section-kicker {
  align-self: flex-start;
  color: var(--med-clinical);
  font-size: 20rpx;
  font-weight: 750;
  letter-spacing: 2rpx;
}
.section-title {
  color: var(--med-ink);
  font-size: 30rpx;
  font-weight: 800;
  line-height: 1.4;
}
.section-note {
  color: var(--med-muted);
  font-size: 23rpx;
  line-height: 1.65;
}
</style>
