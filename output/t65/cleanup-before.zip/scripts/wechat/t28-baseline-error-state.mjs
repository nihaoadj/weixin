import { mkdirSync, writeFileSync } from 'node:fs'
import { resolve } from 'node:path'
import { fileURLToPath } from 'node:url'
import { Launcher } from '@weapp-vite/miniprogram-automator'
import { diagnose } from './doctor.mjs'

// Supplements the T28 stage-0 baseline with a recoverable error state of the
// follow-up detail page: a well-formed but nonexistent plan id fails the
// detail load through the page's own load path. Navigation is platform-level;
// screenshots use the internal channel.
await diagnose({ probe: false })

const port = Number(process.env.WECHAT_AUTO_PORT || 9421)
const root = fileURLToPath(new URL('../../', import.meta.url))
const output = resolve(root, 'output/wechat', `t28-baseline-error-${Date.now()}`)
const wait = (ms) => new Promise((r) => setTimeout(r, ms))

async function captureBackgroundScreenshot(path) {
  const socket = new WebSocket(`ws://127.0.0.1:${port}`)
  const data = await new Promise((resolveCapture, rejectCapture) => {
    const timer = setTimeout(() => rejectCapture(new Error('timeout:capture')), 30000)
    const finish = (value) => {
      clearTimeout(timer)
      if (value instanceof Error) rejectCapture(value)
      else resolveCapture(value)
    }
    socket.onerror = () => finish(new Error('capture-unavailable'))
    socket.onopen = () => socket.send(JSON.stringify({ id: 'c', method: 'App.captureScreenshot', params: {} }))
    socket.onmessage = ({ data: payload }) => {
      let response
      try {
        response = JSON.parse(String(payload))
      } catch {
        return
      }
      if (response.id === 'c' && typeof response.result?.data === 'string') finish(response.result.data)
    }
  })
  writeFileSync(path, data, 'base64')
  socket.close()
}

let miniProgram
try {
  miniProgram = await new Launcher().connect({ wsEndpoint: `ws://127.0.0.1:${port}` })
  mkdirSync(output, { recursive: true })
  let opened = false
  try {
    await miniProgram.navigateTo({ url: '/pages/teacher/pbl-follow-up-detail/pbl-follow-up-detail?planId=999999' })
    opened = true
  } catch (error) {
    console.log('navigateTo rejected (tolerated):', String(error).slice(0, 120))
  }
  await wait(2600)
  const page = await miniProgram.currentPage()
  console.log('PAGE', page.path, 'opened:', opened)
  await captureBackgroundScreenshot(resolve(output, '07-follow-up-load-error.png'))
  console.log('CAPTURED 07-follow-up-load-error.png')
  try {
    await miniProgram.navigateBack()
  } catch {
    // The best-effort back walk must not mask the captured evidence above.
  }
  console.log(JSON.stringify({ output, status: 'ok' }))
} finally {
  miniProgram?.disconnect()
}
