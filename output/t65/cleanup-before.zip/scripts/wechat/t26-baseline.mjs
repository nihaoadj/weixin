import assert from 'node:assert/strict'
import { mkdirSync, writeFileSync } from 'node:fs'
import { resolve } from 'node:path'
import { fileURLToPath } from 'node:url'
import { Launcher } from '@weapp-vite/miniprogram-automator'
import { diagnose } from './doctor.mjs'

// T26 evidence helper: walks the four teacher workspaces with real taps on
// rendered navigation controls and captures Developer Tools internal
// screenshots. With --student it also walks the student primary pages after a
// real logout/login role switch. It never sets data, calls business methods,
// writes storage or clears tool state. Run:
//   node scripts/wechat/t26-baseline.mjs [--student]
await diagnose({ probe: false })

const port = Number(process.env.WECHAT_AUTO_PORT || 9420)
const root = fileURLToPath(new URL('../../', import.meta.url))
const includeStudent = process.argv.includes('--student')
const output = resolve(root, 'output/wechat', `t26-baseline-${Date.now()}`)
const timeoutMs = 10000
const within = (promise, label) =>
  Promise.race([
    promise,
    new Promise((_, reject) => setTimeout(() => reject(new Error(`timeout:${label}`)), timeoutMs)),
  ])
const wait = (milliseconds) => new Promise((resolveWait) => setTimeout(resolveWait, milliseconds))

async function current(miniProgram, expectedPath) {
  let lastPath = ''
  for (let attempt = 0; attempt < 48; attempt += 1) {
    const page = await within(miniProgram.currentPage(), `page:${expectedPath}`)
    lastPath = page.path
    if (page.path === expectedPath) return page
    await wait(300)
  }
  throw new Error(`route:${expectedPath} (stuck at ${lastPath})`)
}

async function findComponentRoot(page, selector) {
  const componentHosts = [
    ...(await within(page.$$('component', { fallback: false, timeout: timeoutMs }), `component-hosts:${selector}`)),
  ]
  const seen = new Set()
  while (componentHosts.length) {
    const host = componentHosts.shift()
    if (!host || seen.has(host)) continue
    seen.add(host)
    const rootElement = await within(host.$(selector), `component-root:${selector}`)
    if (rootElement) return rootElement
    componentHosts.push(...(await within(host.$$('component'), `nested-component-hosts:${selector}`)))
  }
  return null
}

async function captureBackgroundScreenshot(path) {
  let lastError
  for (let attempt = 0; attempt < 3; attempt += 1) {
    const socket = new WebSocket(`ws://127.0.0.1:${port}`)
    try {
      const data = await new Promise((resolveCapture, rejectCapture) => {
        const timer = setTimeout(() => rejectCapture(new Error('timeout:capture-screenshot')), 30000)
        const finish = (value) => {
          clearTimeout(timer)
          if (value instanceof Error) rejectCapture(value)
          else resolveCapture(value)
        }
        socket.onerror = () => finish(new Error('capture-screenshot-unavailable'))
        socket.onopen = () =>
          socket.send(JSON.stringify({ id: 'capture', method: 'App.captureScreenshot', params: {} }))
        socket.onmessage = ({ data: payload }) => {
          try {
            const response = JSON.parse(String(payload))
            if (response.id !== 'capture') return
            if (typeof response.result?.data !== 'string') return finish(new Error('capture-screenshot-missing-data'))
            finish(response.result.data)
          } catch {
            finish(new Error('capture-screenshot-invalid-response'))
          }
        }
      })
      writeFileSync(path, data, 'base64')
      return
    } catch (error) {
      lastError = error
      await wait(750)
    } finally {
      socket.close()
    }
  }
  throw lastError
}

async function ensureTeacher(miniProgram) {
  let page = await within(miniProgram.currentPage(), 'page:any')
  if (page.path === 'pages/teacher/index/index') return page
  if (page.path === 'pages/login/login') {
    const teacherRole = await within(page.$('.role-button.teacher', { fallback: false }), 'teacher-role')
    assert.ok(teacherRole, 'The teacher role button is not rendered.')
    await within(teacherRole.tap(), 'teacher-role-tap')
    return current(miniProgram, 'pages/teacher/index/index')
  }
  // Student primary pages return through the 研讨 tab, the only page with a
  // real logout control, then follow the ordinary login path.
  const navRoot = await findComponentRoot(page, '.student-nav')
  assert.ok(navRoot, `No teacher, login or student navigation found on ${page.path}.`)
  const navItems = await within(navRoot.$$('.student-nav__item'), 'student-nav-items:any')
  const navLabels = []
  for (const item of navItems) navLabels.push(await within(item.text(), 'student-nav-label:any'))
  const pblIndex = navLabels.findIndex((label) => label.trim() === '研讨')
  assert.ok(pblIndex >= 0, `The 研讨 tab is not rendered on ${page.path}.`)
  await within(navItems[pblIndex].tap(), 'student-tap:研讨')
  const pblPage = await current(miniProgram, 'pages/student/pbl/pbl')
  const accountBar = await within(pblPage.$('.account-bar', { fallback: false }), 'account-bar')
  assert.ok(accountBar, 'The student account bar is not rendered.')
  const accountButtons = await within(accountBar.$$('button'), 'account-bar-buttons')
  let tapped = false
  for (const button of accountButtons) {
    if ((await within(button.text(), 'account-button-label')).trim() === '退出') {
      await within(button.tap(), 'student-logout-tap')
      tapped = true
      break
    }
  }
  assert.ok(tapped, 'The student logout control is not rendered.')
  const login = await current(miniProgram, 'pages/login/login')
  const teacherRole = await within(login.$('.role-button.teacher', { fallback: false }), 'teacher-role')
  assert.ok(teacherRole, 'The teacher role button is not rendered.')
  await within(teacherRole.tap(), 'teacher-role-tap')
  return current(miniProgram, 'pages/teacher/index/index')
}

async function findAllDeep(page, selector) {
  const matches = []
  const seen = new Set()
  const queue = [
    ...(await within(page.$$('component', { fallback: false, timeout: timeoutMs }), `component-hosts:${selector}`)),
  ]
  while (queue.length) {
    const host = queue.shift()
    if (!host || seen.has(host)) continue
    seen.add(host)
    for (const element of await within(host.$$(selector), `component-root:${selector}`)) matches.push(element)
    queue.push(...(await within(host.$$('component'), `nested-component-hosts:${selector}`)))
  }
  return matches
}

async function findVisibleDeep(page, selector) {
  // v-show keeps hidden workspaces in the tree with zero size; only a
  // non-zero box proves the element the user can see and tap.
  for (const element of await findAllDeep(page, selector)) {
    const size = await within(element.size(), `visible-size:${selector}`)
    if (size.width > 0 && size.height > 0) return element
  }
  return null
}

let miniProgram
try {
  console.log('STEP connect')
  miniProgram = await within(new Launcher().connect({ wsEndpoint: `ws://127.0.0.1:${port}` }), 'connect')
  let page = await ensureTeacher(miniProgram)
  mkdirSync(output, { recursive: true })

  const nav = await findComponentRoot(page, '.teacher-nav')
  assert.ok(nav, 'The teacher primary navigation is not rendered.')
  const items = await within(nav.$$('.teacher-nav__item'), 'teacher-navigation-items')
  const labels = []
  for (const item of items) labels.push(await within(item.text(), 'teacher-navigation-label'))
  console.log(JSON.stringify({ navLabels: labels }))

  const plan = [
    { label: '待办', file: '01-overview.png' },
    { label: '学情', file: '02-insights-followups.png' },
    { label: '内容', file: '03-content-diagnostics.png' },
    { label: 'PBL', file: '04-pbl-classrooms.png' },
  ]
  for (const step of plan) {
    const index = labels.findIndex((label) => label.trim() === step.label)
    assert.ok(index >= 0, `Workspace label ${step.label} is not rendered.`)
    await within(items[index].tap(), `tap:${step.label}`)
    // Let the workspace finish its own data load before capturing.
    await wait(1600)
    page = await current(miniProgram, 'pages/teacher/index/index')
    await captureBackgroundScreenshot(resolve(output, step.file))
    console.log(`CAPTURED ${step.file}`)
  }

  if (process.argv.includes('--classroom')) {
    // Real taps only: expand the creation form, capture, collapse it, then
    // open and close the stage dashboard without creating or closing data.
    const pblNav = await findComponentRoot(page, '.teacher-nav')
    const pblItems = await within(pblNav.$$('.teacher-nav__item'), 'nav-items-classroom')
    const pblLabels = []
    for (const item of pblItems) pblLabels.push(await within(item.text(), 'nav-label-classroom'))
    await within(pblItems[pblLabels.findIndex((label) => label.trim() === 'PBL')].tap(), 'tap-pbl')
    await wait(1600)
    page = await current(miniProgram, 'pages/teacher/index/index')
    const createToggle = await findVisibleDeep(page, '.create-toggle')
    assert.ok(createToggle, 'The classroom create toggle is not rendered.')
    await within(createToggle.tap(), 'open-create')
    await wait(900)
    await captureBackgroundScreenshot(resolve(output, '06-classroom-create-form.png'))
    console.log('CAPTURED 06-classroom-create-form.png')
    await within(createToggle.tap(), 'close-create')
    await wait(600)
    const dashboardLink = await findVisibleDeep(page, '.session-row__action')
    assert.ok(dashboardLink, 'The classroom dashboard entry is not rendered.')
    await within(dashboardLink.tap(), 'open-dashboard')
    await wait(1600)
    await captureBackgroundScreenshot(resolve(output, '07-classroom-dashboard.png'))
    console.log('CAPTURED 07-classroom-dashboard.png')
    const back = await findVisibleDeep(page, '.dashboard-back')
    assert.ok(back, 'The dashboard back control is not rendered.')
    await within(back.tap(), 'close-dashboard')
    await wait(900)
  }

  if (process.argv.includes('--advanced')) {
    // Real tap on the exact-filter expander to evidence the collapsed layout
    // and the expanded labeled inputs; state stays component-local.
    const nav2 = await findComponentRoot(page, '.teacher-nav')
    const nav2Items = await within(nav2.$$('.teacher-nav__item'), 'nav-items-advanced')
    const nav2Labels = []
    for (const item of nav2Items) nav2Labels.push(await within(item.text(), 'nav-label-advanced'))
    await within(nav2Items[nav2Labels.findIndex((label) => label.trim() === '内容')].tap(), 'tap-content-advanced')
    await wait(1600)
    page = await current(miniProgram, 'pages/teacher/index/index')
    const toggle = await findVisibleDeep(page, '.teacher-filter-panel__toggle')
    assert.ok(toggle, 'The exact-filter toggle is not rendered.')
    // The panel keeps its local expansion across walks in the same session.
    const expandedBefore = await within(toggle.attribute('aria-expanded'), 'toggle-state')
    if (String(expandedBefore) !== 'true') {
      await within(toggle.tap(), 'toggle-advanced')
      await wait(900)
    }
    const expandedAfter = await within(toggle.attribute('aria-expanded'), 'toggle-state-after')
    assert.equal(String(expandedAfter), 'true', 'The exact-filter area did not expand.')
    await captureBackgroundScreenshot(resolve(output, '05-advanced-filters-open.png'))
    console.log('CAPTURED 05-advanced-filters-open.png')
  }

  if (process.argv.includes('--pages')) {
    // Walk the overview management entries with real taps: classes page,
    // in-workspace analytics section, and the knowledge-cards page.
    const homeNav = await findComponentRoot(page, '.teacher-nav')
    const homeItems = await within(homeNav.$$('.teacher-nav__item'), 'nav-items-pages')
    const homeLabels = []
    for (const item of homeItems) homeLabels.push(await within(item.text(), 'nav-label-pages'))
    await within(homeItems[homeLabels.findIndex((label) => label.trim() === '待办')].tap(), 'tap-overview')
    await wait(1600)
    page = await current(miniProgram, 'pages/teacher/index/index')
    let managementRows = (await findAllDeep(page, '.management-row')).filter(Boolean)
    assert.ok(managementRows.length >= 3, 'The management rows are not rendered.')
    await within(managementRows[0].tap(), 'open-classes')
    await wait(1800)
    await captureBackgroundScreenshot(resolve(output, '08-teacher-classes.png'))
    console.log('CAPTURED 08-teacher-classes.png')
    await within(miniProgram.navigateBack(), 'classes-back')
    await wait(1200)
    page = await current(miniProgram, 'pages/teacher/index/index')
    managementRows = (await findAllDeep(page, '.management-row')).filter(Boolean)
    await within(managementRows[1].tap(), 'open-analytics')
    await wait(2000)
    await captureBackgroundScreenshot(resolve(output, '09-teacher-analytics.png'))
    console.log('CAPTURED 09-teacher-analytics.png')
    managementRows = (await findAllDeep(page, '.management-row')).filter(Boolean)
    await within(managementRows[2].tap(), 'open-knowledge-cards')
    await wait(1800)
    await captureBackgroundScreenshot(resolve(output, '10-teacher-knowledge-cards.png'))
    console.log('CAPTURED 10-teacher-knowledge-cards.png')
    await within(miniProgram.navigateBack(), 'knowledge-cards-back')
    await wait(1200)
    page = await current(miniProgram, 'pages/teacher/index/index')
  }

  if (includeStudent) {
    const logout = await within(page.$('.logout', { fallback: false }), 'teacher-logout')
    assert.ok(logout, 'The teacher logout control is not rendered.')
    await within(logout.tap(), 'logout-tap')
    const login = await current(miniProgram, 'pages/login/login')
    const studentRole = await within(login.$('.role-button.student', { fallback: false }), 'student-role')
    assert.ok(studentRole, 'The student role button is not rendered.')
    await within(studentRole.tap(), 'student-role-tap')
    let studentPage = await current(miniProgram, 'pages/student/pbl/pbl')
    const studentPlan = [
      { label: '研讨', file: '05-student-pbl.png', path: 'pages/student/pbl/pbl' },
      { label: '学习', file: '06-student-learning.png', path: 'pages/student/learning/index' },
      { label: '学情', file: '07-student-insights.png', path: 'pages/student/insights/index' },
    ]
    for (const step of studentPlan) {
      // Items live inside the nested StudentNav component, so query that
      // component root directly instead of crossing the host boundary.
      const navRoot = await findComponentRoot(studentPage, '.student-nav')
      assert.ok(navRoot, `The student primary navigation is not rendered on ${studentPage.path}.`)
      const navItems = await within(navRoot.$$('.student-nav__item'), `student-nav-items:${step.path}`)
      const navLabels = []
      for (const item of navItems) navLabels.push(await within(item.text(), 'student-nav-label'))
      const target = navLabels.findIndex((label) => label.trim() === step.label)
      assert.ok(target >= 0, `Student label ${step.label} is not rendered on ${studentPage.path}.`)
      await within(navItems[target].tap(), `student-tap:${step.label}`)
      await wait(1600)
      studentPage = await current(miniProgram, step.path)
      await captureBackgroundScreenshot(resolve(output, step.file))
      console.log(`CAPTURED ${step.file}`)
    }
  }
  console.log(JSON.stringify({ output, status: 'ok' }))
} finally {
  miniProgram?.disconnect()
}
