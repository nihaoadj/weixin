const name = process.argv[2] || 'this command'

console.error(
  `${name} is retired: it uses the unsupported App.* WebSocket protocol. ` +
    'Use wechatide.cmd automation_element_action, automation_runtime_info, simulator_refresh, and simulator_screenshot instead. ' +
    'See docs/wechat.md.',
)
process.exitCode = 1
