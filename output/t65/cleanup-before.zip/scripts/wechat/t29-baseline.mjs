import assert from 'node:assert/strict'
import { mkdirSync, writeFileSync } from 'node:fs'
import { resolve } from 'node:path'
import { fileURLToPath } from 'node:url'
import { Launcher } from '@weapp-vite/miniprogram-automator'
import { diagnose } from './doctor.mjs'

// T29 stage-0 baseline: real taps across the four teacher workspaces and the
// student report page before any T29 code change. Internal screenshots only,
// no data mutation, no business-method calls, no OS input. Run:
//   node scripts/wechat/t29-baseline.mjs
await diagnose({ probe: false })

const port = Number(process.env.WECHAT_AUTO_PORT || 9421)
const root = fileURLToPath(new URL('../../', import.meta.url))
const output = resolve(root, 'output/wechat', `t29-baseline-${Date.now()}`)
const timeoutMs = 10000
const within = (promise, label) =>
  Promise.race([
    promise,
    new Promise((_, reject) => setTimeout(() => reject(new Error(`timeout:${label}`)), timeoutMs)),
  ])
const wait = (milliseconds) => new Promise((resolveWait) => setTimeout(resolveWait, milliseconds))

async function current(miniProgram, expectedPath) {
  let lastPath = ''
  for (let attempt = 0; attempt < 48; attempt += 1) {
    const page = await within(miniProgram.currentPage(), `page:${expectedPath}`)
    lastPath = page.path
    if (page.path === expectedPath) return page
    await wait(300)
  }
  throw new Error(`route:${expectedPath} (stuck at ${lastPath})`)
}

async function findComponentRoot(page, selector) {
  const componentHosts = [
    ...(await within(page.$$('component', { fallback: false, timeout: timeoutMs }), `component-hosts:${selector}`)),
  ]
  const seen = new Set()
  while (componentHosts.length) {
    const host = componentHosts.shift()
    if (!host || seen.has(host)) continue
    seen.add(host)
    const rootElement = await within(host.$(selector), `component-root:${selector}`)
    if (rootElement) return rootElement
    componentHosts.push(...(await within(host.$$('component'), `nested-component-hosts:${selector}`)))
  }
  return null
}

async function captureBackgroundScreenshot(path) {
  let lastError
  for (let attempt = 0; attempt < 3; attempt += 1) {
    const socket = new WebSocket(`ws://127.0.0.1:${port}`)
    try {
      const data = await new Promise((resolveCapture, rejectCapture) => {
        const timer = setTimeout(() => rejectCapture(new Error('timeout:capture-screenshot')), 30000)
        const finish = (value) => {
          clearTimeout(timer)
          if (value instanceof Error) rejectCapture(value)
          else resolveCapture(value)
        }
        socket.onerror = () => finish(new Error('capture-screenshot-unavailable'))
        socket.onopen = () =>
          socket.send(JSON.stringify({ id: 'capture', method: 'App.captureScreenshot', params: {} }))
        socket.onmessage = ({ data: payload }) => {
          try {
            const response = JSON.parse(String(payload))
            if (response.id !== 'capture') return
            if (typeof response.result?.data !== 'string') return finish(new Error('capture-screenshot-missing-data'))
            finish(response.result.data)
          } catch {
            finish(new Error('capture-screenshot-invalid-response'))
          }
        }
      })
      writeFileSync(path, data, 'base64')
      return
    } catch (error) {
      lastError = error
      await wait(750)
    } finally {
      socket.close()
    }
  }
  throw lastError
}

async function ensureTeacher(miniProgram) {
  let page = await within(miniProgram.currentPage(), 'page:any')
  if (page.path === 'pages/teacher/index/index') return page
  if (page.path === 'pages/login/login') {
    const teacherRole = await within(page.$('.role-button.teacher', { fallback: false }), 'teacher-role')
    assert.ok(teacherRole, 'The teacher role button is not rendered.')
    await within(teacherRole.tap(), 'teacher-role-tap')
    return current(miniProgram, 'pages/teacher/index/index')
  }
  const navRoot = await findComponentRoot(page, '.student-nav')
  assert.ok(navRoot, `No teacher, login or student navigation found on ${page.path}.`)
  const navItems = await within(navRoot.$$('.student-nav__item'), 'student-nav-items:any')
  const navLabels = []
  for (const item of navItems) navLabels.push(await within(item.text(), 'student-nav-label:any'))
  const pblIndex = navLabels.findIndex((label) => label.trim() === '研讨')
  assert.ok(pblIndex >= 0, `The 研讨 tab is not rendered on ${page.path}.`)
  await within(navItems[pblIndex].tap(), 'student-tap:研讨')
  const pblPage = await current(miniProgram, 'pages/student/pbl/pbl')
  const accountBar = await within(pblPage.$('.account-bar', { fallback: false }), 'account-bar')
  assert.ok(accountBar, 'The student account bar is not rendered.')
  const accountButtons = await within(accountBar.$$('button'), 'account-bar-buttons')
  let tapped = false
  for (const button of accountButtons) {
    if ((await within(button.text(), 'account-button-label')).trim() === '退出') {
      await within(button.tap(), 'student-logout-tap')
      tapped = true
      break
    }
  }
  assert.ok(tapped, 'The student logout control is not rendered.')
  const login = await current(miniProgram, 'pages/login/login')
  const teacherRole = await within(login.$('.role-button.teacher', { fallback: false }), 'teacher-role')
  assert.ok(teacherRole, 'The teacher role button is not rendered.')
  await within(teacherRole.tap(), 'teacher-role-tap')
  return current(miniProgram, 'pages/teacher/index/index')
}

async function openTeacherWorkspace(miniProgram, page, label) {
  const nav = await findComponentRoot(page, '.teacher-nav')
  assert.ok(nav, 'The teacher primary navigation is not rendered.')
  const items = await within(nav.$$('.teacher-nav__item'), `teacher-nav-items:${label}`)
  const labels = []
  for (const item of items) labels.push(await within(item.text(), 'teacher-nav-label'))
  const index = labels.findIndex((text) => text.trim() === label)
  assert.ok(index >= 0, `Workspace label ${label} is not rendered.`)
  await within(items[index].tap(), `tap:${label}`)
  await wait(1500)
  return current(miniProgram, 'pages/teacher/index/index')
}

let miniProgram
try {
  console.log('STEP connect')
  miniProgram = await within(new Launcher().connect({ wsEndpoint: `ws://127.0.0.1:${port}` }), 'connect')
  let page = await ensureTeacher(miniProgram)
  mkdirSync(output, { recursive: true })

  page = await openTeacherWorkspace(miniProgram, page, '待办')
  await captureBackgroundScreenshot(resolve(output, '01-teacher-overview.png'))
  console.log('CAPTURED 01-teacher-overview.png')

  page = await openTeacherWorkspace(miniProgram, page, '学情')
  await captureBackgroundScreenshot(resolve(output, '02-teacher-insights.png'))
  console.log('CAPTURED 02-teacher-insights.png')

  page = await openTeacherWorkspace(miniProgram, page, '内容')
  await captureBackgroundScreenshot(resolve(output, '03-teacher-content.png'))
  console.log('CAPTURED 03-teacher-content.png')

  page = await openTeacherWorkspace(miniProgram, page, 'PBL')
  await captureBackgroundScreenshot(resolve(output, '04-teacher-pbl.png'))
  console.log('CAPTURED 04-teacher-pbl.png')

  // Switch to the student role through the real logout control.
  page = await openTeacherWorkspace(miniProgram, page, '待办')
  const overviewRoot = await findComponentRoot(page, '.overview')
  assert.ok(overviewRoot, 'The teacher overview is not rendered.')
  const logout = await within(overviewRoot.$('.logout', { fallback: false }), 'teacher-logout')
  assert.ok(logout, 'The teacher logout control is not rendered.')
  await within(logout.tap(), 'teacher-logout-tap')
  const login = await current(miniProgram, 'pages/login/login')
  const studentRole = await within(login.$('.role-button.student', { fallback: false }), 'student-role')
  assert.ok(studentRole, 'The student role button is not rendered.')
  await within(studentRole.tap(), 'student-role-tap')
  page = await within(miniProgram.currentPage(), 'page:any-student')
  for (let attempt = 0; attempt < 30 && page.path === 'pages/login/login'; attempt += 1) {
    await wait(500)
    page = await within(miniProgram.currentPage(), 'page:any-student')
  }
  assert.ok(page.path.startsWith('pages/student/'), `Unexpected student landing page ${page.path}.`)

  // T17 converged the student primary navigation to 研讨/学习/学情; the
  // history entry lives inside the 研讨 page as the 历史答疑 control.
  if (page.path !== 'pages/student/pbl/pbl') {
    const navRootForPbl = await findComponentRoot(page, '.student-nav')
    assert.ok(navRootForPbl, 'The student primary navigation is not rendered.')
    const pblNavItems = await within(navRootForPbl.$$('.student-nav__item'), 'student-nav-items:研讨')
    const pblNavLabels = []
    for (const item of pblNavItems) pblNavLabels.push(await within(item.text(), 'student-nav-label:研讨'))
    const pblIdx = pblNavLabels.findIndex((label) => label.trim() === '研讨')
    assert.ok(pblIdx >= 0, 'The 研讨 tab is not rendered.')
    await within(pblNavItems[pblIdx].tap(), 'student-tap:研讨')
    await wait(1600)
    page = await current(miniProgram, 'pages/student/pbl/pbl')
  }
  const accountBar = await within(page.$('.account-bar', { fallback: false }), 'account-bar')
  assert.ok(accountBar, 'The 研讨 account bar is not rendered.')
  const accountButtons = await within(accountBar.$$('button'), 'account-bar-buttons:history')
  let historyButton = null
  for (const button of accountButtons) {
    if ((await within(button.text(), 'account-button-label:history')).trim() === '历史答疑') {
      historyButton = button
      break
    }
  }
  if (historyButton) {
    await within(historyButton.tap(), 'tap:查看全部历史')
    await wait(1600)
    page = await current(miniProgram, 'pages/student/history/history')
    await captureBackgroundScreenshot(resolve(output, '05-student-history.png'))
    console.log('CAPTURED 05-student-history.png')
    const reportButtons = await within(
      page.$$('.tag', { fallback: false }).catch(() => []),
      'report-entries',
    )
    let opened = false
    if (reportButtons.length) {
      await within(reportButtons[0].tap(), 'tap:查看报告')
      await wait(1800)
      page = await current(miniProgram, 'pages/report/report')
      await captureBackgroundScreenshot(resolve(output, '06-student-report.png'))
      console.log('CAPTURED 06-student-report.png')
      opened = true
      await within(miniProgram.navigateBack(), 'report-native-back')
      await wait(1400)
      page = await current(miniProgram, 'pages/student/history/history')
    }
    if (!opened) console.log('NOTE no visible report entry rendered; report page baseline left to stage 8')
  } else {
    console.log('NOTE history entry not found on chat page; report page baseline left to stage 8')
  }

  console.log(JSON.stringify({ output, status: 'ok' }))
} finally {
  miniProgram?.disconnect()
}
