import assert from 'node:assert/strict'
import { mkdirSync, writeFileSync } from 'node:fs'
import { resolve } from 'node:path'
import { fileURLToPath } from 'node:url'
import { Launcher } from '@weapp-vite/miniprogram-automator'
import { diagnose } from './doctor.mjs'

// Background-only Demo visual acceptance for the teacher insights tabs and the
// student PBL report surfaces. It uses rendered controls only: no setData,
// method calls, or operating-system input.
await diagnose({ probe: false })

const port = Number(process.env.WECHAT_AUTO_PORT || 9421)
const root = fileURLToPath(new URL('../../', import.meta.url))
const output = resolve(root, 'output/wechat', `teacher-insights-ui-${Date.now()}`)
const timeoutMs = 10000
const wait = (milliseconds) => new Promise((resolveWait) => setTimeout(resolveWait, milliseconds))
const within = (promise, label) =>
  Promise.race([
    promise,
    new Promise((_, reject) => setTimeout(() => reject(new Error(`timeout:${label}`)), timeoutMs)),
  ])

async function current(miniProgram, expectedPath) {
  let path = ''
  for (let attempt = 0; attempt < 36; attempt += 1) {
    const page = await within(miniProgram.currentPage(), `page:${expectedPath}`)
    path = page.path
    if (path === expectedPath) return page
    await wait(300)
  }
  throw new Error(`route:${expectedPath} (stuck at ${path})`)
}

async function component(page, selector) {
  const queue = [...(await within(page.$$('component', { fallback: false }), `components:${selector}`))]
  const seen = new Set()
  while (queue.length) {
    const host = queue.shift()
    if (!host || seen.has(host)) continue
    seen.add(host)
    const match = await within(host.$(selector), `component:${selector}`)
    if (match) return match
    queue.push(...(await within(host.$$('component'), `nested:${selector}`)))
  }
  return null
}

async function visibleElements(page, selector) {
  const matches = []
  const queue = [...(await within(page.$$('component', { fallback: false }), `components:${selector}`))]
  const seen = new Set()
  while (queue.length) {
    const host = queue.shift()
    if (!host || seen.has(host)) continue
    seen.add(host)
    matches.push(...(await within(host.$$(selector), `find:${selector}`)))
    queue.push(...(await within(host.$$('component'), `nested:${selector}`)))
  }
  const visible = []
  for (const item of matches) {
    const size = await within(item.size(), `size:${selector}`)
    if (size.width > 0 && size.height > 0) visible.push(item)
  }
  return visible
}

async function capture(file) {
  const socket = new WebSocket(`ws://127.0.0.1:${port}`)
  try {
    const base64 = await new Promise((resolveCapture, rejectCapture) => {
      const timer = setTimeout(() => rejectCapture(new Error('timeout:screenshot')), 30000)
      const finish = (value) => {
        clearTimeout(timer)
        if (value instanceof Error) rejectCapture(value)
        else resolveCapture(value)
      }
      socket.onerror = () => finish(new Error('screenshot-unavailable'))
      socket.onopen = () => socket.send(JSON.stringify({ id: 'capture', method: 'App.captureScreenshot', params: {} }))
      socket.onmessage = ({ data }) => {
        try {
          const result = JSON.parse(String(data))
          if (result.id !== 'capture') return
          if (typeof result.result?.data !== 'string') return finish(new Error('screenshot-missing-data'))
          finish(result.result.data)
        } catch {
          finish(new Error('screenshot-invalid-data'))
        }
      }
    })
    writeFileSync(resolve(output, file), base64, 'base64')
  } finally {
    socket.close()
  }
}

async function tapLabel(items, label, name) {
  const labels = []
  for (const item of items) labels.push((await within(item.text(), `${name}:label`)).trim())
  const index = labels.indexOf(label)
  assert.ok(index >= 0, `${name} ${label} is not rendered: ${labels.join('/')}`)
  await within(items[index].tap(), `${name}:tap:${label}`)
}

async function ensureTeacher(miniProgram) {
  let page = await within(miniProgram.currentPage(), 'page:any')
  if (page.path === 'pages/teacher/index/index') return page
  if (page.path === 'pages/login/login') {
    const teacher = await within(page.$('.role-button.teacher', { fallback: false }), 'teacher-role')
    assert.ok(teacher, 'Teacher role entry is not rendered.')
    await within(teacher.tap(), 'teacher-role-tap')
    return current(miniProgram, 'pages/teacher/index/index')
  }
  const nav = await component(page, '.student-nav')
  assert.ok(nav, `Cannot reach teacher role from ${page.path}.`)
  await tapLabel(await within(nav.$$('.student-nav__item'), 'student-nav-items'), '研讨', 'student nav')
  page = await current(miniProgram, 'pages/student/pbl/pbl')
  const account = await within(page.$('.account-bar', { fallback: false }), 'student-account')
  const buttons = await within(account.$$('button'), 'student-account-buttons')
  await tapLabel(buttons, '退出', 'student account')
  page = await current(miniProgram, 'pages/login/login')
  const teacher = await within(page.$('.role-button.teacher', { fallback: false }), 'teacher-role')
  await within(teacher.tap(), 'teacher-role-tap')
  return current(miniProgram, 'pages/teacher/index/index')
}

let miniProgram
try {
  miniProgram = await within(new Launcher().connect({ wsEndpoint: `ws://127.0.0.1:${port}` }), 'connect')
  mkdirSync(output, { recursive: true })
  if (process.env.WECHAT_CAPTURE_CURRENT === '1') {
    let pagePath = 'unavailable'
    try {
      pagePath = (await within(miniProgram.currentPage(), 'current-page')).path
    } catch {
      // A screenshot can still expose a compile/simulator failure when the
      // automator temporarily has no page metadata after an ordinary compile.
    }
    await capture('00-current-page.png')
    console.log(JSON.stringify({ output, page: pagePath, status: 'current-page-only' }))
  } else {
    let page = await ensureTeacher(miniProgram)

    const teacherNav = await component(page, '.teacher-nav')
    assert.ok(teacherNav, 'Teacher primary navigation is not rendered.')
    await tapLabel(await within(teacherNav.$$('.teacher-nav__item'), 'teacher-nav-items'), '学情', 'teacher nav')
    await wait(1400)
    page = await current(miniProgram, 'pages/teacher/index/index')
    const workspaceScroll = await within(page.$('.workspace-scroll', { fallback: false }), 'workspace-scroll')
    if (workspaceScroll) await within(workspaceScroll.scrollTo(0, 0), 'workspace-scroll-top')
    await wait(300)

    const expectedTabs = ['总览', '学习进度', '知识掌握', '学生记录']
    for (const [index, label] of expectedTabs.entries()) {
      const tabs = await visibleElements(page, '.record-index__item')
      const labels = []
      for (const tab of tabs) labels.push((await within(tab.text(), 'insight-tab-label')).trim())
      assert.deepEqual(labels, expectedTabs, 'Teacher insights tabs do not match the intended compact structure.')
      await within(tabs[index].tap(), `insight-tab:${label}`)
      await wait(800)
      if (workspaceScroll) await within(workspaceScroll.scrollTo(0, 0), `workspace-scroll-top:${label}`)
      await wait(300)
      await capture(`${String(index + 1).padStart(2, '0')}-teacher-insights-${index + 1}.png`)
    }

    const navForLogout = await component(page, '.teacher-nav')
    await tapLabel(
      await within(navForLogout.$$('.teacher-nav__item'), 'teacher-nav-items:logout'),
      '待办',
      'teacher nav',
    )
    await wait(1000)
    page = await current(miniProgram, 'pages/teacher/index/index')
    const overview = await component(page, '.overview')
    assert.ok(overview, 'Teacher overview is not rendered for sign-out.')
    const logout = await within(overview.$('.logout', { fallback: false }), 'teacher-logout')
    assert.ok(logout, 'Teacher sign-out control is not rendered.')
    await within(logout.tap(), 'teacher-logout-tap')
    page = await current(miniProgram, 'pages/login/login')
    const student = await within(page.$('.role-button.student', { fallback: false }), 'student-role')
    await within(student.tap(), 'student-role-tap')
    let studentNav = null
    for (let attempt = 0; attempt < 16 && !studentNav; attempt += 1) {
      await wait(500)
      page = await within(miniProgram.currentPage(), 'student-page')
      studentNav = await component(page, '.student-nav')
    }
    assert.ok(studentNav, 'Student primary navigation is not rendered.')
    await tapLabel(
      await within(studentNav.$$('.student-nav__item'), 'student-nav-items:insights'),
      '学情',
      'student nav',
    )
    await wait(1400)
    page = await current(miniProgram, 'pages/student/insights/index')
    const reportRows = await visibleElements(page, '.report-row')
    assert.ok(reportRows.length > 0, 'Demo must render at least one PBL learning report row.')
    await within(reportRows[0].tap(), 'student-report-row')
    await wait(1400)
    page = await current(miniProgram, 'pages/student/insights/detail')
    assert.ok(await component(page, '.report-cover'), 'Learning report focus module is not rendered.')
    assert.ok((await visibleElements(page, '.report-section')).length > 0, 'Learning report modules are not rendered.')
    await capture('05-student-learning-report.png')

    console.log(JSON.stringify({ output, status: 'ok' }))
  }
} finally {
  miniProgram?.disconnect()
}
