import assert from 'node:assert/strict'
import { mkdirSync, writeFileSync } from 'node:fs'
import { resolve } from 'node:path'
import { fileURLToPath } from 'node:url'
import { Launcher } from '@weapp-vite/miniprogram-automator'
import { diagnose } from './doctor.mjs'

// T29 stage-8 evidence, teacher half of flow A: the submitted QA learning
// report appears in the class-scoped 学习记录, the detail shows the receiving
// class, and a real review writes feedback. Internal screenshots only.
// Run: node scripts/wechat/t29-evidence-teacher.mjs
await diagnose({ probe: false })

const port = Number(process.env.WECHAT_AUTO_PORT || 9421)
const root = fileURLToPath(new URL('../../', import.meta.url))
const output = resolve(root, 'output/wechat', `t29-teacher-${Date.now()}`)
const timeoutMs = 10000
const within = (promise, label) =>
  Promise.race([
    promise,
    new Promise((_, reject) => setTimeout(() => reject(new Error(`timeout:${label}`)), timeoutMs)),
  ])
const wait = (milliseconds) => new Promise((resolveWait) => setTimeout(resolveWait, milliseconds))

async function current(miniProgram, expectedPath) {
  let lastPath = ''
  for (let attempt = 0; attempt < 48; attempt += 1) {
    const page = await within(miniProgram.currentPage(), `page:${expectedPath}`)
    lastPath = page.path
    if (page.path === expectedPath) return page
    await wait(300)
  }
  throw new Error(`route:${expectedPath} (stuck at ${lastPath})`)
}

async function findComponentRoot(page, selector) {
  const componentHosts = [
    ...(await within(page.$$('component', { fallback: false, timeout: timeoutMs }), `component-hosts:${selector}`)),
  ]
  const seen = new Set()
  while (componentHosts.length) {
    const host = componentHosts.shift()
    if (!host || seen.has(host)) continue
    seen.add(host)
    const rootElement = await within(host.$(selector), `component-root:${selector}`)
    if (rootElement) return rootElement
    componentHosts.push(...(await within(host.$$('component'), `nested-component-hosts:${selector}`)))
  }
  return null
}

async function captureBackgroundScreenshot(path) {
  let lastError
  for (let attempt = 0; attempt < 3; attempt += 1) {
    const socket = new WebSocket(`ws://127.0.0.1:${port}`)
    try {
      const data = await new Promise((resolveCapture, rejectCapture) => {
        const timer = setTimeout(() => rejectCapture(new Error('timeout:capture-screenshot')), 30000)
        const finish = (value) => {
          clearTimeout(timer)
          if (value instanceof Error) rejectCapture(value)
          else resolveCapture(value)
        }
        socket.onerror = () => finish(new Error('capture-screenshot-unavailable'))
        socket.onopen = () =>
          socket.send(JSON.stringify({ id: 'capture', method: 'App.captureScreenshot', params: {} }))
        socket.onmessage = ({ data: payload }) => {
          try {
            const response = JSON.parse(String(payload))
            if (response.id !== 'capture') return
            if (typeof response.result?.data !== 'string') return finish(new Error('capture-screenshot-missing-data'))
            finish(response.result.data)
          } catch {
            finish(new Error('capture-screenshot-invalid-response'))
          }
        }
      })
      writeFileSync(path, data, 'base64')
      return
    } catch (error) {
      lastError = error
      await wait(750)
    } finally {
      socket.close()
    }
  }
  throw lastError
}

async function findAllDeep(page, selector) {
  const matches = []
  const seen = new Set()
  const queue = [
    ...(await within(page.$$('component', { fallback: false, timeout: timeoutMs }), `component-hosts:${selector}`)),
  ]
  while (queue.length) {
    const host = queue.shift()
    if (!host || seen.has(host)) continue
    seen.add(host)
    for (const element of await within(host.$$(selector), `component-hit:${selector}`)) matches.push(element)
    queue.push(...(await within(host.$$('component'), `nested-hosts:${selector}`)))
  }
  return matches
}

async function ensureTeacher(miniProgram) {
  let page = await within(miniProgram.currentPage(), 'page:any')
  const roots = [
    'pages/teacher/index/index',
    'pages/student/pbl/pbl',
    'pages/student/learning/learning',
    'pages/student/insights/index',
    'pages/student/chat/chat',
    'pages/login/login',
  ]
  for (let attempt = 0; attempt < 8 && !roots.includes(page.path); attempt += 1) {
    // Walk back through the real page stack from detail pages only; a cold
    // start can land on a teacher detail with an empty back stack.
    try {
      await within(miniProgram.navigateBack(), 'detail-back')
    } catch {
      break
    }
    await wait(1200)
    page = await within(miniProgram.currentPage(), 'page:any-after-back')
  }
  if (page.path === 'pages/teacher/index/index') return page
  if (page.path === 'pages/login/login') {
    const teacherRole = await within(page.$('.role-button.teacher', { fallback: false }), 'teacher-role')
    await within(teacherRole.tap(), 'teacher-role-tap')
    return current(miniProgram, 'pages/teacher/index/index')
  }
  const navRoot = await findComponentRoot(page, '.student-nav')
  assert.ok(navRoot, `No teacher, login or student navigation found on ${page.path}.`)
  const navItems = await within(navRoot.$$('.student-nav__item'), 'student-nav-items:any')
  const navLabels = []
  for (const item of navItems) navLabels.push(await within(item.text(), 'student-nav-label:any'))
  const pblIndex = navLabels.findIndex((label) => label.trim() === '研讨')
  await within(navItems[pblIndex].tap(), 'student-tap:研讨')
  const pblPage = await current(miniProgram, 'pages/student/pbl/pbl')
  const accountBar = await within(pblPage.$('.account-bar', { fallback: false }), 'account-bar')
  const accountButtons = await within(accountBar.$$('button'), 'account-bar-buttons')
  let tapped = false
  for (const button of accountButtons) {
    if ((await within(button.text(), 'account-button-label')).trim() === '退出') {
      await within(button.tap(), 'student-logout-tap')
      tapped = true
      break
    }
  }
  assert.ok(tapped, 'The student logout control is not rendered.')
  const login = await current(miniProgram, 'pages/login/login')
  const teacherRole = await within(login.$('.role-button.teacher', { fallback: false }), 'teacher-role')
  await within(teacherRole.tap(), 'teacher-role-tap')
  return current(miniProgram, 'pages/teacher/index/index')
}

let miniProgram
try {
  console.log('STEP connect')
  miniProgram = await within(new Launcher().connect({ wsEndpoint: `ws://127.0.0.1:${port}` }), 'connect')
  let page = await ensureTeacher(miniProgram)
  mkdirSync(output, { recursive: true })

  console.log('STEP overview count after student submit')
  await wait(1200)
  const overview = await findComponentRoot(page, '.overview')
  assert.ok(overview, 'The teacher overview is not rendered.')
  await captureBackgroundScreenshot(resolve(output, '01-overview-after-submit.png'))
  console.log('CAPTURED 01-overview-after-submit.png')

  console.log('STEP open records from the overview row')
  const rows = await within(overview.$$('.priority-row'), 'overview-rows')
  let reportRow = null
  for (const row of rows) {
    const title = await within(row.$('.row-title', { fallback: false }), 'row-title')
    if (title && (await within(title.text(), 'row-title-text')).includes('问答报告批阅')) {
      reportRow = row
      break
    }
  }
  assert.ok(reportRow, 'The QA-report row is not rendered.')
  await within(reportRow.tap(), 'tap:问答报告批阅')
  await wait(1600)
  page = await current(miniProgram, 'pages/teacher/index/index')
  const recordsTabs = await findAllDeep(page, '.record-index__item')
  let activeTab = ''
  for (const tab of recordsTabs) {
    const size = await within(tab.size(), 'records-tab-size')
    if (size.width > 0 && size.height > 0) {
      const current = await tab.text()
      if (current.trim() === '学习记录') activeTab = 'records'
    }
  }
  assert.equal(activeTab, 'records', 'The QA row must land on the records section.')
  await captureBackgroundScreenshot(resolve(output, '02-records-with-class.png'))
  console.log('CAPTURED 02-records-with-class.png')

  console.log('STEP open report detail')
  const reportCard = await findAllDeep(page, '.report-card')
  assert.ok(reportCard.length >= 1, 'No QA learning report row rendered in records.')
  await within(reportCard[0].tap(), 'tap:report-row')
  await wait(2000)
  page = await current(miniProgram, 'pages/teacher/detail/detail')
  await captureBackgroundScreenshot(resolve(output, '03-report-detail-summary.png'))
  console.log('CAPTURED 03-report-detail-summary.png')

  console.log('STEP real review')
  const scoreInputs = await findAllDeep(page, '.score-input')
  assert.ok(scoreInputs.length >= 1, 'The score input is not rendered.')
  await within(scoreInputs[0].input('86'), 'score-input')
  const textareas = await findAllDeep(page, '.feedback-input, textarea')
  assert.ok(textareas.length >= 1, 'The feedback textarea is not rendered.')
  await within(textareas[0].input('T29 证据：补充鉴别依据后再看，注意可逆与不可逆的形态对照。'), 'feedback-input')
  await captureBackgroundScreenshot(resolve(output, '04-review-filled.png'))
  console.log('CAPTURED 04-review-filled.png')
  let submitReview = null
  for (const button of await findAllDeep(page, 'button')) {
    const label = await within(button.text(), 'review-button-label')
    if (label.includes('提交批阅') || label.includes('更新批阅')) {
      const size = await within(button.size(), 'review-button-size')
      if (size.width > 0 && size.height > 0) {
        submitReview = button
        break
      }
    }
  }
  assert.ok(submitReview, 'The review submit control is not rendered.')
  await within(submitReview.tap(), 'tap:submit-review')
  await wait(2200)
  await captureBackgroundScreenshot(resolve(output, '05-review-submitted.png'))
  console.log('CAPTURED 05-review-submitted.png')

  console.log('STEP native back keeps records context')
  await within(miniProgram.navigateBack(), 'report-back')
  await wait(1500)
  page = await current(miniProgram, 'pages/teacher/index/index')
  const recordCards = await findAllDeep(page, '.report-card')
  assert.ok(recordCards.length >= 1, 'The records list must survive the native back.')
  await captureBackgroundScreenshot(resolve(output, '06-records-after-back.png'))
  console.log('CAPTURED 06-records-after-back.png')

  console.log(JSON.stringify({ output, status: 'ok' }))
} finally {
  miniProgram?.disconnect()
}
