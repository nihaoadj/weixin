console.error(
  'T31 legacy evidence script is retired: it used the unsupported App.* WebSocket protocol. ' +
    'Run the T31 flow with wechatide.cmd automation_element_action and simulator_screenshot as documented in docs/wechat.md.',
)
process.exitCode = 1
