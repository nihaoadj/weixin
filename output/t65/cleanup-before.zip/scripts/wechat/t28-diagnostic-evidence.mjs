import assert from 'node:assert/strict'
import { mkdirSync, writeFileSync } from 'node:fs'
import { resolve } from 'node:path'
import { fileURLToPath } from 'node:url'
import { Launcher } from '@weapp-vite/miniprogram-automator'
import { diagnose } from './doctor.mjs'

// T28 stage-5 evidence for the reworked PBL diagnostic detail: real taps from
// 内容 → 诊断建议 into the native detail route, real feedback input and one
// safe Demo submit (仅发送反馈). Internal screenshots only; no setData, no
// business-method calls, no OS input. Run:
//   node scripts/wechat/t28-diagnostic-evidence.mjs [--no-submit]
await diagnose({ probe: false })

const port = Number(process.env.WECHAT_AUTO_PORT || 9421)
const root = fileURLToPath(new URL('../../', import.meta.url))
const submitAction = !process.argv.includes('--no-submit')
const output = resolve(root, 'output/wechat', `t28-diagnostic-${Date.now()}`)
const timeoutMs = 10000
const within = (promise, label) =>
  Promise.race([
    promise,
    new Promise((_, reject) => setTimeout(() => reject(new Error(`timeout:${label}`)), timeoutMs)),
  ])
const wait = (milliseconds) => new Promise((resolveWait) => setTimeout(resolveWait, milliseconds))

async function current(miniProgram, expectedPath) {
  let lastPath = ''
  for (let attempt = 0; attempt < 48; attempt += 1) {
    const page = await within(miniProgram.currentPage(), `page:${expectedPath}`)
    lastPath = page.path
    if (page.path === expectedPath) return page
    await wait(300)
  }
  throw new Error(`route:${expectedPath} (stuck at ${lastPath})`)
}

async function findComponentRoot(page, selector) {
  const componentHosts = [
    ...(await within(page.$$('component', { fallback: false, timeout: timeoutMs }), `component-hosts:${selector}`)),
  ]
  const seen = new Set()
  while (componentHosts.length) {
    const host = componentHosts.shift()
    if (!host || seen.has(host)) continue
    seen.add(host)
    const rootElement = await within(host.$(selector), `component-root:${selector}`)
    if (rootElement) return rootElement
    componentHosts.push(...(await within(host.$$('component'), `nested-component-hosts:${selector}`)))
  }
  return null
}

async function findAllDeep(page, selector) {
  const matches = []
  const seen = new Set()
  const queue = [
    ...(await within(page.$$('component', { fallback: false, timeout: timeoutMs }), `component-hosts:${selector}`)),
  ]
  while (queue.length) {
    const host = queue.shift()
    if (!host || seen.has(host)) continue
    seen.add(host)
    for (const element of await within(host.$$(selector), `component-hit:${selector}`)) matches.push(element)
    queue.push(...(await within(host.$$('component'), `nested-hosts:${selector}`)))
  }
  return matches
}

async function findVisibleDeep(page, selector) {
  for (const element of await findAllDeep(page, selector)) {
    const size = await within(element.size(), `visible-size:${selector}`)
    if (size.width > 0 && size.height > 0) return element
  }
  return null
}

async function captureBackgroundScreenshot(path) {
  let lastError
  for (let attempt = 0; attempt < 3; attempt += 1) {
    const socket = new WebSocket(`ws://127.0.0.1:${port}`)
    try {
      const data = await new Promise((resolveCapture, rejectCapture) => {
        const timer = setTimeout(() => rejectCapture(new Error('timeout:capture-screenshot')), 30000)
        const finish = (value) => {
          clearTimeout(timer)
          if (value instanceof Error) rejectCapture(value)
          else resolveCapture(value)
        }
        socket.onerror = () => finish(new Error('capture-screenshot-unavailable'))
        socket.onopen = () =>
          socket.send(JSON.stringify({ id: 'capture', method: 'App.captureScreenshot', params: {} }))
        socket.onmessage = ({ data: payload }) => {
          try {
            const response = JSON.parse(String(payload))
            if (response.id !== 'capture') return
            if (typeof response.result?.data !== 'string') return finish(new Error('capture-screenshot-missing-data'))
            finish(response.result.data)
          } catch {
            finish(new Error('capture-screenshot-invalid-response'))
          }
        }
      })
      writeFileSync(path, data, 'base64')
      return
    } catch (error) {
      lastError = error
      await wait(750)
    } finally {
      socket.close()
    }
  }
  throw lastError
}

async function ensureTeacher(miniProgram) {
  let page = await within(miniProgram.currentPage(), 'page:any')
  for (let attempt = 0; attempt < 6; attempt += 1) {
    if (
      ![
        'pages/teacher/pbl-follow-up-detail/pbl-follow-up-detail',
        'pages/teacher/pbl-diagnostic-detail/pbl-diagnostic-detail',
      ].includes(page.path)
    )
      break
    await within(miniProgram.navigateBack(), 'detail-leftover-back')
    await wait(1200)
    page = await within(miniProgram.currentPage(), 'page:any-after-back')
  }
  if (page.path === 'pages/teacher/index/index') return page
  if (page.path === 'pages/login/login') {
    const teacherRole = await within(page.$('.role-button.teacher', { fallback: false }), 'teacher-role')
    assert.ok(teacherRole, 'The teacher role button is not rendered.')
    await within(teacherRole.tap(), 'teacher-role-tap')
    return current(miniProgram, 'pages/teacher/index/index')
  }
  const navRoot = await findComponentRoot(page, '.student-nav')
  assert.ok(navRoot, `No teacher, login or student navigation found on ${page.path}.`)
  const navItems = await within(navRoot.$$('.student-nav__item'), 'student-nav-items:any')
  const navLabels = []
  for (const item of navItems) navLabels.push(await within(item.text(), 'student-nav-label:any'))
  const pblIndex = navLabels.findIndex((label) => label.trim() === '研讨')
  assert.ok(pblIndex >= 0, `The 研讨 tab is not rendered on ${page.path}.`)
  await within(navItems[pblIndex].tap(), 'student-tap:研讨')
  const pblPage = await current(miniProgram, 'pages/student/pbl/pbl')
  const accountBar = await within(pblPage.$('.account-bar', { fallback: false }), 'account-bar')
  assert.ok(accountBar, 'The student account bar is not rendered.')
  const accountButtons = await within(accountBar.$$('button'), 'account-bar-buttons')
  let tapped = false
  for (const button of accountButtons) {
    if ((await within(button.text(), 'account-button-label')).trim() === '退出') {
      await within(button.tap(), 'student-logout-tap')
      tapped = true
      break
    }
  }
  assert.ok(tapped, 'The student logout control is not rendered.')
  const login = await current(miniProgram, 'pages/login/login')
  const teacherRole = await within(login.$('.role-button.teacher', { fallback: false }), 'teacher-role')
  assert.ok(teacherRole, 'The teacher role button is not rendered.')
  await within(teacherRole.tap(), 'teacher-role-tap')
  return current(miniProgram, 'pages/teacher/index/index')
}

let miniProgram
try {
  console.log('STEP connect')
  miniProgram = await within(new Launcher().connect({ wsEndpoint: `ws://127.0.0.1:${port}` }), 'connect')
  let page = await ensureTeacher(miniProgram)
  mkdirSync(output, { recursive: true })

  console.log('STEP open-content-diagnostics')
  const nav = await findComponentRoot(page, '.teacher-nav')
  assert.ok(nav, 'The teacher primary navigation is not rendered.')
  const navItems = await within(nav.$$('.teacher-nav__item'), 'teacher-nav-items:内容')
  const navLabels = []
  for (const item of navItems) navLabels.push(await within(item.text(), 'teacher-nav-label'))
  const contentIndex = navLabels.findIndex((text) => text.trim() === '内容')
  assert.ok(contentIndex >= 0, 'The content workspace label is not rendered.')
  await within(navItems[contentIndex].tap(), 'tap:内容')
  await wait(1600)
  page = await current(miniProgram, 'pages/teacher/index/index')
  const content = await findComponentRoot(page, '.teacher-content-workspace')
  assert.ok(content, 'The teacher content workspace did not open.')
  const contentSections = await findComponentRoot(content, '.record-index')
  assert.ok(contentSections, 'The teaching-content subsection navigation is not rendered.')
  const contentSectionItems = await within(contentSections.$$('.record-index__item'), 'content-section-items')
  const contentSectionLabels = []
  for (const item of contentSectionItems) contentSectionLabels.push(await within(item.text(), 'content-section-label'))
  const diagnosticsIndex = contentSectionLabels.findIndex((label) => label.includes('诊断建议'))
  assert.ok(diagnosticsIndex >= 0, 'The diagnostic-suggestions section is not rendered.')
  await within(contentSectionItems[diagnosticsIndex].tap(), 'tap:诊断建议')
  await wait(900)
  const workItems = await findComponentRoot(page, '.work-items')
  assert.ok(workItems, 'The teacher diagnostic work-items are not rendered.')
  const workItemList = await findComponentRoot(workItems, '.work-item-list')
  assert.ok(workItemList, 'The teacher diagnostic list is not rendered.')
  const diagnosticRow = await within(workItemList.$('.row'), 'diagnostic-row')
  assert.ok(diagnosticRow, 'The seeded diagnostic row is not rendered.')

  console.log('STEP open-detail')
  await within(miniProgram.pageScrollTo(0), 'pre-entry-scroll-top')
  await wait(400)
  await within(diagnosticRow.tap(), 'diagnostic-row-tap')
  await wait(2000)
  page = await current(miniProgram, 'pages/teacher/pbl-diagnostic-detail/pbl-diagnostic-detail')
  const detailComponent = await findVisibleDeep(page, '.detail')
  assert.ok(detailComponent, 'The diagnostic detail is not rendered after the list tap.')
  const referenceModule = await findVisibleDeep(page, '.tms--reference')
  assert.ok(referenceModule, 'The AI reference module is not rendered.')
  const editorModule = await findVisibleDeep(page, '.tms--editor')
  assert.ok(editorModule, 'The teacher disposition editor module is not rendered.')

  console.log('STEP screenshot-detail-top')
  await within(miniProgram.pageScrollTo(0), 'detail-scroll-top')
  await wait(700)
  await captureBackgroundScreenshot(resolve(output, '01-detail-object-evidence.png'))
  console.log('CAPTURED 01-detail-object-evidence.png')

  console.log('STEP screenshot-detail-findings')
  await within(miniProgram.pageScrollTo(600), 'detail-scroll-findings')
  await wait(900)
  await captureBackgroundScreenshot(resolve(output, '02-detail-findings.png'))
  console.log('CAPTURED 02-detail-findings.png')

  console.log('STEP screenshot-detail-ai')
  await within(miniProgram.pageScrollTo(1400), 'detail-scroll-ai')
  await wait(900)
  await captureBackgroundScreenshot(resolve(output, '03-detail-ai-reference.png'))
  console.log('CAPTURED 03-detail-ai-reference.png')

  console.log('STEP screenshot-detail-disposition')
  await within(miniProgram.pageScrollTo(100000), 'detail-scroll-bottom')
  await wait(1000)
  await captureBackgroundScreenshot(resolve(output, '04-detail-disposition.png'))
  console.log('CAPTURED 04-detail-disposition.png')

  if (submitAction) {
    console.log('STEP real-feedback-input')
    const textareas = await findAllDeep(page, 'textarea')
    let feedbackField = null
    for (const candidate of textareas) {
      const size = await within(candidate.size(), 'textarea-size')
      if (Number(size.width) > 0 && Number(size.height) > 0) {
        feedbackField = candidate
        break
      }
    }
    assert.ok(feedbackField, 'The visible feedback textarea is not rendered.')
    await within(feedbackField.input('请重点核对血管通透性与渗出的证据连接。'), 'feedback-input')
    await wait(400)
    await captureBackgroundScreenshot(resolve(output, '05-detail-feedback-filled.png'))
    console.log('CAPTURED 05-detail-feedback-filled.png')

    console.log('STEP real-safe-submit')
    const secondaryButtons = []
    for (const button of await findAllDeep(page, 'button')) {
      const text = await within(button.text(), 'button-text')
      if (text.trim() === '仅发送反馈') secondaryButtons.push(button)
    }
    let submitButton = null
    for (const candidate of secondaryButtons) {
      const size = await within(candidate.size(), 'submit-size')
      if (Number(size.width) > 0 && Number(size.height) > 0) submitButton = candidate
    }
    assert.ok(submitButton, 'The visible 仅发送反馈 button is not rendered.')
    await within(submitButton.tap(), 'feedback-only-tap')
    await wait(2000)
    await captureBackgroundScreenshot(resolve(output, '06-detail-after-submit.png'))
    console.log('CAPTURED 06-detail-after-submit.png')
  }

  console.log('STEP native-back')
  await within(miniProgram.navigateBack(), 'diagnostic-native-back')
  await wait(1500)
  page = await current(miniProgram, 'pages/teacher/index/index')
  await captureBackgroundScreenshot(resolve(output, '07-back-to-list.png'))
  console.log('CAPTURED 07-back-to-list.png')

  console.log(JSON.stringify({ output, status: 'ok' }))
} finally {
  miniProgram?.disconnect()
}
