import assert from 'node:assert/strict'
import { mkdirSync, writeFileSync } from 'node:fs'
import { resolve } from 'node:path'
import { fileURLToPath } from 'node:url'
import { Launcher } from '@weapp-vite/miniprogram-automator'
import { diagnose } from './doctor.mjs'

// T28 stage-4 evidence for the reworked PBL follow-up detail: real taps from
// 学情 → PBL 跟进 into the native detail route, real textarea input and a real
// Demo send of the support feedback. Screenshots come from the internal
// channel; no setData, no business-method calls, no OS input. Run:
//   node scripts/wechat/t28-follow-up-evidence.mjs [--no-send]
await diagnose({ probe: false })

const port = Number(process.env.WECHAT_AUTO_PORT || 9421)
const root = fileURLToPath(new URL('../../', import.meta.url))
const sendFeedback = !process.argv.includes('--no-send')
const output = resolve(root, 'output/wechat', `t28-followup-${Date.now()}`)
const timeoutMs = 10000
const within = (promise, label) =>
  Promise.race([
    promise,
    new Promise((_, reject) => setTimeout(() => reject(new Error(`timeout:${label}`)), timeoutMs)),
  ])
const wait = (milliseconds) => new Promise((resolveWait) => setTimeout(resolveWait, milliseconds))

async function current(miniProgram, expectedPath) {
  let lastPath = ''
  for (let attempt = 0; attempt < 48; attempt += 1) {
    const page = await within(miniProgram.currentPage(), `page:${expectedPath}`)
    lastPath = page.path
    if (page.path === expectedPath) return page
    await wait(300)
  }
  throw new Error(`route:${expectedPath} (stuck at ${lastPath})`)
}

async function findComponentRoot(page, selector) {
  const componentHosts = [
    ...(await within(page.$$('component', { fallback: false, timeout: timeoutMs }), `component-hosts:${selector}`)),
  ]
  const seen = new Set()
  while (componentHosts.length) {
    const host = componentHosts.shift()
    if (!host || seen.has(host)) continue
    seen.add(host)
    const rootElement = await within(host.$(selector), `component-root:${selector}`)
    if (rootElement) return rootElement
    componentHosts.push(...(await within(host.$$('component'), `nested-component-hosts:${selector}`)))
  }
  return null
}

async function findAllDeep(page, selector) {
  const matches = []
  const seen = new Set()
  const queue = [
    ...(await within(page.$$('component', { fallback: false, timeout: timeoutMs }), `component-hosts:${selector}`)),
  ]
  while (queue.length) {
    const host = queue.shift()
    if (!host || seen.has(host)) continue
    seen.add(host)
    for (const element of await within(host.$$(selector), `component-hit:${selector}`)) matches.push(element)
    queue.push(...(await within(host.$$('component'), `nested-hosts:${selector}`)))
  }
  return matches
}

async function findVisibleDeep(page, selector) {
  for (const element of await findAllDeep(page, selector)) {
    const size = await within(element.size(), `visible-size:${selector}`)
    if (size.width > 0 && size.height > 0) return element
  }
  return null
}

async function captureBackgroundScreenshot(path) {
  let lastError
  for (let attempt = 0; attempt < 3; attempt += 1) {
    const socket = new WebSocket(`ws://127.0.0.1:${port}`)
    try {
      const data = await new Promise((resolveCapture, rejectCapture) => {
        const timer = setTimeout(() => rejectCapture(new Error('timeout:capture-screenshot')), 30000)
        const finish = (value) => {
          clearTimeout(timer)
          if (value instanceof Error) rejectCapture(value)
          else resolveCapture(value)
        }
        socket.onerror = () => finish(new Error('capture-screenshot-unavailable'))
        socket.onopen = () =>
          socket.send(JSON.stringify({ id: 'capture', method: 'App.captureScreenshot', params: {} }))
        socket.onmessage = ({ data: payload }) => {
          try {
            const response = JSON.parse(String(payload))
            if (response.id !== 'capture') return
            if (typeof response.result?.data !== 'string') return finish(new Error('capture-screenshot-missing-data'))
            finish(response.result.data)
          } catch {
            finish(new Error('capture-screenshot-invalid-response'))
          }
        }
      })
      writeFileSync(path, data, 'base64')
      return
    } catch (error) {
      lastError = error
      await wait(750)
    } finally {
      socket.close()
    }
  }
  throw lastError
}

async function ensureTeacher(miniProgram) {
  let page = await within(miniProgram.currentPage(), 'page:any')
  // Native detail routes can be left over from an earlier crashed run; walk
  // back through the real page stack before role recovery.
  for (let attempt = 0; attempt < 6; attempt += 1) {
    if (
      ![
        'pages/teacher/pbl-follow-up-detail/pbl-follow-up-detail',
        'pages/teacher/pbl-diagnostic-detail/pbl-diagnostic-detail',
      ].includes(page.path)
    )
      break
    await within(miniProgram.navigateBack(), 'detail-leftover-back')
    await wait(1200)
    page = await within(miniProgram.currentPage(), 'page:any-after-back')
  }
  if (page.path === 'pages/teacher/index/index') return page
  if (page.path === 'pages/login/login') {
    const teacherRole = await within(page.$('.role-button.teacher', { fallback: false }), 'teacher-role')
    assert.ok(teacherRole, 'The teacher role button is not rendered.')
    await within(teacherRole.tap(), 'teacher-role-tap')
    return current(miniProgram, 'pages/teacher/index/index')
  }
  const navRoot = await findComponentRoot(page, '.student-nav')
  assert.ok(navRoot, `No teacher, login or student navigation found on ${page.path}.`)
  const navItems = await within(navRoot.$$('.student-nav__item'), 'student-nav-items:any')
  const navLabels = []
  for (const item of navItems) navLabels.push(await within(item.text(), 'student-nav-label:any'))
  const pblIndex = navLabels.findIndex((label) => label.trim() === '研讨')
  assert.ok(pblIndex >= 0, `The 研讨 tab is not rendered on ${page.path}.`)
  await within(navItems[pblIndex].tap(), 'student-tap:研讨')
  const pblPage = await current(miniProgram, 'pages/student/pbl/pbl')
  const accountBar = await within(pblPage.$('.account-bar', { fallback: false }), 'account-bar')
  assert.ok(accountBar, 'The student account bar is not rendered.')
  const accountButtons = await within(accountBar.$$('button'), 'account-bar-buttons')
  let tapped = false
  for (const button of accountButtons) {
    if ((await within(button.text(), 'account-button-label')).trim() === '退出') {
      await within(button.tap(), 'student-logout-tap')
      tapped = true
      break
    }
  }
  assert.ok(tapped, 'The student logout control is not rendered.')
  const login = await current(miniProgram, 'pages/login/login')
  const teacherRole = await within(login.$('.role-button.teacher', { fallback: false }), 'teacher-role')
  assert.ok(teacherRole, 'The teacher role button is not rendered.')
  await within(teacherRole.tap(), 'teacher-role-tap')
  return current(miniProgram, 'pages/teacher/index/index')
}

let miniProgram
try {
  console.log('STEP connect')
  miniProgram = await within(new Launcher().connect({ wsEndpoint: `ws://127.0.0.1:${port}` }), 'connect')
  let page = await ensureTeacher(miniProgram)
  mkdirSync(output, { recursive: true })

  console.log('STEP open-insights-followups')
  const nav = await findComponentRoot(page, '.teacher-nav')
  assert.ok(nav, 'The teacher primary navigation is not rendered.')
  const navItems = await within(nav.$$('.teacher-nav__item'), 'teacher-nav-items:学情')
  const navLabels = []
  for (const item of navItems) navLabels.push(await within(item.text(), 'teacher-nav-label'))
  const insightsIndex = navLabels.findIndex((text) => text.trim() === '学情')
  assert.ok(insightsIndex >= 0, 'The insights workspace label is not rendered.')
  await within(navItems[insightsIndex].tap(), 'tap:学情')
  await wait(1600)
  page = await current(miniProgram, 'pages/teacher/index/index')
  const insights = await findComponentRoot(page, '.teacher-insights-workspace')
  assert.ok(insights, 'The teacher insights workspace did not open.')
  const insightComponents = await within(insights.$$('component'), 'insight-components')
  let insightNav = null
  for (const component of insightComponents) {
    const candidate = await within(component.$('.record-index'), 'insight-navigation')
    if (candidate) {
      insightNav = candidate
      break
    }
  }
  assert.ok(insightNav, 'The teacher insights navigation is not rendered.')
  const sectionItems = await within(insightNav.$$('.record-index__item'), 'insight-section-items')
  const sectionLabels = []
  for (const item of sectionItems) sectionLabels.push(await within(item.text(), 'insight-section-label'))
  const followUpsIndex = sectionLabels.findIndex((label) => label.includes('PBL 跟进'))
  assert.ok(followUpsIndex >= 0, 'The PBL follow-up section is not rendered.')
  await within(sectionItems[followUpsIndex].tap(), 'tap:PBL 跟进')
  await wait(900)
  const followUps = await findComponentRoot(insights, '.follow-ups')
  assert.ok(followUps, 'The PBL follow-up workspace is not rendered.')
  const followUpList = await findComponentRoot(followUps, '.follow-up-list')
  assert.ok(followUpList, 'The PBL follow-up list is not rendered.')
  const followUpRow = await within(followUpList.$('.follow-up-row'), 'pbl-follow-up-row')
  assert.ok(followUpRow, 'The seeded PBL follow-up row is not rendered.')
  await within(miniProgram.pageScrollTo(0), 'pre-entry-scroll-top')
  await wait(400)
  console.log('STEP screenshot-list')
  await captureBackgroundScreenshot(resolve(output, '00-followup-list.png'))
  console.log('CAPTURED 00-followup-list.png')

  console.log('STEP open-detail')
  await within(followUpRow.tap(), 'pbl-follow-up-row-tap')
  await wait(2000)
  page = await current(miniProgram, 'pages/teacher/pbl-follow-up-detail/pbl-follow-up-detail')
  const detailComponent = await findVisibleDeep(page, '.detail')
  assert.ok(detailComponent, 'The follow-up detail is not rendered after the list tap.')
  const focusModule = await findVisibleDeep(page, '.tms--focus')
  assert.ok(focusModule, 'The verdict focus module is not rendered.')
  const editorModule = await findVisibleDeep(page, '.tms--editor')
  assert.ok(editorModule, 'The support feedback editor module is not rendered.')

  console.log('STEP screenshot-detail-top')
  await within(miniProgram.pageScrollTo(0), 'detail-scroll-top')
  await wait(700)
  await captureBackgroundScreenshot(resolve(output, '01-detail-verdict.png'))
  console.log('CAPTURED 01-detail-verdict.png')

  console.log('STEP screenshot-detail-tasks')
  await within(miniProgram.pageScrollTo(500), 'detail-scroll-tasks')
  await wait(900)
  await captureBackgroundScreenshot(resolve(output, '02-detail-tasks.png'))
  console.log('CAPTURED 02-detail-tasks.png')

  console.log('STEP screenshot-detail-history')
  await within(miniProgram.pageScrollTo(1200), 'detail-scroll-history')
  await wait(900)
  await captureBackgroundScreenshot(resolve(output, '03-detail-history.png'))
  console.log('CAPTURED 03-detail-history.png')

  console.log('STEP screenshot-detail-form')
  await within(miniProgram.pageScrollTo(100000), 'detail-scroll-bottom')
  await wait(1000)
  await captureBackgroundScreenshot(resolve(output, '04-detail-support-form.png'))
  console.log('CAPTURED 04-detail-support-form.png')

  if (sendFeedback) {
    console.log('STEP real-support-feedback')
    const textarea = await findVisibleDeep(page, 'textarea')
    assert.ok(textarea, 'The support textarea is not rendered.')
    await within(textarea.input('请重点带教血管通透性与渗出的证据连接。'), 'support-textarea-input')
    await wait(400)
    await captureBackgroundScreenshot(resolve(output, '05-detail-form-filled.png'))
    console.log('CAPTURED 05-detail-form-filled.png')
    const sendButton = await findVisibleDeep(page, '.primary-action')
    assert.ok(sendButton, 'The send button is not rendered.')
    await within(sendButton.tap(), 'support-send-tap')
    await wait(1800)
    await captureBackgroundScreenshot(resolve(output, '06-detail-after-send.png'))
    console.log('CAPTURED 06-detail-after-send.png')
  }

  console.log('STEP native-back')
  await within(miniProgram.navigateBack(), 'follow-up-native-back')
  await wait(1500)
  page = await current(miniProgram, 'pages/teacher/index/index')
  await captureBackgroundScreenshot(resolve(output, '07-back-to-list.png'))
  console.log('CAPTURED 07-back-to-list.png')

  console.log(JSON.stringify({ output, status: 'ok' }))
} finally {
  miniProgram?.disconnect()
}
