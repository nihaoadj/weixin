import assert from 'node:assert/strict'
import { mkdirSync, writeFileSync } from 'node:fs'
import { resolve } from 'node:path'
import { fileURLToPath } from 'node:url'
import { Launcher } from '@weapp-vite/miniprogram-automator'
import { diagnose } from './doctor.mjs'

// T29 stage-8 evidence: real taps/inputs across the reworked teacher
// workspaces and the student QA-report submit flow. Developer Tools internal
// screenshots only; no setData, no business-method calls, no OS input.
// Run: node scripts/wechat/t29-evidence.mjs
await diagnose({ probe: false })

const port = Number(process.env.WECHAT_AUTO_PORT || 9421)
const root = fileURLToPath(new URL('../../', import.meta.url))
const output = resolve(root, 'output/wechat', `t29-evidence-${Date.now()}`)
const timeoutMs = 10000
const within = (promise, label) =>
  Promise.race([
    promise,
    new Promise((_, reject) => setTimeout(() => reject(new Error(`timeout:${label}`)), timeoutMs)),
  ])
const wait = (milliseconds) => new Promise((resolveWait) => setTimeout(resolveWait, milliseconds))

async function current(miniProgram, expectedPath) {
  let lastPath = ''
  for (let attempt = 0; attempt < 48; attempt += 1) {
    const page = await within(miniProgram.currentPage(), `page:${expectedPath}`)
    lastPath = page.path
    if (page.path === expectedPath) return page
    await wait(300)
  }
  throw new Error(`route:${expectedPath} (stuck at ${lastPath})`)
}

async function findComponentRoot(page, selector) {
  const componentHosts = [
    ...(await within(page.$$('component', { fallback: false, timeout: timeoutMs }), `component-hosts:${selector}`)),
  ]
  const seen = new Set()
  while (componentHosts.length) {
    const host = componentHosts.shift()
    if (!host || seen.has(host)) continue
    seen.add(host)
    const rootElement = await within(host.$(selector), `component-root:${selector}`)
    if (rootElement) return rootElement
    componentHosts.push(...(await within(host.$$('component'), `nested-component-hosts:${selector}`)))
  }
  return null
}

async function captureBackgroundScreenshot(path) {
  let lastError
  for (let attempt = 0; attempt < 3; attempt += 1) {
    const socket = new WebSocket(`ws://127.0.0.1:${port}`)
    try {
      const data = await new Promise((resolveCapture, rejectCapture) => {
        const timer = setTimeout(() => rejectCapture(new Error('timeout:capture-screenshot')), 30000)
        const finish = (value) => {
          clearTimeout(timer)
          if (value instanceof Error) rejectCapture(value)
          else resolveCapture(value)
        }
        socket.onerror = () => finish(new Error('capture-screenshot-unavailable'))
        socket.onopen = () =>
          socket.send(JSON.stringify({ id: 'capture', method: 'App.captureScreenshot', params: {} }))
        socket.onmessage = ({ data: payload }) => {
          try {
            const response = JSON.parse(String(payload))
            if (response.id !== 'capture') return
            if (typeof response.result?.data !== 'string') return finish(new Error('capture-screenshot-missing-data'))
            finish(response.result.data)
          } catch {
            finish(new Error('capture-screenshot-invalid-response'))
          }
        }
      })
      writeFileSync(path, data, 'base64')
      return
    } catch (error) {
      lastError = error
      await wait(750)
    } finally {
      socket.close()
    }
  }
  throw lastError
}

async function findAllDeep(page, selector) {
  const matches = []
  const seen = new Set()
  const queue = [
    ...(await within(page.$$('component', { fallback: false, timeout: timeoutMs }), `component-hosts:${selector}`)),
  ]
  while (queue.length) {
    const host = queue.shift()
    if (!host || seen.has(host)) continue
    seen.add(host)
    for (const element of await within(host.$$(selector), `component-hit:${selector}`)) matches.push(element)
    queue.push(...(await within(host.$$('component'), `nested-hosts:${selector}`)))
  }
  return matches
}

async function findVisibleDeep(page, selector) {
  for (const element of await findAllDeep(page, selector)) {
    const size = await within(element.size(), `visible-size:${selector}`)
    if (size.width > 0 && size.height > 0) return element
  }
  return null
}

async function ensureTeacher(miniProgram) {
  let page = await within(miniProgram.currentPage(), 'page:any')
  if (page.path === 'pages/teacher/index/index') return page
  if (page.path === 'pages/login/login') {
    const teacherRole = await within(page.$('.role-button.teacher', { fallback: false }), 'teacher-role')
    assert.ok(teacherRole, 'The teacher role button is not rendered.')
    await within(teacherRole.tap(), 'teacher-role-tap')
    return current(miniProgram, 'pages/teacher/index/index')
  }
  const navRoot = await findComponentRoot(page, '.student-nav')
  assert.ok(navRoot, `No teacher, login or student navigation found on ${page.path}.`)
  const navItems = await within(navRoot.$$('.student-nav__item'), 'student-nav-items:any')
  const navLabels = []
  for (const item of navItems) navLabels.push(await within(item.text(), 'student-nav-label:any'))
  const pblIndex = navLabels.findIndex((label) => label.trim() === '研讨')
  assert.ok(pblIndex >= 0, `The 研讨 tab is not rendered on ${page.path}.`)
  await within(navItems[pblIndex].tap(), 'student-tap:研讨')
  const pblPage = await current(miniProgram, 'pages/student/pbl/pbl')
  const accountBar = await within(pblPage.$('.account-bar', { fallback: false }), 'account-bar')
  assert.ok(accountBar, 'The student account bar is not rendered.')
  const accountButtons = await within(accountBar.$$('button'), 'account-bar-buttons')
  let tapped = false
  for (const button of accountButtons) {
    if ((await within(button.text(), 'account-button-label')).trim() === '退出') {
      await within(button.tap(), 'student-logout-tap')
      tapped = true
      break
    }
  }
  assert.ok(tapped, 'The student logout control is not rendered.')
  const login = await current(miniProgram, 'pages/login/login')
  const teacherRole = await within(login.$('.role-button.teacher', { fallback: false }), 'teacher-role')
  assert.ok(teacherRole, 'The teacher role button is not rendered.')
  await within(teacherRole.tap(), 'teacher-role-tap')
  return current(miniProgram, 'pages/teacher/index/index')
}

async function openTeacherWorkspace(miniProgram, page, label) {
  const nav = await findComponentRoot(page, '.teacher-nav')
  assert.ok(nav, 'The teacher primary navigation is not rendered.')
  const items = await within(nav.$$('.teacher-nav__item'), `teacher-nav-items:${label}`)
  const labels = []
  for (const item of items) labels.push(await within(item.text(), 'teacher-nav-label'))
  const index = labels.findIndex((text) => text.trim() === label)
  assert.ok(index >= 0, `Workspace label ${label} is not rendered.`)
  await within(items[index].tap(), `tap:${label}`)
  await wait(1500)
  return current(miniProgram, 'pages/teacher/index/index')
}

let miniProgram
try {
  console.log('STEP connect')
  miniProgram = await within(new Launcher().connect({ wsEndpoint: `ws://127.0.0.1:${port}` }), 'connect')
  let page = await ensureTeacher(miniProgram)
  mkdirSync(output, { recursive: true })

  // ---- B. workspace duties ------------------------------------------------
  console.log('STEP B overview')
  page = await openTeacherWorkspace(miniProgram, page, '待办')
  const overview = await findComponentRoot(page, '.overview')
  assert.ok(overview, 'The teacher overview is not rendered.')
  const rowTitles = await within(overview.$$('.row-title'), 'overview-row-titles')
  const titleTexts = []
  for (const node of rowTitles) titleTexts.push(await within(node.text(), 'overview-row-title'))
  assert.ok(titleTexts.includes('问答报告批阅'), `问答报告批阅 row missing: ${titleTexts.join('/')}`)
  assert.ok(titleTexts.includes('PBL 诊断审阅'), `PBL 诊断审阅 row missing: ${titleTexts.join('/')}`)
  assert.ok(titleTexts.includes('PBL 人工支持'), `PBL 人工支持 row missing: ${titleTexts.join('/')}`)
  assert.ok(!titleTexts.includes('PBL 待处理'), 'The merged PBL row must be gone.')
  await captureBackgroundScreenshot(resolve(output, '01-overview-four-queues.png'))
  console.log('CAPTURED 01-overview-four-queues.png')

  console.log('STEP B insights')
  page = await openTeacherWorkspace(miniProgram, page, '学情')
  const insightSections = await findAllDeep(page, '.record-index__item')
  const insightLabels = []
  for (const item of insightSections) {
    const size = await within(item.size(), 'insight-section-size')
    if (size.width > 0 && size.height > 0) insightLabels.push(await within(item.text(), 'insight-section-label'))
  }
  assert.deepEqual(insightLabels, ['班级学情', '学习记录'])
  assert.equal(await findVisibleDeep(page, '.follow-ups'), null, 'PBL follow-ups must not be visible in insights')
  await captureBackgroundScreenshot(resolve(output, '02-insights-analytics.png'))
  console.log('CAPTURED 02-insights-analytics.png')
  const recordsTab = insightSections[insightLabels.indexOf('学习记录')]
  await within(recordsTab.tap(), 'tap:学习记录')
  await wait(1600)
  await captureBackgroundScreenshot(resolve(output, '03-insights-records.png'))
  console.log('CAPTURED 03-insights-records.png')

  console.log('STEP B content')
  page = await openTeacherWorkspace(miniProgram, page, '内容')
  const contentPanels = await findAllDeep(page, '#teacher-content-panel-resources')
  assert.ok(contentPanels.length >= 1, 'The resources panel is not rendered.')
  const visibleContentNavItems = []
  for (const item of await findAllDeep(page, '.record-index__item')) {
    const size = await within(item.size(), 'content-nav-size')
    if (size.width > 0 && size.height > 0) visibleContentNavItems.push(item)
  }
  assert.equal(visibleContentNavItems.length, 0, 'Content must not render a visible subsection nav')
  assert.equal(await findVisibleDeep(page, '.work-items'), null, 'Diagnostics must not be visible in content')
  await captureBackgroundScreenshot(resolve(output, '04-content-resources.png'))
  console.log('CAPTURED 04-content-resources.png')

  console.log('STEP B pbl sections')
  page = await openTeacherWorkspace(miniProgram, page, 'PBL')
  const pblRoot = await findVisibleDeep(page, '.pbl-workspace')
  assert.ok(pblRoot, 'The unified PBL workspace is not rendered.')
  const pblSectionNodes = await findAllDeep(page, '.record-index__item')
  const pblLabels = []
  const pblSections = []
  for (const item of pblSectionNodes) {
    const size = await within(item.size(), 'pbl-section-size')
    if (size.width > 0 && size.height > 0) {
      pblLabels.push(await within(item.text(), 'pbl-section-label'))
      pblSections.push(item)
    }
  }
  assert.deepEqual(pblLabels, ['课堂', '诊断审阅', '巩固跟进'])
  await captureBackgroundScreenshot(resolve(output, '05-pbl-classrooms.png'))
  console.log('CAPTURED 05-pbl-classrooms.png')
  await within(pblSections[2].tap(), 'tap:巩固跟进')
  await wait(1600)
  await captureBackgroundScreenshot(resolve(output, '06-pbl-follow-ups.png'))
  console.log('CAPTURED 06-pbl-follow-ups.png')
  page = await openTeacherWorkspace(miniProgram, page, 'PBL')
  const pblSectionNodes2 = await findAllDeep(page, '.record-index__item')
  const pblLabels2 = []
  const pblSections2 = []
  for (const item of pblSectionNodes2) {
    const size = await within(item.size(), 'pbl-section-size-2')
    if (size.width > 0 && size.height > 0) {
      pblLabels2.push(await within(item.text(), 'pbl-section-label-2'))
      pblSections2.push(item)
    }
  }
  await within(pblSections2[pblLabels2.indexOf('诊断审阅')].tap(), 'tap:诊断审阅')
  await wait(1600)
  await captureBackgroundScreenshot(resolve(output, '07-pbl-diagnostics.png'))
  console.log('CAPTURED 07-pbl-diagnostics.png')

  // ---- C. diagnostic detail through the moved workspace -------------------
  console.log('STEP C diagnostic detail')
  const diagnosticRow = await findVisibleDeep(page, '.row')
  assert.ok(diagnosticRow, 'The pending diagnostic row is not rendered.')
  await within(diagnosticRow.tap(), 'tap:diagnostic-row')
  await wait(2000)
  page = await current(miniProgram, 'pages/teacher/pbl-diagnostic-detail/pbl-diagnostic-detail')
  await captureBackgroundScreenshot(resolve(output, '08-diagnostic-detail.png'))
  console.log('CAPTURED 08-diagnostic-detail.png')
  await within(miniProgram.navigateBack(), 'diagnostic-back')
  await wait(1500)
  page = await current(miniProgram, 'pages/teacher/index/index')

  // ---- D. human support flow ---------------------------------------------
  console.log('STEP D support flow')
  page = await openTeacherWorkspace(miniProgram, page, '待办')
  const overviewForSupport = await findComponentRoot(page, '.overview')
  const supportRows = await within(overviewForSupport.$$('.priority-row'), 'support-rows')
  let supportRow = null
  for (const row of supportRows) {
    const titleNode = await within(row.$('.row-title', { fallback: false }), 'support-row-title')
    if (titleNode && (await within(titleNode.text(), 'support-title-text')).includes('人工支持')) {
      supportRow = row
      break
    }
  }
  assert.ok(supportRow, 'The PBL human-support row is not rendered.')
  await within(supportRow.tap(), 'tap:pbl-support')
  await wait(1800)
  page = await current(miniProgram, 'pages/teacher/index/index')
  await captureBackgroundScreenshot(resolve(output, '09-follow-ups-support-needed.png'))
  console.log('CAPTURED 09-follow-ups-support-needed.png')
  const followUpRow = await findVisibleDeep(page, '.follow-up-row')
  assert.ok(followUpRow, 'The support-needed follow-up row is not rendered.')
  await within(followUpRow.tap(), 'tap:follow-up-row')
  await wait(2000)
  page = await current(miniProgram, 'pages/teacher/pbl-follow-up-detail/pbl-follow-up-detail')
  await captureBackgroundScreenshot(resolve(output, '10-follow-up-detail.png'))
  console.log('CAPTURED 10-follow-up-detail.png')
  const editors = []
  for (const node of await findAllDeep(page, 'textarea')) {
    const size = await within(node.size(), 'support-textarea-size')
    if (size.width > 0 && size.height > 0) editors.push(node)
  }
  if (editors.length) {
    await within(editors[0].input('T29 阶段证据：建议结合首次判定失败目标安排线下补讲。'), 'support-input')
    await wait(400)
    let sendButton = null
    for (const button of await findAllDeep(page, 'button')) {
      if ((await within(button.text(), 'send-button-label')).includes('发送补充反馈')) {
        const size = await within(button.size(), 'send-button-size')
        if (size.width > 0 && size.height > 0) {
          sendButton = button
          break
        }
      }
    }
    if (sendButton) {
      await within(sendButton.tap(), 'tap:send-support-feedback')
      await wait(1800)
      await captureBackgroundScreenshot(resolve(output, '11-support-feedback-sent.png'))
      console.log('CAPTURED 11-support-feedback-sent.png')
    } else {
      console.log('NOTE the send control was not found; support feedback send recorded as Unverified')
    }
  } else {
    console.log('NOTE the support textarea was not found; support feedback send recorded as Unverified')
  }
  await within(miniProgram.navigateBack(), 'follow-up-back')
  await wait(1500)
  page = await current(miniProgram, 'pages/teacher/index/index')

  // ---- A. student QA-report submit loop ----------------------------------
  console.log('STEP A student draft report')
  page = await openTeacherWorkspace(miniProgram, page, '待办')
  const overviewForLogout = await findComponentRoot(page, '.overview')
  const logoutButton = await within(overviewForLogout.$('.logout', { fallback: false }), 'teacher-logout')
  assert.ok(logoutButton, 'The teacher logout control is not rendered.')
  await within(logoutButton.tap(), 'teacher-logout-tap')
  const login = await current(miniProgram, 'pages/login/login')
  const studentRole = await within(login.$('.role-button.student', { fallback: false }), 'student-role')
  assert.ok(studentRole, 'The student role button is not rendered.')
  await within(studentRole.tap(), 'student-role-tap')
  page = await within(miniProgram.currentPage(), 'page:any-student')
  for (let attempt = 0; attempt < 30 && page.path === 'pages/login/login'; attempt += 1) {
    await wait(500)
    page = await within(miniProgram.currentPage(), 'page:any-student')
  }
  assert.ok(page.path.startsWith('pages/student/'), `Unexpected student landing page ${page.path}.`)
  if (page.path !== 'pages/student/pbl/pbl') {
    const navRoot = await findComponentRoot(page, '.student-nav')
    const navItems = await within(navRoot.$$('.student-nav__item'), 'student-nav-items:pbl')
    const navLabels = []
    for (const item of navItems) navLabels.push(await within(item.text(), 'student-nav-label:pbl'))
    const pblIdx = navLabels.findIndex((label) => label.trim() === '研讨')
    await within(navItems[pblIdx].tap(), 'student-tap:研讨')
    await wait(1500)
    page = await current(miniProgram, 'pages/student/pbl/pbl')
  }
  const accountBar = await within(page.$('.account-bar', { fallback: false }), 'student-account-bar')
  const accountButtons = await within(accountBar.$$('button'), 'account-buttons:history')
  let historyButton = null
  for (const button of accountButtons) {
    if ((await within(button.text(), 'account-button-label')).trim() === '历史答疑') {
      historyButton = button
      break
    }
  }
  assert.ok(historyButton, 'The history entry is not rendered.')
  await within(historyButton.tap(), 'tap:历史答疑')
  await wait(1600)
  page = await current(miniProgram, 'pages/student/history/history')
  await captureBackgroundScreenshot(resolve(output, '12-student-history.png'))
  console.log('CAPTURED 12-student-history.png')
  const draftTags = await within(page.$$('.tag', { fallback: false }), 'history-tags')
  let openedDraft = false
  for (const tag of draftTags) {
    const label = await within(tag.text(), 'history-tag-label')
    if (label.includes('查看报告')) {
      await within(tag.tap(), 'tap:查看报告')
      await wait(2000)
      openedDraft = true
      break
    }
  }
  assert.ok(openedDraft, 'No report entry rendered in history.')
  page = await current(miniProgram, 'pages/report/report')
  await captureBackgroundScreenshot(resolve(output, '13-student-draft-report.png'))
  console.log('CAPTURED 13-student-draft-report.png')

  // The report page template renders at page level (no component host), so
  // its elements are queried directly on the page.
  const submitModule = await within(page.$('.submit-module', { fallback: false }), 'submit-module')
  assert.ok(submitModule, 'The submit module is not rendered for a draft report.')
  const pickerValue = await within(page.$('.picker-value', { fallback: false }), 'picker-value')
  assert.ok(pickerValue, 'The class picker is not rendered.')
  const pickerText = await within(pickerValue.text(), 'picker-value-text')
  assert.ok(pickerText.includes('病理学演示班'), `The single demo class should be preselected, got: ${pickerText}`)

  console.log('STEP A confirm modal cancel then confirm')
  const submitButton = await within(page.$('.submit-button', { fallback: false }), 'submit-button')
  assert.ok(submitButton, 'The submit button is not rendered.')
  await within(submitButton.tap(), 'tap:submit')
  await wait(1500)
  await captureBackgroundScreenshot(resolve(output, '14-submit-confirm-modal.png'))
  console.log('CAPTURED 14-submit-confirm-modal.png')
  // The simulator renders wx.showModal inside the page DOM; cancel first.
  let modalButtons = await page.$$('.weui-dialog__btn')
  if (!modalButtons.length) modalButtons = await page.$$('.uni-modal__btn')
  if (modalButtons.length >= 2) {
    await within(modalButtons[0].tap(), 'tap:modal-cancel')
    await wait(1200)
    await captureBackgroundScreenshot(resolve(output, '15-after-cancel.png'))
    console.log('CAPTURED 15-after-cancel.png')
    const stillDraft = await within(page.$('.submit-button', { fallback: false }), 'submit-button-after-cancel')
    assert.ok(stillDraft, 'Cancelling must keep the draft submit module.')
    await within(stillDraft.tap(), 'tap:submit-again')
    await wait(1500)
    let confirmButtons = await page.$$('.weui-dialog__btn')
    if (!confirmButtons.length) confirmButtons = await page.$$('.uni-modal__btn')
    assert.ok(confirmButtons.length >= 2, 'The confirm modal did not render again.')
    await within(confirmButtons[confirmButtons.length - 1].tap(), 'tap:modal-confirm')
    await wait(2500)
    await captureBackgroundScreenshot(resolve(output, '16-after-confirm.png'))
    console.log('CAPTURED 16-after-confirm.png')
  } else {
    console.log('NOTE modal buttons are not reachable through the page tree; confirm flow recorded as Unverified')
  }

  console.log(JSON.stringify({ output, status: 'ok' }))
} finally {
  miniProgram?.disconnect()
}
