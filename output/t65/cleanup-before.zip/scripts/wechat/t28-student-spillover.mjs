import assert from 'node:assert/strict'
import { mkdirSync, writeFileSync } from 'node:fs'
import { resolve } from 'node:path'
import { fileURLToPath } from 'node:url'
import { Launcher } from '@weapp-vite/miniprogram-automator'
import { diagnose } from './doctor.mjs'

// T28 stage-6 spillover check: T28 changed teacher components only and added
// no global tokens, but this walks one student primary page with real taps to
// evidence that the student look is untouched. Internal screenshots only.
// Run: node scripts/wechat/t28-student-spillover.mjs
await diagnose({ probe: false })

const port = Number(process.env.WECHAT_AUTO_PORT || 9421)
const root = fileURLToPath(new URL('../../', import.meta.url))
const output = resolve(root, 'output/wechat', `t28-student-spillover-${Date.now()}`)
const timeoutMs = 10000
const within = (promise, label) =>
  Promise.race([
    promise,
    new Promise((_, reject) => setTimeout(() => reject(new Error(`timeout:${label}`)), timeoutMs)),
  ])
const wait = (milliseconds) => new Promise((resolveWait) => setTimeout(resolveWait, milliseconds))

async function current(miniProgram, expectedPath) {
  let lastPath = ''
  for (let attempt = 0; attempt < 48; attempt += 1) {
    const page = await within(miniProgram.currentPage(), `page:${expectedPath}`)
    lastPath = page.path
    if (page.path === expectedPath) return page
    await wait(300)
  }
  throw new Error(`route:${expectedPath} (stuck at ${lastPath})`)
}

async function findComponentRoot(page, selector) {
  const componentHosts = [
    ...(await within(page.$$('component', { fallback: false, timeout: timeoutMs }), `component-hosts:${selector}`)),
  ]
  const seen = new Set()
  while (componentHosts.length) {
    const host = componentHosts.shift()
    if (!host || seen.has(host)) continue
    seen.add(host)
    const rootElement = await within(host.$(selector), `component-root:${selector}`)
    if (rootElement) return rootElement
    componentHosts.push(...(await within(host.$$('component'), `nested-component-hosts:${selector}`)))
  }
  return null
}

async function captureBackgroundScreenshot(path) {
  let lastError
  for (let attempt = 0; attempt < 3; attempt += 1) {
    const socket = new WebSocket(`ws://127.0.0.1:${port}`)
    try {
      const data = await new Promise((resolveCapture, rejectCapture) => {
        const timer = setTimeout(() => rejectCapture(new Error('timeout:capture-screenshot')), 30000)
        const finish = (value) => {
          clearTimeout(timer)
          if (value instanceof Error) rejectCapture(value)
          else resolveCapture(value)
        }
        socket.onerror = () => finish(new Error('capture-screenshot-unavailable'))
        socket.onopen = () =>
          socket.send(JSON.stringify({ id: 'capture', method: 'App.captureScreenshot', params: {} }))
        socket.onmessage = ({ data: payload }) => {
          try {
            const response = JSON.parse(String(payload))
            if (response.id !== 'capture') return
            if (typeof response.result?.data !== 'string') return finish(new Error('capture-screenshot-missing-data'))
            finish(response.result.data)
          } catch {
            finish(new Error('capture-screenshot-invalid-response'))
          }
        }
      })
      writeFileSync(path, data, 'base64')
      return
    } catch (error) {
      lastError = error
      await wait(750)
    } finally {
      socket.close()
    }
  }
  throw lastError
}

let miniProgram
try {
  console.log('STEP connect')
  miniProgram = await within(new Launcher().connect({ wsEndpoint: `ws://127.0.0.1:${port}` }), 'connect')
  let page = await within(miniProgram.currentPage(), 'page:any')
  mkdirSync(output, { recursive: true })

  // Native detail routes can be left over from an earlier run; walk back
  // through the real page stack first.
  for (let attempt = 0; attempt < 6; attempt += 1) {
    if (
      ![
        'pages/teacher/pbl-follow-up-detail/pbl-follow-up-detail',
        'pages/teacher/pbl-diagnostic-detail/pbl-diagnostic-detail',
      ].includes(page.path)
    )
      break
    await within(miniProgram.navigateBack(), 'detail-leftover-back')
    await wait(1200)
    page = await within(miniProgram.currentPage(), 'page:any-after-back')
  }

  // Leave the teacher workspace through the real logout control. The logout
  // control only renders inside the 待办 workspace, so switch there first.
  if (page.path === 'pages/teacher/index/index') {
    const teacherNav = await findComponentRoot(page, '.teacher-nav')
    assert.ok(teacherNav, 'The teacher primary navigation is not rendered.')
    const teacherNavItems = await within(teacherNav.$$('.teacher-nav__item'), 'teacher-nav-items:logout')
    const teacherNavLabels = []
    for (const item of teacherNavItems) teacherNavLabels.push(await within(item.text(), 'teacher-nav-label:logout'))
    const todoIndex = teacherNavLabels.findIndex((label) => label.trim() === '待办')
    assert.ok(todoIndex >= 0, 'The overview workspace label is not rendered.')
    await within(teacherNavItems[todoIndex].tap(), 'tap:待办-before-logout')
    await wait(1200)
    page = await current(miniProgram, 'pages/teacher/index/index')
    const logout = await within(page.$('.logout', { fallback: false }), 'teacher-logout')
    assert.ok(logout, 'The teacher logout control is not rendered.')
    await within(logout.tap(), 'teacher-logout-tap')
    page = await current(miniProgram, 'pages/login/login')
  }
  if (!page.path.startsWith('pages/student/')) {
    assert.equal(page.path, 'pages/login/login', `Unexpected page ${page.path}.`)
    const studentRole = await within(page.$('.role-button.student', { fallback: false }), 'student-role')
    assert.ok(studentRole, 'The student role button is not rendered.')
    await within(studentRole.tap(), 'student-role-tap')
    await wait(2000)
    page = await within(miniProgram.currentPage(), 'page:any-student')
  }
  assert.ok(
    ['pages/student/pbl/pbl', 'pages/student/insights/index'].includes(page.path),
    `Unexpected student landing page ${page.path}.`,
  )

  // Walk both student primary pages with real taps; the spillover check only
  // needs one token-heavy page, but two make the evidence stronger.
  async function openStudentTab(label, expectedPath, file) {
    const navRoot = await findComponentRoot(page, '.student-nav')
    assert.ok(navRoot, `The student primary navigation is not rendered on ${page.path}.`)
    const navItems = await within(navRoot.$$('.student-nav__item'), `student-nav-items:${label}`)
    const navLabels = []
    for (const item of navItems) navLabels.push(await within(item.text(), `student-nav-label:${label}`))
    const index = navLabels.findIndex((text) => text.trim() === label)
    assert.ok(index >= 0, `The student tab ${label} is not rendered.`)
    await within(navItems[index].tap(), `student-tap:${label}`)
    await wait(1600)
    page = await current(miniProgram, expectedPath)
    await captureBackgroundScreenshot(resolve(output, file))
    console.log(`CAPTURED ${file}`)
  }

  if (page.path === 'pages/student/pbl/pbl') {
    await captureBackgroundScreenshot(resolve(output, '01-student-pbl.png'))
    console.log('CAPTURED 01-student-pbl.png')
    await openStudentTab('学情', 'pages/student/insights/index', '02-student-insights.png')
  } else {
    await captureBackgroundScreenshot(resolve(output, '02-student-insights.png'))
    console.log('CAPTURED 02-student-insights.png')
    await openStudentTab('研讨', 'pages/student/pbl/pbl', '01-student-pbl.png')
  }

  console.log(JSON.stringify({ output, status: 'ok' }))
} finally {
  miniProgram?.disconnect()
}
