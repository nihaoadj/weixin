import assert from 'node:assert/strict'
import { mkdirSync, writeFileSync } from 'node:fs'
import { resolve } from 'node:path'
import { fileURLToPath } from 'node:url'
import { Launcher } from '@weapp-vite/miniprogram-automator'
import { diagnose } from './doctor.mjs'

// T28 stage-0 baseline: documents the CURRENT rendering of the teacher
// overview and the two PBL detail pages before any T28 visual change.
// All movement uses rendered controls (taps) or platform-level page
// navigation; it never sets data or calls business methods. Screenshots use
// the Developer Tools internal capture channel only. Run:
//   node scripts/wechat/t28-baseline.mjs
await diagnose({ probe: false })

const port = Number(process.env.WECHAT_AUTO_PORT || 9420)
const root = fileURLToPath(new URL('../../', import.meta.url))
const output = resolve(root, 'output/wechat', `t28-baseline-${Date.now()}`)
const timeoutMs = 10000
const within = (promise, label) =>
  Promise.race([
    promise,
    new Promise((_, reject) => setTimeout(() => reject(new Error(`timeout:${label}`)), timeoutMs)),
  ])
const wait = (milliseconds) => new Promise((resolveWait) => setTimeout(resolveWait, milliseconds))

async function current(miniProgram, expectedPath) {
  let lastPath = ''
  for (let attempt = 0; attempt < 48; attempt += 1) {
    const page = await within(miniProgram.currentPage(), `page:${expectedPath}`)
    lastPath = page.path
    if (page.path === expectedPath) return page
    await wait(300)
  }
  throw new Error(`route:${expectedPath} (stuck at ${lastPath})`)
}

async function findComponentRoot(page, selector) {
  const componentHosts = [
    ...(await within(page.$$('component', { fallback: false, timeout: timeoutMs }), `component-hosts:${selector}`)),
  ]
  const seen = new Set()
  while (componentHosts.length) {
    const host = componentHosts.shift()
    if (!host || seen.has(host)) continue
    seen.add(host)
    const rootElement = await within(host.$(selector), `component-root:${selector}`)
    if (rootElement) return rootElement
    componentHosts.push(...(await within(host.$$('component'), `nested-component-hosts:${selector}`)))
  }
  return null
}

async function captureBackgroundScreenshot(path) {
  let lastError
  for (let attempt = 0; attempt < 3; attempt += 1) {
    const socket = new WebSocket(`ws://127.0.0.1:${port}`)
    try {
      const data = await new Promise((resolveCapture, rejectCapture) => {
        const timer = setTimeout(() => rejectCapture(new Error('timeout:capture-screenshot')), 30000)
        const finish = (value) => {
          clearTimeout(timer)
          if (value instanceof Error) rejectCapture(value)
          else resolveCapture(value)
        }
        socket.onerror = () => finish(new Error('capture-screenshot-unavailable'))
        socket.onopen = () =>
          socket.send(JSON.stringify({ id: 'capture', method: 'App.captureScreenshot', params: {} }))
        socket.onmessage = ({ data: payload }) => {
          try {
            const response = JSON.parse(String(payload))
            if (response.id !== 'capture') return
            if (typeof response.result?.data !== 'string') return finish(new Error('capture-screenshot-missing-data'))
            finish(response.result.data)
          } catch {
            finish(new Error('capture-screenshot-invalid-response'))
          }
        }
      })
      writeFileSync(path, data, 'base64')
      return
    } catch (error) {
      lastError = error
      await wait(750)
    } finally {
      socket.close()
    }
  }
  throw lastError
}

async function ensureTeacher(miniProgram) {
  let page = await within(miniProgram.currentPage(), 'page:any')
  if (page.path === 'pages/teacher/index/index') return page
  if (page.path === 'pages/login/login') {
    const teacherRole = await within(page.$('.role-button.teacher', { fallback: false }), 'teacher-role')
    assert.ok(teacherRole, 'The teacher role button is not rendered.')
    await within(teacherRole.tap(), 'teacher-role-tap')
    return current(miniProgram, 'pages/teacher/index/index')
  }
  const navRoot = await findComponentRoot(page, '.student-nav')
  assert.ok(navRoot, `No teacher, login or student navigation found on ${page.path}.`)
  const navItems = await within(navRoot.$$('.student-nav__item'), 'student-nav-items:any')
  const navLabels = []
  for (const item of navItems) navLabels.push(await within(item.text(), 'student-nav-label:any'))
  const pblIndex = navLabels.findIndex((label) => label.trim() === '研讨')
  assert.ok(pblIndex >= 0, `The 研讨 tab is not rendered on ${page.path}.`)
  await within(navItems[pblIndex].tap(), 'student-tap:研讨')
  const pblPage = await current(miniProgram, 'pages/student/pbl/pbl')
  const accountBar = await within(pblPage.$('.account-bar', { fallback: false }), 'account-bar')
  assert.ok(accountBar, 'The student account bar is not rendered.')
  const accountButtons = await within(accountBar.$$('button'), 'account-bar-buttons')
  let tapped = false
  for (const button of accountButtons) {
    if ((await within(button.text(), 'account-button-label')).trim() === '退出') {
      await within(button.tap(), 'student-logout-tap')
      tapped = true
      break
    }
  }
  assert.ok(tapped, 'The student logout control is not rendered.')
  const login = await current(miniProgram, 'pages/login/login')
  const teacherRole = await within(login.$('.role-button.teacher', { fallback: false }), 'teacher-role')
  assert.ok(teacherRole, 'The teacher role button is not rendered.')
  await within(teacherRole.tap(), 'teacher-role-tap')
  return current(miniProgram, 'pages/teacher/index/index')
}

async function openWorkspace(page, label) {
  const nav = await findComponentRoot(page, '.teacher-nav')
  assert.ok(nav, 'The teacher primary navigation is not rendered.')
  const items = await within(nav.$$('.teacher-nav__item'), `teacher-nav-items:${label}`)
  const labels = []
  for (const item of items) labels.push(await within(item.text(), 'teacher-nav-label'))
  const index = labels.findIndex((text) => text.trim() === label)
  assert.ok(index >= 0, `Workspace label ${label} is not rendered.`)
  await within(items[index].tap(), `tap:${label}`)
  await wait(1600)
  return current(miniProgram, 'pages/teacher/index/index')
}

let miniProgram
try {
  console.log('STEP connect')
  miniProgram = await within(new Launcher().connect({ wsEndpoint: `ws://127.0.0.1:${port}` }), 'connect')
  let page = await ensureTeacher(miniProgram)
  mkdirSync(output, { recursive: true })

  // A. Today overview — top and bottom (account area).
  console.log('STEP overview')
  page = await openWorkspace(page, '待办')
  await within(miniProgram.pageScrollTo(0), 'overview-scroll-top')
  await wait(700)
  await captureBackgroundScreenshot(resolve(output, '01-overview-top.png'))
  console.log('CAPTURED 01-overview-top.png')
  await within(miniProgram.pageScrollTo(100000), 'overview-scroll-bottom')
  await wait(900)
  await captureBackgroundScreenshot(resolve(output, '02-overview-bottom.png'))
  console.log('CAPTURED 02-overview-bottom.png')

  // B. Follow-up detail — entered by a real tap from 学情 → PBL 跟进.
  console.log('STEP follow-up-entry')
  page = await openWorkspace(page, '学情')
  const insights = await findComponentRoot(page, '.teacher-insights-workspace')
  assert.ok(insights, 'The teacher insights workspace did not open.')
  const insightComponents = await within(insights.$$('component'), 'insight-components')
  let insightNav = null
  for (const component of insightComponents) {
    const candidate = await within(component.$('.record-index'), 'insight-navigation')
    if (candidate) {
      insightNav = candidate
      break
    }
  }
  assert.ok(insightNav, 'The teacher insights navigation is not rendered.')
  const sectionItems = await within(insightNav.$$('.record-index__item'), 'insight-section-items')
  const sectionLabels = []
  for (const item of sectionItems) sectionLabels.push(await within(item.text(), 'insight-section-label'))
  const followUpsIndex = sectionLabels.findIndex((label) => label.includes('PBL 跟进'))
  assert.ok(followUpsIndex >= 0, 'The PBL follow-up section is not rendered.')
  await within(sectionItems[followUpsIndex].tap(), 'pbl-follow-up-tap')
  await wait(800)
  const followUps = await findComponentRoot(insights, '.follow-ups')
  assert.ok(followUps, 'The PBL follow-up workspace is not rendered.')
  const followUpList = await findComponentRoot(followUps, '.follow-up-list')
  assert.ok(followUpList, 'The PBL follow-up list is not rendered.')
  const followUpRow = await within(followUpList.$('.follow-up-row'), 'pbl-follow-up-row')
  assert.ok(followUpRow, 'The seeded PBL follow-up row is not rendered.')
  await within(miniProgram.pageScrollTo(0), 'pre-entry-scroll-top')
  await wait(400)
  await within(followUpRow.tap(), 'pbl-follow-up-row-tap')
  await wait(1800)
  page = await current(miniProgram, 'pages/teacher/pbl-follow-up-detail/pbl-follow-up-detail')
  console.log('STEP follow-up-detail')
  const followUpDetail = await findComponentRoot(page, '.detail')
  assert.ok(followUpDetail, 'The follow-up detail is not rendered after the list tap.')
  await within(miniProgram.pageScrollTo(0), 'follow-up-scroll-top')
  await wait(700)
  await captureBackgroundScreenshot(resolve(output, '03-follow-up-top.png'))
  console.log('CAPTURED 03-follow-up-top.png')
  await within(miniProgram.pageScrollTo(100000), 'follow-up-scroll-bottom')
  await wait(1000)
  await captureBackgroundScreenshot(resolve(output, '04-follow-up-bottom.png'))
  console.log('CAPTURED 04-follow-up-bottom.png')

  // Native back to the source workspace before entering the next detail.
  await within(miniProgram.navigateBack(), 'follow-up-native-back')
  await wait(1400)
  page = await current(miniProgram, 'pages/teacher/index/index')

  // C. Diagnostic detail — entered by a real tap from 内容 → 诊断建议.
  console.log('STEP diagnostic-entry')
  page = await openWorkspace(page, '内容')
  const content = await findComponentRoot(page, '.teacher-content-workspace')
  assert.ok(content, 'The teacher content workspace did not open.')
  const contentSections = await findComponentRoot(content, '.record-index')
  assert.ok(contentSections, 'The teaching-content subsection navigation is not rendered.')
  const contentSectionItems = await within(contentSections.$$('.record-index__item'), 'content-section-items')
  const contentSectionLabels = []
  for (const item of contentSectionItems) contentSectionLabels.push(await within(item.text(), 'content-section-label'))
  const diagnosticsIndex = contentSectionLabels.findIndex((label) => label.includes('诊断建议'))
  assert.ok(diagnosticsIndex >= 0, 'The diagnostic-suggestions section is not rendered.')
  await within(contentSectionItems[diagnosticsIndex].tap(), 'diagnostic-suggestions-tap')
  await wait(800)
  const workItems = await findComponentRoot(page, '.work-items')
  assert.ok(workItems, 'The teacher diagnostic work-items are not rendered.')
  const workItemList = await findComponentRoot(workItems, '.work-item-list')
  assert.ok(workItemList, 'The teacher diagnostic list is not rendered.')
  const diagnosticRow = await within(workItemList.$('.row'), 'diagnostic-row')
  assert.ok(diagnosticRow, 'The seeded diagnostic row is not rendered.')
  await within(miniProgram.pageScrollTo(0), 'pre-diagnostic-scroll-top')
  await wait(400)
  await within(diagnosticRow.tap(), 'diagnostic-row-tap')
  await wait(1800)
  page = await current(miniProgram, 'pages/teacher/pbl-diagnostic-detail/pbl-diagnostic-detail')
  console.log('STEP diagnostic-detail')
  const diagnosticDetail = await findComponentRoot(page, '.detail')
  assert.ok(diagnosticDetail, 'The diagnostic detail is not rendered after the list tap.')
  await within(miniProgram.pageScrollTo(0), 'diagnostic-scroll-top')
  await wait(700)
  await captureBackgroundScreenshot(resolve(output, '05-diagnostic-top.png'))
  console.log('CAPTURED 05-diagnostic-top.png')
  await within(miniProgram.pageScrollTo(100000), 'diagnostic-scroll-bottom')
  await wait(1000)
  await captureBackgroundScreenshot(resolve(output, '06-diagnostic-bottom.png'))
  console.log('CAPTURED 06-diagnostic-bottom.png')

  // D. Invalid deep link — documents the recoverable error state without
  // touching page data; the route itself rejects the missing id.
  console.log('STEP invalid-follow-up')
  await within(
    miniProgram.navigateTo({ url: '/pages/teacher/pbl-follow-up-detail/pbl-follow-up-detail?planId=0' }),
    'invalid-follow-up-navigate',
  )
  await wait(1500)
  page = await current(miniProgram, 'pages/teacher/pbl-follow-up-detail/pbl-follow-up-detail')
  await captureBackgroundScreenshot(resolve(output, '07-follow-up-invalid.png'))
  console.log('CAPTURED 07-follow-up-invalid.png')
  await within(miniProgram.navigateBack(), 'invalid-follow-up-back')
  await wait(1200)
  page = await current(miniProgram, 'pages/teacher/pbl-diagnostic-detail/pbl-diagnostic-detail')

  console.log(JSON.stringify({ output, status: 'ok' }))
} finally {
  miniProgram?.disconnect()
}
