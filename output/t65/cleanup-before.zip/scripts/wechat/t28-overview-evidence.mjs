import assert from 'node:assert/strict'
import { mkdirSync, writeFileSync } from 'node:fs'
import { resolve } from 'node:path'
import { fileURLToPath } from 'node:url'
import { Launcher } from '@weapp-vite/miniprogram-automator'
import { diagnose } from './doctor.mjs'

// T28 stage-3 evidence for the reworked teacher overview: real taps on the
// rendered rows and primary navigation, Developer Tools internal screenshots,
// no data mutation, no business-method calls, no OS input. Run:
//   node scripts/wechat/t28-overview-evidence.mjs
await diagnose({ probe: false })

const port = Number(process.env.WECHAT_AUTO_PORT || 9421)
const root = fileURLToPath(new URL('../../', import.meta.url))
const output = resolve(root, 'output/wechat', `t28-overview-${Date.now()}`)
const timeoutMs = 10000
const within = (promise, label) =>
  Promise.race([
    promise,
    new Promise((_, reject) => setTimeout(() => reject(new Error(`timeout:${label}`)), timeoutMs)),
  ])
const wait = (milliseconds) => new Promise((resolveWait) => setTimeout(resolveWait, milliseconds))

async function current(miniProgram, expectedPath) {
  let lastPath = ''
  for (let attempt = 0; attempt < 48; attempt += 1) {
    const page = await within(miniProgram.currentPage(), `page:${expectedPath}`)
    lastPath = page.path
    if (page.path === expectedPath) return page
    await wait(300)
  }
  throw new Error(`route:${expectedPath} (stuck at ${lastPath})`)
}

async function findComponentRoot(page, selector) {
  const componentHosts = [
    ...(await within(page.$$('component', { fallback: false, timeout: timeoutMs }), `component-hosts:${selector}`)),
  ]
  const seen = new Set()
  while (componentHosts.length) {
    const host = componentHosts.shift()
    if (!host || seen.has(host)) continue
    seen.add(host)
    const rootElement = await within(host.$(selector), `component-root:${selector}`)
    if (rootElement) return rootElement
    componentHosts.push(...(await within(host.$$('component'), `nested-component-hosts:${selector}`)))
  }
  return null
}

async function captureBackgroundScreenshot(path) {
  let lastError
  for (let attempt = 0; attempt < 3; attempt += 1) {
    const socket = new WebSocket(`ws://127.0.0.1:${port}`)
    try {
      const data = await new Promise((resolveCapture, rejectCapture) => {
        const timer = setTimeout(() => rejectCapture(new Error('timeout:capture-screenshot')), 30000)
        const finish = (value) => {
          clearTimeout(timer)
          if (value instanceof Error) rejectCapture(value)
          else resolveCapture(value)
        }
        socket.onerror = () => finish(new Error('capture-screenshot-unavailable'))
        socket.onopen = () =>
          socket.send(JSON.stringify({ id: 'capture', method: 'App.captureScreenshot', params: {} }))
        socket.onmessage = ({ data: payload }) => {
          try {
            const response = JSON.parse(String(payload))
            if (response.id !== 'capture') return
            if (typeof response.result?.data !== 'string') return finish(new Error('capture-screenshot-missing-data'))
            finish(response.result.data)
          } catch {
            finish(new Error('capture-screenshot-invalid-response'))
          }
        }
      })
      writeFileSync(path, data, 'base64')
      return
    } catch (error) {
      lastError = error
      await wait(750)
    } finally {
      socket.close()
    }
  }
  throw lastError
}

async function ensureTeacher(miniProgram) {
  let page = await within(miniProgram.currentPage(), 'page:any')
  if (page.path === 'pages/teacher/index/index') return page
  if (page.path === 'pages/login/login') {
    const teacherRole = await within(page.$('.role-button.teacher', { fallback: false }), 'teacher-role')
    assert.ok(teacherRole, 'The teacher role button is not rendered.')
    await within(teacherRole.tap(), 'teacher-role-tap')
    return current(miniProgram, 'pages/teacher/index/index')
  }
  const navRoot = await findComponentRoot(page, '.student-nav')
  assert.ok(navRoot, `No teacher, login or student navigation found on ${page.path}.`)
  const navItems = await within(navRoot.$$('.student-nav__item'), 'student-nav-items:any')
  const navLabels = []
  for (const item of navItems) navLabels.push(await within(item.text(), 'student-nav-label:any'))
  const pblIndex = navLabels.findIndex((label) => label.trim() === '研讨')
  assert.ok(pblIndex >= 0, `The 研讨 tab is not rendered on ${page.path}.`)
  await within(navItems[pblIndex].tap(), 'student-tap:研讨')
  const pblPage = await current(miniProgram, 'pages/student/pbl/pbl')
  const accountBar = await within(pblPage.$('.account-bar', { fallback: false }), 'account-bar')
  assert.ok(accountBar, 'The student account bar is not rendered.')
  const accountButtons = await within(accountBar.$$('button'), 'account-bar-buttons')
  let tapped = false
  for (const button of accountButtons) {
    if ((await within(button.text(), 'account-button-label')).trim() === '退出') {
      await within(button.tap(), 'student-logout-tap')
      tapped = true
      break
    }
  }
  assert.ok(tapped, 'The student logout control is not rendered.')
  const login = await current(miniProgram, 'pages/login/login')
  const teacherRole = await within(login.$('.role-button.teacher', { fallback: false }), 'teacher-role')
  assert.ok(teacherRole, 'The teacher role button is not rendered.')
  await within(teacherRole.tap(), 'teacher-role-tap')
  return current(miniProgram, 'pages/teacher/index/index')
}

async function openWorkspace(miniProgram, page, label) {
  const nav = await findComponentRoot(page, '.teacher-nav')
  assert.ok(nav, 'The teacher primary navigation is not rendered.')
  const items = await within(nav.$$('.teacher-nav__item'), `teacher-nav-items:${label}`)
  const labels = []
  for (const item of items) labels.push(await within(item.text(), 'teacher-nav-label'))
  const index = labels.findIndex((text) => text.trim() === label)
  assert.ok(index >= 0, `Workspace label ${label} is not rendered.`)
  await within(items[index].tap(), `tap:${label}`)
  await wait(1400)
  return current(miniProgram, 'pages/teacher/index/index')
}

async function findAllDeep(page, selector) {
  const matches = []
  const seen = new Set()
  const queue = [
    ...(await within(page.$$('component', { fallback: false, timeout: timeoutMs }), `component-hosts:${selector}`)),
  ]
  while (queue.length) {
    const host = queue.shift()
    if (!host || seen.has(host)) continue
    seen.add(host)
    for (const element of await within(host.$$(selector), `component-hit:${selector}`)) matches.push(element)
    queue.push(...(await within(host.$$('component'), `nested-hosts:${selector}`)))
  }
  return matches
}

async function findVisibleDeep(page, selector) {
  // v-show keeps hidden workspaces in the tree with zero size; only a
  // non-zero box proves the element the user can see and tap.
  for (const element of await findAllDeep(page, selector)) {
    const size = await within(element.size(), `visible-size:${selector}`)
    if (size.width > 0 && size.height > 0) return element
  }
  return null
}

let miniProgram
try {
  console.log('STEP connect')
  miniProgram = await within(new Launcher().connect({ wsEndpoint: `ws://127.0.0.1:${port}` }), 'connect')
  let page = await ensureTeacher(miniProgram)
  mkdirSync(output, { recursive: true })

  page = await openWorkspace(miniProgram, page, '待办')
  const overview = await findComponentRoot(page, '.overview')
  assert.ok(overview, 'The teacher overview is not rendered.')
  const focusModule = await findVisibleDeep(page, '.tms--focus')
  assert.ok(focusModule, 'The focus module surface is not rendered.')
  const focusSize = await within(focusModule.size(), 'focus-module-size')
  assert.ok(Number(focusSize.width) > 0 && Number(focusSize.height) > 0, 'The focus module has no rendered size.')
  const allModules = await findAllDeep(page, '.tms')
  let visibleModules = 0
  for (const module of allModules) {
    const size = await within(module.size(), 'module-size')
    if (Number(size.width) > 0 && Number(size.height) > 0) visibleModules += 1
  }
  assert.equal(visibleModules, 2, 'The overview must render exactly two module surfaces.')
  console.log('STEP screenshot-overview')
  await captureBackgroundScreenshot(resolve(output, '01-overview.png'))
  console.log('CAPTURED 01-overview.png')

  const rows = await within(overview.$$('.priority-row'), 'overview-priority-rows')
  assert.ok(rows.length >= 2, 'The overview priority rows are not rendered.')
  console.log('STEP tap-reports-row')
  await within(rows[0].tap(), 'tap:student-reports')
  await wait(1600)
  page = await current(miniProgram, 'pages/teacher/index/index')
  await captureBackgroundScreenshot(resolve(output, '02-reports-destination.png'))
  console.log('CAPTURED 02-reports-destination.png')
  page = await openWorkspace(miniProgram, page, '待办')

  const overview2 = await findComponentRoot(page, '.overview')
  const rows2 = await within(overview2.$$('.priority-row'), 'overview-priority-rows-2')
  console.log('STEP tap-pbl-row')
  await within(rows2[1].tap(), 'tap:pbl-pending')
  await wait(1600)
  page = await current(miniProgram, 'pages/teacher/index/index')
  await captureBackgroundScreenshot(resolve(output, '03-pbl-destination.png'))
  console.log('CAPTURED 03-pbl-destination.png')
  page = await openWorkspace(miniProgram, page, '待办')

  console.log('STEP tap-classes')
  const overview3 = await findComponentRoot(page, '.overview')
  const managementRows = await within(overview3.$$('.management-row'), 'overview-management-rows')
  assert.ok(managementRows.length >= 3, 'The management rows are not rendered.')
  await within(managementRows[0].tap(), 'tap:classes')
  await wait(1800)
  page = await current(miniProgram, 'pages/teacher/classes/classes')
  await captureBackgroundScreenshot(resolve(output, '04-classes.png'))
  console.log('CAPTURED 04-classes.png')
  await within(miniProgram.navigateBack(), 'classes-native-back')
  await wait(1400)
  page = await current(miniProgram, 'pages/teacher/index/index')

  console.log('STEP tap-analytics')
  const overview4 = await findComponentRoot(page, '.overview')
  const managementRows2 = await within(overview4.$$('.management-row'), 'overview-management-rows-2')
  await within(managementRows2[1].tap(), 'tap:analytics')
  await wait(1600)
  page = await current(miniProgram, 'pages/teacher/index/index')
  await captureBackgroundScreenshot(resolve(output, '05-analytics-destination.png'))
  console.log('CAPTURED 05-analytics-destination.png')
  page = await openWorkspace(miniProgram, page, '待办')

  console.log('STEP tap-knowledge-cards')
  const overview5 = await findComponentRoot(page, '.overview')
  const managementRows3 = await within(overview5.$$('.management-row'), 'overview-management-rows-3')
  await within(managementRows3[2].tap(), 'tap:knowledge-cards')
  await wait(1800)
  page = await current(miniProgram, 'pages/teacher/knowledge-cards/knowledge-cards')
  await captureBackgroundScreenshot(resolve(output, '06-knowledge-cards.png'))
  console.log('CAPTURED 06-knowledge-cards.png')
  await within(miniProgram.navigateBack(), 'knowledge-cards-native-back')
  await wait(1400)
  page = await current(miniProgram, 'pages/teacher/index/index')
  await openWorkspace(miniProgram, page, '待办')
  await captureBackgroundScreenshot(resolve(output, '07-overview-final.png'))
  console.log('CAPTURED 07-overview-final.png')

  console.log(JSON.stringify({ output, status: 'ok' }))
} finally {
  miniProgram?.disconnect()
}
